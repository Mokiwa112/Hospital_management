<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hospital_management');

// Application configuration
define('SITE_NAME', 'Hospital Management System');
define('SITE_URL', 'http://localhost/HealthInfo');
define('UPLOAD_PATH', __DIR__ . '/uploads/');

// Debug mode - set to false in production
define('DEBUG_MODE', true);

// Error reporting
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Security hardening for sessions and headers
if (!headers_sent()) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: frame-ancestors 'self'");
}

if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
} else {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_secure', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? '1' : '0');
}

ini_set('session.use_only_cookies', '1');
ini_set('session.use_strict_mode', '1');

// Start session only if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Basic CSRF hardening: reject cross-site POST if Origin/Referer is present and mismatched
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';

    $is_origin_ok = true;
    if (!empty($origin)) {
        $origin_host = parse_url($origin, PHP_URL_HOST);
        $is_origin_ok = ($origin_host === $host);
    } elseif (!empty($referer)) {
        $referer_host = parse_url($referer, PHP_URL_HOST);
        $is_origin_ok = ($referer_host === $host);
    }

    if (!$is_origin_ok) {
        http_response_code(403);
        die('Forbidden request origin');
    }
}

// Database connection with error handling
function getConnection() {
    static $conn = null;
    
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            error_log("Connection failed: " . mysqli_connect_error());
            if (DEBUG_MODE) {
                die("Database connection failed: " . mysqli_connect_error());
            } else {
                die("Database connection failed. Please try again later.");
            }
        }
        mysqli_set_charset($conn, "utf8mb4");
    }
    return $conn;
}

// Centralized user activity log helper (best-effort)
function app_log_action($user_id, $action, $details = '') {
    $conn = getConnection();
    $uid = (int)$user_id;
    $safe_action = sanitize($action);
    $safe_details = sanitize($details);
    $ip = sanitize($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    @mysqli_query($conn, "INSERT INTO user_logs (user_id, action, ip_address) VALUES ($uid, '$safe_action', '$ip')");
}

// Safe sanitization function
function sanitize($data) {
    if (empty($data)) return '';
    
    $conn = getConnection();
    if (is_array($data)) {
        return array_map(function($item) use ($conn) {
            return mysqli_real_escape_string($conn, trim($item));
        }, $data);
    }
    return mysqli_real_escape_string($conn, trim($data));
}

// Redirect function
function redirect($url) {
    header("Location: $url");
    exit();
}

// Check if staff is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if patient is logged in
function isPatientLoggedIn() {
    return isset($_SESSION['patient_id']);
}

// Get current user type
function getUserType() {
    return $_SESSION['user_type'] ?? '';
}

// Resolve role-based landing pages for staff users
function getRoleHomePage($role = null) {
    if ($role === null) {
        $role = getUserType();
    }

    switch ($role) {
        case 'admin':
            return 'dashboard.php';
        case 'doctor':
            return 'doctor_dashboard.php';
        case 'lab_tech':
            return 'labtech_dashboard.php';
        case 'pharmacist':
            return 'pharmacist_dashboard.php';
        case 'hr_admin':
            return 'hr_dashboard.php';
        default:
            return 'dashboard.php';
    }
}

// Check whether a table has a given column (cached per request)
function tableHasColumn($table, $column) {
    static $cache = [];
    $key = strtolower($table . '.' . $column);
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $conn = getConnection();
    $table_safe = mysqli_real_escape_string($conn, $table);
    $column_safe = mysqli_real_escape_string($conn, $column);
    $sql = "SELECT 1
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = '$table_safe'
              AND COLUMN_NAME = '$column_safe'
            LIMIT 1";
    $res = mysqli_query($conn, $sql);
    $exists = ($res && mysqli_num_rows($res) > 0);
    $cache[$key] = $exists;
    return $exists;
}

function firstExistingColumn($table, $candidates) {
    foreach ($candidates as $col) {
        if (tableHasColumn($table, $col)) {
            return $col;
        }
    }
    return null;
}

function normalizeLabUnit($unit) {
    $unit = trim((string)$unit);
    if ($unit === '' || strtolower($unit) === 'panel') {
        return '';
    }
    return $unit;
}

function parseStructuredLabNotes($notes) {
    $notes = (string)$notes;
    $prefix = '##LAB_PARAMS_JSON##';
    $parsed = [
        'parameters' => [],
        'plain_notes' => trim($notes)
    ];

    if (strpos($notes, $prefix) !== 0) {
        return $parsed;
    }

    $payload = substr($notes, strlen($prefix));
    $line_break_pos = strpos($payload, "\n");

    if ($line_break_pos === false) {
        $json_part = trim($payload);
        $plain_notes = '';
    } else {
        $json_part = trim(substr($payload, 0, $line_break_pos));
        $plain_notes = trim(substr($payload, $line_break_pos + 1));
    }

    $decoded = json_decode($json_part, true);
    if (is_array($decoded) && isset($decoded['parameters']) && is_array($decoded['parameters'])) {
        $clean_parameters = [];
        foreach ($decoded['parameters'] as $item) {
            if (!is_array($item)) {
                continue;
            }
            $name = trim((string)($item['name'] ?? ''));
            $value = trim((string)($item['value'] ?? ''));
            if ($name === '' || $value === '') {
                continue;
            }
            $clean_parameters[] = [
                'name' => $name,
                'value' => $value,
                'unit' => normalizeLabUnit($item['unit'] ?? ''),
                'reference' => trim((string)($item['reference'] ?? '')),
                'flag' => trim((string)($item['flag'] ?? ''))
            ];
        }
        $parsed['parameters'] = $clean_parameters;
        $parsed['plain_notes'] = $plain_notes;
    }

    return $parsed;
}

// Phone validation rule:
// - 10 digits starting with 0 (e.g. 0712345678)
// - OR + followed by 11 or 12 digits (supports common international formats)
function isValidPhoneNumber($phone) {
    $phone = trim((string)$phone);
    return preg_match('/^(0\d{9}|\+\d{11,12})$/', $phone) === 1;
}

function getPhoneValidationMessage() {
    return "Phone number must be 10 digits starting with 0, or start with + followed by 11 to 12 digits";
}

function getAllowedTanzaniaInsuranceProviders() {
    return [
        'National Insurance Corporation (NIC)',
        'Jubilee Insurance',
        'Alliance Insurance Tanzania',
        'Sanlam Tanzania',
        'Britam Insurance Tanzania',
        'Strategis Insurance Tanzania',
        'Heritage Insurance Tanzania',
        'Mayfair Insurance Tanzania',
        'Phoenix Insurance Tanzania',
        'Golden Crescent Insurance',
        'MGen Tanzania Insurance',
        'APA Insurance Tanzania',
        'Zanzibar Insurance Corporation (ZIC)',
        'Milvik Tanzania',
        'Tanzania Agricultural Insurance Scheme (TAIS)'
    ];
}

function getCurrentHomePage() {
    if (isLoggedIn()) {
        return getRoleHomePage();
    }
    if (isPatientLoggedIn()) {
        return 'patient_dashboard.php';
    }
    return 'index.php';
}

function get_system_settings() {
    static $settings_cache = null;
    if ($settings_cache !== null) {
        return $settings_cache;
    }

    $defaults = [
        'timezone' => 'Africa/Dar_es_Salaam',
        'currency' => 'TZS',
        'currency_symbol' => 'TSh',
        'backup_path' => __DIR__ . '/backups/',
        'auto_backup' => false,
        'backup_frequency' => 'daily',
        'retain_backups' => 30,
        'auto_billing_uninsured' => true
    ];

    $settings_file = __DIR__ . '/settings.json';
    if (file_exists($settings_file)) {
        $decoded = json_decode(file_get_contents($settings_file), true);
        if (is_array($decoded)) {
            $settings_cache = array_merge($defaults, $decoded);
            return $settings_cache;
        }
    }

    $settings_cache = $defaults;
    return $settings_cache;
}

function get_system_setting($key, $default = null) {
    $settings = get_system_settings();
    return array_key_exists($key, $settings) ? $settings[$key] : $default;
}

function load_env_file($path = null) {
    static $loaded = false;
    if ($loaded) {
        return;
    }
    $loaded = true;

    $env_path = $path ?: (__DIR__ . '/.env');
    if (!file_exists($env_path)) {
        return;
    }

    $lines = @file($env_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) {
        return;
    }

    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($trimmed === '' || strpos($trimmed, '#') === 0) {
            continue;
        }
        $parts = explode('=', $trimmed, 2);
        if (count($parts) !== 2) {
            continue;
        }
        $key = trim($parts[0]);
        $value = trim($parts[1]);
        $value = trim($value, "\"'");

        if ($key === '') {
            continue;
        }
        $_ENV[$key] = $value;
        $_SERVER[$key] = $value;
        putenv($key . '=' . $value);
    }
}

function env_value($key, $default = null) {
    load_env_file();

    $value = getenv($key);
    if ($value === false || $value === null || $value === '') {
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return $_ENV[$key];
        }
        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return $_SERVER[$key];
        }
        return $default;
    }
    return $value;
}

function smtp_write_line($socket, $line) {
    fwrite($socket, $line . "\r\n");
}

function smtp_read_response($socket) {
    $response = '';
    while (($line = fgets($socket, 515)) !== false) {
        $response .= $line;
        if (strlen($line) >= 4 && $line[3] === ' ') {
            break;
        }
    }
    return $response;
}

function smtp_expect_code($socket, $expected_prefixes) {
    $response = smtp_read_response($socket);
    foreach ($expected_prefixes as $prefix) {
        if (strpos($response, (string)$prefix) === 0) {
            return true;
        }
    }
    if (DEBUG_MODE) {
        error_log('SMTP unexpected response: ' . trim($response));
    }
    return false;
}

function send_via_smtp($to_email, $subject, $message, $from_email, $from_name, $smtp_cfg) {
    $host = $smtp_cfg['host'];
    $port = (int)$smtp_cfg['port'];
    $username = $smtp_cfg['username'];
    $password = $smtp_cfg['password'];
    $secure = strtolower((string)$smtp_cfg['secure']);

    $scheme = ($secure === 'ssl') ? 'ssl://' : 'tcp://';
    $socket = @stream_socket_client(
        $scheme . $host . ':' . $port,
        $errno,
        $errstr,
        20,
        STREAM_CLIENT_CONNECT
    );
    if (!$socket) {
        if (DEBUG_MODE) {
            error_log("SMTP connect failed: $errno $errstr");
        }
        return false;
    }

    stream_set_timeout($socket, 20);

    if (!smtp_expect_code($socket, ['220'])) {
        fclose($socket);
        return false;
    }

    $client_name = preg_replace('/[^a-zA-Z0-9\.\-]/', '', ($_SERVER['HTTP_HOST'] ?? 'localhost'));
    if ($client_name === '') {
        $client_name = 'localhost';
    }

    smtp_write_line($socket, "EHLO " . $client_name);
    if (!smtp_expect_code($socket, ['250'])) {
        fclose($socket);
        return false;
    }

    if ($secure === 'tls') {
        smtp_write_line($socket, "STARTTLS");
        if (!smtp_expect_code($socket, ['220'])) {
            fclose($socket);
            return false;
        }
        if (!@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($socket);
            return false;
        }
        smtp_write_line($socket, "EHLO " . $client_name);
        if (!smtp_expect_code($socket, ['250'])) {
            fclose($socket);
            return false;
        }
    }

    if ($username !== '' && $password !== '') {
        smtp_write_line($socket, "AUTH LOGIN");
        if (!smtp_expect_code($socket, ['334'])) {
            fclose($socket);
            return false;
        }
        smtp_write_line($socket, base64_encode($username));
        if (!smtp_expect_code($socket, ['334'])) {
            fclose($socket);
            return false;
        }
        smtp_write_line($socket, base64_encode($password));
        if (!smtp_expect_code($socket, ['235'])) {
            fclose($socket);
            return false;
        }
    }

    smtp_write_line($socket, "MAIL FROM:<" . $from_email . ">");
    if (!smtp_expect_code($socket, ['250'])) {
        fclose($socket);
        return false;
    }

    smtp_write_line($socket, "RCPT TO:<" . $to_email . ">");
    if (!smtp_expect_code($socket, ['250', '251'])) {
        fclose($socket);
        return false;
    }

    smtp_write_line($socket, "DATA");
    if (!smtp_expect_code($socket, ['354'])) {
        fclose($socket);
        return false;
    }

    $safe_subject = str_replace(["\r", "\n"], '', $subject);
    $headers = [];
    $headers[] = "From: " . $from_name . " <" . $from_email . ">";
    $headers[] = "To: <" . $to_email . ">";
    $headers[] = "Subject: " . $safe_subject;
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-Type: text/plain; charset=UTF-8";

    $body = preg_replace("/\r\n|\r|\n/", "\r\n", $message);
    $body = preg_replace('/^\./m', '..', $body); // dot-stuffing

    $data = implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.";
    smtp_write_line($socket, $data);
    if (!smtp_expect_code($socket, ['250'])) {
        fclose($socket);
        return false;
    }

    smtp_write_line($socket, "QUIT");
    fclose($socket);
    return true;
}

function send_system_email($to_email, $subject, $message, $from_name = null) {
    $to_email = trim((string)$to_email);
    if ($to_email === '' || !filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $sender_name = trim((string)($from_name ?? env_value('SMTP_FROM_NAME', SITE_NAME)));
    if ($sender_name === '') {
        $sender_name = 'Hospital System';
    }
    $sender_email = trim((string)env_value('SMTP_FROM', 'no-reply@localhost'));
    if (!filter_var($sender_email, FILTER_VALIDATE_EMAIL)) {
        $sender_email = 'no-reply@localhost';
    }

    $smtp_host = trim((string)env_value('SMTP_HOST', ''));
    $smtp_port = (int)env_value('SMTP_PORT', 587);
    $smtp_user = trim((string)env_value('SMTP_USER', ''));
    $smtp_pass_raw = trim((string)env_value('SMTP_PASS', ''));
    $smtp_pass = preg_replace('/[\s-]/', '', $smtp_pass_raw);
    $smtp_secure = strtolower(trim((string)env_value('SMTP_SECURE', 'tls'))); // tls|ssl|none

    $looks_like_placeholder = (
        stripos($smtp_user, 'your_outlook_email') !== false ||
        stripos($sender_email, 'your_outlook_email') !== false ||
        stripos($smtp_pass_raw, 'your_app_password') !== false
    );

    if (!$looks_like_placeholder && $smtp_host !== '' && $smtp_port > 0 && $smtp_user !== '' && $smtp_pass !== '') {
        $sent = send_via_smtp(
            $to_email,
            $subject,
            $message,
            $sender_email,
            $sender_name,
            [
                'host' => $smtp_host,
                'port' => $smtp_port,
                'username' => $smtp_user,
                'password' => $smtp_pass,
                'secure' => $smtp_secure
            ]
        );
        if ($sent) {
            return true;
        }
        if (DEBUG_MODE) {
            error_log('SMTP send failed, falling back to mail()');
        }
    } elseif (DEBUG_MODE && $looks_like_placeholder) {
        error_log('SMTP placeholders detected in .env. Replace SMTP_USER/SMTP_PASS/SMTP_FROM with real values.');
    }

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $headers .= "From: " . $sender_name . " <" . $sender_email . ">\r\n";

    return @mail($to_email, $subject, $message, $headers);
}

function redirectToRoleHome() {
    redirect(getCurrentHomePage());
}

// Generate unique ID with better error handling
function generateUniqueId($prefix, $table, $field) {
    $conn = getConnection();
    $max_attempts = 100;
    $attempt = 0;
    
    while ($attempt < $max_attempts) {
        $id = $prefix . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $query = "SELECT COUNT(*) as count FROM $table WHERE $field = '$id'";
        $result = mysqli_query($conn, $query);
        
        if ($result) {
            $row = mysqli_fetch_assoc($result);
            if ($row['count'] == 0) {
                return $id;
            }
        }
        $attempt++;
    }
    
    // Fallback: use timestamp
    return $prefix . date('YmdHis') . rand(100, 999);
}

// Create upload directories if they don't exist
$upload_dirs = ['uploads', 'uploads/profiles', 'uploads/documents', 'uploads/reports'];
foreach ($upload_dirs as $dir) {
    $full_path = __DIR__ . '/' . $dir;
    if (!file_exists($full_path)) {
        mkdir($full_path, 0777, true);
    }
}

// Load currency helper FIRST - before any other includes
$currency_helper_path = __DIR__ . '/currency_helper.php';
if (file_exists($currency_helper_path)) {
    require_once $currency_helper_path;
    if (DEBUG_MODE) {
        error_log("currency_helper.php loaded from: " . $currency_helper_path);
    }
} else {
    // Define fallback currency functions if file doesn't exist
    if (DEBUG_MODE) {
        error_log("WARNING: currency_helper.php not found at: " . $currency_helper_path);
    }
    
    function format_currency($amount) {
        return 'TZS ' . number_format((float)$amount, 2);
    }
    
    function get_currency_code() {
        return 'TZS';
    }
    
    function get_currency_symbol() {
        return 'TZS';
    }
    
    function format_number($amount) {
        return number_format((float)$amount, 2);
    }
}

// Set default timezone from settings if available
$settings_file = __DIR__ . '/settings.json';
if (file_exists($settings_file)) {
    $settings = json_decode(file_get_contents($settings_file), true);
    if (isset($settings['timezone'])) {
        date_default_timezone_set($settings['timezone']);
    }
} else {
    // Default to East Africa Time
    date_default_timezone_set('Africa/Dar_es_Salaam');
}

// Load auth check functions if exists
$auth_check_path = __DIR__ . '/auth_check.php';
if (file_exists($auth_check_path)) {
    require_once $auth_check_path;
}

// Debug info (remove in production)
if (DEBUG_MODE && isset($_GET['debug'])) {
    echo "<pre>";
    echo "config.php loaded\n";
    echo "Currency functions exist: " . (function_exists('format_currency') ? 'Yes' : 'No') . "\n";
    echo "Session status: " . session_status() . "\n";
    echo "Session data: ";
    print_r($_SESSION);
    echo "</pre>";
}

// Ensure users.user_type enum includes hr_admin (safe idempotent migration hook)
function ensureHrRoleInUsersEnum() {
    static $done = false;
    if ($done) return;
    $done = true;

    $conn = getConnection();
    $res = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'user_type'");
    if (!$res || mysqli_num_rows($res) === 0) return;
    $row = mysqli_fetch_assoc($res);
    $type = $row['Type'] ?? '';
    if (stripos($type, "hr_admin") !== false) return;

    if (preg_match("/^enum\\((.*)\\)$/i", $type, $m)) {
        $values = str_getcsv($m[1], ',', "'");
        if (!in_array('hr_admin', $values, true)) {
            $values[] = 'hr_admin';
        }
        $quoted = array_map(function($v){ return "'" . str_replace("'", "\\'", $v) . "'"; }, $values);
        $sql = "ALTER TABLE users MODIFY user_type ENUM(" . implode(',', $quoted) . ") NOT NULL";
        @mysqli_query($conn, $sql);
    }
}

ensureHrRoleInUsersEnum();

// Least-privilege guard: HR users cannot access financial/accounting modules.
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'hr_admin') {
    $blocked = [
        'dashboard.php', 'billing.php', 'insurance.php', 'reports.php',
        'process_payment.php', 'print_bill.php', 'print_claim.php', 'view_bill.php'
    ];
    $current = basename($_SERVER['PHP_SELF'] ?? '');
    if (in_array($current, $blocked, true)) {
        $_SESSION['error'] = "Access denied: HR role cannot access financial modules";
        header("Location: hr_dashboard.php");
        exit();
    }
}
?>
