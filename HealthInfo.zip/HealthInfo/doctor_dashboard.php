<?php
require_once 'config.php';

// Check if user is logged in and is doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'doctor') {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$today = date('Y-m-d');
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');

// Get today's appointments
$today_appointments = mysqli_query($conn,
    "SELECT a.*, p.first_name, p.last_name, p.patient_number, p.date_of_birth, p.patient_id
     FROM appointments a
     JOIN patients p ON a.patient_id = p.patient_id
     WHERE a.doctor_id = $doctor_id 
     AND a.appointment_date = '$today'
     AND a.status IN ('scheduled', 'in_progress')
     ORDER BY a.appointment_time"
);

// Get pending lab results to review
$approval_filter = $has_doctor_approval
    ? "AND (lr.approved_by_doctor IS NULL OR lr.approved_by_doctor = 0)"
    : "";
$pending_lab = mysqli_query($conn,
    "SELECT lr.*, p.first_name, p.last_name, p.patient_number, p.patient_id,
            lt.test_name, lt.normal_range, lt.unit
     FROM lab_requests lr
     JOIN patients p ON lr.patient_id = p.patient_id
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.doctor_id = $doctor_id 
     AND lr.status = 'completed'
     $approval_filter
     ORDER BY lr.result_date DESC"
);

// New patients assigned to this doctor (first visit in last 14 days)
$new_patients = mysqli_query($conn,
    "SELECT a.appointment_id, a.patient_id, a.appointment_date, a.appointment_time, a.status, a.reason,
            p.first_name, p.last_name, p.patient_number, p.date_of_birth
     FROM appointments a
     JOIN patients p ON p.patient_id = a.patient_id
     WHERE a.doctor_id = $doctor_id
       AND a.appointment_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
       AND a.appointment_date = (
            SELECT MIN(a2.appointment_date)
            FROM appointments a2
            WHERE a2.patient_id = a.patient_id
              AND a2.doctor_id = $doctor_id
       )
     ORDER BY a.appointment_date DESC, a.appointment_time DESC
     LIMIT 10"
);

// Get doctor's attendance history (last 10 records)
$attendance = mysqli_query($conn,
    "SELECT * FROM attendance 
     WHERE user_id = $doctor_id 
     ORDER BY date DESC 
     LIMIT 10"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .card-dashboard {
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .card-dashboard:hover {
            transform: translateY(-5px);
        }
        .card-header-custom {
            padding: 15px 20px;
            border-radius: 12px 12px 0 0;
            font-weight: 600;
        }
        .appointment-item {
            border-left: 4px solid;
            padding: 15px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .appointment-scheduled { border-left-color: #007bff; }
        .appointment-in_progress { border-left-color: #ffc107; }
        
        .lab-item {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .status-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-present { background: #d4edda; color: #155724; }
        .status-absent { background: #f8d7da; color: #721c24; }
        .status-late { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <h2><i class="fas fa-user-md"></i> Dr. <?php echo $_SESSION['full_name']; ?>'s Dashboard</h2>
            <p class="mb-0"><?php echo date('l, F j, Y'); ?></p>
        </div>
        
        <div class="row">
            <!-- Left Column - Today's Appointments -->
            <div class="col-md-4">
                <div class="card card-dashboard">
                    <div class="card-header-custom bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-calendar-check"></i> Today's Appointments</h5>
                    </div>
                    <div class="card-body">
                        <?php if($today_appointments && mysqli_num_rows($today_appointments) > 0): ?>
                            <?php while($apt = mysqli_fetch_assoc($today_appointments)): 
                                $status_class = $apt['status'] == 'scheduled' ? 'appointment-scheduled' : 'appointment-in_progress';
                                $age = date_diff(date_create($apt['date_of_birth']), date_create('today'))->y;
                            ?>
                                <div class="appointment-item <?php echo $status_class; ?>">
                                    <div class="d-flex justify-content-between">
                                        <strong><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></strong>
                                        <span class="badge bg-<?php echo $apt['status'] == 'scheduled' ? 'primary' : 'warning'; ?>">
                                            <?php echo ucfirst($apt['status']); ?>
                                        </span>
                                    </div>
                                    <h6 class="mt-2"><?php echo $apt['first_name'] . ' ' . $apt['last_name']; ?></h6>
                                    <p class="mb-1 small">
                                        #<?php echo $apt['patient_number']; ?> | <?php echo $age; ?> yrs
                                    </p>
                                    <p class="small text-muted"><?php echo $apt['reason']; ?></p>
                                    <div class="btn-group btn-group-sm w-100">
                                        <a href="view_appointment.php?id=<?php echo $apt['appointment_id']; ?>" 
                                           class="btn btn-outline-primary">View</a>
                                        <a href="create_prescription.php?patient_id=<?php echo $apt['patient_id']; ?>" 
                                           class="btn btn-outline-success">Prescription</a>
                                        <a href="patient_history.php?patient_id=<?php echo $apt['patient_id']; ?>" 
                                           class="btn btn-outline-secondary">History</a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center py-4">No appointments today</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Middle Column - Pending Lab Results to Review -->
            <div class="col-md-4">
                <div class="card card-dashboard">
                    <div class="card-header-custom bg-warning">
                        <h5 class="mb-0"><i class="fas fa-flask"></i> Pending Lab Results</h5>
                    </div>
                    <div class="card-body">
                        <?php if($pending_lab && mysqli_num_rows($pending_lab) > 0): ?>
                            <?php while($lab = mysqli_fetch_assoc($pending_lab)): ?>
                                <div class="lab-item">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="mb-0"><?php echo $lab['first_name'] . ' ' . $lab['last_name']; ?></h6>
                                        <span class="badge bg-warning">New</span>
                                    </div>
                                    <p class="small mb-1">#<?php echo $lab['patient_number']; ?> | <?php echo $lab['test_name']; ?></p>
                                    <p class="mb-1">
                                        <strong>Result:</strong> <?php echo $lab['result_value'] . ' ' . $lab['unit']; ?>
                                    </p>
                                    <p class="small text-muted mb-2">Normal: <?php echo $lab['normal_range'] ?: 'N/A'; ?></p>
                                    <div class="btn-group btn-group-sm w-100">
                                        <a href="review_lab_result.php?id=<?php echo $lab['request_id']; ?>" 
                                           class="btn btn-warning">Review</a>
                                        <a href="patient_history.php?patient_id=<?php echo $lab['patient_id']; ?>" 
                                           class="btn btn-outline-secondary">History</a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center py-4">No pending lab results</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="card card-dashboard">
                    <div class="card-header-custom bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-bolt"></i> Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="my_appointments.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-check"></i> All My Appointments
                            </a>
                            <a href="search_patients.php" class="btn btn-outline-success">
                                <i class="fas fa-search"></i> Search Patients
                            </a>
                            <a href="lab_requests_list.php" class="btn btn-outline-warning">
                                <i class="fas fa-flask"></i> All Lab Requests
                            </a>
                            <a href="worker_attendance.php" class="btn btn-outline-secondary">
                                <i class="fas fa-clock"></i> My Attendance
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column - Attendance History -->
            <div class="col-md-4">
                <div class="card card-dashboard">
                    <div class="card-header-custom bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-user-plus"></i> New Patients (14 Days)</h5>
                    </div>
                    <div class="card-body">
                        <?php if($new_patients && mysqli_num_rows($new_patients) > 0): ?>
                            <?php while($np = mysqli_fetch_assoc($new_patients)): ?>
                                <?php $age = date_diff(date_create($np['date_of_birth']), date_create('today'))->y; ?>
                                <div class="appointment-item appointment-scheduled">
                                    <div class="d-flex justify-content-between">
                                        <strong><?php echo htmlspecialchars($np['first_name'] . ' ' . $np['last_name']); ?></strong>
                                        <span class="badge bg-primary">New</span>
                                    </div>
                                    <p class="small mb-1">#<?php echo htmlspecialchars($np['patient_number']); ?> | <?php echo (int)$age; ?> yrs</p>
                                    <p class="small mb-2">
                                        First Visit: <?php echo date('d M Y', strtotime($np['appointment_date'])); ?>
                                    </p>
                                    <div class="btn-group btn-group-sm w-100">
                                        <a href="lab_request.php?patient_id=<?php echo (int)$np['patient_id']; ?>" class="btn btn-outline-warning">
                                            Lab Request
                                        </a>
                                        <a href="lab_requests_list.php?patient_id=<?php echo (int)$np['patient_id']; ?>&status=completed" class="btn btn-outline-success">
                                            Lab Results
                                        </a>
                                        <a href="patient_history.php?patient_id=<?php echo (int)$np['patient_id']; ?>" class="btn btn-outline-secondary">
                                            History
                                        </a>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted text-center py-3">No new patient assignments in last 14 days</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card card-dashboard">
                    <div class="card-header-custom bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-history"></i> My Recent Attendance</h5>
                    </div>
                    <div class="card-body">
                        <?php if($attendance && mysqli_num_rows($attendance) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Check In</th>
                                            <th>Check Out</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($att = mysqli_fetch_assoc($attendance)): ?>
                                            <tr>
                                                <td><?php echo date('d M', strtotime($att['date'])); ?></td>
                                                <td><?php echo $att['check_in'] ? date('h:i A', strtotime($att['check_in'])) : '-'; ?></td>
                                                <td><?php echo $att['check_out'] ? date('h:i A', strtotime($att['check_out'])) : '-'; ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $att['status']; ?>">
                                                        <?php echo ucfirst($att['status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center mt-2">
                                <a href="attendance_history.php" class="btn btn-sm btn-primary">View Full History</a>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4">No attendance records found</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Patient Specific Test Search -->
                <div class="card card-dashboard">
                    <div class="card-header-custom bg-secondary text-white">
                        <h5 class="mb-0"><i class="fas fa-search"></i> Find Patient Test</h5>
                    </div>
                    <div class="card-body">
                        <form action="patient_tests.php" method="GET">
                            <div class="mb-3">
                                <label class="form-label">Patient Number or Name</label>
                                <input type="text" class="form-control" name="search" required 
                                       placeholder="e.g., PAT001 or John">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i> Find Tests
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
