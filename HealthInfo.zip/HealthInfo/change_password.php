<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Fetch current user data for verification
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    // Verify current password
    if (password_verify($current, $user['password'])) {
        if ($new != $confirm) {
            $error = "New passwords do not match";
        } elseif (strlen($new) < 8) {
            $error = "Password must be at least 8 characters long";
        } elseif (!preg_match('/[A-Z]/', $new)) {
            $error = "Password must contain at least one uppercase letter";
        } elseif (!preg_match('/[a-z]/', $new)) {
            $error = "Password must contain at least one lowercase letter";
        } elseif (!preg_match('/[0-9]/', $new)) {
            $error = "Password must contain at least one number";
        } else {
            $hashed = password_hash($new, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password = '$hashed' WHERE user_id = $user_id";
            
            if (mysqli_query($conn, $update_query)) {
                $success = "Password changed successfully!";
                
                // Log the password change
                $log_query = "INSERT INTO user_logs (user_id, action, ip_address) 
                              VALUES ($user_id, 'password_change', '{$_SERVER['REMOTE_ADDR']}')";
                @mysqli_query($conn, $log_query);
            } else {
                $error = "Error changing password: " . mysqli_error($conn);
            }
        }
    } else {
        $error = "Current password is incorrect";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .password-card {
            max-width: 500px;
            margin: 50px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .password-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px 15px 0 0;
        }
        .password-body {
            padding: 30px;
        }
        .strength-meter {
            height: 5px;
            background: #e9ecef;
            border-radius: 5px;
            margin-top: 10px;
            overflow: hidden;
        }
        .strength-bar {
            height: 100%;
            width: 0;
            transition: all 0.3s;
        }
        .strength-weak { background: #dc3545; }
        .strength-medium { background: #ffc107; }
        .strength-strong { background: #28a745; }
        .requirement-item {
            font-size: 13px;
            margin-bottom: 5px;
            color: #666;
        }
        .requirement-item.valid {
            color: #28a745;
        }
        .requirement-item.invalid {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="password-card">
            <div class="password-header">
                <h4 class="mb-0"><i class="fas fa-key"></i> Change Password</h4>
                <p class="mb-0 mt-2">Update your account password</p>
            </div>
            
            <div class="password-body">
                <?php if($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="passwordForm">
                    <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                        <div class="strength-meter mt-2">
                            <div class="strength-bar" id="strengthBar"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <!-- Password Requirements -->
                    <div class="alert alert-info">
                        <h6 class="mb-2">Password Requirements:</h6>
                        <div class="requirement-item" id="req-length">
                            <i class="fas fa-circle"></i> At least 8 characters
                        </div>
                        <div class="requirement-item" id="req-uppercase">
                            <i class="fas fa-circle"></i> At least one uppercase letter
                        </div>
                        <div class="requirement-item" id="req-lowercase">
                            <i class="fas fa-circle"></i> At least one lowercase letter
                        </div>
                        <div class="requirement-item" id="req-number">
                            <i class="fas fa-circle"></i> At least one number
                        </div>
                        <div class="requirement-item" id="req-match">
                            <i class="fas fa-circle"></i> Passwords match
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100" id="submitBtn" disabled>
                        <i class="fas fa-save"></i> Change Password
                    </button>
                    
                    <div class="text-center mt-3">
                        <a href="profile.php" class="text-muted">
                            <i class="fas fa-arrow-left"></i> Back to Profile
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        const submitBtn = document.getElementById('submitBtn');
        
        const reqLength = document.getElementById('req-length');
        const reqUppercase = document.getElementById('req-uppercase');
        const reqLowercase = document.getElementById('req-lowercase');
        const reqNumber = document.getElementById('req-number');
        const reqMatch = document.getElementById('req-match');
        const strengthBar = document.getElementById('strengthBar');
        
        function checkPassword() {
            const password = newPassword.value;
            const confirm = confirmPassword.value;
            
            // Check requirements
            const hasLength = password.length >= 8;
            const hasUppercase = /[A-Z]/.test(password);
            const hasLowercase = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const passwordsMatch = password === confirm && password !== '';
            
            // Update requirement icons
            updateRequirement(reqLength, hasLength);
            updateRequirement(reqUppercase, hasUppercase);
            updateRequirement(reqLowercase, hasLowercase);
            updateRequirement(reqNumber, hasNumber);
            updateRequirement(reqMatch, passwordsMatch);
            
            // Calculate strength
            let strength = 0;
            if (hasLength) strength += 25;
            if (hasUppercase) strength += 25;
            if (hasLowercase) strength += 25;
            if (hasNumber) strength += 25;
            
            strengthBar.style.width = strength + '%';
            
            if (strength <= 25) {
                strengthBar.className = 'strength-bar strength-weak';
            } else if (strength <= 50) {
                strengthBar.className = 'strength-bar strength-medium';
            } else {
                strengthBar.className = 'strength-bar strength-strong';
            }
            
            // Enable/disable submit button
            submitBtn.disabled = !(hasLength && hasUppercase && hasLowercase && hasNumber && passwordsMatch);
        }
        
        function updateRequirement(element, isValid) {
            if (isValid) {
                element.classList.add('valid');
                element.classList.remove('invalid');
                element.innerHTML = '<i class="fas fa-check-circle"></i> ' + element.innerText.substring(2);
            } else {
                element.classList.add('invalid');
                element.classList.remove('valid');
                element.innerHTML = '<i class="fas fa-times-circle"></i> ' + element.innerText.substring(2);
            }
        }
        
        newPassword.addEventListener('input', checkPassword);
        confirmPassword.addEventListener('input', checkPassword);
    </script>
</body>
</html>