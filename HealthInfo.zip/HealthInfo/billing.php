<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['accountant', 'receptionist']);
require_once 'lab_test_catalog_helper.php';

$conn = getConnection();
seed_regional_lab_tests($conn);
$currency_symbol = get_currency_symbol();
$has_created_by = tableHasColumn('billing', 'created_by');

// Handle billing operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['create_bill'])) {
        $bill_number = generateUniqueId('BILL', 'billing', 'bill_number');
        $patient_id = intval($_POST['patient_id']);
        $items = json_decode($_POST['items'], true);
        $discount = floatval($_POST['discount'] ?: 0);
        $tax = floatval($_POST['tax'] ?: 0);
        $notes = sanitize($_POST['notes'] ?? '');
        $insurance_claim_id = !empty($_POST['insurance_claim_id']) ? intval($_POST['insurance_claim_id']) : 'NULL';

        if ($patient_id <= 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Select a valid patient']);
            exit();
        }
        if (!is_array($items) || count($items) === 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Add at least one bill item']);
            exit();
        }
        if ($discount < 0 || $tax < 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Discount and tax cannot be negative']);
            exit();
        }
        
        // Calculate totals
        $total_amount = 0;
        foreach($items as $item) {
            $item_price = (float)($item['price'] ?? 0);
            $item_qty = (int)($item['quantity'] ?? 0);
            if ($item_price < 0 || $item_qty <= 0) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'Item quantity must be above zero and price cannot be negative']);
                exit();
            }
            $total_amount += $item_price * $item_qty;
        }
        if ($discount > ($total_amount + $tax)) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Discount cannot exceed total service cost']);
            exit();
        }

        $net_amount = $total_amount - $discount + $tax;
        if ($net_amount < 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Net amount cannot be negative']);
            exit();
        }
        
        // Start transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Insert bill (schema-safe for optional columns like created_by)
            $columns = ['bill_number', 'patient_id', 'total_amount', 'discount', 'tax', 'net_amount'];
            $values = ["'$bill_number'", $patient_id, $total_amount, $discount, $tax, $net_amount];
            if (tableHasColumn('billing', 'notes')) {
                $columns[] = 'notes';
                $values[] = "'$notes'";
            }
            if (tableHasColumn('billing', 'insurance_claim_id')) {
                $columns[] = 'insurance_claim_id';
                $values[] = $insurance_claim_id;
            }
            if ($has_created_by) {
                $columns[] = 'created_by';
                $values[] = (int)$_SESSION['user_id'];
            }
            $query = "INSERT INTO billing (" . implode(', ', $columns) . ")
                      VALUES (" . implode(', ', $values) . ")";
            
            if (!mysqli_query($conn, $query)) {
                throw new Exception("Error inserting bill: " . mysqli_error($conn));
            }
            
            $bill_id = mysqli_insert_id($conn);
            
            // Insert bill items
            foreach($items as $item) {
                $item_type = sanitize($item['type']);
                // Keep UI-compatible type but store consultations using schema enum value.
                if ($item_type === 'appointment') {
                    $db_item_type = 'consultation';
                } elseif ($item_type === 'hospital_service') {
                    $db_item_type = 'other';
                } else {
                    $db_item_type = $item_type;
                }
                $item_id = is_numeric($item['id']) ? intval($item['id']) : 0;
                $description = sanitize($item['description']);
                $quantity = intval($item['quantity']);
                $unit_price = floatval($item['price']);
                $total_price = $unit_price * $quantity;

                if ($quantity <= 0 || $unit_price < 0 || $total_price < 0) {
                    throw new Exception("Invalid monetary values for selected bill item");
                }

                if ($item_type === 'appointment' && $item_id > 0) {
                    $chk = mysqli_query($conn, "SELECT appointment_id FROM appointments WHERE appointment_id = $item_id AND patient_id = $patient_id");
                    if (!$chk || mysqli_num_rows($chk) === 0) {
                        throw new Exception("Selected appointment does not belong to this patient");
                    }
                }
                if ($item_type === 'lab_test' && $item_id > 0) {
                    $chk = mysqli_query($conn, "SELECT request_id FROM lab_requests WHERE request_id = $item_id AND patient_id = $patient_id");
                    if (!$chk || mysqli_num_rows($chk) === 0) {
                        throw new Exception("Selected lab test does not belong to this patient");
                    }
                }
                
                $item_query = "INSERT INTO billing_items (bill_id, item_type, item_id, description, quantity, unit_price, total_price) 
                              VALUES ($bill_id, '$db_item_type', $item_id, '$description', $quantity, $unit_price, $total_price)";
                
                if (!mysqli_query($conn, $item_query)) {
                    throw new Exception("Error inserting bill item: " . mysqli_error($conn));
                }
                
                // Update inventory if medicine
                if ($item_type == 'medicine' && is_numeric($item_id) && $item_id > 0) {
                    $update_inv = "UPDATE inventory_items SET quantity = quantity - $quantity 
                                   WHERE item_id = $item_id AND quantity >= $quantity";
                    if (!mysqli_query($conn, $update_inv)) {
                        throw new Exception("Error updating inventory: " . mysqli_error($conn));
                    }
                }
            }
            
            mysqli_commit($conn);

            @send_patient_service_summary_email(
                $conn,
                $patient_id,
                $bill_number,
                array_map(function($it) {
                    return [
                        'description' => $it['description'] ?? '',
                        'quantity' => (int)($it['quantity'] ?? 1),
                        'unit_price' => (float)($it['price'] ?? 0)
                    ];
                }, $items),
                [
                    'subtotal' => $total_amount,
                    'discount' => $discount,
                    'tax' => $tax,
                    'net_amount' => $net_amount
                ]
            );
            
            // Return JSON response
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true, 
                'bill_id' => $bill_id, 
                'bill_number' => $bill_number,
                'message' => 'Bill created successfully!'
            ]);
            exit();
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit();
        }
    }
}

// Fetch data for dropdowns
$patients = mysqli_query($conn, "SELECT patient_id, patient_number, first_name, last_name FROM patients ORDER BY first_name");

// Loaded dynamically per patient from service records
$lab_tests = [];

// Fetch medicines
$medicines_result = mysqli_query($conn, "SELECT item_id, item_name,
    CASE
        WHEN COALESCE(unit_price, 0) > 0 AND COALESCE(unit_price, 0) < 1000 THEN unit_price * 1000
        ELSE unit_price
    END AS unit_price
    FROM inventory_items
    WHERE category = 'Medicine' AND quantity > 0
    ORDER BY item_name");
$medicines = [];
while($row = mysqli_fetch_assoc($medicines_result)) {
    $medicines[] = [
        'id' => $row['item_id'],
        'name' => $row['item_name'],
        'price' => floatval($row['unit_price'])
    ];
}

// Loaded dynamically per patient from service records
$consultations = [];

$procedures = [
    ['id' => 1, 'name' => 'Wound Dressing', 'price' => 35000.00],
    ['id' => 2, 'name' => 'Suturing', 'price' => 65000.00],
    ['id' => 3, 'name' => 'Nebulization', 'price' => 28000.00],
    ['id' => 4, 'name' => 'ECG', 'price' => 55000.00],
    ['id' => 5, 'name' => 'Ultrasound (General)', 'price' => 95000.00],
    ['id' => 6, 'name' => 'X-Ray (Single View)', 'price' => 70000.00],
    ['id' => 7, 'name' => 'IV Cannulation and Setup', 'price' => 30000.00],
    ['id' => 8, 'name' => 'Minor Surgery Procedure', 'price' => 250000.00]
];

$hospital_services = [
    ['id' => 101, 'name' => 'Emergency Consultation', 'price' => 80000.00],
    ['id' => 102, 'name' => 'Specialist Consultation', 'price' => 120000.00],
    ['id' => 103, 'name' => 'Inpatient Bed Charge (Per Day)', 'price' => 150000.00],
    ['id' => 104, 'name' => 'ICU Bed Charge (Per Day)', 'price' => 450000.00],
    ['id' => 105, 'name' => 'Theatre Charge - Major', 'price' => 900000.00],
    ['id' => 106, 'name' => 'Theatre Charge - Minor', 'price' => 350000.00],
    ['id' => 107, 'name' => 'Anesthesia Service', 'price' => 300000.00],
    ['id' => 108, 'name' => 'Maternity Delivery Package', 'price' => 750000.00],
    ['id' => 109, 'name' => 'Antenatal Clinic Visit', 'price' => 40000.00],
    ['id' => 110, 'name' => 'Postnatal Clinic Visit', 'price' => 35000.00],
    ['id' => 111, 'name' => 'Physiotherapy Session', 'price' => 60000.00],
    ['id' => 112, 'name' => 'Dental Consultation', 'price' => 45000.00],
    ['id' => 113, 'name' => 'Dental Extraction', 'price' => 85000.00],
    ['id' => 114, 'name' => 'CT Scan', 'price' => 380000.00],
    ['id' => 115, 'name' => 'MRI Scan', 'price' => 650000.00],
    ['id' => 116, 'name' => 'Ambulance Transfer', 'price' => 180000.00],
    ['id' => 117, 'name' => 'Home Care Visit', 'price' => 220000.00],
    ['id' => 118, 'name' => 'Vaccination Service', 'price' => 30000.00],
    ['id' => 119, 'name' => 'Nutrition and Diet Counseling', 'price' => 50000.00],
    ['id' => 120, 'name' => 'Chronic Disease Clinic Review', 'price' => 70000.00]
];

// Fetch recent bills
$recent_bills = mysqli_query($conn, 
    "SELECT b.*, p.first_name, p.last_name, p.patient_number 
     FROM billing b
     JOIN patients p ON b.patient_id = p.patient_id
     ORDER BY b.bill_date DESC LIMIT 10"
);

$auto_pending_count = 0;
$auto_pending_bills = null;
if (tableHasColumn('billing', 'notes') && tableHasColumn('billing', 'payment_status')) {
    $auto_pending_count = (int)(mysqli_fetch_assoc(mysqli_query(
        $conn,
        "SELECT COUNT(*) AS count
         FROM billing
         WHERE payment_status='pending'
           AND LOWER(COALESCE(notes, '')) LIKE '%auto-generated bill for uninsured patient%'"
    ))['count'] ?? 0);

    $auto_pending_bills = mysqli_query(
        $conn,
        "SELECT b.bill_id, b.bill_number, b.bill_date, b.net_amount, p.patient_number, p.first_name, p.last_name
         FROM billing b
         JOIN patients p ON p.patient_id = b.patient_id
         WHERE b.payment_status='pending'
           AND LOWER(COALESCE(b.notes, '')) LIKE '%auto-generated bill for uninsured patient%'
         ORDER BY b.bill_date DESC
         LIMIT 5"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing System - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <style>
        .bill-item {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            border-left: 4px solid #007bff;
        }
        .total-section {
            background: #e9ecef;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .nav-tabs .nav-link {
            color: #495057;
        }
        .nav-tabs .nav-link.active {
            color: #007bff;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <?php if($auto_pending_count > 0): ?>
            <div class="alert alert-info">
                Pending Auto Bills: <strong><?php echo $auto_pending_count; ?></strong>
                <?php if($auto_pending_bills && mysqli_num_rows($auto_pending_bills) > 0): ?>
                    <ul class="mb-0 mt-2">
                        <?php while($ab = mysqli_fetch_assoc($auto_pending_bills)): ?>
                            <li>
                                <a href="view_bill.php?id=<?php echo (int)$ab['bill_id']; ?>">
                                    <?php echo htmlspecialchars($ab['bill_number']); ?>
                                </a>
                                - <?php echo htmlspecialchars($ab['patient_number'] . ' ' . $ab['first_name'] . ' ' . $ab['last_name']); ?>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <ul class="nav nav-tabs mb-4" id="billingTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="create-tab" data-bs-toggle="tab" data-bs-target="#create" type="button">
                    <i class="fas fa-plus-circle"></i> Create Bill
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="history-tab" data-bs-toggle="tab" data-bs-target="#history" type="button">
                    <i class="fas fa-history"></i> Bill History
                </button>
            </li>
        </ul>
        
        <div class="tab-content">
            <!-- Create Bill Tab -->
            <div class="tab-pane fade show active" id="create">
                <div class="row">
                    <!-- Bill Creation Form -->
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-file-invoice"></i> Create New Bill</h5>
                            </div>
                            <div class="card-body">
                                <form id="billingForm">
                                    <div class="row mb-3">
                                        <div class="col-md-8">
                                            <label class="form-label">Select Patient *</label>
                                            <select class="form-control select2" id="patient_id" required>
                                                <option value="">Search patient...</option>
                                                <?php 
                                                mysqli_data_seek($patients, 0);
                                                while($patient = mysqli_fetch_assoc($patients)): 
                                                ?>
                                                    <option value="<?php echo $patient['patient_id']; ?>">
                                                        <?php echo $patient['patient_number'] . ' - ' . $patient['first_name'] . ' ' . $patient['last_name']; ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Insurance Claim</label>
                                            <select class="form-control" id="insurance_claim_id">
                                                <option value="">None</option>
                                                <?php
                                                $claims = mysqli_query($conn, "SELECT c.*, p.first_name, p.last_name FROM insurance_claims c JOIN patients p ON c.patient_id = p.patient_id WHERE c.status = 'approved'");
                                                while($claim = mysqli_fetch_assoc($claims)):
                                                ?>
                                                    <option value="<?php echo $claim['claim_id']; ?>">
                                                        #<?php echo $claim['claim_number']; ?> - <?php echo $claim['first_name'] . ' ' . $claim['last_name']; ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <!-- Item Selection -->
                                    <div class="card mb-3">
                                        <div class="card-header bg-info text-white">
                                            <h6 class="mb-0">Add Items</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="row mb-3">
                                                <div class="col-md-3">
                                                    <label class="form-label">Item Type</label>
                                                    <select class="form-control" id="item_type">
                                                        <option value="hospital_service">Hospital Service</option>
                                                        <option value="procedure">Procedure</option>
                                                        <option value="medicine">Medicine</option>
                                                        <option value="appointment">Appointment Service</option>
                                                        <option value="lab_test">Lab Test</option>
                                                        <option value="other">Custom Item (Manual)</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-5">
                                                    <label class="form-label">Select Item</label>
                                                    <select class="form-control" id="item_select">
                                                        <option value="">Choose item...</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-2">
                                                    <label class="form-label">Quantity</label>
                                                    <input type="number" class="form-control" id="item_quantity" value="1" min="1">
                                                </div>
                                                <div class="col-md-2">
                                                    <label class="form-label">&nbsp;</label>
                                                    <button type="button" class="btn btn-success w-100" onclick="addSelectedItem()">
                                                        <i class="fas fa-plus"></i> Add
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <!-- Manual Entry Section -->
                                            <div id="manualEntry" class="mt-3 p-3 border rounded bg-light">
                                                <h6 class="mb-2">Custom Item</h6>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <input type="text" class="form-control" id="custom_desc" placeholder="Description">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <input type="number" class="form-control" id="custom_price" placeholder="Price" step="0.01">
                                                    </div>
                                                    <div class="col-md-2">
                                                        <input type="number" class="form-control" id="custom_qty" value="1" min="1">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <button type="button" class="btn btn-success w-100" onclick="addCustomItem()">
                                                            <i class="fas fa-plus"></i> Add Custom
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Items List -->
                                    <div id="itemsList" class="mt-3"></div>
                                    
                                    <!-- Totals -->
                                    <div class="total-section">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="mb-2">
                                                    <label>Subtotal: <strong><?php echo $currency_symbol; ?> <span id="subtotal">0.00</span></strong></label>
                                                </div>
                                                <div class="mb-2">
                                                    <label>Discount (<?php echo $currency_symbol; ?>):</label>
                                                    <input type="number" class="form-control form-control-sm" id="discount" value="0" min="0" step="0.01" onchange="calculateTotal()">
                                                </div>
                                                <div class="mb-2">
                                                    <label>Tax (<?php echo $currency_symbol; ?>):</label>
                                                    <input type="number" class="form-control form-control-sm" id="tax" value="0" min="0" step="0.01" onchange="calculateTotal()">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h3>Total: <?php echo $currency_symbol; ?> <span id="total">0.00</span></h3>
                                                <textarea class="form-control mt-2" id="notes" placeholder="Additional notes..." rows="2"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-3">
                                        <button type="button" class="btn btn-primary btn-lg" onclick="createBill()">
                                            <i class="fas fa-save"></i> Generate Bill
                                        </button>
                                        <button type="button" class="btn btn-secondary btn-lg" onclick="resetForm()">
                                            <i class="fas fa-undo"></i> Reset
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Patient Info & Summary -->
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0"><i class="fas fa-user"></i> Patient Information</h5>
                            </div>
                            <div class="card-body" id="patientInfo">
                                <p class="text-muted">Select a patient to view details</p>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0"><i class="fas fa-list"></i> Current Bill Items</h5>
                            </div>
                            <div class="card-body" id="billSummary">
                                <p class="text-muted">No items added yet</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Bill History Tab -->
            <div class="tab-pane fade" id="history">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-history"></i> Recent Bills</h5>
                    </div>
                    <div class="card-body">
                        <table id="billsTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Bill #</th>
                                    <th>Patient</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($bill = mysqli_fetch_assoc($recent_bills)): ?>
                                <tr>
                                    <td><?php echo $bill['bill_number']; ?></td>
                                    <td><?php echo $bill['first_name'] . ' ' . $bill['last_name']; ?><br>
                                        <small><?php echo $bill['patient_number']; ?></small>
                                    </td>
                                    <td><?php echo date('d-m-Y H:i', strtotime($bill['bill_date'])); ?></td>
                                    <td><?php echo format_currency($bill['net_amount']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $bill['payment_status'] == 'paid' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($bill['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_bill.php?id=<?php echo $bill['bill_id']; ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <a href="print_bill.php?id=<?php echo $bill['bill_id']; ?>" target="_blank" class="btn btn-sm btn-primary">
                                            <i class="fas fa-print"></i> Print
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <script>
        // Data arrays
        const consultations = <?php echo json_encode($consultations); ?>;
        const labTests = <?php echo json_encode($lab_tests); ?>;
        const medicines = <?php echo json_encode($medicines); ?>;
        const procedures = <?php echo json_encode($procedures); ?>;
        const hospitalServices = <?php echo json_encode($hospital_services); ?>;
        const currencySymbol = <?php echo json_encode($currency_symbol); ?>;
        let patientServices = { appointments: [], lab_tests: [] };
        
        let items = [];
        let itemId = 0;
        
        $(document).ready(function() {
            // Initialize Select2
            $('.select2').select2({
                width: '100%',
                placeholder: 'Search patient...'
            });
            $('#item_select').select2({
                width: '100%',
                placeholder: 'Choose item...'
            });
            
            // Initialize DataTable
            $('#billsTable').DataTable({
                order: [[2, 'desc']],
                pageLength: 10
            });
            
            // Load items when type changes
            $('#item_type').change(function() {
                const type = $(this).val();
                loadItems(type);
            });
            
            // Load initial items from selected default type
            loadItems($('#item_type').val());
        });
        
        function loadItems(type) {
            let data = [];
            
            switch(type) {
                case 'appointment':
                    data = patientServices.appointments;
                    break;
                case 'lab_test':
                    data = patientServices.lab_tests;
                    break;
                case 'medicine':
                    data = medicines;
                    break;
                case 'procedure':
                    data = procedures;
                    break;
                case 'hospital_service':
                    data = hospitalServices;
                    break;
                default:
                    $('#item_select').html('<option value="">Choose item...</option>').trigger('change');
                    return;
            }
            
            let options = '<option value="">Choose item...</option>';
            if ((type === 'appointment' || type === 'lab_test') && !$('#patient_id').val()) {
                options = '<option value="">Select patient first...</option>';
                $('#item_select').html(options).trigger('change');
                return;
            }
            if ((type === 'appointment' || type === 'lab_test') && data.length === 0) {
                options = '<option value="">No billable services found</option>';
                $('#item_select').html(options).trigger('change');
                return;
            }
            data.forEach(function(item) {
                options += `<option value="${item.id}" data-price="${item.price}" data-name="${item.name}">
                    ${item.name} - ${currencySymbol} ${parseFloat(item.price).toFixed(2)}
                </option>`;
            });
            
            $('#item_select').html(options).trigger('change');
        }
        
        function addSelectedItem() {
            const type = $('#item_type').val();
            
            if (type === 'other') {
                addCustomItem();
                return;
            }
            
            const itemId = $('#item_select').val();
            const quantity = parseInt($('#item_quantity').val());
            const selected = $('#item_select option:selected');
            if (isNaN(quantity) || quantity <= 0) {
                alert('Quantity must be greater than 0');
                return;
            }
            
            if (!itemId) {
                const customDesc = $('#custom_desc').val().trim();
                const customPrice = parseFloat($('#custom_price').val());
                if (customDesc && !isNaN(customPrice) && customPrice > 0) {
                    addCustomItem();
                    return;
                }
                alert('Please select an item from dropdown, or use Custom Item section below.');
                return;
            }
            
            const price = parseFloat(selected.data('price'));
            const name = selected.data('name');
            
            addItemToList({
                id: itemId,
                tempId: 'item_' + Date.now() + Math.random(),
                type: type,
                name: name,
                quantity: quantity,
                price: price,
                description: name
            });
        }
        
        function addCustomItem() {
            const desc = $('#custom_desc').val().trim();
            const price = parseFloat($('#custom_price').val());
            const qty = parseInt($('#custom_qty').val());
            
            if (!desc) {
                alert('Please enter a description');
                return;
            }
            
            if (isNaN(price) || price <= 0) {
                alert('Please enter a valid price');
                return;
            }
            if (isNaN(qty) || qty <= 0) {
                alert('Quantity must be greater than 0');
                return;
            }
            
            addItemToList({
                id: 'custom_' + Date.now(),
                tempId: 'custom_' + Date.now() + Math.random(),
                type: 'other',
                name: desc,
                quantity: qty,
                price: price,
                description: desc
            });
            
            // Clear fields
            $('#custom_desc').val('');
            $('#custom_price').val('');
        }
        
        function addItemToList(item) {
            items.push(item);
            renderItems();
            calculateTotal();
            updateSummary();
        }
        
        function renderItems() {
            if (items.length === 0) {
                $('#itemsList').html('<p class="text-muted">No items added yet</p>');
                return;
            }
            
            let html = '<h6>Bill Items:</h6>';
            items.forEach((item, index) => {
                html += `
                    <div class="bill-item">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>${item.name}</strong><br>
                                <small class="text-muted">${item.type.replace('_', ' ')}</small>
                            </div>
                            <div class="col-md-3">
                                Qty: ${item.quantity} x ${currencySymbol} ${item.price.toFixed(2)}
                            </div>
                            <div class="col-md-2">
                                <strong>${currencySymbol} ${(item.quantity * item.price).toFixed(2)}</strong>
                            </div>
                            <div class="col-md-1">
                                <button class="btn btn-sm btn-danger" onclick="removeItem(${index})">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            $('#itemsList').html(html);
        }
        
        function removeItem(index) {
            items.splice(index, 1);
            renderItems();
            calculateTotal();
            updateSummary();
        }
        
        function calculateTotal() {
            let subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            let discount = parseFloat($('#discount').val()) || 0;
            let tax = parseFloat($('#tax').val()) || 0;
            if (discount < 0) {
                discount = 0;
                $('#discount').val('0');
            }
            if (tax < 0) {
                tax = 0;
                $('#tax').val('0');
            }
            if (discount > (subtotal + tax)) {
                discount = subtotal + tax;
                $('#discount').val(discount.toFixed(2));
            }
            let total = subtotal - discount + tax;
            
            $('#subtotal').text(subtotal.toFixed(2));
            $('#total').text(total.toFixed(2));
        }
        
        function updateSummary() {
            if (items.length === 0) {
                $('#billSummary').html('<p class="text-muted">No items added yet</p>');
                return;
            }
            
            let html = '<div class="list-group">';
            items.forEach(item => {
                html += `
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between">
                            <span>${item.name}</span>
                            <strong>${currencySymbol} ${(item.quantity * item.price).toFixed(2)}</strong>
                        </div>
                        <small class="text-muted">${item.quantity} x ${currencySymbol} ${item.price.toFixed(2)}</small>
                    </div>
                `;
            });
            html += '</div>';
            $('#billSummary').html(html);
        }
        
        $('#patient_id').change(function() {
            const patientId = $(this).val();
            if (patientId) {
                $.ajax({
                    url: 'get_patient_details.php',
                    method: 'POST',
                    data: { patient_id: patientId },
                    dataType: 'json',
                    success: function(data) {
                        if (data) {
                            let html = `
                                <h6>${data.first_name} ${data.last_name}</h6>
                                <p class="mb-1"><strong>Patient #:</strong> ${data.patient_number}</p>
                                <p class="mb-1"><strong>Phone:</strong> ${data.phone}</p>
                                <p class="mb-1"><strong>Email:</strong> ${data.email || 'N/A'}</p>
                                <p class="mb-0"><strong>Blood Group:</strong> ${data.blood_group || 'N/A'}</p>
                            `;
                            $('#patientInfo').html(html);
                        }
                    }
                });
                $.ajax({
                    url: 'get_billable_services.php',
                    method: 'POST',
                    data: { patient_id: patientId },
                    dataType: 'json',
                    success: function(data) {
                        patientServices = data || { appointments: [], lab_tests: [] };
                        loadItems($('#item_type').val());
                    },
                    error: function() {
                        patientServices = { appointments: [], lab_tests: [] };
                        loadItems($('#item_type').val());
                    }
                });
            } else {
                $('#patientInfo').html('<p class="text-muted">Select a patient to view details</p>');
                patientServices = { appointments: [], lab_tests: [] };
                loadItems($('#item_type').val());
            }
        });
        
        function createBill() {
            const patientId = $('#patient_id').val();
            
            if (!patientId) {
                alert('Please select a patient');
                return;
            }
            
            if (items.length === 0) {
                alert('Please add at least one item');
                return;
            }
            
            const billItems = items.map(item => ({
                id: item.id,
                type: item.type,
                description: item.description,
                quantity: item.quantity,
                price: item.price
            }));

            const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const discount = parseFloat($('#discount').val()) || 0;
            const tax = parseFloat($('#tax').val()) || 0;
            if (discount < 0 || tax < 0) {
                alert('Discount and tax cannot be negative');
                return;
            }
            if (discount > (subtotal + tax)) {
                alert('Discount cannot exceed total service cost');
                return;
            }
            
            const formData = {
                create_bill: true,
                patient_id: patientId,
                items: JSON.stringify(billItems),
                discount: $('#discount').val() || '0',
                tax: $('#tax').val() || '0',
                notes: $('#notes').val() || '',
                insurance_claim_id: $('#insurance_claim_id').val() || ''
            };
            
            // Show loading
            const btn = document.querySelector('button[onclick="createBill()"]');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
            btn.disabled = true;
            
            $.ajax({
                url: 'billing.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('Bill created successfully!\nBill Number: ' + response.bill_number);
                        window.open('print_bill.php?id=' + response.bill_id, '_blank');
                        setTimeout(function() {
                            window.location.href = 'view_bill.php?id=' + response.bill_id;
                        }, 1000);
                    } else {
                        alert('Error: ' + (response.message || 'Unknown error'));
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error: ' + error);
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }
            });
        }
        
        function resetForm() {
            items = [];
            renderItems();
            updateSummary();
            $('#patient_id').val(null).trigger('change');
            $('#insurance_claim_id').val('');
            $('#discount').val('0');
            $('#tax').val('0');
            $('#notes').val('');
            $('#subtotal').text('0.00');
            $('#total').text('0.00');
        }
    </script>
</body>
</html>
