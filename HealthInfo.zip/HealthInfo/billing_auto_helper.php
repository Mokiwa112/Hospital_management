<?php

if (!function_exists('is_patient_uninsured')) {
    function is_patient_uninsured($conn, $patient_id) {
        $patient_id = (int)$patient_id;
        if ($patient_id <= 0) {
            return false;
        }

        $insurance_col = firstExistingColumn('patients', ['insurance_provider_id', 'insurance_id']);
        if ($insurance_col === null) {
            return true;
        }

        $q = mysqli_query(
            $conn,
            "SELECT $insurance_col AS insurance_ref
             FROM patients
             WHERE patient_id = $patient_id
             LIMIT 1"
        );
        if (!$q || mysqli_num_rows($q) === 0) {
            return false;
        }

        $row = mysqli_fetch_assoc($q);
        return empty($row['insurance_ref']) || (int)$row['insurance_ref'] === 0;
    }
}

if (!function_exists('send_patient_service_summary_email')) {
    function send_patient_service_summary_email($conn, $patient_id, $bill_number, $items, $totals = []) {
        $patient_id = (int)$patient_id;
        if ($patient_id <= 0 || empty($bill_number) || empty($items) || !is_array($items)) {
            return false;
        }

        $patient_q = mysqli_query(
            $conn,
            "SELECT first_name, last_name, email
             FROM patients
             WHERE patient_id = $patient_id
             LIMIT 1"
        );
        if (!$patient_q || mysqli_num_rows($patient_q) === 0) {
            return false;
        }
        $patient = mysqli_fetch_assoc($patient_q);
        $email = trim((string)($patient['email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        $first_name = trim((string)($patient['first_name'] ?? 'Patient'));
        $last_name = trim((string)($patient['last_name'] ?? ''));
        $full_name = trim($first_name . ' ' . $last_name);

        $subtotal = (float)($totals['subtotal'] ?? 0);
        $discount = (float)($totals['discount'] ?? 0);
        $tax = (float)($totals['tax'] ?? 0);
        $net_amount = (float)($totals['net_amount'] ?? $subtotal - $discount + $tax);

        $lines = [];
        foreach ($items as $item) {
            $desc = trim((string)($item['description'] ?? 'Service'));
            $qty = max(1, (int)($item['quantity'] ?? 1));
            $unit = (float)($item['unit_price'] ?? 0);
            $line_total = $qty * $unit;
            $lines[] = "- " . $desc . " | Qty: " . $qty . " | Unit: " . format_currency($unit) . " | Total: " . format_currency($line_total);
        }

        $subject = SITE_NAME . " - Service Details (Bill " . $bill_number . ")";
        $message = "Hello " . ($full_name !== '' ? $full_name : 'Patient') . ",\n\n";
        $message .= "You received the following hospital services:\n";
        $message .= implode("\n", $lines) . "\n\n";
        $message .= "Bill Number: " . $bill_number . "\n";
        $message .= "Subtotal: " . format_currency($subtotal) . "\n";
        if ($discount > 0) {
            $message .= "Discount: -" . format_currency($discount) . "\n";
        }
        if ($tax > 0) {
            $message .= "Tax: +" . format_currency($tax) . "\n";
        }
        $message .= "Net Amount: " . format_currency($net_amount) . "\n\n";
        $message .= "To view records, login to Patient Portal:\n";
        $message .= SITE_URL . "/patient_portal.php\n\n";
        $message .= SITE_NAME;

        return send_system_email($email, $subject, $message);
    }
}

if (!function_exists('get_unbilled_completed_services')) {
    function get_unbilled_completed_services($conn, $patient_id, $include_requested_lab = false) {
        $patient_id = (int)$patient_id;
        if ($patient_id <= 0) {
            return [];
        }

        $items = [];
        $appointment_price_col = firstExistingColumn('appointments', ['consultation_fee', 'fee', 'amount', 'price']);
        $appointment_reason_col = tableHasColumn('appointments', 'reason');
        $appt_price_expr = $appointment_price_col ? "COALESCE(a.$appointment_price_col, 50000.00)" : "50000.00";
        $appt_reason_select = $appointment_reason_col ? "a.reason" : "'' AS reason";

        $appt_query = "SELECT a.appointment_id, a.appointment_date, $appt_reason_select, $appt_price_expr AS service_price
                       FROM appointments a
                       WHERE a.patient_id = $patient_id
                         AND a.status = 'completed'
                         AND NOT EXISTS (
                            SELECT 1
                            FROM billing_items bi
                            JOIN billing b ON b.bill_id = bi.bill_id
                            WHERE bi.item_type IN ('appointment', 'consultation')
                              AND bi.item_id = a.appointment_id
                              AND b.patient_id = $patient_id
                        )";
        $appt_result = mysqli_query($conn, $appt_query);
        if ($appt_result) {
            while ($row = mysqli_fetch_assoc($appt_result)) {
                $description = 'Consultation - ' . date('d M Y', strtotime($row['appointment_date']));
                if (!empty($row['reason'])) {
                    $description .= ' (' . $row['reason'] . ')';
                }
                $items[] = [
                    'type' => 'consultation',
                    'item_id' => (int)$row['appointment_id'],
                    'description' => $description,
                    'quantity' => 1,
                    'unit_price' => (float)$row['service_price']
                ];
            }
        }

        $lab_status_col = tableHasColumn('lab_requests', 'status');
        $lab_cost_col = firstExistingColumn('lab_tests', ['cost', 'price', 'amount']);
        $lab_price_expr = $lab_cost_col ? "COALESCE(lt.$lab_cost_col, 0)" : "0";
        $lab_where = "lr.patient_id = $patient_id";
        if ($lab_status_col) {
            if ($include_requested_lab) {
                $lab_where .= " AND lr.status IN ('pending', 'processing', 'completed')";
            } else {
                $lab_where .= " AND lr.status = 'completed'";
            }
        }

        $lab_query = "SELECT lr.request_id, lr.request_date, lt.test_name, $lab_price_expr AS service_price
                      FROM lab_requests lr
                      JOIN lab_tests lt ON lt.test_id = lr.test_id
                      WHERE $lab_where
                        AND NOT EXISTS (
                            SELECT 1
                            FROM billing_items bi
                            JOIN billing b ON b.bill_id = bi.bill_id
                            WHERE bi.item_type = 'lab_test'
                              AND bi.item_id = lr.request_id
                              AND b.patient_id = $patient_id
                        )";
        $lab_result = mysqli_query($conn, $lab_query);
        if ($lab_result) {
            while ($row = mysqli_fetch_assoc($lab_result)) {
                $items[] = [
                    'type' => 'lab_test',
                    'item_id' => (int)$row['request_id'],
                    'description' => $row['test_name'] . ' - ' . date('d M Y', strtotime($row['request_date'])),
                    'quantity' => 1,
                    'unit_price' => (float)$row['service_price']
                ];
            }
        }

        return $items;
    }
}

if (!function_exists('create_auto_bill_for_uninsured_patient')) {
    function create_auto_bill_for_uninsured_patient($conn, $patient_id, $created_by, $notes = '', $options = []) {
        $patient_id = (int)$patient_id;
        $created_by = (int)$created_by;
        $auto_billing_enabled = (bool)get_system_setting('auto_billing_uninsured', true);
        $include_requested_lab = !empty($options['include_requested_lab']);

        if (!$auto_billing_enabled) {
            return ['created' => false, 'reason' => 'auto_billing_disabled'];
        }

        if ($patient_id <= 0) {
            return ['created' => false, 'reason' => 'invalid_patient'];
        }
        if (!is_patient_uninsured($conn, $patient_id)) {
            return ['created' => false, 'reason' => 'insured_patient'];
        }

        $items = get_unbilled_completed_services($conn, $patient_id, $include_requested_lab);
        if (empty($items)) {
            return ['created' => false, 'reason' => 'no_unbilled_services'];
        }

        $bill_number = generateUniqueId('BILL', 'billing', 'bill_number');
        $total_amount = 0;
        foreach ($items as $item) {
            $total_amount += ((float)$item['unit_price'] * (int)$item['quantity']);
        }

        mysqli_begin_transaction($conn);
        try {
            $safe_notes = sanitize($notes);
            $columns = ['bill_number', 'patient_id', 'total_amount', 'discount', 'tax', 'net_amount'];
            $values = ["'$bill_number'", $patient_id, $total_amount, 0, 0, $total_amount];
            if (tableHasColumn('billing', 'notes')) {
                $columns[] = 'notes';
                $values[] = "'$safe_notes'";
            }
            if (tableHasColumn('billing', 'created_by')) {
                $columns[] = 'created_by';
                $values[] = $created_by;
            }

            $insert_bill = "INSERT INTO billing (" . implode(', ', $columns) . ")
                            VALUES (" . implode(', ', $values) . ")";
            if (!mysqli_query($conn, $insert_bill)) {
                throw new Exception(mysqli_error($conn));
            }
            $bill_id = (int)mysqli_insert_id($conn);

            foreach ($items as $item) {
                $item_type = sanitize($item['type']);
                $item_id = (int)$item['item_id'];
                $description = sanitize($item['description']);
                $quantity = (int)$item['quantity'];
                $unit_price = (float)$item['unit_price'];
                $total_price = $quantity * $unit_price;

                $insert_item = "INSERT INTO billing_items (bill_id, item_type, item_id, description, quantity, unit_price, total_price)
                                VALUES ($bill_id, '$item_type', $item_id, '$description', $quantity, $unit_price, $total_price)";
                if (!mysqli_query($conn, $insert_item)) {
                    throw new Exception(mysqli_error($conn));
                }
            }

            mysqli_commit($conn);

            @send_patient_service_summary_email(
                $conn,
                $patient_id,
                $bill_number,
                $items,
                [
                    'subtotal' => $total_amount,
                    'discount' => 0,
                    'tax' => 0,
                    'net_amount' => $total_amount
                ]
            );

            return [
                'created' => true,
                'bill_id' => $bill_id,
                'bill_number' => $bill_number
            ];
        } catch (Exception $e) {
            mysqli_rollback($conn);
            return [
                'created' => false,
                'reason' => 'insert_failed',
                'error' => $e->getMessage()
            ];
        }
    }
}

?>
