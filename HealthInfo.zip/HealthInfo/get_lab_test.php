<?php
require_once 'config.php';

$conn = getConnection();
$query = "SELECT test_id as id, test_name as name, cost as price FROM lab_tests";
$result = mysqli_query($conn, $query);

$tests = [];
while($row = mysqli_fetch_assoc($result)) {
    $tests[] = $row;
}

echo json_encode($tests);
mysqli_close($conn);
?>