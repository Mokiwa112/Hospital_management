<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();

// Handle worker operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_worker'])) {
        $username = sanitize($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $user_type = sanitize($_POST['user_type']);
        $department = sanitize($_POST['department']);
        $employee_id = generateUniqueId('EMP', 'users', 'employee_id');
        
        if (!isValidPhoneNumber($phone)) {
            $_SESSION['error'] = getPhoneValidationMessage();
        }
        // Check if username exists
        else {
            $check = mysqli_query($conn, "SELECT user_id FROM users WHERE username = '$username'");
            if (mysqli_num_rows($check) > 0) {
            $_SESSION['error'] = "Username already exists";
            } else {
                $query = "INSERT INTO users (username, password, full_name, email, phone, address, user_type, department, employee_id) 
                          VALUES ('$username', '$password', '$full_name', '$email', '$phone', '$address', '$user_type', '$department', '$employee_id')";
                
                if (mysqli_query($conn, $query)) {
                    $_SESSION['success'] = "Worker added successfully! Employee ID: $employee_id";
                } else {
                    $_SESSION['error'] = "Error: " . mysqli_error($conn);
                }
            }
        }
        redirect('workers.php');
    }
    
    elseif (isset($_POST['update_worker'])) {
        $user_id = sanitize($_POST['user_id']);
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $department = sanitize($_POST['department']);
        $user_type = sanitize($_POST['user_type']);

        if (!isValidPhoneNumber($phone)) {
            $_SESSION['error'] = getPhoneValidationMessage();
            redirect('workers.php');
        }
        
        $query = "UPDATE users SET 
                  full_name='$full_name', 
                  email='$email', 
                  phone='$phone', 
                  address='$address', 
                  department='$department',
                  user_type='$user_type'
                  WHERE user_id=$user_id";
        
        if (mysqli_query($conn, $query)) {
            $_SESSION['success'] = "Worker updated successfully!";
        } else {
            $_SESSION['error'] = "Error: " . mysqli_error($conn);
        }
        redirect('workers.php');
    }
    
    elseif (isset($_POST['update_attendance'])) {
        $user_id = sanitize($_POST['user_id']);
        $date = sanitize($_POST['date']);
        $status = sanitize($_POST['status']);
        $check_in = sanitize($_POST['check_in']);
        $check_out = sanitize($_POST['check_out']);
        
        // Check if attendance record exists
        $check = mysqli_query($conn, "SELECT * FROM attendance WHERE user_id=$user_id AND date='$date'");
        if (mysqli_num_rows($check) > 0) {
            $query = "UPDATE attendance SET status='$status', check_in='$check_in', check_out='$check_out' 
                      WHERE user_id=$user_id AND date='$date'";
        } else {
            $query = "INSERT INTO attendance (user_id, date, status, check_in, check_out) 
                      VALUES ($user_id, '$date', '$status', '$check_in', '$check_out')";
        }
        
        mysqli_query($conn, $query);
        $_SESSION['success'] = "Attendance updated successfully!";
        redirect('workers.php');
    }
    
    elseif (isset($_POST['delete_worker'])) {
        $user_id = sanitize($_POST['user_id']);
        
        // Check if user has any related records
        $check = mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE doctor_id=$user_id");
        $appointments = mysqli_fetch_assoc($check)['count'];
        
        if ($appointments > 0) {
            $_SESSION['error'] = "Cannot delete user with existing appointments";
        } else {
            $query = "DELETE FROM users WHERE user_id=$user_id";
            if (mysqli_query($conn, $query)) {
                $_SESSION['success'] = "Worker deleted successfully!";
            } else {
                $_SESSION['error'] = "Error: " . mysqli_error($conn);
            }
        }
        redirect('workers.php');
    }
}

// Fetch all workers
$workers = mysqli_query($conn, "SELECT * FROM users ORDER BY user_type, full_name");

// Fetch attendance for today
$today = date('Y-m-d');
$attendance = mysqli_query($conn, 
    "SELECT a.*, u.full_name, u.user_type, u.employee_id 
     FROM attendance a 
     JOIN users u ON a.user_id = u.user_id 
     WHERE a.date = '$today' 
     ORDER BY a.check_in"
);

// Get worker statistics
$stats = mysqli_query($conn, 
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN user_type = 'doctor' THEN 1 ELSE 0 END) as doctors,
        SUM(CASE WHEN user_type = 'nurse' THEN 1 ELSE 0 END) as nurses,
        SUM(CASE WHEN user_type = 'receptionist' THEN 1 ELSE 0 END) as receptionists,
        SUM(CASE WHEN user_type = 'lab_tech' THEN 1 ELSE 0 END) as lab_techs,
        SUM(CASE WHEN user_type = 'pharmacist' THEN 1 ELSE 0 END) as pharmacists,
        SUM(CASE WHEN user_type = 'accountant' THEN 1 ELSE 0 END) as accountants,
        SUM(CASE WHEN user_type = 'hr_admin' THEN 1 ELSE 0 END) as hr_admins,
        SUM(CASE WHEN user_type = 'admin' THEN 1 ELSE 0 END) as admins
     FROM users"
);
$worker_stats = mysqli_fetch_assoc($stats);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Portal - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .worker-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            margin-bottom: 20px;
        }
        .worker-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .worker-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: bold;
            margin: 0 auto 10px;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-present {
            background: #d4edda;
            color: #155724;
        }
        .status-absent {
            background: #f8d7da;
            color: #721c24;
        }
        .status-late {
            background: #fff3cd;
            color: #856404;
        }
        .schedule-timeline {
            position: relative;
            padding: 20px 0;
        }
        .timeline-item {
            padding: 10px 20px;
            border-left: 2px solid #007bff;
            position: relative;
            margin-left: 20px;
            margin-bottom: 15px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -8px;
            top: 15px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #007bff;
        }
        .role-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }
        .role-admin { background: #dc3545; color: white; }
        .role-doctor { background: #28a745; color: white; }
        .role-nurse { background: #17a2b8; color: white; }
        .role-receptionist { background: #ffc107; color: #333; }
        .role-lab_tech { background: #007bff; color: white; }
        .role-pharmacist { background: #6c757d; color: white; }
        .role-accountant { background: #6610f2; color: white; }
        .role-hr_admin { background: #198754; color: white; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Alerts -->
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-users-cog"></i> Worker Management</h2>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addWorkerModal">
                    <i class="fas fa-user-plus"></i> Add New Worker
                </button>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5>Total Workers</h5>
                        <h2><?php echo $worker_stats['total'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5>Doctors</h5>
                        <h2><?php echo $worker_stats['doctors'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5>Nurses</h5>
                        <h2><?php echo $worker_stats['nurses'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning">
                    <div class="card-body">
                        <h5>Present Today</h5>
                        <h2><?php echo mysqli_num_rows($attendance); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Workers List -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-list"></i> Workers Directory</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="workersTable" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Employee ID</th>
                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Department</th>
                                        <th>Contact</th>
                                        <th>Status Today</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($workers && mysqli_num_rows($workers) > 0): ?>
                                        <?php while($worker = mysqli_fetch_assoc($workers)): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo htmlspecialchars($worker['employee_id'] ?? 'N/A'); ?></strong>
                                                </td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="worker-avatar me-2" style="width: 40px; height: 40px; font-size: 16px;">
                                                            <?php 
                                                            $first = !empty($worker['full_name']) ? substr($worker['full_name'], 0, 1) : '?';
                                                            $last = !empty($worker['full_name']) && strpos($worker['full_name'], ' ') ? 
                                                                   substr($worker['full_name'], strpos($worker['full_name'], ' ') + 1, 1) : '';
                                                            echo htmlspecialchars($first . $last);
                                                            ?>
                                                        </div>
                                                        <div>
                                                            <strong><?php echo htmlspecialchars($worker['full_name'] ?? 'N/A'); ?></strong><br>
                                                            <small><?php echo htmlspecialchars($worker['email'] ?? 'N/A'); ?></small>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php
                                                    $type = $worker['user_type'] ?? 'unknown';
                                                    $roleClass = '';
                                                    switch($type) {
                                                        case 'admin': $roleClass = 'role-admin'; break;
                                                        case 'doctor': $roleClass = 'role-doctor'; break;
                                                        case 'nurse': $roleClass = 'role-nurse'; break;
                                                        case 'receptionist': $roleClass = 'role-receptionist'; break;
                                                        case 'lab_tech': $roleClass = 'role-lab_tech'; break;
                                                        case 'pharmacist': $roleClass = 'role-pharmacist'; break;
                                                        case 'accountant': $roleClass = 'role-accountant'; break;
                                                        case 'hr_admin': $roleClass = 'role-hr_admin'; break;
                                                        default: $roleClass = 'bg-secondary text-white';
                                                    }
                                                    ?>
                                                    <span class="role-badge <?php echo $roleClass; ?>">
                                                        <?php echo ucfirst(str_replace('_', ' ', $type)); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($worker['department'] ?? 'N/A'); ?></td>
                                                <td>
                                                    <i class="fas fa-phone"></i> <?php echo htmlspecialchars($worker['phone'] ?? 'N/A'); ?><br>
                                                    <?php if(!empty($worker['address'])): ?>
                                                        <small><i class="fas fa-map-marker-alt"></i> 
                                                            <?php echo htmlspecialchars(substr($worker['address'], 0, 30) . (strlen($worker['address'] ?? '') > 30 ? '...' : '')); ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    // Check if worker is checked in today
                                                    $check = mysqli_query($conn, "SELECT * FROM attendance WHERE user_id={$worker['user_id']} AND date='$today'");
                                                    if ($check && mysqli_num_rows($check) > 0) {
                                                        $att = mysqli_fetch_assoc($check);
                                                        $statusClass = $att['status'] == 'present' ? 'status-present' : ($att['status'] == 'late' ? 'status-late' : 'status-absent');
                                                        echo "<span class='status-badge $statusClass'>" . ucfirst($att['status'] ?? 'present') . "</span><br>";
                                                        if (!empty($att['check_in'])) {
                                                            echo "<small>In: " . date('h:i A', strtotime($att['check_in'])) . "</small>";
                                                        }
                                                    } else {
                                                        echo "<span class='status-badge status-absent'>Absent</span>";
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <button class="btn btn-sm btn-info" onclick="viewWorker(<?php echo $worker['user_id']; ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-warning" onclick="editWorker(<?php echo $worker['user_id']; ?>, '<?php echo htmlspecialchars(addslashes($worker['full_name'] ?? '')); ?>', '<?php echo htmlspecialchars(addslashes($worker['email'] ?? '')); ?>', '<?php echo htmlspecialchars(addslashes($worker['phone'] ?? '')); ?>', '<?php echo htmlspecialchars(addslashes($worker['address'] ?? '')); ?>', '<?php echo $worker['department'] ?? ''; ?>', '<?php echo $worker['user_type'] ?? ''; ?>')">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-success" onclick="markAttendance(<?php echo $worker['user_id']; ?>, '<?php echo htmlspecialchars(addslashes($worker['full_name'] ?? '')); ?>')">
                                                            <i class="fas fa-clock"></i>
                                                        </button>
                                                        <?php if($worker['user_id'] != $_SESSION['user_id']): ?>
                                                            <button class="btn btn-sm btn-danger" onclick="deleteWorker(<?php echo $worker['user_id']; ?>)">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center">No workers found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Today's Attendance & Schedule -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-clock"></i> Today's Attendance (<?php echo date('d-m-Y'); ?>)</h5>
                    </div>
                    <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                        <?php if ($attendance && mysqli_num_rows($attendance) > 0): ?>
                            <div class="schedule-timeline">
                                <?php while($att = mysqli_fetch_assoc($attendance)): ?>
                                    <div class="timeline-item">
                                        <strong><?php echo htmlspecialchars($att['full_name'] ?? 'N/A'); ?></strong>
                                        <span class="role-badge bg-info text-white" style="margin-left: 5px;">
                                            <?php echo ucfirst(str_replace('_', ' ', $att['user_type'] ?? 'staff')); ?>
                                        </span>
                                        <div class="mt-1">
                                            <small>
                                                <i class="fas fa-sign-in-alt text-success"></i> 
                                                <?php echo !empty($att['check_in']) ? date('h:i A', strtotime($att['check_in'])) : 'Not checked in'; ?>
                                                <?php if(!empty($att['check_out'])): ?>
                                                    <br><i class="fas fa-sign-out-alt text-danger"></i> 
                                                    <?php echo date('h:i A', strtotime($att['check_out'])); ?>
                                                <?php endif; ?>
                                                <br>
                                                <span class="badge bg-<?php echo $att['status'] == 'present' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($att['status'] ?? 'present'); ?>
                                                </span>
                                            </small>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-center text-muted">No attendance records for today</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Worker Modal -->
    <div class="modal fade" id="addWorkerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-user-plus"></i> Add New Worker</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Username *</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password *</label>
                            <input type="password" class="form-control" name="password" required 
                                   pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                                   title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters">
                            <small class="text-muted">Minimum 8 characters with at least one uppercase, one lowercase, and one number</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" class="form-control" name="full_name" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone *</label>
                                    <input type="tel" class="form-control" name="phone" required pattern="^(0\d{9}|\+\d{11,12})$" title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" name="address" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">User Type *</label>
                                <select class="form-control" name="user_type" required>
                                    <option value="">Select Type</option>
                                    <option value="doctor">Doctor</option>
                                    <option value="nurse">Nurse</option>
                                    <option value="receptionist">Receptionist</option>
                                    <option value="lab_tech">Lab Technician</option>
                                    <option value="pharmacist">Pharmacist</option>
                                    <option value="accountant">Accountant</option>
                                    <option value="hr_admin">HR Admin</option>
                                    <option value="admin">Administrator</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Department</label>
                                <input type="text" class="form-control" name="department" 
                                       placeholder="e.g., Cardiology, ICU, Pharmacy">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_worker" class="btn btn-primary">Add Worker</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Edit Worker Modal -->
    <div class="modal fade" id="editWorkerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Worker</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="edit_user_id">
                        <div class="mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" class="form-control" name="full_name" id="edit_full_name" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" id="edit_email" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone *</label>
                                <input type="tel" class="form-control" name="phone" id="edit_phone" required
                                       pattern="^(0\d{9}|\+\d{11,12})$"
                                       title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" name="address" id="edit_address" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">User Type *</label>
                                <select class="form-control" name="user_type" id="edit_user_type" required>
                                    <option value="doctor">Doctor</option>
                                    <option value="nurse">Nurse</option>
                                    <option value="receptionist">Receptionist</option>
                                    <option value="lab_tech">Lab Technician</option>
                                    <option value="pharmacist">Pharmacist</option>
                                    <option value="accountant">Accountant</option>
                                    <option value="hr_admin">HR Admin</option>
                                    <option value="admin">Administrator</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Department</label>
                                <input type="text" class="form-control" name="department" id="edit_department">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_worker" class="btn btn-warning">Update Worker</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Attendance Modal -->
    <div class="modal fade" id="attendanceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-clock"></i> Mark Attendance</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="attendance_user_id">
                        <h5 id="attendance_worker_name" class="mb-3"></h5>
                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" name="date" value="<?php echo date('Y-m-d'); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-control" name="status" id="attendance_status" required>
                                <option value="present">Present</option>
                                <option value="absent">Absent</option>
                                <option value="late">Late</option>
                                <option value="half_day">Half Day</option>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Check In Time</label>
                                <input type="time" class="form-control" name="check_in" value="<?php echo date('H:i'); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Check Out Time</label>
                                <input type="time" class="form-control" name="check_out">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_attendance" class="btn btn-success">Save Attendance</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Confirm Delete</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="delete_user_id">
                        <p>Are you sure you want to delete this worker? This action cannot be undone.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="delete_worker" class="btn btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#workersTable').DataTable({
                order: [[2, 'asc'], [1, 'asc']],
                pageLength: 10,
                language: {
                    emptyTable: "No workers found"
                }
            });
        });
        
        function markAttendance(id, name) {
            document.getElementById('attendance_user_id').value = id;
            document.getElementById('attendance_worker_name').innerHTML = '<strong>Worker:</strong> ' + (name || 'Unknown');
            $('#attendanceModal').modal('show');
        }
        
        function editWorker(id, name, email, phone, address, department, userType) {
            document.getElementById('edit_user_id').value = id;
            document.getElementById('edit_full_name').value = name || '';
            document.getElementById('edit_email').value = email || '';
            document.getElementById('edit_phone').value = phone || '';
            document.getElementById('edit_address').value = address || '';
            document.getElementById('edit_department').value = department || '';
            
            // Set user type
            const select = document.getElementById('edit_user_type');
            for (let i = 0; i < select.options.length; i++) {
                if (select.options[i].value === userType) {
                    select.options[i].selected = true;
                    break;
                }
            }
            
            $('#editWorkerModal').modal('show');
        }
        
        function viewWorker(id) {
            window.location.href = 'view_worker.php?id=' + id;
        }
        
        function deleteWorker(id) {
            document.getElementById('delete_user_id').value = id;
            $('#deleteModal').modal('show');
        }
    </script>
</body>
</html>

