<?php
require_once 'config.php';
requireRole('lab_tech'); // Only lab techs can add results

$conn = getConnection();
$user_id = $_SESSION['user_id'];
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch lab request details
$query = "SELECT lr.*, p.first_name, p.last_name, p.patient_number,
          lt.test_name, lt.normal_range, lt.unit
          FROM lab_requests lr
          JOIN patients p ON lr.patient_id = p.patient_id
          JOIN lab_tests lt ON lr.test_id = lt.test_id
          WHERE lr.request_id = $request_id AND lr.status = 'processing'";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Lab request not found or not ready for results";
    header("Location: lab_requests_list.php");
    exit();
}

$lab = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $raw_result_value = trim($_POST['result_value'] ?? '');
    $raw_result_notes = trim($_POST['result_notes'] ?? '');
    $parameter_names = $_POST['parameter_name'] ?? [];
    $parameter_values = $_POST['parameter_value'] ?? [];
    $parameter_units = $_POST['parameter_unit'] ?? [];
    $parameter_ranges = $_POST['parameter_range'] ?? [];
    $parameter_flags = $_POST['parameter_flag'] ?? [];

    $structured_parameters = [];
    $max_rows = max(
        count((array)$parameter_names),
        count((array)$parameter_values),
        count((array)$parameter_units),
        count((array)$parameter_ranges),
        count((array)$parameter_flags)
    );

    for ($i = 0; $i < $max_rows; $i++) {
        $name = trim($parameter_names[$i] ?? '');
        $value = trim($parameter_values[$i] ?? '');
        $unit = trim($parameter_units[$i] ?? '');
        $range = trim($parameter_ranges[$i] ?? '');
        $flag = trim($parameter_flags[$i] ?? '');

        if ($name === '' && $value === '' && $unit === '' && $range === '' && $flag === '') {
            continue;
        }

        if ($name === '' || $value === '') {
            $error = "Each result row must have both parameter name and value.";
            break;
        }

        $structured_parameters[] = [
            'name' => $name,
            'value' => $value,
            'unit' => $unit,
            'reference' => $range,
            'flag' => $flag
        ];
    }

    if (!isset($error)) {
        if ($raw_result_value === '' && empty($structured_parameters)) {
            $error = "Enter either a summary result value or at least one parameter row.";
        }
    }

    if (!isset($error)) {
        $summary_value = $raw_result_value;
        if (empty($summary_value) && !empty($structured_parameters)) {
            if (count($structured_parameters) === 1) {
                $only = $structured_parameters[0];
                $summary_value = $only['name'] . ': ' . $only['value'];
                if (!empty($only['unit']) && strtolower($only['unit']) !== 'panel') {
                    $summary_value .= ' ' . $only['unit'];
                }
            } else {
                $summary_value = 'Multiple parameters recorded (' . count($structured_parameters) . ')';
            }
        }

        $notes_to_store = $raw_result_notes;
        if (!empty($structured_parameters)) {
            $encoded = json_encode([
                'version' => 1,
                'parameters' => $structured_parameters
            ], JSON_UNESCAPED_UNICODE);
            $notes_to_store = '##LAB_PARAMS_JSON##' . $encoded . "\n" . $raw_result_notes;
        }

        $result_value = sanitize($summary_value);
        $result_notes = sanitize($notes_to_store);
    }

    if (!isset($error)) {
        $updates = [];
        if (tableHasColumn('lab_requests', 'status')) {
            $updates[] = "status = 'completed'";
        }
        if (tableHasColumn('lab_requests', 'result_value')) {
            $updates[] = "result_value = '$result_value'";
        }
        $result_notes_column = firstExistingColumn('lab_requests', ['result_notes', 'lab_notes', 'notes']);
        if ($result_notes_column !== null) {
            $updates[] = "$result_notes_column = '$result_notes'";
        }
        if (tableHasColumn('lab_requests', 'result_date')) {
            $updates[] = "result_date = NOW()";
        }
        if (tableHasColumn('lab_requests', 'lab_tech_id')) {
            $updates[] = "lab_tech_id = $user_id";
        }
        if (empty($updates)) {
            $updates[] = "request_id = request_id";
        }
        $update_query = "UPDATE lab_requests SET " . implode(', ', $updates) . " WHERE request_id = $request_id";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Lab result saved successfully.";
            header("Location: view_lab_request.php?id=$request_id");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Lab Result - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .result-card {
            max-width: 700px;
            margin: 50px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .test-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .normal-range {
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="result-card">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0"><i class="fas fa-flask"></i> Add Lab Result</h4>
            </div>
            <div class="card-body">
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="test-info">
                    <h5>Test Information</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Patient:</strong> <?php echo htmlspecialchars($lab['first_name'] . ' ' . $lab['last_name']); ?></p>
                            <p class="mb-1"><strong>Patient #:</strong> <?php echo htmlspecialchars($lab['patient_number']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Test:</strong> <?php echo htmlspecialchars($lab['test_name']); ?></p>
                            <?php $display_unit = normalizeLabUnit($lab['unit'] ?? ''); ?>
                            <p class="mb-0"><strong>Reference Range:</strong> <?php echo htmlspecialchars($lab['normal_range'] ?: 'Not specified'); ?><?php echo $display_unit !== '' ? ' ' . htmlspecialchars($display_unit) : ''; ?></p>
                        </div>
                    </div>
                </div>
                
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Summary Result (optional if parameter rows are filled)</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="result_value" 
                                   placeholder="Example: Normal, Reactive, Non-reactive">
                            <?php if($display_unit !== ''): ?>
                                <span class="input-group-text"><?php echo htmlspecialchars($display_unit); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="normal-range">
                            <i class="fas fa-info-circle"></i> 
                            Reference range: <?php echo htmlspecialchars($lab['normal_range'] ?: 'Not specified'); ?><?php echo $display_unit !== '' ? ' ' . htmlspecialchars($display_unit) : ''; ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Detailed Parameters (for multi-component tests)</label>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered align-middle" id="result-params-table">
                                <thead class="table-light">
                                    <tr>
                                        <th style="min-width: 160px;">Parameter Name</th>
                                        <th style="min-width: 140px;">Value</th>
                                        <th style="min-width: 110px;">Unit</th>
                                        <th style="min-width: 160px;">Reference Range</th>
                                        <th style="min-width: 120px;">Flag</th>
                                        <th style="width: 60px;">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="text" name="parameter_name[]" class="form-control form-control-sm" placeholder="e.g. Hemoglobin"></td>
                                        <td><input type="text" name="parameter_value[]" class="form-control form-control-sm" placeholder="e.g. 13.8"></td>
                                        <td><input type="text" name="parameter_unit[]" class="form-control form-control-sm" placeholder="g/dL"></td>
                                        <td><input type="text" name="parameter_range[]" class="form-control form-control-sm" placeholder="12 - 16"></td>
                                        <td>
                                            <select name="parameter_flag[]" class="form-select form-select-sm">
                                                <option value="">-</option>
                                                <option value="Low">Low</option>
                                                <option value="Normal">Normal</option>
                                                <option value="High">High</option>
                                                <option value="Critical">Critical</option>
                                            </select>
                                        </td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-outline-danger remove-param-row" title="Remove row">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <button type="button" id="add-param-row" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-plus"></i> Add Parameter Row
                        </button>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Result Notes</label>
                        <textarea class="form-control" name="result_notes" rows="3" 
                                  placeholder="Interpretation and observations"></textarea>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i>
                        Confirm values carefully before submitting.
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fas fa-save"></i> Submit Result
                        </button>
                        <a href="view_lab_request.php?id=<?php echo $request_id; ?>" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function () {
            const tableBody = document.querySelector('#result-params-table tbody');
            const addBtn = document.getElementById('add-param-row');

            function bindRemoveButtons() {
                document.querySelectorAll('.remove-param-row').forEach(function(btn) {
                    btn.onclick = function() {
                        const rows = tableBody.querySelectorAll('tr');
                        if (rows.length === 1) {
                            rows[0].querySelectorAll('input').forEach(function(input) { input.value = ''; });
                            const select = rows[0].querySelector('select');
                            if (select) { select.value = ''; }
                            return;
                        }
                        btn.closest('tr').remove();
                    };
                });
            }

            addBtn.addEventListener('click', function() {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><input type="text" name="parameter_name[]" class="form-control form-control-sm" placeholder="e.g. WBC"></td>
                    <td><input type="text" name="parameter_value[]" class="form-control form-control-sm" placeholder="e.g. 7.4"></td>
                    <td><input type="text" name="parameter_unit[]" class="form-control form-control-sm" placeholder="x10^9/L"></td>
                    <td><input type="text" name="parameter_range[]" class="form-control form-control-sm" placeholder="4 - 11"></td>
                    <td>
                        <select name="parameter_flag[]" class="form-select form-select-sm">
                            <option value="">-</option>
                            <option value="Low">Low</option>
                            <option value="Normal">Normal</option>
                            <option value="High">High</option>
                            <option value="Critical">Critical</option>
                        </select>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-outline-danger remove-param-row" title="Remove row">
                            <i class="fas fa-times"></i>
                        </button>
                    </td>
                `;
                tableBody.appendChild(row);
                bindRemoveButtons();
            });

            bindRemoveButtons();
        })();
    </script>
</body>
</html>
