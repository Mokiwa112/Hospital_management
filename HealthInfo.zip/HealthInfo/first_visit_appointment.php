<?php
require_once 'config.php';

$conn = getConnection();
$error = '';
$success = '';

function ensureFirstVisitOtpTable($conn) {
    static $ready = false;
    if ($ready) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS first_visit_email_otps (
                otp_id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) NOT NULL,
                otp_hash VARCHAR(255) NOT NULL,
                expires_at DATETIME NOT NULL,
                verified TINYINT(1) NOT NULL DEFAULT 0,
                consumed TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_email (email),
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    mysqli_query($conn, $sql);
    $ready = true;
}

function sendOtpEmail($to_email, $recipient_name, $otp_code, $valid_minutes = 10) {
    $subject = SITE_NAME . " - Email Verification Code";
    $safe_name = trim($recipient_name) !== '' ? $recipient_name : 'Patient';
    $message = "Hello " . $safe_name . ",\n\n"
             . "Your verification code is: " . $otp_code . "\n"
             . "This code expires in " . (int)$valid_minutes . " minutes.\n\n"
             . "If you did not request this, ignore this email.\n\n"
             . SITE_NAME;
    return send_system_email($to_email, $subject, $message);
}

ensureFirstVisitOtpTable($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email_otp'])) {
    header('Content-Type: application/json');

    $raw_email = trim((string)($_POST['email'] ?? ''));
    $raw_name = trim((string)($_POST['first_name'] ?? ''));
    if ($raw_email === '' || !filter_var($raw_email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Enter a valid email address first.']);
        exit();
    }

    $email = sanitize($raw_email);
    $name = sanitize($raw_name);
    $otp_code = (string)random_int(100000, 999999);
    $otp_hash = password_hash($otp_code, PASSWORD_DEFAULT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    mysqli_begin_transaction($conn);
    try {
        mysqli_query($conn, "UPDATE first_visit_email_otps SET consumed = 1 WHERE email = '$email' AND consumed = 0");
        $insert = "INSERT INTO first_visit_email_otps (email, otp_hash, expires_at) VALUES ('$email', '$otp_hash', '$expires_at')";
        if (!mysqli_query($conn, $insert)) {
            throw new Exception("Failed to store OTP request.");
        }

        $email_sent = sendOtpEmail($raw_email, $raw_name, $otp_code, 10);

        // Session fallback to avoid false OTP rejects on some hosts.
        $_SESSION['first_visit_otp_email'] = strtolower($raw_email);
        $_SESSION['first_visit_otp_code'] = $otp_code;
        $_SESSION['first_visit_otp_expires'] = time() + (10 * 60);

        mysqli_commit($conn);
        if ($email_sent) {
            echo json_encode(['success' => true, 'message' => 'Verification code sent to your email.']);
        } else {
            $dev_allow = (bool)env_value('OTP_DEV_FALLBACK', DEBUG_MODE ? '1' : '0');
            if ($dev_allow) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Email sending failed on this environment. Use this test OTP: ' . $otp_code
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to send verification code. Check SMTP settings in .env'
                ]);
            }
        }
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

$doctors = mysqli_query(
    $conn,
    "SELECT user_id, full_name, department
     FROM users
     WHERE user_type = 'doctor'
     ORDER BY full_name"
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = sanitize($_POST['first_name'] ?? '');
    $last_name = sanitize($_POST['last_name'] ?? '');
    $date_of_birth = sanitize($_POST['date_of_birth'] ?? '');
    $gender = sanitize($_POST['gender'] ?? '');
    $phone_input = trim((string)($_POST['phone'] ?? ''));
    $phone_normalized = preg_replace('/[\s\-\(\)]/', '', $phone_input);
    if (strpos($phone_normalized, '255') === 0 && strpos($phone_normalized, '+') !== 0) {
        $phone_normalized = '+' . $phone_normalized;
    }
    $phone = sanitize($phone_normalized);
    $email_raw = trim((string)($_POST['email'] ?? ''));
    $email = sanitize($email_raw);
    $email_otp_raw = trim((string)($_POST['email_otp'] ?? ''));
    $email_otp = preg_replace('/\D/', '', $email_otp_raw);
    $doctor_id = (int)($_POST['doctor_id'] ?? 0);
    $appointment_date = sanitize($_POST['appointment_date'] ?? '');
    $appointment_time = sanitize($_POST['appointment_time'] ?? '');
    $reason = sanitize($_POST['reason'] ?? '');

    if ($first_name === '' || $last_name === '' || $date_of_birth === '' || $gender === '' || $phone === '' || $doctor_id <= 0 || $appointment_date === '' || $appointment_time === '' || $reason === '') {
        $error = 'Please fill all required fields.';
    } elseif (!in_array($gender, ['M', 'F', 'O'], true)) {
        $error = 'Invalid gender selected.';
    } elseif (!isValidPhoneNumber($phone_normalized)) {
        $error = getPhoneValidationMessage();
    } elseif ($email_raw === '' || !filter_var($email_raw, FILTER_VALIDATE_EMAIL)) {
        $error = 'Valid email is required for first-visit verification.';
    } elseif (!preg_match('/^\d{6}$/', $email_otp)) {
        $error = 'Enter the 6-digit email verification code.';
    } else {
        $today = date('Y-m-d');
        if ($appointment_date < $today) {
            $error = 'Appointment date cannot be in the past.';
        }
    }

    $matched_otp_id = 0;
    if ($error === '') {
        $otp_rs = mysqli_query(
            $conn,
            "SELECT otp_id, otp_hash
             FROM first_visit_email_otps
             WHERE email = '$email'
               AND consumed = 0
               AND expires_at >= NOW()
             ORDER BY otp_id DESC
             LIMIT 5"
        );
        $otp_valid = false;
        if ($otp_rs) {
            while ($otp_row = mysqli_fetch_assoc($otp_rs)) {
                if (password_verify($email_otp, $otp_row['otp_hash'])) {
                    $otp_valid = true;
                    $matched_otp_id = (int)$otp_row['otp_id'];
                    break;
                }
            }
        }
        if (!$otp_valid) {
            $sess_email = strtolower((string)($_SESSION['first_visit_otp_email'] ?? ''));
            $sess_code = (string)($_SESSION['first_visit_otp_code'] ?? '');
            $sess_exp = (int)($_SESSION['first_visit_otp_expires'] ?? 0);
            if ($sess_email !== '' && $sess_email === strtolower($email_raw) && $sess_code !== '' && hash_equals($sess_code, $email_otp) && $sess_exp >= time()) {
                $otp_valid = true;
            }
        }

        if (!$otp_valid) {
            $error = 'Invalid or expired verification code. Please request a new code and use the latest email.';
        }
    }

    if ($error === '') {
        $existing = mysqli_query(
            $conn,
            "SELECT patient_id, patient_number
             FROM patients
             WHERE phone = '$phone' AND date_of_birth = '$date_of_birth'
             LIMIT 1"
        );
        if ($existing && mysqli_num_rows($existing) > 0) {
            $row = mysqli_fetch_assoc($existing);
            $error = "This patient appears to already exist (Patient #: " . htmlspecialchars($row['patient_number']) . "). Please use Patient Portal login.";
        }
    }

    if ($error === '') {
        $slot_check = mysqli_query(
            $conn,
            "SELECT appointment_id
             FROM appointments
             WHERE doctor_id = $doctor_id
               AND appointment_date = '$appointment_date'
               AND appointment_time = '$appointment_time'
               AND status != 'cancelled'
             LIMIT 1"
        );
        if ($slot_check && mysqli_num_rows($slot_check) > 0) {
            $error = 'Selected time slot is already booked. Please choose another time.';
        }
    }

    if ($error === '') {
        mysqli_begin_transaction($conn);
        try {
            $patient_number = generateUniqueId('PAT', 'patients', 'patient_number');
            $appointment_number = generateUniqueId('APT', 'appointments', 'appointment_number');

            $patient_columns = [
                'patient_number', 'first_name', 'last_name', 'date_of_birth', 'gender', 'phone',
                'email', 'address', 'emergency_contact', 'emergency_contact_name',
                'blood_group', 'allergies', 'patient_type'
            ];
            $patient_values = [
                "'$patient_number'", "'$first_name'", "'$last_name'", "'$date_of_birth'", "'$gender'", "'$phone'",
                "'$email'", "''", "''", "''", "''", "''", "'outpatient'"
            ];

            if (tableHasColumn('patients', 'created_by')) {
                $patient_columns[] = 'created_by';
                $patient_values[] = 'NULL';
            }

            $insert_patient = "INSERT INTO patients (" . implode(', ', $patient_columns) . ")
                               VALUES (" . implode(', ', $patient_values) . ")";
            if (!mysqli_query($conn, $insert_patient)) {
                throw new Exception("Failed to register patient: " . mysqli_error($conn));
            }

            $patient_id = (int)mysqli_insert_id($conn);

            $appointment_columns = [
                'appointment_number', 'patient_id', 'doctor_id', 'appointment_date', 'appointment_time', 'reason'
            ];
            $appointment_values = [
                "'$appointment_number'", $patient_id, $doctor_id, "'$appointment_date'", "'$appointment_time'", "'$reason'"
            ];

            if (tableHasColumn('appointments', 'status')) {
                $appointment_columns[] = 'status';
                $appointment_values[] = "'scheduled'";
            }
            if (tableHasColumn('appointments', 'notes')) {
                $appointment_columns[] = 'notes';
                $appointment_values[] = "'Booked online as first-visit patient'";
            }
            if (tableHasColumn('appointments', 'created_by')) {
                $appointment_columns[] = 'created_by';
                $appointment_values[] = 'NULL';
            }

            $insert_appointment = "INSERT INTO appointments (" . implode(', ', $appointment_columns) . ")
                                   VALUES (" . implode(', ', $appointment_values) . ")";
            if (!mysqli_query($conn, $insert_appointment)) {
                throw new Exception("Failed to create appointment: " . mysqli_error($conn));
            }

            if ($matched_otp_id > 0) {
                mysqli_query($conn, "UPDATE first_visit_email_otps SET verified = 1, consumed = 1 WHERE otp_id = $matched_otp_id");
            }
            unset($_SESSION['first_visit_otp_email'], $_SESSION['first_visit_otp_code'], $_SESSION['first_visit_otp_expires']);

            mysqli_commit($conn);

            if ($email_raw !== '' && filter_var($email_raw, FILTER_VALIDATE_EMAIL)) {
                $subject = SITE_NAME . " - Registration and Appointment Details";
                $message = "Hello " . $first_name . " " . $last_name . ",\n\n"
                         . "Your first-visit appointment has been booked successfully.\n"
                         . "Patient Number: " . $patient_number . "\n"
                         . "Appointment Number: " . $appointment_number . "\n"
                         . "Appointment Date: " . $appointment_date . " " . $appointment_time . "\n\n"
                         . "Patient Portal Login:\n"
                         . "1. Open: " . SITE_URL . "/patient_portal.php\n"
                         . "2. Login using Patient Number and Date of Birth (" . $date_of_birth . ").\n\n"
                         . "Keep this email for your records.\n\n"
                         . SITE_NAME;
                @send_system_email($email_raw, $subject, $message);
            }

            $success = "Appointment booked successfully. Patient Number: " . htmlspecialchars($patient_number) . " | Appointment Number: " . htmlspecialchars($appointment_number) . ". Keep these details for your next visit.";
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First Visit Appointment - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-calendar-plus"></i> First Visit Appointment (No Login)</h4>
                    </div>
                    <div class="card-body">
                        <p class="text-muted">
                            For new patients visiting the hospital for the first time. Existing patients should use
                            <a href="patient_portal.php">Patient Portal</a>.
                        </p>

                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        <?php if ($success !== ''): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <form method="POST" id="firstVisitForm">
                            <h6 class="mb-3">Patient Information</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name *</label>
                                    <input type="text" class="form-control" name="first_name" id="first_name" required value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name *</label>
                                    <input type="text" class="form-control" name="last_name" required value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Date of Birth *</label>
                                    <input type="date" class="form-control" name="date_of_birth" required value="<?php echo htmlspecialchars($_POST['date_of_birth'] ?? ''); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Gender *</label>
                                    <select class="form-control" name="gender" required>
                                        <option value="">Select</option>
                                        <option value="M" <?php echo (($_POST['gender'] ?? '') === 'M') ? 'selected' : ''; ?>>Male</option>
                                        <option value="F" <?php echo (($_POST['gender'] ?? '') === 'F') ? 'selected' : ''; ?>>Female</option>
                                        <option value="O" <?php echo (($_POST['gender'] ?? '') === 'O') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Phone *</label>
                                    <input type="tel" class="form-control" name="phone" required
                                           pattern="^(0\d{9}|\+\d{11,12})$"
                                           title="Use 10 digits starting with 0, or + followed by 11-12 digits"
                                           value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label class="form-label">Email (required for verification) *</label>
                                    <input type="email" class="form-control" name="email" id="emailField" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                                </div>
                                <div class="col-md-4 mb-3 d-grid">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="button" class="btn btn-outline-primary" id="sendOtpBtn">
                                        <i class="fas fa-envelope"></i> Send Verification Code
                                    </button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email Verification Code *</label>
                                    <input type="text" class="form-control" name="email_otp" id="emailOtpField" maxlength="6" inputmode="numeric" required placeholder="Enter 6-digit code">
                                </div>
                                <div class="col-md-6">
                                    <div class="alert alert-info py-2 mt-4 d-none" id="otpMessage"></div>
                                </div>
                            </div>

                            <hr>
                            <h6 class="mb-3">Appointment Information</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Doctor *</label>
                                    <select class="form-control" name="doctor_id" id="doctorSelect" required>
                                        <option value="">Choose doctor</option>
                                        <?php if ($doctors): ?>
                                            <?php while($doc = mysqli_fetch_assoc($doctors)): ?>
                                                <option value="<?php echo (int)$doc['user_id']; ?>" <?php echo ((int)($_POST['doctor_id'] ?? 0) === (int)$doc['user_id']) ? 'selected' : ''; ?>>
                                                    Dr. <?php echo htmlspecialchars($doc['full_name']); ?> (<?php echo htmlspecialchars($doc['department']); ?>)
                                                </option>
                                            <?php endwhile; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Date *</label>
                                    <input type="date" class="form-control" name="appointment_date" id="appointmentDate"
                                           min="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d', strtotime('+3 months')); ?>"
                                           required value="<?php echo htmlspecialchars($_POST['appointment_date'] ?? ''); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Time *</label>
                                    <select class="form-control" name="appointment_time" id="timeSelect" required>
                                        <option value="">Select time</option>
                                        <?php
                                            $time_options = ['09:00:00' => '09:00 AM', '10:00:00' => '10:00 AM', '11:00:00' => '11:00 AM', '14:00:00' => '02:00 PM', '15:00:00' => '03:00 PM', '16:00:00' => '04:00 PM'];
                                            $selected_time = $_POST['appointment_time'] ?? '';
                                            foreach ($time_options as $tv => $label):
                                        ?>
                                            <option value="<?php echo $tv; ?>" <?php echo ($selected_time === $tv) ? 'selected' : ''; ?>><?php echo $label; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Reason for Visit *</label>
                                <input type="text" class="form-control" name="reason" required value="<?php echo htmlspecialchars($_POST['reason'] ?? ''); ?>">
                            </div>

                            <div class="alert alert-info d-none" id="availabilityMessage"></div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-check"></i> Submit Appointment
                                </button>
                                <a href="index.php" class="btn btn-outline-secondary">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $('#doctorSelect, #appointmentDate').on('change', function() {
            const doctorId = $('#doctorSelect').val();
            const date = $('#appointmentDate').val();
            if (!doctorId || !date) {
                return;
            }
            $.ajax({
                url: 'check_availability.php',
                method: 'POST',
                data: { doctor_id: doctorId, date: date },
                dataType: 'json',
                success: function(bookedSlots) {
                    $('#timeSelect option').each(function() {
                        $(this).prop('disabled', false);
                    });
                    (bookedSlots || []).forEach(function(time) {
                        $('#timeSelect option[value="' + time + '"]').prop('disabled', true);
                    });
                    if ((bookedSlots || []).length > 0) {
                        $('#availabilityMessage')
                            .removeClass('d-none')
                            .html('<i class="fas fa-info-circle"></i> Some slots are booked for this doctor on selected date.');
                    } else {
                        $('#availabilityMessage').addClass('d-none').html('');
                    }
                }
            });
        });

        $('#sendOtpBtn').on('click', function() {
            const email = $('#emailField').val().trim();
            const firstName = $('#first_name').val().trim();
            const messageBox = $('#otpMessage');
            if (!email) {
                messageBox.removeClass('d-none alert-info').addClass('alert-danger').text('Enter email first.');
                return;
            }

            const btn = $(this);
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Sending...');
            $.ajax({
                url: 'first_visit_appointment.php',
                method: 'POST',
                dataType: 'json',
                data: {
                    send_email_otp: 1,
                    email: email,
                    first_name: firstName
                },
                success: function(resp) {
                    if (resp && resp.success) {
                        const msg = (resp.message || 'Verification code sent.');
                        messageBox.removeClass('d-none alert-danger').addClass('alert-info').text(msg);
                        const match = msg.match(/(\d{6})/);
                        if (match) {
                            $('#emailOtpField').val(match[1]);
                        }
                    } else {
                        messageBox.removeClass('d-none alert-info').addClass('alert-danger').text((resp && resp.message) ? resp.message : 'Failed to send code.');
                    }
                },
                error: function() {
                    messageBox.removeClass('d-none alert-info').addClass('alert-danger').text('Failed to send code. Try again.');
                },
                complete: function() {
                    btn.prop('disabled', false).html('<i class="fas fa-envelope"></i> Send Verification Code');
                }
            });
        });

        $('#emailOtpField').on('input', function() {
            const digits = ($(this).val() || '').replace(/\D/g, '').slice(0, 6);
            $(this).val(digits);
        });
    </script>
</body>
</html>
