<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch patient data
$query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Patient not found";
    redirect('patients.php');
}

$patient = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $emergency_contact = sanitize($_POST['emergency_contact']);
    $emergency_name = sanitize($_POST['emergency_name']);
    $blood_group = sanitize($_POST['blood_group']);
    $allergies = sanitize($_POST['allergies']);

    if (!isValidPhoneNumber($phone)) {
        $error = getPhoneValidationMessage();
    } elseif (!empty($emergency_contact) && !isValidPhoneNumber($emergency_contact)) {
        $error = "Emergency contact: " . getPhoneValidationMessage();
    } else {
        $update_query = "UPDATE patients SET 
            first_name = '$first_name',
            last_name = '$last_name',
            phone = '$phone',
            email = '$email',
            address = '$address',
            emergency_contact = '$emergency_contact',
            emergency_contact_name = '$emergency_name',
            blood_group = '$blood_group',
            allergies = '$allergies'
            WHERE patient_id = $patient_id";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Patient information updated successfully!";
            redirect("view_patient.php?id=$patient_id");
        } else {
            $error = "Error updating record: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h4><i class="fas fa-edit"></i> Edit Patient: <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control" name="first_name" value="<?php echo $patient['first_name']; ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control" name="last_name" value="<?php echo $patient['last_name']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" class="form-control" name="phone" value="<?php echo $patient['phone']; ?>" required
                                           pattern="^(0\d{9}|\+\d{11,12})$"
                                           title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo $patient['email']; ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="2"><?php echo $patient['address']; ?></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Emergency Contact Name</label>
                                    <input type="text" class="form-control" name="emergency_name" value="<?php echo $patient['emergency_contact_name']; ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Emergency Contact Phone</label>
                                    <input type="tel" class="form-control" name="emergency_contact" value="<?php echo $patient['emergency_contact']; ?>"
                                           pattern="^(0\d{9}|\+\d{11,12})$"
                                           title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Blood Group</label>
                                    <select class="form-control" name="blood_group">
                                        <option value="">Select</option>
                                        <?php
                                        $blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                                        foreach($blood_groups as $bg) {
                                            $selected = ($bg == $patient['blood_group']) ? 'selected' : '';
                                            echo "<option value='$bg' $selected>$bg</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Allergies/Medical History</label>
                                    <textarea class="form-control" name="allergies" rows="2"><?php echo $patient['allergies']; ?></textarea>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Patient
                                </button>
                                <a href="view_patient.php?id=<?php echo $patient_id; ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

