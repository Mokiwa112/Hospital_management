<?php
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id']) || isset($_SESSION['patient_id'])) {
    redirectToRoleHome();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?php echo defined('SITE_NAME') ? SITE_NAME : 'Hospital Management System'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            position: relative;
            background: linear-gradient(135deg, #2f5f9e 0%, #2f7a6a 100%);
            color: white;
            padding: 100px 0;
            text-align: center;
            overflow: hidden;
        }
        .hero-section::before {
            content: "";
            position: absolute;
            inset: 0;
            background: rgba(7, 19, 36, 0.28);
        }
        .hero-section .container {
            position: relative;
            z-index: 1;
        }
        .hero-section h1,
        .hero-section .lead {
            text-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
        }
        .feature-box {
            padding: 30px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            transition: transform 0.3s;
            background: white;
        }
        .feature-box:hover {
            transform: translateY(-10px);
        }
        .feature-icon {
            font-size: 48px;
            color: #2f5f9e;
            margin-bottom: 20px;
        }
        .navbar {
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <h1 class="display-4">Welcome to <?php echo defined('SITE_NAME') ? SITE_NAME : 'Hospital Management System'; ?></h1>
            <p class="lead">Providing Quality Healthcare with Modern Technology</p>
            <div class="mt-4">
                <a href="first_visit_appointment.php" class="btn btn-warning btn-lg mx-2">
                    <i class="fas fa-calendar-plus"></i> First Visit Appointment
                </a>
                <a href="patient_portal.php" class="btn btn-light btn-lg mx-2">
                    <i class="fas fa-user"></i> Patient Portal
                </a>
                <a href="login.php" class="btn btn-outline-light btn-lg mx-2">
                    <i class="fas fa-sign-in-alt"></i> Staff Login
                </a>
            </div>
        </div>
    </div>
    
    <!-- Features -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h4>Online Appointments</h4>
                    <p>Book appointments with our specialist doctors online</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-file-medical"></i>
                    </div>
                    <h4>Medical Records</h4>
                    <p>Access your medical history and lab results anytime</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-box">
                    <div class="feature-icon">
                        <i class="fas fa-flask"></i>
                    </div>
                    <h4>Lab Reports</h4>
                    <p>View your laboratory test results online</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-white mt-5 py-4">
        <div class="container text-center">
            <p>&copy; <?php echo date('Y'); ?> <?php echo defined('SITE_NAME') ? SITE_NAME : 'Hospital Management System'; ?>. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
