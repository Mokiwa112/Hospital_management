<?php
require_once 'config.php';

// Check if user is logged in (staff or patient)
if (!isset($_SESSION['user_id']) && !isset($_SESSION['patient_id'])) {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Determine access level
$is_patient = isset($_SESSION['patient_id']);
$is_staff = isset($_SESSION['user_id']);

// Build query based on access
if ($is_patient) {
    // Patients can only view their own lab requests
    $patient_id = $_SESSION['patient_id'];
    $query = "SELECT lr.*, 
              p.first_name, p.last_name, p.patient_number, p.date_of_birth,
              lt.test_name, lt.category, lt.normal_range, lt.unit, lt.description,
              u.full_name as doctor_name,
              tech.full_name as tech_name
              FROM lab_requests lr
              JOIN patients p ON lr.patient_id = p.patient_id
              JOIN lab_tests lt ON lr.test_id = lt.test_id
              LEFT JOIN users u ON lr.doctor_id = u.user_id
              LEFT JOIN users tech ON lr.lab_tech_id = tech.user_id
              WHERE lr.request_id = $request_id AND lr.patient_id = $patient_id";
} else {
    // Staff can view any lab request
    $query = "SELECT lr.*, 
              p.first_name, p.last_name, p.patient_number, p.date_of_birth,
              lt.test_name, lt.category, lt.normal_range, lt.unit, lt.description,
              u.full_name as doctor_name,
              tech.full_name as tech_name
              FROM lab_requests lr
              JOIN patients p ON lr.patient_id = p.patient_id
              JOIN lab_tests lt ON lr.test_id = lt.test_id
              LEFT JOIN users u ON lr.doctor_id = u.user_id
              LEFT JOIN users tech ON lr.lab_tech_id = tech.user_id
              WHERE lr.request_id = $request_id";
}

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Lab request not found";
    if ($is_patient) {
        header("Location: view_medical_record.php");
    } else {
        header("Location: lab_requests_list.php");
    }
    exit();
}

$lab = mysqli_fetch_assoc($result);
$lab_notes_raw = $lab['lab_notes'] ?? ($lab['result_notes'] ?? '');
$parsed_lab_notes = parseStructuredLabNotes($lab_notes_raw);
$display_lab_unit = normalizeLabUnit($lab['unit'] ?? '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Request Details - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #cce5ff; color: #004085; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        
        .info-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .info-label {
            font-weight: 600;
            color: #666;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .info-value {
            font-size: 16px;
            margin-bottom: 15px;
        }
        .result-box {
            background: #f8f9fa;
            border-left: 4px solid #28a745;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .action-btn {
            transition: all 0.3s;
            margin-bottom: 10px;
        }
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-flask"></i> Lab Request Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <?php if($is_patient): ?>
                    <a href="view_medical_record.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Records
                    </a>
                <?php else: ?>
                    <a href="lab_requests_list.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <!-- Main Info Card -->
                <div class="info-card">
                    <div class="d-flex justify-content-between align-items-start mb-4">
                        <h4>Test: <?php echo htmlspecialchars($lab['test_name'] ?? 'N/A'); ?></h4>
                        <span class="status-badge status-<?php echo $lab['status'] ?? 'pending'; ?>">
                            <?php echo ucfirst($lab['status'] ?? 'pending'); ?>
                        </span>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-label">Request Number</div>
                            <div class="info-value"><?php echo htmlspecialchars($lab['request_number'] ?? 'N/A'); ?></div>
                            
                            <div class="info-label">Request Date</div>
                            <div class="info-value">
                                <?php 
                                if (!empty($lab['request_date'])) {
                                    echo date('d M Y h:i A', strtotime($lab['request_date']));
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </div>
                            
                            <div class="info-label">Requested By</div>
                            <div class="info-value">Dr. <?php echo htmlspecialchars($lab['doctor_name'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-label">Patient Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($lab['first_name'] ?? '') . ' ' . htmlspecialchars($lab['last_name'] ?? ''); ?></div>
                            
                            <div class="info-label">Patient Number</div>
                            <div class="info-value"><?php echo htmlspecialchars($lab['patient_number'] ?? 'N/A'); ?></div>
                            
                            <div class="info-label">Category</div>
                            <div class="info-value"><?php echo htmlspecialchars($lab['category'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Clinical Notes Section - Fixed undefined array key -->
                    <?php if (!empty($lab['notes'])): ?>
                        <div class="mt-3">
                            <div class="info-label">Clinical Notes</div>
                            <div class="info-value"><?php echo nl2br(htmlspecialchars($lab['notes'])); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Test Description -->
                <?php if (!empty($lab['description'])): ?>
                <div class="info-card">
                    <h5>Test Description</h5>
                    <p><?php echo nl2br(htmlspecialchars($lab['description'])); ?></p>
                </div>
                <?php endif; ?>
                
                <!-- Results Section -->
                <?php if (($lab['status'] ?? '') == 'completed'): ?>
                    <div class="info-card">
                        <h5 class="text-success"><i class="fas fa-check-circle"></i> Test Results</h5>
                        
                        <div class="result-box">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="info-label">Result Value</div>
                                    <h3><?php echo htmlspecialchars($lab['result_value'] ?? 'N/A'); ?><?php echo $display_lab_unit !== '' ? ' ' . htmlspecialchars($display_lab_unit) : ''; ?></h3>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-label">Reference Range</div>
                                    <h5><?php echo htmlspecialchars($lab['normal_range'] ?: 'Not specified'); ?></h5>
                                </div>
                            </div>
                            
                            <?php if (!empty($parsed_lab_notes['parameters'])): ?>
                                <div class="mt-3">
                                    <div class="info-label">Detailed Test Parameters</div>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Parameter</th>
                                                    <th>Value</th>
                                                    <th>Reference</th>
                                                    <th>Flag</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($parsed_lab_notes['parameters'] as $param): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($param['name']); ?></td>
                                                        <td>
                                                            <?php echo htmlspecialchars($param['value']); ?>
                                                            <?php if(!empty($param['unit'])): ?>
                                                                <?php echo htmlspecialchars($param['unit']); ?>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($param['reference'] ?: '-'); ?></td>
                                                        <td><?php echo htmlspecialchars($param['flag'] ?: '-'); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($parsed_lab_notes['plain_notes'])): ?>
                                <div class="mt-3">
                                    <div class="info-label">Lab Technician Notes</div>
                                    <p><?php echo nl2br(htmlspecialchars($parsed_lab_notes['plain_notes'])); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <small class="text-muted">
                                        <i class="fas fa-user"></i> Processed by: <?php echo htmlspecialchars($lab['tech_name'] ?? 'N/A'); ?>
                                    </small>
                                </div>
                                <div class="col-md-6 text-end">
                                    <small class="text-muted">
                                        <i class="fas fa-calendar"></i> Result Date: 
                                        <?php 
                                        if (!empty($lab['result_date'])) {
                                            echo date('d M Y h:i A', strtotime($lab['result_date']));
                                        } else {
                                            echo 'N/A';
                                        }
                                        ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="col-md-4">
                <!-- Timeline Card -->
                <div class="info-card">
                    <h5><i class="fas fa-clock"></i> Timeline</h5>
                    
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="fas fa-circle text-primary me-2" style="font-size: 8px;"></i>
                            <strong>Requested:</strong>
                            <br>
                            <small class="text-muted ms-3">
                                <?php 
                                if (!empty($lab['request_date'])) {
                                    echo date('d M Y h:i A', strtotime($lab['request_date']));
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </small>
                        </li>
                        
                        <?php if (!empty($lab['sample_collected_date'])): ?>
                        <li class="mb-3">
                            <i class="fas fa-circle text-warning me-2" style="font-size: 8px;"></i>
                            <strong>Sample Collected:</strong>
                            <br>
                            <small class="text-muted ms-3"><?php echo date('d M Y h:i A', strtotime($lab['sample_collected_date'])); ?></small>
                        </li>
                        <?php endif; ?>
                        
                        <?php if (($lab['status'] ?? '') == 'processing'): ?>
                        <li class="mb-3">
                            <i class="fas fa-circle text-info me-2" style="font-size: 8px;"></i>
                            <strong>Processing Started:</strong>
                            <br>
                            <small class="text-muted ms-3">In progress</small>
                        </li>
                        <?php endif; ?>
                        
                        <?php if (!empty($lab['result_date'])): ?>
                        <li class="mb-3">
                            <i class="fas fa-circle text-success me-2" style="font-size: 8px;"></i>
                            <strong>Completed:</strong>
                            <br>
                            <small class="text-muted ms-3"><?php echo date('d M Y h:i A', strtotime($lab['result_date'])); ?></small>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Quick Actions for Staff -->
                <?php if($is_staff): ?>
                <div class="info-card">
                    <h5><i class="fas fa-bolt"></i> Actions</h5>
                    
                    <?php if (($lab['status'] ?? '') == 'pending'): ?>
                        <a href="collect_sample.php?id=<?php echo $lab['request_id']; ?>" 
                           class="btn btn-warning w-100 action-btn">
                            <i class="fas fa-syringe"></i> Collect Sample
                        </a>
                    <?php endif; ?>
                    
                    <?php if (($lab['status'] ?? '') == 'processing'): ?>
                        <a href="add_lab_result.php?id=<?php echo $lab['request_id']; ?>" 
                           class="btn btn-success w-100 action-btn">
                            <i class="fas fa-pen"></i> Add Result
                        </a>
                    <?php endif; ?>
                    
                    <?php if (($lab['status'] ?? '') == 'completed' && empty($lab['approved_by_doctor']) && ($_SESSION['user_type'] ?? '') == 'doctor'): ?>
                        <a href="review_lab_result.php?id=<?php echo $lab['request_id']; ?>" 
                           class="btn btn-primary w-100 action-btn">
                            <i class="fas fa-check-circle"></i> Review Result
                        </a>
                    <?php endif; ?>
                    
                    <!-- Print button for all staff -->
                    <a href="print_lab_result.php?id=<?php echo $lab['request_id']; ?>" 
                       class="btn btn-info w-100 action-btn" target="_blank">
                        <i class="fas fa-print"></i> Print Report
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
