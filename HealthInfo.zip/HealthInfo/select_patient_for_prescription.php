<?php
require_once 'config.php';
requireRole('doctor');

$conn = getConnection();

// Search for patients
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$where = "";
if ($search) {
    $where = "WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR patient_number LIKE '%$search%'";
}

$patients = mysqli_query($conn, "SELECT * FROM patients $where ORDER BY first_name LIMIT 20");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Patient for Prescription</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4><i class="fas fa-prescription"></i> Select Patient for Prescription</h4>
            </div>
            <div class="card-body">
                <form method="GET" class="mb-4">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" 
                               placeholder="Search by patient name or number..." value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                </form>
                
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Patient #</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($patients) > 0): ?>
                                <?php while($patient = mysqli_fetch_assoc($patients)): ?>
                                    <tr>
                                        <td><?php echo $patient['patient_number']; ?></td>
                                        <td><?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?></td>
                                        <td><?php echo $patient['phone']; ?></td>
                                        <td>
                                            <a href="create_prescription.php?patient_id=<?php echo $patient['patient_id']; ?>" 
                                               class="btn btn-sm btn-success">
                                                <i class="fas fa-prescription"></i> Create Prescription
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">No patients found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>