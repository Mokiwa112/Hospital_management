<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch worker details
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Worker not found";
    header("Location: workers.php");
    exit();
}

$worker = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $department = sanitize($_POST['department']);
    $user_type = sanitize($_POST['user_type']);
    
    // Check if email already exists for another user
    $check_email = mysqli_query($conn, "SELECT user_id FROM users WHERE email = '$email' AND user_id != $user_id");
    if (mysqli_num_rows($check_email) > 0) {
        $error = "Email already in use by another user";
    } elseif (!isValidPhoneNumber($phone)) {
        $error = getPhoneValidationMessage();
    } else {
        $update_query = "UPDATE users SET 
                         full_name = '$full_name',
                         email = '$email',
                         phone = '$phone',
                         address = '$address',
                         department = '$department',
                         user_type = '$user_type'
                         WHERE user_id = $user_id";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Worker updated successfully!";
            header("Location: view_worker.php?id=$user_id");
            exit();
        } else {
            $error = "Error updating worker: " . mysqli_error($conn);
        }
    }
}

// Get list of departments
$departments = [
    'Administration', 'Cardiology', 'Pediatrics', 'Neurology', 
    'Orthopedics', 'Emergency', 'ICU', 'Radiology', 'Laboratory',
    'Pharmacy', 'Billing', 'Front Office', 'HR', 'IT'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Worker - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h4><i class="fas fa-edit"></i> Edit Worker: <?php echo htmlspecialchars($worker['full_name']); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" class="form-control" name="full_name" 
                                           value="<?php echo htmlspecialchars($worker['full_name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" 
                                           value="<?php echo htmlspecialchars($worker['email']); ?>" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" class="form-control" name="phone" 
                                           value="<?php echo htmlspecialchars($worker['phone']); ?>" required
                                           pattern="^(0\d{9}|\+\d{11,12})$"
                                           title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">User Type</label>
                                    <select class="form-control" name="user_type" required>
                                        <option value="admin" <?php echo $worker['user_type'] == 'admin' ? 'selected' : ''; ?>>Administrator</option>
                                        <option value="doctor" <?php echo $worker['user_type'] == 'doctor' ? 'selected' : ''; ?>>Doctor</option>
                                        <option value="nurse" <?php echo $worker['user_type'] == 'nurse' ? 'selected' : ''; ?>>Nurse</option>
                                        <option value="receptionist" <?php echo $worker['user_type'] == 'receptionist' ? 'selected' : ''; ?>>Receptionist</option>
                                        <option value="lab_tech" <?php echo $worker['user_type'] == 'lab_tech' ? 'selected' : ''; ?>>Lab Technician</option>
                                        <option value="pharmacist" <?php echo $worker['user_type'] == 'pharmacist' ? 'selected' : ''; ?>>Pharmacist</option>
                                        <option value="accountant" <?php echo $worker['user_type'] == 'accountant' ? 'selected' : ''; ?>>Accountant</option>
                                        <option value="hr_admin" <?php echo $worker['user_type'] == 'hr_admin' ? 'selected' : ''; ?>>HR Admin</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="2"><?php echo htmlspecialchars($worker['address']); ?></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Department</label>
                                    <select class="form-control" name="department">
                                        <option value="">Select Department</option>
                                        <?php foreach($departments as $dept): ?>
                                            <option value="<?php echo $dept; ?>" <?php echo $worker['department'] == $dept ? 'selected' : ''; ?>>
                                                <?php echo $dept; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Username (cannot be changed)</label>
                                    <input type="text" class="form-control" value="<?php echo $worker['username']; ?>" disabled>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Worker
                                </button>
                                <a href="view_worker.php?id=<?php echo $user_id; ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                        
                        <hr class="my-4">
                        
                        <div class="text-center">
                            <a href="reset_password.php?id=<?php echo $user_id; ?>" class="btn btn-warning" 
                               onclick="return confirm('Are you sure you want to reset this user\'s password?')">
                                <i class="fas fa-key"></i> Reset Password
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

