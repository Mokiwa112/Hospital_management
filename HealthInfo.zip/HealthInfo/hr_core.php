<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['admin', 'hr_admin']);

$conn = getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);
$tab = sanitize($_GET['tab'] ?? 'employees');

function ensure_hr_core_schema($conn) {
    $sql = [];
    $sql[] = "CREATE TABLE IF NOT EXISTS hr_departments (
        department_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        description TEXT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS hr_positions (
        position_id INT AUTO_INCREMENT PRIMARY KEY,
        department_id INT NULL,
        title VARCHAR(120) NOT NULL,
        description TEXT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS employee_employment_details (
        emp_detail_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        department_id INT NULL,
        position_id INT NULL,
        hire_date DATE NULL,
        employment_type ENUM('full_time','part_time','contract','intern') NOT NULL DEFAULT 'full_time',
        status ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
        deactivation_date DATE NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS employee_documents (
        document_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        document_type VARCHAR(80) NOT NULL,
        file_path VARCHAR(300) NOT NULL,
        uploaded_by INT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS leave_types (
        leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
        leave_name VARCHAR(80) NOT NULL UNIQUE,
        days_per_year DECIMAL(6,2) NOT NULL DEFAULT 0,
        is_paid TINYINT(1) NOT NULL DEFAULT 1,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS leave_requests (
        leave_request_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        leave_type_id INT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        total_days DECIMAL(6,2) NOT NULL DEFAULT 0,
        reason TEXT NULL,
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        approved_by INT NULL,
        approval_date DATETIME NULL,
        approval_comment TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS performance_reviews (
        review_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        period_start DATE NOT NULL,
        period_end DATE NOT NULL,
        score DECIMAL(5,2) NOT NULL DEFAULT 0,
        comments TEXT NULL,
        supervisor_id INT NULL,
        evaluation_date DATE NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS job_postings (
        job_posting_id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(150) NOT NULL,
        department_id INT NULL,
        description TEXT NULL,
        status ENUM('open','closed') NOT NULL DEFAULT 'open',
        posted_date DATE NOT NULL,
        closed_date DATE NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS applicants (
        applicant_id INT AUTO_INCREMENT PRIMARY KEY,
        job_posting_id INT NULL,
        full_name VARCHAR(150) NOT NULL,
        email VARCHAR(120) NULL,
        phone VARCHAR(30) NULL,
        status ENUM('applied','shortlisted','interviewed','offered','hired','rejected') NOT NULL DEFAULT 'applied',
        applied_date DATE NOT NULL,
        notes TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS interviews (
        interview_id INT AUTO_INCREMENT PRIMARY KEY,
        applicant_id INT NOT NULL,
        interview_date DATETIME NOT NULL,
        interviewer_id INT NULL,
        status ENUM('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
        remarks TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS disciplinary_records (
        disciplinary_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        action_type VARCHAR(120) NOT NULL,
        action_date DATE NOT NULL,
        description TEXT NULL,
        compliance_notes TEXT NULL,
        confidential_remarks TEXT NULL,
        recorded_by INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    foreach ($sql as $q) mysqli_query($conn, $q);
    mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Annual Leave',28,1)");
    mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Sick Leave',14,1)");
    mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Maternity Leave',90,1)");
    mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Unpaid Leave',30,0)");
}
ensure_hr_core_schema($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_department'])) {
        $name = sanitize($_POST['name']);
        $desc = sanitize($_POST['description']);
        mysqli_query($conn, "INSERT INTO hr_departments (name, description) VALUES ('$name', '$desc')");
        $_SESSION['success'] = "Department saved";
        redirect('hr_core.php?tab=org');
    }
    if (isset($_POST['add_position'])) {
        $department_id = (int)($_POST['department_id'] ?? 0);
        $title = sanitize($_POST['title']);
        $desc = sanitize($_POST['description']);
        mysqli_query($conn, "INSERT INTO hr_positions (department_id, title, description) VALUES (" . ($department_id ?: "NULL") . ", '$title', '$desc')");
        $_SESSION['success'] = "Position saved";
        redirect('hr_core.php?tab=org');
    }
    if (isset($_POST['save_employment'])) {
        $emp_user_id = (int)($_POST['user_id'] ?? 0);
        $department_id = (int)($_POST['department_id'] ?? 0);
        $position_id = (int)($_POST['position_id'] ?? 0);
        $hire_date = sanitize($_POST['hire_date'] ?? '');
        $employment_type = sanitize($_POST['employment_type'] ?? 'full_time');
        $status = sanitize($_POST['status'] ?? 'active');
        $deactivation = $status === 'active' ? 'NULL' : "'" . date('Y-m-d') . "'";
        $exists = mysqli_query($conn, "SELECT emp_detail_id FROM employee_employment_details WHERE user_id=$emp_user_id");
        if ($exists && mysqli_num_rows($exists) > 0) {
            mysqli_query($conn, "UPDATE employee_employment_details SET department_id=" . ($department_id ?: "NULL") . ", position_id=" . ($position_id ?: "NULL") . ", hire_date='" . ($hire_date ?: date('Y-m-d')) . "', employment_type='$employment_type', status='$status', deactivation_date=$deactivation WHERE user_id=$emp_user_id");
        } else {
            mysqli_query($conn, "INSERT INTO employee_employment_details (user_id, department_id, position_id, hire_date, employment_type, status, deactivation_date) VALUES ($emp_user_id, " . ($department_id ?: "NULL") . ", " . ($position_id ?: "NULL") . ", '" . ($hire_date ?: date('Y-m-d')) . "', '$employment_type', '$status', $deactivation)");
        }
        $_SESSION['success'] = "Employment details updated";
        redirect('hr_core.php?tab=employees');
    }
    if (isset($_POST['upload_document'])) {
        $emp_user_id = (int)($_POST['user_id'] ?? 0);
        $doc_type = sanitize($_POST['document_type'] ?? 'Other');
        if (!empty($_FILES['document_file']['name']) && $emp_user_id > 0) {
            $dir = __DIR__ . '/uploads/documents/hr';
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            $fname = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $_FILES['document_file']['name']);
            $path = $dir . '/' . $fname;
            if (move_uploaded_file($_FILES['document_file']['tmp_name'], $path)) {
                $db_path = 'uploads/documents/hr/' . $fname;
                mysqli_query($conn, "INSERT INTO employee_documents (user_id, document_type, file_path, uploaded_by) VALUES ($emp_user_id, '$doc_type', '$db_path', $user_id)");
                $_SESSION['success'] = "Document uploaded";
            }
        }
        redirect('hr_core.php?tab=employees');
    }
    if (isset($_POST['add_leave_type'])) {
        $name = sanitize($_POST['leave_name']); $days = (float)($_POST['days_per_year'] ?? 0); $is_paid = isset($_POST['is_paid']) ? 1 : 0;
        mysqli_query($conn, "INSERT INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('$name', $days, $is_paid)");
        $_SESSION['success'] = "Leave type added";
        redirect('hr_core.php?tab=leave');
    }
    if (isset($_POST['submit_leave_request'])) {
        $emp_user_id = (int)($_POST['user_id'] ?? 0); $leave_type_id = (int)($_POST['leave_type_id'] ?? 0);
        $start_date = sanitize($_POST['start_date'] ?? ''); $end_date = sanitize($_POST['end_date'] ?? ''); $reason = sanitize($_POST['reason'] ?? '');
        $days = max(1, (strtotime($end_date) - strtotime($start_date)) / 86400 + 1);
        mysqli_query($conn, "INSERT INTO leave_requests (user_id, leave_type_id, start_date, end_date, total_days, reason, status) VALUES ($emp_user_id, $leave_type_id, '$start_date', '$end_date', $days, '$reason', 'pending')");
        $_SESSION['success'] = "Leave request submitted";
        redirect('hr_core.php?tab=leave');
    }
    if (isset($_POST['leave_decision'])) {
        $leave_request_id = (int)($_POST['leave_request_id'] ?? 0); $decision = sanitize($_POST['decision'] ?? 'rejected'); $comment = sanitize($_POST['approval_comment'] ?? '');
        mysqli_query($conn, "UPDATE leave_requests SET status='$decision', approved_by=$user_id, approval_date=NOW(), approval_comment='$comment' WHERE leave_request_id=$leave_request_id");
        $_SESSION['success'] = "Leave request updated";
        redirect('hr_core.php?tab=leave');
    }
    if (isset($_POST['add_review'])) {
        $emp_user_id = (int)($_POST['user_id'] ?? 0); $start = sanitize($_POST['period_start'] ?? ''); $end = sanitize($_POST['period_end'] ?? '');
        $score = (float)($_POST['score'] ?? 0); $comments = sanitize($_POST['comments'] ?? ''); $supervisor = (int)($_POST['supervisor_id'] ?? 0);
        mysqli_query($conn, "INSERT INTO performance_reviews (user_id, period_start, period_end, score, comments, supervisor_id, evaluation_date) VALUES ($emp_user_id, '$start', '$end', $score, '$comments', " . ($supervisor ?: "NULL") . ", CURDATE())");
        $_SESSION['success'] = "Performance review saved";
        redirect('hr_core.php?tab=performance');
    }
    if (isset($_POST['add_job_posting'])) {
        $title = sanitize($_POST['title'] ?? ''); $department_id = (int)($_POST['department_id'] ?? 0); $description = sanitize($_POST['description'] ?? '');
        mysqli_query($conn, "INSERT INTO job_postings (title, department_id, description, status, posted_date) VALUES ('$title', " . ($department_id ?: "NULL") . ", '$description', 'open', CURDATE())");
        $_SESSION['success'] = "Job posting created";
        redirect('hr_core.php?tab=recruitment');
    }
    if (isset($_POST['add_applicant'])) {
        $job_posting_id = (int)($_POST['job_posting_id'] ?? 0); $name = sanitize($_POST['full_name'] ?? ''); $email = sanitize($_POST['email'] ?? ''); $phone = sanitize($_POST['phone'] ?? ''); $notes = sanitize($_POST['notes'] ?? '');
        mysqli_query($conn, "INSERT INTO applicants (job_posting_id, full_name, email, phone, status, applied_date, notes) VALUES (" . ($job_posting_id ?: "NULL") . ", '$name', '$email', '$phone', 'applied', CURDATE(), '$notes')");
        $_SESSION['success'] = "Applicant added";
        redirect('hr_core.php?tab=recruitment');
    }
    if (isset($_POST['add_interview'])) {
        $applicant_id = (int)($_POST['applicant_id'] ?? 0); $interview_date = sanitize($_POST['interview_date'] ?? ''); $status = sanitize($_POST['status'] ?? 'scheduled'); $remarks = sanitize($_POST['remarks'] ?? '');
        mysqli_query($conn, "INSERT INTO interviews (applicant_id, interview_date, interviewer_id, status, remarks) VALUES ($applicant_id, '$interview_date', $user_id, '$status', '$remarks')");
        mysqli_query($conn, "UPDATE applicants SET status='interviewed' WHERE applicant_id=$applicant_id");
        $_SESSION['success'] = "Interview record added";
        redirect('hr_core.php?tab=recruitment');
    }
    if (isset($_POST['convert_to_employee'])) {
        $applicant_id = (int)($_POST['applicant_id'] ?? 0); $username = sanitize($_POST['username'] ?? ''); $password = $_POST['password'] ?? '';
        $user_type_new = sanitize($_POST['user_type'] ?? 'nurse'); $department = sanitize($_POST['department'] ?? 'HR');
        $app = mysqli_query($conn, "SELECT * FROM applicants WHERE applicant_id=$applicant_id LIMIT 1");
        if ($app && mysqli_num_rows($app) > 0 && $username && $password) {
            $a = mysqli_fetch_assoc($app);
            $check = mysqli_query($conn, "SELECT user_id FROM users WHERE username='$username'");
            if (!$check || mysqli_num_rows($check) === 0) {
                $employee_id = generateUniqueId('EMP', 'users', 'employee_id');
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $full_name = sanitize($a['full_name']); $email = sanitize($a['email']); $phone = sanitize($a['phone']);
                mysqli_query($conn, "INSERT INTO users (username, password, full_name, email, phone, user_type, department, employee_id) VALUES ('$username', '$hash', '$full_name', '$email', '$phone', '$user_type_new', '$department', '$employee_id')");
                $new_uid = (int)mysqli_insert_id($conn);
                if ($new_uid > 0) {
                    mysqli_query($conn, "INSERT INTO employee_employment_details (user_id, hire_date, employment_type, status) VALUES ($new_uid, CURDATE(), 'full_time', 'active')");
                    mysqli_query($conn, "UPDATE applicants SET status='hired' WHERE applicant_id=$applicant_id");
                    $_SESSION['success'] = "Applicant converted to employee: $employee_id";
                }
            } else {
                $_SESSION['error'] = "Username already exists";
            }
        }
        redirect('hr_core.php?tab=recruitment');
    }
    if (isset($_POST['add_disciplinary'])) {
        $emp_user_id = (int)($_POST['user_id'] ?? 0); $action_type = sanitize($_POST['action_type'] ?? 'Warning'); $action_date = sanitize($_POST['action_date'] ?? date('Y-m-d'));
        $description = sanitize($_POST['description'] ?? ''); $compliance_notes = sanitize($_POST['compliance_notes'] ?? ''); $conf = sanitize($_POST['confidential_remarks'] ?? '');
        mysqli_query($conn, "INSERT INTO disciplinary_records (user_id, action_type, action_date, description, compliance_notes, confidential_remarks, recorded_by) VALUES ($emp_user_id, '$action_type', '$action_date', '$description', '$compliance_notes', '$conf', $user_id)");
        $_SESSION['success'] = "Disciplinary record saved";
        redirect('hr_core.php?tab=compliance');
    }
}

$employees = mysqli_query($conn, "SELECT u.user_id, u.full_name, u.employee_id, u.department, u.user_type, e.hire_date, e.employment_type, e.status, d.name AS hr_department, p.title AS hr_position FROM users u LEFT JOIN employee_employment_details e ON e.user_id=u.user_id LEFT JOIN hr_departments d ON d.department_id=e.department_id LEFT JOIN hr_positions p ON p.position_id=e.position_id WHERE u.user_type <> 'admin' ORDER BY u.full_name");
$departments = mysqli_query($conn, "SELECT * FROM hr_departments WHERE is_active=1 ORDER BY name");
$positions = mysqli_query($conn, "SELECT p.*, d.name AS dept_name FROM hr_positions p LEFT JOIN hr_departments d ON d.department_id=p.department_id WHERE p.is_active=1 ORDER BY p.title");
$documents = mysqli_query($conn, "SELECT ed.*, u.full_name FROM employee_documents ed JOIN users u ON u.user_id=ed.user_id ORDER BY ed.uploaded_at DESC LIMIT 50");
$leave_types = mysqli_query($conn, "SELECT * FROM leave_types WHERE is_active=1 ORDER BY leave_name");
$leave_requests = mysqli_query($conn, "SELECT lr.*, u.full_name, lt.leave_name FROM leave_requests lr JOIN users u ON u.user_id=lr.user_id JOIN leave_types lt ON lt.leave_type_id=lr.leave_type_id ORDER BY lr.created_at DESC");
$attendance_summary = mysqli_query($conn, "SELECT u.full_name, u.employee_id, SUM(CASE WHEN a.status IN ('present','late') THEN 1 ELSE 0 END) AS present_days, SUM(CASE WHEN a.status='half_day' THEN 1 ELSE 0 END) AS half_days, SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) AS absent_days FROM users u LEFT JOIN attendance a ON a.user_id=u.user_id AND YEAR(a.date)=YEAR(CURDATE()) AND MONTH(a.date)=MONTH(CURDATE()) WHERE u.user_type <> 'admin' GROUP BY u.user_id ORDER BY u.full_name");
$reviews = mysqli_query($conn, "SELECT r.*, u.full_name, s.full_name AS supervisor_name FROM performance_reviews r JOIN users u ON u.user_id=r.user_id LEFT JOIN users s ON s.user_id=r.supervisor_id ORDER BY r.evaluation_date DESC");
$jobs = mysqli_query($conn, "SELECT j.*, d.name AS dept_name FROM job_postings j LEFT JOIN hr_departments d ON d.department_id=j.department_id ORDER BY j.posted_date DESC");
$applicants = mysqli_query($conn, "SELECT a.*, j.title FROM applicants a LEFT JOIN job_postings j ON j.job_posting_id=a.job_posting_id ORDER BY a.created_at DESC");
$interviews = mysqli_query($conn, "SELECT i.*, a.full_name AS applicant_name, u.full_name AS interviewer_name FROM interviews i JOIN applicants a ON a.applicant_id=i.applicant_id LEFT JOIN users u ON u.user_id=i.interviewer_id ORDER BY i.interview_date DESC");
$disciplinary = mysqli_query($conn, "SELECT d.*, u.full_name FROM disciplinary_records d JOIN users u ON u.user_id=d.user_id ORDER BY d.action_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Core - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid mt-4">
    <?php if(isset($_SESSION['success'])): ?><div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?><div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div><?php endif; ?>
    <div class="d-flex justify-content-between mb-3"><h3>HR Core Operations</h3><a href="hr_dashboard.php" class="btn btn-secondary">Back to HR Dashboard</a></div>
    <ul class="nav nav-tabs mb-3">
        <li class="nav-item"><a class="nav-link <?php echo $tab==='employees'?'active':''; ?>" href="hr_core.php?tab=employees">Employees</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='org'?'active':''; ?>" href="hr_core.php?tab=org">Departments & Positions</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='attendance'?'active':''; ?>" href="hr_core.php?tab=attendance">Attendance</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='leave'?'active':''; ?>" href="hr_core.php?tab=leave">Leave</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='performance'?'active':''; ?>" href="hr_core.php?tab=performance">Performance</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='recruitment'?'active':''; ?>" href="hr_core.php?tab=recruitment">Recruitment</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='compliance'?'active':''; ?>" href="hr_core.php?tab=compliance">Compliance</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $tab==='reports'?'active':''; ?>" href="hr_core.php?tab=reports">Reports</a></li>
    </ul>
    <div class="alert alert-info">Use this screen for all Core HR functions. Payroll support remains under <a href="human_resource.php">Payroll Data Support</a>.</div>
    <div class="card"><div class="card-body">
        <?php if($tab==='reports'): ?>
            <h5>Department-wise Employee Report</h5>
            <table class="table table-striped" id="tblReport"><thead><tr><th>Department</th><th>Count</th></tr></thead><tbody>
            <?php $dept_report=mysqli_query($conn,"SELECT COALESCE(d.name,u.department,'Unassigned') dept, COUNT(*) c FROM users u LEFT JOIN employee_employment_details e ON e.user_id=u.user_id LEFT JOIN hr_departments d ON d.department_id=e.department_id WHERE u.user_type<>'admin' GROUP BY COALESCE(d.name,u.department,'Unassigned') ORDER BY c DESC"); while($r=mysqli_fetch_assoc($dept_report)): ?>
                <tr><td><?php echo htmlspecialchars($r['dept']); ?></td><td><?php echo (int)$r['c']; ?></td></tr>
            <?php endwhile; ?>
            </tbody></table>
        <?php elseif($tab==='employees'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded mb-3">
                        <h6>Employment Details</h6>
                        <select class="form-select mb-2" name="user_id" required>
                            <?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?>
                                <option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars(($e['employee_id']?:'-') . ' - ' . $e['full_name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                        <select class="form-select mb-2" name="department_id">
                            <option value="">Department</option>
                            <?php mysqli_data_seek($departments,0); while($d=mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $d['department_id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                        <select class="form-select mb-2" name="position_id">
                            <option value="">Position</option>
                            <?php mysqli_data_seek($positions,0); while($p=mysqli_fetch_assoc($positions)): ?>
                                <option value="<?php echo $p['position_id']; ?>"><?php echo htmlspecialchars($p['title']); ?></option>
                            <?php endwhile; ?>
                        </select>
                        <input type="date" class="form-control mb-2" name="hire_date" value="<?php echo date('Y-m-d'); ?>">
                        <select class="form-select mb-2" name="employment_type"><option value="full_time">Full Time</option><option value="part_time">Part Time</option><option value="contract">Contract</option><option value="intern">Intern</option></select>
                        <select class="form-select mb-2" name="status"><option value="active">Active</option><option value="inactive">Inactive</option><option value="terminated">Terminated</option></select>
                        <button class="btn btn-primary w-100" name="save_employment">Save</button>
                    </form>
                    <form method="POST" enctype="multipart/form-data" class="border p-3 rounded">
                        <h6>Upload Employee Document</h6>
                        <select class="form-select mb-2" name="user_id" required>
                            <?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?>
                                <option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars(($e['employee_id']?:'-') . ' - ' . $e['full_name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                        <input class="form-control mb-2" name="document_type" placeholder="CV/Contract/ID" required>
                        <input type="file" class="form-control mb-2" name="document_file" required>
                        <button class="btn btn-secondary w-100" name="upload_document">Upload</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <table class="table table-striped" id="tblEmpList"><thead><tr><th>ID</th><th>Name</th><th>Dept</th><th>Position</th><th>Status</th></tr></thead><tbody>
                    <?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?>
                        <tr><td><?php echo htmlspecialchars($e['employee_id']?:'-'); ?></td><td><?php echo htmlspecialchars($e['full_name']); ?></td><td><?php echo htmlspecialchars($e['hr_department']?:$e['department']?:'-'); ?></td><td><?php echo htmlspecialchars($e['hr_position']?:'-'); ?></td><td><?php echo htmlspecialchars($e['status']?:'active'); ?></td></tr>
                    <?php endwhile; ?>
                    </tbody></table>
                </div>
            </div>
        <?php elseif($tab==='org'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded mb-3">
                        <h6>Add Department</h6>
                        <input class="form-control mb-2" name="name" placeholder="Department name" required>
                        <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
                        <button class="btn btn-primary w-100" name="add_department">Save Department</button>
                    </form>
                    <form method="POST" class="border p-3 rounded">
                        <h6>Add Position</h6>
                        <select class="form-select mb-2" name="department_id"><option value="">No department</option><?php mysqli_data_seek($departments,0); while($d=mysqli_fetch_assoc($departments)): ?><option value="<?php echo $d['department_id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option><?php endwhile; ?></select>
                        <input class="form-control mb-2" name="title" placeholder="Position title" required>
                        <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
                        <button class="btn btn-success w-100" name="add_position">Save Position</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <h6>Departments</h6>
                    <table class="table table-sm"><thead><tr><th>Name</th><th>Description</th></tr></thead><tbody><?php mysqli_data_seek($departments,0); while($d=mysqli_fetch_assoc($departments)): ?><tr><td><?php echo htmlspecialchars($d['name']); ?></td><td><?php echo htmlspecialchars($d['description']); ?></td></tr><?php endwhile; ?></tbody></table>
                    <h6>Positions</h6>
                    <table class="table table-sm"><thead><tr><th>Title</th><th>Department</th></tr></thead><tbody><?php mysqli_data_seek($positions,0); while($p=mysqli_fetch_assoc($positions)): ?><tr><td><?php echo htmlspecialchars($p['title']); ?></td><td><?php echo htmlspecialchars($p['dept_name']?:'-'); ?></td></tr><?php endwhile; ?></tbody></table>
                </div>
            </div>
        <?php elseif($tab==='attendance'): ?>
            <table class="table table-striped" id="tblAttendance"><thead><tr><th>Employee</th><th>Present</th><th>Half Day</th><th>Absent</th></tr></thead><tbody>
            <?php while($a=mysqli_fetch_assoc($attendance_summary)): ?>
                <tr><td><?php echo htmlspecialchars(($a['employee_id']?:'-') . ' - ' . $a['full_name']); ?></td><td><?php echo (int)$a['present_days']; ?></td><td><?php echo (int)$a['half_days']; ?></td><td><?php echo (int)$a['absent_days']; ?></td></tr>
            <?php endwhile; ?>
            </tbody></table>
        <?php elseif($tab==='leave'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded mb-3">
                        <h6>Add Leave Type</h6>
                        <input class="form-control mb-2" name="leave_name" placeholder="Leave name" required>
                        <input type="number" step="0.5" class="form-control mb-2" name="days_per_year" placeholder="Days per year" required>
                        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_paid" checked><label class="form-check-label">Paid</label></div>
                        <button class="btn btn-primary w-100" name="add_leave_type">Save</button>
                    </form>
                    <form method="POST" class="border p-3 rounded">
                        <h6>Create Leave Request</h6>
                        <select class="form-select mb-2" name="user_id" required><?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?><option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars($e['full_name']); ?></option><?php endwhile; ?></select>
                        <select class="form-select mb-2" name="leave_type_id" required><?php mysqli_data_seek($leave_types,0); while($lt=mysqli_fetch_assoc($leave_types)): ?><option value="<?php echo $lt['leave_type_id']; ?>"><?php echo htmlspecialchars($lt['leave_name']); ?></option><?php endwhile; ?></select>
                        <input type="date" class="form-control mb-2" name="start_date" required>
                        <input type="date" class="form-control mb-2" name="end_date" required>
                        <textarea class="form-control mb-2" name="reason" placeholder="Reason"></textarea>
                        <button class="btn btn-success w-100" name="submit_leave_request">Submit</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <table class="table table-striped" id="tblLeave"><thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Status</th><th>Action</th></tr></thead><tbody>
                    <?php while($lr=mysqli_fetch_assoc($leave_requests)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($lr['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($lr['leave_name']); ?></td>
                            <td><?php echo htmlspecialchars($lr['start_date'] . ' to ' . $lr['end_date']); ?></td>
                            <td><?php echo htmlspecialchars($lr['total_days']); ?></td>
                            <td><?php echo htmlspecialchars($lr['status']); ?></td>
                            <td>
                                <?php if($lr['status']==='pending'): ?>
                                <form method="POST" class="d-flex gap-1">
                                    <input type="hidden" name="leave_request_id" value="<?php echo $lr['leave_request_id']; ?>">
                                    <input type="hidden" name="decision" value="approved" class="decision-input">
                                    <input type="text" class="form-control form-control-sm" name="approval_comment" placeholder="comment">
                                    <button class="btn btn-sm btn-success" name="leave_decision" onclick="this.form.querySelector('.decision-input').value='approved'">Approve</button>
                                    <button class="btn btn-sm btn-danger" name="leave_decision" onclick="this.form.querySelector('.decision-input').value='rejected'">Reject</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody></table>
                </div>
            </div>
        <?php elseif($tab==='performance'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded">
                        <h6>Add Performance Review</h6>
                        <select class="form-select mb-2" name="user_id" required><?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?><option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars($e['full_name']); ?></option><?php endwhile; ?></select>
                        <input type="date" class="form-control mb-2" name="period_start" required>
                        <input type="date" class="form-control mb-2" name="period_end" required>
                        <input type="number" step="0.1" min="0" max="100" class="form-control mb-2" name="score" placeholder="Score /100" required>
                        <select class="form-select mb-2" name="supervisor_id"><option value="">Supervisor</option><?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?><option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars($e['full_name']); ?></option><?php endwhile; ?></select>
                        <textarea class="form-control mb-2" name="comments" placeholder="Comments"></textarea>
                        <button class="btn btn-primary w-100" name="add_review">Save</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <table class="table table-striped" id="tblReview"><thead><tr><th>Employee</th><th>Period</th><th>Score</th><th>Supervisor</th></tr></thead><tbody>
                    <?php while($r=mysqli_fetch_assoc($reviews)): ?>
                        <tr><td><?php echo htmlspecialchars($r['full_name']); ?></td><td><?php echo htmlspecialchars($r['period_start'] . ' to ' . $r['period_end']); ?></td><td><?php echo htmlspecialchars($r['score']); ?></td><td><?php echo htmlspecialchars($r['supervisor_name']?:'-'); ?></td></tr>
                    <?php endwhile; ?>
                    </tbody></table>
                </div>
            </div>
        <?php elseif($tab==='recruitment'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded mb-3">
                        <h6>Add Job Posting</h6>
                        <input class="form-control mb-2" name="title" placeholder="Job title" required>
                        <select class="form-select mb-2" name="department_id"><option value="">Department</option><?php mysqli_data_seek($departments,0); while($d=mysqli_fetch_assoc($departments)): ?><option value="<?php echo $d['department_id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option><?php endwhile; ?></select>
                        <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
                        <button class="btn btn-primary w-100" name="add_job_posting">Save</button>
                    </form>
                    <form method="POST" class="border p-3 rounded mb-3">
                        <h6>Add Applicant</h6>
                        <select class="form-select mb-2" name="job_posting_id"><option value="">Job posting</option><?php mysqli_data_seek($jobs,0); while($j=mysqli_fetch_assoc($jobs)): ?><option value="<?php echo $j['job_posting_id']; ?>"><?php echo htmlspecialchars($j['title']); ?></option><?php endwhile; ?></select>
                        <input class="form-control mb-2" name="full_name" placeholder="Name" required>
                        <input class="form-control mb-2" name="email" placeholder="Email">
                        <input class="form-control mb-2" name="phone" placeholder="Phone">
                        <textarea class="form-control mb-2" name="notes" placeholder="Notes"></textarea>
                        <button class="btn btn-success w-100" name="add_applicant">Save</button>
                    </form>
                    <form method="POST" class="border p-3 rounded">
                        <h6>Schedule Interview</h6>
                        <select class="form-select mb-2" name="applicant_id" required><?php mysqli_data_seek($applicants,0); while($a=mysqli_fetch_assoc($applicants)): ?><option value="<?php echo $a['applicant_id']; ?>"><?php echo htmlspecialchars($a['full_name']); ?></option><?php endwhile; ?></select>
                        <input type="datetime-local" class="form-control mb-2" name="interview_date" required>
                        <select class="form-select mb-2" name="status"><option value="scheduled">Scheduled</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select>
                        <textarea class="form-control mb-2" name="remarks" placeholder="Remarks"></textarea>
                        <button class="btn btn-warning w-100" name="add_interview">Save</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <table class="table table-striped" id="tblApplicants"><thead><tr><th>Applicant</th><th>Job</th><th>Status</th><th>Convert</th></tr></thead><tbody>
                    <?php mysqli_data_seek($applicants,0); while($a=mysqli_fetch_assoc($applicants)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($a['full_name']); ?></td><td><?php echo htmlspecialchars($a['title']?:'-'); ?></td><td><?php echo htmlspecialchars($a['status']); ?></td>
                            <td>
                                <?php if($a['status']!=='hired'): ?>
                                    <form method="POST" class="d-flex gap-1">
                                        <input type="hidden" name="applicant_id" value="<?php echo $a['applicant_id']; ?>">
                                        <input class="form-control form-control-sm" name="username" placeholder="username" required>
                                        <input class="form-control form-control-sm" name="password" placeholder="temp pass" required>
                                        <select class="form-select form-select-sm" name="user_type"><option value="nurse">Nurse</option><option value="doctor">Doctor</option><option value="receptionist">Receptionist</option><option value="lab_tech">Lab Tech</option><option value="pharmacist">Pharmacist</option><option value="accountant">Accountant</option><option value="hr_admin">HR Admin</option></select>
                                        <input class="form-control form-control-sm" name="department" placeholder="Department">
                                        <button class="btn btn-sm btn-primary" name="convert_to_employee">Convert</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody></table>
                </div>
            </div>
        <?php elseif($tab==='compliance'): ?>
            <div class="row">
                <div class="col-md-4">
                    <form method="POST" class="border p-3 rounded">
                        <h6>Add Disciplinary Record</h6>
                        <select class="form-select mb-2" name="user_id" required><?php mysqli_data_seek($employees,0); while($e=mysqli_fetch_assoc($employees)): ?><option value="<?php echo $e['user_id']; ?>"><?php echo htmlspecialchars($e['full_name']); ?></option><?php endwhile; ?></select>
                        <input class="form-control mb-2" name="action_type" placeholder="Warning/Suspension" required>
                        <input type="date" class="form-control mb-2" name="action_date" value="<?php echo date('Y-m-d'); ?>" required>
                        <textarea class="form-control mb-2" name="description" placeholder="Description"></textarea>
                        <textarea class="form-control mb-2" name="compliance_notes" placeholder="Compliance notes"></textarea>
                        <textarea class="form-control mb-2" name="confidential_remarks" placeholder="Confidential remarks"></textarea>
                        <button class="btn btn-danger w-100" name="add_disciplinary">Save</button>
                    </form>
                </div>
                <div class="col-md-8">
                    <table class="table table-striped" id="tblDisc"><thead><tr><th>Employee</th><th>Action</th><th>Date</th><th>Description</th></tr></thead><tbody>
                    <?php while($d=mysqli_fetch_assoc($disciplinary)): ?>
                        <tr><td><?php echo htmlspecialchars($d['full_name']); ?></td><td><?php echo htmlspecialchars($d['action_type']); ?></td><td><?php echo htmlspecialchars($d['action_date']); ?></td><td><?php echo htmlspecialchars($d['description']); ?></td></tr>
                    <?php endwhile; ?>
                    </tbody></table>
                </div>
            </div>
        <?php endif; ?>
    </div></div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function(){
  ['#tblReport','#tblEmpList','#tblAttendance','#tblLeave','#tblReview','#tblApplicants','#tblDisc'].forEach(function(id){
    if($(id).length){ $(id).DataTable({pageLength:10}); }
  });
});
</script>
</body>
</html>
