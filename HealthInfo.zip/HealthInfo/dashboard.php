<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_type = $_SESSION['user_type'];
$user_id = $_SESSION['user_id'];
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body.dashboard-shell {
            background: #f4f7fb;
            min-height: 100vh;
        }
        body.dashboard-shell .navbar {
            position: sticky;
            top: 0;
            z-index: 1040;
        }
        body.dashboard-shell .dashboard-content {
            padding: 1.5rem 1.25rem 2rem;
        }
        body.dashboard-shell .card {
            border: 0;
            border-radius: 14px;
            box-shadow: 0 8px 18px rgba(0,0,0,0.08);
        }
        body.dashboard-shell .card .card-body {
            padding: 1.5rem 1.5rem;
            min-height: 150px;
        }
        body.dashboard-shell .card h2 {
            font-size: 2.2rem;
            font-weight: 700;
        }
        @media (max-width: 991.98px) {
            body.dashboard-shell .dashboard-content {
                padding-top: 1rem;
            }
        }
    </style>
</head>
<body class="dashboard-shell">
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4 dashboard-content">
        <h2>Welcome, <?php echo $_SESSION['full_name']; ?></h2>
        <p><?php echo date('l, F j, Y'); ?></p>
        
        <!-- ADMIN DASHBOARD -->
        <?php if($user_type == 'admin'): 
            $total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
            $total_patients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM patients"))['count'];
            $today_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE appointment_date = CURDATE()"))['count'];
        ?>
        <div class="row">
            <div class="col-md-3">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Users</h5>
                        <h2><?php echo $total_users; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Total Patients</h5>
                        <h2><?php echo $total_patients; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-info mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Today's Appointments</h5>
                        <h2><?php echo $today_appointments; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Pending Attendance</h5>
                        <?php 
                        $pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM attendance WHERE approval_status='pending'"))['count'];
                        ?>
                        <h2><?php echo $pending; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-dark text-white">
                        <h5 class="mb-0"><i class="fas fa-tools"></i> Admin Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <a href="workers.php" class="btn btn-outline-primary me-2 mb-2">
                            <i class="fas fa-users-cog"></i> Manage Workers
                        </a>
                        <a href="reports.php" class="btn btn-outline-success me-2 mb-2">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                        <a href="backup.php" class="btn btn-outline-warning me-2 mb-2">
                            <i class="fas fa-database"></i> Backup Manager
                        </a>
                        <a href="system_settings.php" class="btn btn-outline-secondary mb-2">
                            <i class="fas fa-cog"></i> System Settings
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- DOCTOR DASHBOARD -->
        <?php if($user_type == 'doctor'): 
            $today_appointments = mysqli_num_rows(mysqli_query($conn, 
                "SELECT * FROM appointments WHERE doctor_id=$user_id AND appointment_date=CURDATE()"));
            $pending_lab_filter = $has_doctor_approval ? "AND approved_by_doctor IS NULL" : "";
            $pending_lab = mysqli_num_rows(mysqli_query($conn,
                "SELECT * FROM lab_requests WHERE doctor_id=$user_id AND status='completed' $pending_lab_filter"));
        ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5>Today's Appointments</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $today_appointments; ?></h2>
                        <a href="appointments.php?date=<?php echo date('Y-m-d'); ?>" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5>Pending Lab Results</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $pending_lab; ?></h2>
                        <a href="lab_requests_list.php?status=completed" class="btn btn-warning">Review</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- NURSE DASHBOARD -->
        <?php if($user_type == 'nurse'): 
            $inpatients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM patients WHERE patient_type='inpatient'"))['count'];
        ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5>Current Inpatients</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $inpatients; ?></h2>
                        <a href="patients.php?type=inpatient" class="btn btn-info">View Patients</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- RECEPTIONIST DASHBOARD -->
        <?php if($user_type == 'receptionist'): 
            $today_appointments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM appointments WHERE appointment_date=CURDATE()"))['count'];
            $new_patients = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM patients WHERE DATE(registration_date)=CURDATE()"))['count'];
            $auto_bill_condition = "LOWER(COALESCE(notes, '')) LIKE '%auto-generated bill for uninsured patient%'";
            $auto_pending_reception = mysqli_fetch_assoc(mysqli_query($conn,
                "SELECT COUNT(*) as count
                 FROM billing
                 WHERE payment_status='pending'
                   AND $auto_bill_condition"
            ))['count'];
        ?>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5>Today's Appointments</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $today_appointments; ?></h2>
                        <a href="appointments.php?date=<?php echo date('Y-m-d'); ?>" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5>New Patients Today</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $new_patients; ?></h2>
                        <a href="register_patient.php" class="btn btn-success">Register New</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5>Auto Bills Pending</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo (int)$auto_pending_reception; ?></h2>
                        <a href="billing.php" class="btn btn-warning">Open Billing</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- LAB TECHNICIAN DASHBOARD -->
        <?php if($user_type == 'lab_tech'): 
            $pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM lab_requests WHERE status='pending'"))['count'];
            $processing = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM lab_requests WHERE status='processing'"))['count'];
        ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5>Pending Tests</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $pending; ?></h2>
                        <a href="lab_requests_list.php?status=pending" class="btn btn-warning">View</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5>In Progress</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $processing; ?></h2>
                        <a href="lab_requests_list.php?status=processing" class="btn btn-info">Continue</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- PHARMACIST DASHBOARD -->
        <?php if($user_type == 'pharmacist'): 
            $pending_rx = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM prescriptions WHERE status='sent_to_pharmacy'"))['count'];
            $low_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM inventory_items WHERE category='Medicine' AND quantity <= reorder_level"))['count'];
        ?>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5>Pending Prescriptions</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $pending_rx; ?></h2>
                        <a href="pharmacist_dashboard.php" class="btn btn-warning">Dispense</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5>Low Stock Items</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $low_stock; ?></h2>
                        <a href="inventory.php" class="btn btn-danger">Check Stock</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- ACCOUNTANT DASHBOARD -->
        <?php if($user_type == 'accountant'): 
            $has_payment_status = tableHasColumn('billing', 'payment_status');
            $has_bill_date = tableHasColumn('billing', 'bill_date');
            $amount_col = firstExistingColumn('billing', ['net_amount', 'total_amount']);
            $has_notes_col = tableHasColumn('billing', 'notes');

            $pending_condition = $has_payment_status ? "payment_status='pending'" : "1=1";
            $pending_bills = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM billing WHERE $pending_condition"))['count'];
            $auto_pending_accounting = 0;
            if ($has_payment_status && $has_notes_col) {
                $auto_pending_accounting = mysqli_fetch_assoc(mysqli_query($conn,
                    "SELECT COUNT(*) as count
                     FROM billing
                     WHERE payment_status='pending'
                       AND LOWER(COALESCE(notes, '')) LIKE '%auto-generated bill for uninsured patient%'"
                ))['count'];
            }

            if ($amount_col !== null) {
                $collection_where = [];
                if ($has_bill_date) {
                    $collection_where[] = "DATE(bill_date)=CURDATE()";
                }
                if ($has_payment_status) {
                    $collection_where[] = "payment_status='paid'";
                }
                $collection_clause = !empty($collection_where) ? ("WHERE " . implode(' AND ', $collection_where)) : '';
                $today_collection = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM($amount_col) as total FROM billing $collection_clause"))['total'];
            } else {
                $today_collection = 0;
            }
        ?>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5>Pending Bills</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo $pending_bills; ?></h2>
                        <a href="billing.php?status=pending" class="btn btn-warning">Process</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5>Today's Collection</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo format_currency($today_collection ?? 0); ?></h2>
                        <a href="reports.php?type=billing&date=<?php echo date('Y-m-d'); ?>" class="btn btn-success">Report</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5>Auto Bills Pending</h5>
                    </div>
                    <div class="card-body">
                        <h2><?php echo (int)$auto_pending_accounting; ?></h2>
                        <a href="billing.php" class="btn btn-info">Review</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
