<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['accountant']);

$conn = getConnection();
$user_type = $_SESSION['user_type'];
$allowed_providers = getAllowedTanzaniaInsuranceProviders();

function getInsuranceProviderCodeMap() {
    return [
        'National Insurance Corporation (NIC)' => 'NIC001',
        'Jubilee Insurance' => 'JUB001',
        'Alliance Insurance Tanzania' => 'ALI001',
        'Sanlam Tanzania' => 'SAN001',
        'Britam Insurance Tanzania' => 'BRI001',
        'Strategis Insurance Tanzania' => 'STR001',
        'Heritage Insurance Tanzania' => 'HER001',
        'Mayfair Insurance Tanzania' => 'MAY001',
        'Phoenix Insurance Tanzania' => 'PHX001',
        'Golden Crescent Insurance' => 'GCI001',
        'MGen Tanzania Insurance' => 'MGT001',
        'APA Insurance Tanzania' => 'APA001',
        'Zanzibar Insurance Corporation (ZIC)' => 'ZIC001',
        'Milvik Tanzania' => 'MLV001',
        'Tanzania Agricultural Insurance Scheme (TAIS)' => 'TAI001'
    ];
}

// Ensure all approved Tanzania insurance providers exist in DB
$provider_codes = getInsuranceProviderCodeMap();
foreach ($allowed_providers as $approved_name) {
    $safe_name = sanitize($approved_name);
    $exists_q = mysqli_query($conn, "SELECT provider_id FROM insurance_providers WHERE provider_name = '$safe_name' LIMIT 1");
    if ($exists_q && mysqli_num_rows($exists_q) === 0) {
        $safe_code = sanitize($provider_codes[$approved_name] ?? ('TZI' . rand(100, 999)));
        mysqli_query(
            $conn,
            "INSERT INTO insurance_providers (provider_name, provider_code, coverage_percentage)
             VALUES ('$safe_name', '$safe_code', 0.00)"
        );
    }
}

// Handle adding new insurance provider (only reception and admin)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_provider'])) {
    if (!in_array($user_type, ['receptionist', 'admin'])) {
        $_SESSION['error'] = "You don't have permission to add insurance providers";
        redirect('insurance.php');
    }
    
    $provider_name_raw = trim((string)($_POST['provider_name'] ?? ''));
    if (!in_array($provider_name_raw, $allowed_providers, true)) {
        $_SESSION['error'] = "Provider is not in the approved Tanzania insurance list";
        redirect('insurance.php');
    }
    $provider_name = sanitize($provider_name_raw);
    $provider_code = sanitize($provider_codes[$provider_name_raw] ?? ($_POST['provider_code'] ?? ''));
    $contact_person = sanitize($_POST['contact_person']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $coverage_percentage = floatval($_POST['coverage_percentage']);
    $terms = sanitize($_POST['terms']);
    
    if (!empty($phone) && !isValidPhoneNumber($phone)) {
        $_SESSION['error'] = getPhoneValidationMessage();
        redirect('insurance.php');
    }

    $query = "INSERT INTO insurance_providers (provider_name, provider_code, contact_person, phone, email, address, coverage_percentage, terms_conditions) 
              VALUES ('$provider_name', '$provider_code', '$contact_person', '$phone', '$email', '$address', $coverage_percentage, '$terms')";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Insurance provider added successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    redirect('insurance.php');
}

// Handle submitting new claim (reception and admin only)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_claim'])) {
    if (!in_array($user_type, ['receptionist', 'admin'])) {
        $_SESSION['error'] = "You don't have permission to submit claims";
        redirect('insurance.php');
    }
    
    $claim_number = generateUniqueId('CLM', 'insurance_claims', 'claim_number');
    $patient_id = sanitize($_POST['patient_id']);
    $provider_id = sanitize($_POST['provider_id']);
    $claim_amount = floatval($_POST['claim_amount']);
    $remarks = sanitize($_POST['remarks']);
    
    $query = "INSERT INTO insurance_claims (claim_number, patient_id, provider_id, claim_amount, remarks, status) 
              VALUES ('$claim_number', $patient_id, $provider_id, $claim_amount, '$remarks', 'pending')";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Insurance claim submitted successfully! Claim Number: $claim_number";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    redirect('insurance.php');
}

// Fetch data
$allowed_sql = array_map(function($name) use ($conn) {
    return "'" . mysqli_real_escape_string($conn, $name) . "'";
}, $allowed_providers);
$allowed_list_sql = implode(', ', $allowed_sql);

$providers = mysqli_query($conn, "SELECT * FROM insurance_providers WHERE provider_name IN ($allowed_list_sql) ORDER BY provider_name");
$claims = mysqli_query($conn, 
    "SELECT c.*, p.first_name, p.last_name, p.patient_number, pr.provider_name 
     FROM insurance_claims c
     JOIN patients p ON c.patient_id = p.patient_id
     JOIN insurance_providers pr ON c.provider_id = pr.provider_id
     ORDER BY c.claim_date DESC"
);
$patients_with_insurance = mysqli_query($conn, 
    "SELECT p.*, ip.provider_name 
     FROM patients p
     LEFT JOIN insurance_providers ip ON p.insurance_provider_id = ip.provider_id
     WHERE p.insurance_provider_id IS NOT NULL"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Management - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .claim-status {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .status-processing { background: #cce5ff; color: #004085; }
        
        .provider-card {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s;
            background: white;
        }
        .provider-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .view-only {
            opacity: 0.8;
            cursor: default;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Alerts -->
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <ul class="nav nav-tabs mb-4" id="insuranceTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="providers-tab" data-bs-toggle="tab" data-bs-target="#providers">
                    <i class="fas fa-building"></i> Insurance Providers
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="claims-tab" data-bs-toggle="tab" data-bs-target="#claims">
                    <i class="fas fa-file-medical"></i> Insurance Claims
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="patients-tab" data-bs-toggle="tab" data-bs-target="#patients">
                    <i class="fas fa-users"></i> Insured Patients
                </button>
            </li>
        </ul>
        
        <div class="tab-content">
            <!-- Insurance Providers Tab -->
            <div class="tab-pane fade show active" id="providers">
                <div class="row">
                    <!-- Add Provider Form - Only for reception and admin -->
                    <?php if(in_array($user_type, ['receptionist', 'admin'])): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5><i class="fas fa-plus-circle"></i> Add Insurance Provider</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                        <label class="form-label">Provider Name *</label>
                                        <select class="form-control" name="provider_name" required>
                                            <option value="">Select approved provider</option>
                                            <?php foreach($allowed_providers as $approved_provider): ?>
                                                <option value="<?php echo htmlspecialchars($approved_provider); ?>">
                                                    <?php echo htmlspecialchars($approved_provider); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Provider Code</label>
                                        <input type="text" class="form-control" name="provider_code" placeholder="Auto-filled from approved list">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contact Person</label>
                                        <input type="text" class="form-control" name="contact_person">
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Phone</label>
                                            <input type="tel" class="form-control" name="phone"
                                                   pattern="^(0\d{9}|\+\d{11,12})$"
                                                   title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Email</label>
                                            <input type="email" class="form-control" name="email">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Address</label>
                                        <textarea class="form-control" name="address" rows="2"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Coverage Percentage *</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" name="coverage_percentage" min="0" max="100" step="0.01" required>
                                            <span class="input-group-text">%</span>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Terms & Conditions</label>
                                        <textarea class="form-control" name="terms" rows="3"></textarea>
                                    </div>
                                    <button type="submit" name="add_provider" class="btn btn-primary w-100">
                                        <i class="fas fa-save"></i> Add Provider
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Providers List -->
                    <div class="col-md-<?php echo in_array($user_type, ['receptionist', 'admin']) ? '8' : '12'; ?>">
                        <div class="card">
                            <div class="card-header bg-info text-white">
                                <h5><i class="fas fa-list"></i> Insurance Providers List</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php while($provider = mysqli_fetch_assoc($providers)): ?>
                                        <div class="col-md-6">
                                            <div class="provider-card">
                                                <h5><?php echo htmlspecialchars($provider['provider_name']); ?></h5>
                                                <p class="text-muted">Code: <?php echo $provider['provider_code']; ?></p>
                                                <p>
                                                    <i class="fas fa-user"></i> <?php echo $provider['contact_person'] ?: 'N/A'; ?><br>
                                                    <i class="fas fa-phone"></i> <?php echo $provider['phone'] ?: 'N/A'; ?><br>
                                                    <i class="fas fa-envelope"></i> <?php echo $provider['email'] ?: 'N/A'; ?>
                                                </p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-success">Coverage: <?php echo $provider['coverage_percentage']; ?>%</span>
                                                    <div>
                                                        <a href="view_provider.php?id=<?php echo $provider['provider_id']; ?>" 
                                                           class="btn btn-sm btn-info">
                                                            <i class="fas fa-eye"></i> View
                                                        </a>
                                                        <!-- No edit button - providers cannot be edited -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Insurance Claims Tab -->
            <div class="tab-pane fade" id="claims">
                <div class="row">
                    <!-- Submit Claim Form - Only for reception and admin -->
                    <?php if(in_array($user_type, ['receptionist', 'admin'])): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5><i class="fas fa-file-medical"></i> Submit New Claim</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                        <label class="form-label">Patient *</label>
                                        <select class="form-control" name="patient_id" required>
                                            <option value="">Select Patient</option>
                                            <?php 
                                            $all_patients = mysqli_query($conn, "SELECT patient_id, patient_number, first_name, last_name FROM patients");
                                            while($patient = mysqli_fetch_assoc($all_patients)): 
                                            ?>
                                                <option value="<?php echo $patient['patient_id']; ?>">
                                                    <?php echo $patient['patient_number'] . ' - ' . $patient['first_name'] . ' ' . $patient['last_name']; ?>
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Insurance Provider *</label>
                                        <select class="form-control" name="provider_id" required>
                                            <option value="">Select Provider</option>
                                            <?php 
                                            mysqli_data_seek($providers, 0);
                                            while($provider = mysqli_fetch_assoc($providers)): 
                                            ?>
                                                <option value="<?php echo $provider['provider_id']; ?>">
                                                    <?php echo $provider['provider_name']; ?> (<?php echo $provider['coverage_percentage']; ?>% coverage)
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Claim Amount *</label>
                                        <div class="input-group">
                                            <span class="input-group-text">TSh</span>
                                            <input type="number" class="form-control" name="claim_amount" min="0" step="0.01" required>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Remarks</label>
                                        <textarea class="form-control" name="remarks" rows="3"></textarea>
                                    </div>
                                    <button type="submit" name="submit_claim" class="btn btn-success w-100">
                                        <i class="fas fa-paper-plane"></i> Submit Claim
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Claims List -->
                    <div class="col-md-<?php echo in_array($user_type, ['receptionist', 'admin']) ? '8' : '12'; ?>">
                        <div class="card">
                            <div class="card-header bg-warning">
                                <h5><i class="fas fa-list"></i> Insurance Claims</h5>
                            </div>
                            <div class="card-body">
                                <table id="claimsTable" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Claim #</th>
                                            <th>Patient</th>
                                            <th>Provider</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($claim = mysqli_fetch_assoc($claims)): ?>
                                            <tr>
                                                <td><?php echo $claim['claim_number']; ?></td>
                                                <td>
                                                    <?php echo $claim['patient_number']; ?><br>
                                                    <small><?php echo $claim['first_name'] . ' ' . $claim['last_name']; ?></small>
                                                </td>
                                                <td><?php echo $claim['provider_name']; ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($claim['claim_date'])); ?></td>
                                                <td>TSh <?php echo number_format($claim['claim_amount'], 2); ?></td>
                                                <td>
                                                    <span class="claim-status status-<?php echo $claim['status']; ?>">
                                                        <?php echo ucfirst($claim['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="view_insurance.php?id=<?php echo $claim['claim_id']; ?>" 
                                                       class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                    <!-- No edit/delete buttons - view only -->
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Insured Patients Tab -->
            <div class="tab-pane fade" id="patients">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-users"></i> Patients with Insurance Coverage</h5>
                    </div>
                    <div class="card-body">
                        <table id="insuredPatientsTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Patient #</th>
                                    <th>Name</th>
                                    <th>Insurance Provider</th>
                                    <th>Policy Number</th>
                                    <th>Contact</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($patient = mysqli_fetch_assoc($patients_with_insurance)): ?>
                                    <tr>
                                        <td><?php echo $patient['patient_number']; ?></td>
                                        <td><?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?></td>
                                        <td><?php echo $patient['provider_name']; ?></td>
                                        <td><?php echo $patient['insurance_policy_number']; ?></td>
                                        <td>
                                            <i class="fas fa-phone"></i> <?php echo $patient['phone']; ?>
                                        </td>
                                        <td>
                                            <a href="view_patient.php?id=<?php echo $patient['patient_id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#claimsTable, #insuredPatientsTable').DataTable({
                order: [[3, 'desc']],
                pageLength: 10
            });
        });
    </script>
</body>
</html>

