<?php
// navbar.php
$is_staff_user = isset($_SESSION['user_id']);
$current_user_type = $is_staff_user ? ($_SESSION['user_type'] ?? '') : '';
$is_admin_sidebar = ($is_staff_user && $current_user_type === 'admin');
?>
<link rel="stylesheet" href="assets/theme.css">
<style>
    .patient-nav .nav-link {
        font-weight: 600;
        opacity: 0.95;
        border-radius: 8px;
        margin-right: 0.15rem;
    }
    .patient-nav .nav-link:hover,
    .patient-nav .nav-link.active {
        background: rgba(255, 255, 255, 0.14);
        opacity: 1;
    }

    @media (max-width: 991.98px) {
        .navbar .navbar-nav .nav-link {
            padding: 0.65rem 0.25rem;
        }
        .navbar .navbar-nav.ms-auto {
            margin-left: 0.5rem !important;
        }
        .navbar .dropdown-menu {
            border: 0;
            box-shadow: none;
            padding-left: 0.5rem;
        }
        .navbar .dropdown-item {
            padding-left: 0.5rem;
        }
    }

    @media (min-width: 992px) {
        body.admin-sidebar-enabled {
            padding-left: 280px;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 280px;
            z-index: 1040;
            overflow-y: auto;
            align-items: flex-start;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav .container-fluid {
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            padding: 1rem;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav .navbar-brand {
            margin-bottom: 1rem;
            white-space: normal;
            font-weight: 700;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav .navbar-collapse {
            display: block !important;
            flex-grow: 1;
            overflow-y: auto;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav .navbar-nav {
            flex-direction: column;
            width: 100%;
        }
        body.admin-sidebar-enabled .navbar.admin-sidebar-nav .nav-link {
            padding: 0.55rem 0.5rem;
        }
        body.admin-sidebar-enabled .admin-top-user {
            display: none !important;
        }
        body.admin-sidebar-enabled .admin-user-menu {
            margin-top: auto;
            padding-top: 0.75rem;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        body.admin-sidebar-enabled .admin-user-menu .dropdown-menu {
            position: static !important;
            transform: none !important;
            width: 100%;
            margin-top: 0.25rem;
        }
    }
</style>
<?php if($is_admin_sidebar): ?>
<script>
    document.body.classList.add('admin-sidebar-enabled');
</script>
<?php endif; ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark <?php echo $is_admin_sidebar ? 'admin-sidebar-nav' : ''; ?>">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php 
            if (isset($_SESSION['user_id'])) {
                echo getRoleHomePage($_SESSION['user_type'] ?? '');
            } elseif (isset($_SESSION['patient_id'])) {
                echo 'patient_dashboard.php';
            } else {
                echo 'index.php';
            }
        ?>">
            <i class="fas fa-hospital"></i> <?php echo SITE_NAME; ?>
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <!-- Staff Navigation -->
            <?php if(isset($_SESSION['user_id'])): 
                $user_type = $_SESSION['user_type'];
            ?>
                <ul class="navbar-nav me-auto">
                    <!-- Dashboard - Everyone -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo getRoleHomePage($user_type); ?>">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    
                    <!-- Patients - Admin, Doctors, Nurses, Receptionists -->
                    <?php if(in_array($user_type, ['admin', 'doctor', 'nurse', 'receptionist'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users"></i> Patients
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Appointments - Admin, Doctors, Receptionists -->
                    <?php if(in_array($user_type, ['admin', 'doctor', 'receptionist'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">
                            <i class="fas fa-calendar-check"></i> Appointments
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Laboratory - Admin, Doctors, Lab Techs -->
                    <?php if(in_array($user_type, ['admin', 'doctor', 'lab_tech'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="lab_requests_list.php">
                            <i class="fas fa-flask"></i> Laboratory
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Inventory Management -->
                    <?php if(canAccessInventory(false)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="inventory.php">
                            <i class="fas fa-boxes"></i> Inventory Management
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Billing - Admin, Accountants, Receptionists -->
                    <?php if(in_array($user_type, ['admin', 'accountant', 'receptionist'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="billing.php">
                            <i class="fas fa-file-invoice-dollar"></i> Billing
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Insurance - Admin, Accountants -->
                    <?php if(in_array($user_type, ['admin', 'accountant'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="insurance.php">
                            <i class="fas fa-shield-alt"></i> Insurance
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- Human Resource - Admin, HR Admin -->
                    <?php if(in_array($user_type, ['admin', 'hr_admin'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="hr_dashboard.php">
                            <i class="fas fa-people-carry-box"></i> HR
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Reports - Admin only -->
                    <?php if($user_type == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar"></i> Reports
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Workers/Users - Admin only -->
                    <?php if($user_type == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="workers.php">
                            <i class="fas fa-user-md"></i> Workers
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- Attendance - Everyone -->
                    <li class="nav-item">
                        <a class="nav-link" href="worker_attendance.php">
                            <i class="fas fa-clock"></i> Attendance
                        </a>
                    </li>

                    <!-- Shift Management - Admin -->
                    <?php if($user_type == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="shift_management.php">
                            <i class="fas fa-business-time"></i> Shifts
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- Leave Request - All staff -->
                    <li class="nav-item">
                        <a class="nav-link" href="leave_request.php">
                            <i class="fas fa-calendar-minus"></i> Leave Request
                        </a>
                    </li>

                    <!-- Leave Approvals - Admin -->
                    <?php if($user_type == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="leave_approvals.php">
                            <i class="fas fa-user-check"></i> Leave Approvals
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            <?php elseif(isset($_SESSION['patient_id'])): 
                $current_page = basename($_SERVER['PHP_SELF'] ?? '');
            ?>
                <ul class="navbar-nav me-auto patient-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'patient_dashboard.php' ? 'active' : ''; ?>" href="patient_dashboard.php">
                            <i class="fas fa-gauge"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'view_medical_record.php' ? 'active' : ''; ?>" href="view_medical_record.php">
                            <i class="fas fa-notes-medical"></i> Medical Records
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'patient_billing.php' || $current_page === 'view_patient_bill.php' ? 'active' : ''; ?>" href="patient_billing.php">
                            <i class="fas fa-file-invoice"></i> Billing
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'patient_profile.php' ? 'active' : ''; ?>" href="patient_profile.php">
                            <i class="fas fa-id-card"></i> Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page === 'contact_support.php' ? 'active' : ''; ?>" href="contact_support.php">
                            <i class="fas fa-headset"></i> Support
                        </a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>

        <?php if($is_admin_sidebar): ?>
            <div class="admin-user-menu">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i>
                            <?php echo $_SESSION['full_name'] ?? 'Admin'; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="fas fa-id-card"></i> Profile
                            </a></li>
                            <li><a class="dropdown-item" href="change_password.php">
                                <i class="fas fa-key"></i> Change Password
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        <?php else: ?>
            <!-- User Menu (always visible, not hidden inside collapsed nav) -->
            <ul class="navbar-nav ms-auto admin-top-user">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> 
                            <?php echo $_SESSION['full_name'] ?? 'User'; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="fas fa-id-card"></i> Profile
                            </a></li>
                            <li><a class="dropdown-item" href="change_password.php">
                                <i class="fas fa-key"></i> Change Password
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                <?php elseif(isset($_SESSION['patient_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?php echo $_SESSION['patient_name'] ?? 'Patient'; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="patient_profile.php">
                                <i class="fas fa-id-card"></i> Profile
                            </a></li>
                            <li><a class="dropdown-item" href="view_medical_record.php">
                                <i class="fas fa-file-medical"></i> Medical Records
                            </a></li>
                            <li><a class="dropdown-item" href="patient_billing.php">
                                <i class="fas fa-file-invoice"></i> Billing History
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout_patient.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Staff Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="first_visit_appointment.php">First Visit Appointment</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patient_portal.php">Patient Portal</a>
                    </li>
                <?php endif; ?>
            </ul>
        <?php endif; ?>
    </div>
</nav>
<script>
    (function () {
        // Try loading Bootstrap bundle (if not already loaded).
        if (typeof window.bootstrap === 'undefined') {
            var script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js';
            script.defer = true;
            document.head.appendChild(script);
        }

        // Fallback: make navbar collapse + dropdown work even without Bootstrap JS.
        var navToggler = document.querySelector('.navbar-toggler');
        var navCollapse = document.getElementById('navbarNav');
        var dropdownToggles = document.querySelectorAll('.navbar .dropdown-toggle');

        if (navToggler && navCollapse) {
            navToggler.addEventListener('click', function () {
                navCollapse.classList.toggle('show');
            });
        }

        function closeAllDropdowns() {
            document.querySelectorAll('.navbar .dropdown-menu.show').forEach(function (menu) {
                menu.classList.remove('show');
            });
            dropdownToggles.forEach(function (toggle) {
                toggle.setAttribute('aria-expanded', 'false');
            });
        }

        dropdownToggles.forEach(function (toggle) {
            toggle.addEventListener('click', function (e) {
                // If Bootstrap JS failed to initialize, this fallback handles opening.
                e.preventDefault();
                var menu = toggle.nextElementSibling;
                if (!menu || !menu.classList.contains('dropdown-menu')) return;
                var isOpen = menu.classList.contains('show');
                closeAllDropdowns();
                if (!isOpen) {
                    menu.classList.add('show');
                    toggle.setAttribute('aria-expanded', 'true');
                }
            });
        });

        document.addEventListener('click', function (e) {
            if (!e.target.closest('.navbar .dropdown')) {
                closeAllDropdowns();
            }
        });
    })();
</script>
