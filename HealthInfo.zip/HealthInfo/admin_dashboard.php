<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();

// Get pending attendance approvals
$pending_attendance = mysqli_query($conn, 
    "SELECT a.*, u.full_name, u.employee_id, u.department, u.user_type
     FROM attendance a
     JOIN users u ON a.user_id = u.user_id
     WHERE a.approval_status = 'pending'
     ORDER BY a.date DESC, a.check_in DESC"
);

// Get approved attendance today
$approved_today = mysqli_query($conn,
    "SELECT COUNT(*) as count FROM attendance 
     WHERE DATE(date) = CURDATE() 
     AND approval_status = 'approved'"
);
$approved_count = mysqli_fetch_assoc($approved_today)['count'];

// Get pending count
$pending_count = $pending_attendance ? mysqli_num_rows($pending_attendance) : 0;
?>

<!-- In the admin dashboard, replace the attendance section with this: -->

<!-- Pending Attendance Approvals -->
<div class="col-md-6">
    <div class="card">
        <div class="card-header bg-warning text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-user-clock"></i> Pending Attendance Approvals</h5>
            <span class="badge bg-light text-dark"><?php echo $pending_count; ?> pending</span>
        </div>
        <div class="card-body">
            <?php if($pending_attendance && mysqli_num_rows($pending_attendance) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Date</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($att = mysqli_fetch_assoc($pending_attendance)): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($att['full_name']); ?></strong><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($att['employee_id']); ?></small>
                                    </td>
                                    <td><?php echo date('d-m-Y', strtotime($att['date'])); ?></td>
                                    <td>
                                        <?php if($att['check_in']): ?>
                                            <span class="badge bg-success">
                                                <?php echo date('h:i A', strtotime($att['check_in'])); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not checked in</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($att['check_out']): ?>
                                            <span class="badge bg-info">
                                                <?php echo date('h:i A', strtotime($att['check_out'])); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">Not checked out</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $att['status'] == 'present' ? 'success' : 
                                                ($att['status'] == 'late' ? 'warning' : 'secondary'); 
                                        ?>">
                                            <?php echo ucfirst($att['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="process_attendance.php?id=<?php echo $att['attendance_id']; ?>&action=approve" 
                                               class="btn btn-success" 
                                               onclick="return confirmApprove('<?php echo htmlspecialchars(addslashes($att['full_name'])); ?>')">
                                                <i class="fas fa-check"></i> Approve
                                            </a>
                                            <a href="process_attendance.php?id=<?php echo $att['attendance_id']; ?>&action=reject" 
                                               class="btn btn-danger"
                                               onclick="return confirmReject('<?php echo htmlspecialchars(addslashes($att['full_name'])); ?>')">
                                                <i class="fas fa-times"></i> Reject
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                    <p class="text-muted">No pending attendance approvals</p>
                    <p class="text-success">All attendance records are up to date!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add this JavaScript at the bottom of admin_dashboard.php -->
<script>
function confirmApprove(name) {
    return confirm('Are you sure you want to approve attendance for ' + name + '?');
}

function confirmReject(name) {
    return confirm('Are you sure you want to reject attendance for ' + name + '? This may affect their payroll.');
}
</script>