<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor', 'lab_tech']);

$conn = getConnection();
$user_type = $_SESSION['user_type'];
$user_id = $_SESSION['user_id'];
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');

// Handle status update via AJAX
if (isset($_POST['update_status'])) {
    $request_id = sanitize($_POST['request_id']);
    $status = sanitize($_POST['status']);
    
    $query = "UPDATE lab_requests SET status = '$status' WHERE request_id = $request_id";
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
    exit();
}

// Handle result submission
if (isset($_POST['submit_result'])) {
    $request_id = sanitize($_POST['request_id']);
    $result_value = sanitize($_POST['result_value']);
    $result_notes = sanitize($_POST['result_notes']);

    $updates = [];
    if (tableHasColumn('lab_requests', 'status')) {
        $updates[] = "status = 'completed'";
    }
    if (tableHasColumn('lab_requests', 'result_value')) {
        $updates[] = "result_value = '$result_value'";
    }
    $result_notes_column = firstExistingColumn('lab_requests', ['result_notes', 'lab_notes', 'notes']);
    if ($result_notes_column !== null) {
        $updates[] = "$result_notes_column = '$result_notes'";
    }
    if (tableHasColumn('lab_requests', 'result_date')) {
        $updates[] = "result_date = NOW()";
    }
    if (tableHasColumn('lab_requests', 'lab_tech_id')) {
        $updates[] = "lab_tech_id = $user_id";
    }
    if (empty($updates)) {
        $updates[] = "request_id = request_id";
    }
    $query = "UPDATE lab_requests SET " . implode(', ', $updates) . " WHERE request_id = $request_id";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Lab result submitted successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    redirect('lab_requests_list.php');
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$date_from = isset($_GET['date_from']) ? sanitize($_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? sanitize($_GET['date_to']) : '';
$patient_filter = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

// Build query based on user role
$where = [];

if ($user_type == 'doctor') {
    $where[] = "lr.doctor_id = $user_id";
} elseif ($user_type == 'lab_tech') {
    // Lab techs can see all pending and their assigned
    if ($status_filter == 'my_assigned') {
        $where[] = "lr.lab_tech_id = $user_id";
    }
}

if ($status_filter && $status_filter != 'my_assigned') {
    $where[] = "lr.status = '$status_filter'";
}
if ($date_from) {
    $where[] = "DATE(lr.request_date) >= '$date_from'";
}
if ($date_to) {
    $where[] = "DATE(lr.request_date) <= '$date_to'";
}
if ($patient_filter > 0) {
    $where[] = "lr.patient_id = $patient_filter";
}

$where_clause = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

// Fetch lab requests
$query = "SELECT lr.*, 
          p.first_name, p.last_name, p.patient_number, p.date_of_birth,
          lt.test_name, lt.category, lt.normal_range, lt.unit,
          u.full_name as doctor_name,
          tech.full_name as tech_name
          FROM lab_requests lr
          JOIN patients p ON lr.patient_id = p.patient_id
          JOIN lab_tests lt ON lr.test_id = lt.test_id
          JOIN users u ON lr.doctor_id = u.user_id
          LEFT JOIN users tech ON lr.lab_tech_id = tech.user_id
          $where_clause
          ORDER BY 
            CASE lr.status 
                WHEN 'pending' THEN 1
                WHEN 'processing' THEN 2
                WHEN 'completed' THEN 3
                ELSE 4
            END,
          lr.request_date DESC";

$lab_requests = mysqli_query($conn, $query);

// Get statistics
$stats = [];
$stats_query = "SELECT 
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'processing' THEN 1 ELSE 0 END) as processing,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
    FROM lab_requests";
$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
$patients_for_filter = mysqli_query($conn, "SELECT patient_id, patient_number, first_name, last_name FROM patients ORDER BY first_name, last_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Requests - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #cce5ff; color: #004085; }
        .status-completed { background: #d4edda; color: #155724; }
        .filter-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-flask"></i> Laboratory Requests</h2>
            </div>
            <div class="col-md-4 text-end">
                <?php if(in_array($user_type, ['doctor', 'admin'])): ?>
                    <a href="lab_request.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> New Lab Request
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-warning">
                    <div class="card-body">
                        <h5>Pending</h5>
                        <h2><?php echo $stats['pending'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5>In Progress</h5>
                        <h2><?php echo $stats['processing'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5>Completed</h5>
                        <h2><?php echo $stats['completed'] ?? 0; ?></h2>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="filter-card">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select class="form-control" name="status">
                        <option value="">All Status</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                        <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <?php if($user_type == 'lab_tech'): ?>
                            <option value="my_assigned" <?php echo $status_filter == 'my_assigned' ? 'selected' : ''; ?>>My Assigned</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date From</label>
                    <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date To</label>
                    <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Patient</label>
                    <select class="form-control" name="patient_id">
                        <option value="">All Patients</option>
                        <?php if($patients_for_filter): ?>
                            <?php while($pf = mysqli_fetch_assoc($patients_for_filter)): ?>
                                <option value="<?php echo (int)$pf['patient_id']; ?>" <?php echo $patient_filter === (int)$pf['patient_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($pf['patient_number'] . ' - ' . $pf['first_name'] . ' ' . $pf['last_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                </div>
            </form>
        </div>
        
        <!-- Lab Requests Table -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Lab Requests List</h5>
            </div>
            <div class="card-body">
                <?php if(isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <?php if(isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table id="labRequestsTable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Request #</th>
                                <th>Date</th>
                                <th>Patient</th>
                                <th>Test</th>
                                <th>Doctor</th>
                                <th>Status</th>
                                <th>Result</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($lab_requests) > 0): ?>
                                <?php while($req = mysqli_fetch_assoc($lab_requests)): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo $req['request_number']; ?></strong>
                                        </td>
                                        <td>
                                            <?php echo date('d-m-Y', strtotime($req['request_date'])); ?><br>
                                            <small><?php echo date('h:i A', strtotime($req['request_date'])); ?></small>
                                        </td>
                                        <td>
                                            <strong><?php echo $req['first_name'] . ' ' . $req['last_name']; ?></strong><br>
                                            <small>
                                                #<?php echo $req['patient_number']; ?><br>
                                                Age: <?php 
                                                    $dob = new DateTime($req['date_of_birth']);
                                                    $now = new DateTime();
                                                    echo $now->diff($dob)->y;
                                                ?> yrs
                                            </small>
                                        </td>
                                        <td>
                                            <strong><?php echo $req['test_name']; ?></strong><br>
                                            <small><?php echo $req['category']; ?></small>
                                        </td>
                                        <td>Dr. <?php echo $req['doctor_name']; ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $req['status']; ?>">
                                                <?php echo ucfirst($req['status']); ?>
                                                <?php if($req['lab_tech_id']): ?>
                                                    <br><small><?php echo $req['tech_name']; ?></small>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if($req['status'] == 'completed'): ?>
                                                <?php
                                                    $display_unit = normalizeLabUnit($req['unit'] ?? '');
                                                    $parsed_result_notes = parseStructuredLabNotes($req['result_notes'] ?? ($req['lab_notes'] ?? ''));
                                                ?>
                                                <strong><?php echo htmlspecialchars($req['result_value']); ?><?php echo $display_unit !== '' ? ' ' . htmlspecialchars($display_unit) : ''; ?></strong><br>
                                                <?php if (!empty($parsed_result_notes['parameters'])): ?>
                                                    <small class="text-success"><?php echo count($parsed_result_notes['parameters']); ?> parameters recorded</small><br>
                                                <?php endif; ?>
                                                <small>Normal: <?php echo $req['normal_range']; ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-sm btn-info" onclick="viewDetails(<?php echo $req['request_id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                
                                                <?php if($user_type == 'lab_tech' && $req['status'] == 'pending'): ?>
                                                    <a class="btn btn-sm btn-warning" href="collect_sample.php?id=<?php echo $req['request_id']; ?>">
                                                        <i class="fas fa-syringe"></i> Collect
                                                    </a>
                                                <?php endif; ?>
                                                
                                                <?php if($user_type == 'lab_tech' && $req['status'] == 'processing' && $req['lab_tech_id'] == $user_id): ?>
                                                    <button class="btn btn-sm btn-success" onclick="addResult(<?php echo $req['request_id']; ?>)">
                                                        <i class="fas fa-pen"></i> Add Result
                                                    </button>
                                                <?php endif; ?>
                                                
                                                <?php if($user_type == 'doctor' && $req['status'] == 'completed' && (!$has_doctor_approval || empty($req['approved_by_doctor']))): ?>
                                                    <button class="btn btn-sm btn-primary" onclick="reviewResult(<?php echo $req['request_id']; ?>)">
                                                        <i class="fas fa-check-circle"></i> Review
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">No lab requests found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Result Modal -->
    <div class="modal fade" id="resultModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-flask"></i> Add Lab Result</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="resultForm">
                    <div class="modal-body">
                        <input type="hidden" name="request_id" id="result_request_id">
                        <div id="testInfo" class="alert alert-info"></div>
                        
                        <div class="mb-3">
                            <label class="form-label">Result Value *</label>
                            <input type="text" class="form-control" name="result_value" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="result_notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="submit_result" class="btn btn-success">Submit Result</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#labRequestsTable').DataTable({
                order: [[1, 'desc']],
                pageLength: 25
            });
        });
        
        function viewDetails(id) {
            window.location.href = 'view_lab_request.php?id=' + id;
        }
        
        function addResult(id) {
            window.location.href = 'add_lab_result.php?id=' + id;
        }
        
        function reviewResult(id) {
            window.location.href = 'review_lab_result.php?id=' + id;
        }
        
        function updateStatus(id, status) {
            $.ajax({
                url: 'lab_requests_list.php',
                method: 'POST',
                data: { update_status: true, request_id: id, status: status },
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        location.reload();
                    }
                }
            });
        }
    </script>
</body>
</html>
