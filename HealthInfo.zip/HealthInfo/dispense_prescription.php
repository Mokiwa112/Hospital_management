<?php
require_once 'config.php';
requireRole('pharmacist');

$conn = getConnection();
$prescription_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$pharmacist_id = (int)$_SESSION['user_id'];
$has_dispensed_date = tableHasColumn('prescriptions', 'dispensed_date');
$has_pharmacist_id = tableHasColumn('prescriptions', 'pharmacist_id');

function getPrescriptionStatusValuesForDispense($conn) {
    $values = [];
    $res = mysqli_query($conn, "SHOW COLUMNS FROM prescriptions LIKE 'status'");
    if ($res && ($row = mysqli_fetch_assoc($res)) && !empty($row['Type'])) {
        if (preg_match("/^enum\\((.*)\\)$/i", $row['Type'], $m)) {
            $values = str_getcsv($m[1], ',', "'");
        }
    }
    return $values;
}

if ($prescription_id <= 0) {
    $_SESSION['error'] = "Invalid prescription";
    redirect('pharmacist_dashboard.php');
}

$result = mysqli_query(
    $conn,
    "SELECT p.*, pt.first_name, pt.last_name, pt.patient_number
     FROM prescriptions p
     JOIN patients pt ON p.patient_id = pt.patient_id
     WHERE p.prescription_id = $prescription_id"
);

if (!$result || mysqli_num_rows($result) === 0) {
    $_SESSION['error'] = "Prescription not found";
    redirect('pharmacist_dashboard.php');
}

$prescription = mysqli_fetch_assoc($result);

if ($prescription['status'] === 'dispensed') {
    $_SESSION['success'] = "Prescription already dispensed";
    redirect("view_prescription.php?id=$prescription_id");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notes = sanitize($_POST['dispense_notes'] ?? '');
    $status_values = getPrescriptionStatusValuesForDispense($conn);
    $done_status = in_array('dispensed', $status_values, true) ? 'dispensed' : $prescription['status'];

    $updates = [];
    if (in_array('dispensed', $status_values, true)) {
        $updates[] = "status = '$done_status'";
    }
    if ($has_dispensed_date) {
        $updates[] = "dispensed_date = NOW()";
    }
    if ($has_pharmacist_id) {
        $updates[] = "pharmacist_id = $pharmacist_id";
    }
    $updates[] = "notes = CONCAT(IFNULL(notes, ''), '\nDispense: ', '$notes')";

    $query = "UPDATE prescriptions SET " . implode(', ', $updates) . " WHERE prescription_id = $prescription_id";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Prescription dispensed successfully";
        redirect('pharmacist_dashboard.php');
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dispense Prescription - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-check"></i> Dispense Prescription</h5>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <p><strong>Prescription #:</strong> <?php echo htmlspecialchars($prescription['prescription_number']); ?></p>
                <p><strong>Patient:</strong> <?php echo htmlspecialchars($prescription['first_name'] . ' ' . $prescription['last_name']); ?> (<?php echo htmlspecialchars($prescription['patient_number']); ?>)</p>
                <p><strong>Diagnosis:</strong> <?php echo htmlspecialchars($prescription['diagnosis']); ?></p>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Dispense Notes</label>
                        <textarea name="dispense_notes" class="form-control" rows="3" placeholder="Optional notes"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check-circle"></i> Confirm Dispense
                    </button>
                    <a href="view_prescription.php?id=<?php echo $prescription_id; ?>" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
