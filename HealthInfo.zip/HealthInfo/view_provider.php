<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$provider_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch provider details
$query = "SELECT * FROM insurance_providers WHERE provider_id = $provider_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Insurance provider not found";
    header("Location: insurance.php");
    exit();
}

$provider = mysqli_fetch_assoc($result);

// Fetch claims for this provider
$claims = mysqli_query($conn,
    "SELECT c.*, p.first_name, p.last_name, p.patient_number
     FROM insurance_claims c
     JOIN patients p ON c.patient_id = p.patient_id
     WHERE c.provider_id = $provider_id
     ORDER BY c.claim_date DESC
     LIMIT 20"
);

// Fetch patients using this provider
$patients = mysqli_query($conn,
    "SELECT patient_id, patient_number, first_name, last_name, insurance_policy_number
     FROM patients 
     WHERE insurance_provider_id = $provider_id"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Provider Details - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .info-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
            margin-bottom: 0.2rem;
        }
        .info-value {
            margin-bottom: 1rem;
            padding: 0.5rem;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .provider-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Header -->
        <div class="provider-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2><i class="fas fa-building"></i> <?php echo htmlspecialchars($provider['provider_name']); ?></h2>
                    <p class="mb-0">
                        <i class="fas fa-code"></i> Provider Code: <?php echo $provider['provider_code']; ?> |
                        <i class="fas fa-percent"></i> Coverage: <?php echo $provider['coverage_percentage']; ?>%
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="insurance.php" class="btn btn-light">
                        <i class="fas fa-arrow-left"></i> Back to Insurance
                    </a>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Provider Information -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Provider Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="info-label">Provider Name</div>
                        <div class="info-value"><?php echo htmlspecialchars($provider['provider_name']); ?></div>
                        
                        <div class="info-label">Provider Code</div>
                        <div class="info-value"><?php echo $provider['provider_code']; ?></div>
                        
                        <div class="info-label">Contact Person</div>
                        <div class="info-value"><?php echo htmlspecialchars($provider['contact_person'] ?: 'Not specified'); ?></div>
                        
                        <div class="info-label">Phone</div>
                        <div class="info-value"><?php echo $provider['phone'] ?: 'Not specified'; ?></div>
                        
                        <div class="info-label">Email</div>
                        <div class="info-value"><?php echo $provider['email'] ?: 'Not specified'; ?></div>
                        
                        <div class="info-label">Address</div>
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($provider['address'] ?: 'Not specified')); ?></div>
                        
                        <div class="info-label">Coverage Percentage</div>
                        <div class="info-value"><?php echo $provider['coverage_percentage']; ?>%</div>
                        
                        <div class="info-label">Terms & Conditions</div>
                        <div class="info-value">
                            <?php 
                            if (!empty($provider['terms_conditions'])) {
                                echo nl2br(htmlspecialchars($provider['terms_conditions']));
                            } else {
                                echo '<em class="text-muted">No terms and conditions specified</em>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Patients Using This Provider -->
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-users"></i> Patients Using This Provider</h5>
                    </div>
                    <div class="card-body">
                        <?php if($patients && mysqli_num_rows($patients) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Patient #</th>
                                            <th>Name</th>
                                            <th>Policy Number</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($patient = mysqli_fetch_assoc($patients)): ?>
                                            <tr>
                                                <td><?php echo $patient['patient_number']; ?></td>
                                                <td><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></td>
                                                <td><?php echo $patient['insurance_policy_number']; ?></td>
                                                <td>
                                                    <a href="view_patient.php?id=<?php echo $patient['patient_id']; ?>" 
                                                       class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-user-slash fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No patients are currently using this insurance provider</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Recent Claims -->
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0"><i class="fas fa-file-medical"></i> Recent Claims</h5>
                    </div>
                    <div class="card-body">
                        <?php if($claims && mysqli_num_rows($claims) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Claim #</th>
                                            <th>Patient</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($claim = mysqli_fetch_assoc($claims)): ?>
                                            <tr>
                                                <td><?php echo $claim['claim_number']; ?></td>
                                                <td><?php echo htmlspecialchars($claim['first_name'] . ' ' . $claim['last_name']); ?></td>
                                                <td><?php echo date('d-m-Y', strtotime($claim['claim_date'])); ?></td>
                                                <td>TSh <?php echo number_format($claim['claim_amount'], 2); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $claim['status'] == 'approved' ? 'success' : 
                                                            ($claim['status'] == 'pending' ? 'warning' : 
                                                            ($claim['status'] == 'rejected' ? 'danger' : 'secondary')); 
                                                    ?>">
                                                        <?php echo ucfirst($claim['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="view_insurance.php?id=<?php echo $claim['claim_id']; ?>" 
                                                       class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                                <p class="text-muted">No claims have been submitted to this provider</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>