<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();

// Load settings
$settings_file = __DIR__ . '/settings.json';
$settings = [];
if (file_exists($settings_file)) {
    $settings = json_decode(file_get_contents($settings_file), true);
}

$backup_path = $settings['backup_path'] ?? __DIR__ . '/backups/';

// Create backup directory if it doesn't exist
if (!is_dir($backup_path)) {
    mkdir($backup_path, 0777, true);
}

// Handle backup creation
if (isset($_POST['create_backup'])) {
    $backup_type = sanitize($_POST['backup_type']);
    $backup_name = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $backup_file = $backup_path . $backup_name;
    
    // Get database configuration
    $db_host = DB_HOST;
    $db_user = DB_USER;
    $db_pass = DB_PASS;
    $db_name = DB_NAME;
    
    // Try using PHP's MySQL functions first
    $success = false;
    $error_message = '';
    
    // Method 1: Try using mysqldump (command line)
    $command = "\"C:\\xampp\\mysql\\bin\\mysqldump\" --host=$db_host --user=$db_user --password=$db_pass $db_name > \"$backup_file\" 2>&1";
    $output = [];
    $return_var = 0;
    exec($command, $output, $return_var);
    
    if ($return_var === 0 && file_exists($backup_file) && filesize($backup_file) > 0) {
        $success = true;
    } else {
        // Method 2: Fallback to PHP-based backup
        $backup_content = "";
        
        // Get all tables
        $tables_query = "SHOW TABLES";
        $tables_result = mysqli_query($conn, $tables_query);
        
        while ($table_row = mysqli_fetch_row($tables_result)) {
            $table = $table_row[0];
            
            // Get create table syntax
            $create_query = "SHOW CREATE TABLE `$table`";
            $create_result = mysqli_query($conn, $create_query);
            $create_row = mysqli_fetch_row($create_result);
            $backup_content .= "\n\n" . $create_row[1] . ";\n\n";
            
            // Get table data
            $data_query = "SELECT * FROM `$table`";
            $data_result = mysqli_query($conn, $data_query);
            $num_fields = mysqli_num_fields($data_result);
            
            while ($row = mysqli_fetch_row($data_result)) {
                $backup_content .= "INSERT INTO `$table` VALUES(";
                for ($j = 0; $j < $num_fields; $j++) {
                    if (isset($row[$j])) {
                        $backup_content .= "'" . mysqli_real_escape_string($conn, $row[$j]) . "'";
                    } else {
                        $backup_content .= "NULL";
                    }
                    if ($j < ($num_fields - 1)) {
                        $backup_content .= ",";
                    }
                }
                $backup_content .= ");\n";
            }
        }
        
        // Save backup file
        if (file_put_contents($backup_file, $backup_content)) {
            $success = true;
        } else {
            $error_message = "Failed to create backup file. Check directory permissions.";
        }
    }
    
    if ($success) {
        // Log the backup
        $log_query = "INSERT INTO backups (backup_name, backup_type, file_size, created_by) 
                      VALUES ('$backup_name', '$backup_type', " . filesize($backup_file) . ", {$_SESSION['user_id']})";
        @mysqli_query($conn, $log_query);
        
        $_SESSION['success'] = "Backup created successfully! File: $backup_name";
    } else {
        $_SESSION['error'] = "Error creating backup: " . ($error_message ?: "Unknown error");
    }
    
    redirect('backup.php');
}

// Handle backup download
if (isset($_GET['download'])) {
    $backup_file = $backup_path . basename($_GET['download']);
    if (file_exists($backup_file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($backup_file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($backup_file));
        readfile($backup_file);
        exit();
    }
}

// Handle backup restore
if (isset($_POST['restore_backup'])) {
    $backup_file = $backup_path . basename($_POST['backup_file']);
    
    if (file_exists($backup_file)) {
        // Read SQL file
        $sql = file_get_contents($backup_file);
        
        // Split SQL into individual queries
        $queries = explode(';', $sql);
        $success = true;
        
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!mysqli_query($conn, $query)) {
                    $success = false;
                    $error_message = mysqli_error($conn);
                    break;
                }
            }
        }
        
        if ($success) {
            $_SESSION['success'] = "Database restored successfully from: " . basename($backup_file);
        } else {
            $_SESSION['error'] = "Error restoring database: " . $error_message;
        }
    } else {
        $_SESSION['error'] = "Backup file not found";
    }
    
    redirect('backup.php');
}

// Handle backup deletion
if (isset($_GET['delete'])) {
    $backup_file = $backup_path . basename($_GET['delete']);
    if (file_exists($backup_file)) {
        unlink($backup_file);
        $_SESSION['success'] = "Backup deleted successfully";
    }
    redirect('backup.php');
}

// Get list of backup files
$backup_files = glob($backup_path . '*.sql');
if ($backup_files === false) {
    $backup_files = [];
}
usort($backup_files, function($a, $b) {
    return filemtime($b) - filemtime($a);
});

// Get backup statistics
$total_size = 0;
$latest_backup = null;
foreach ($backup_files as $file) {
    $total_size += filesize($file);
    if (!$latest_backup || filemtime($file) > filemtime($latest_backup)) {
        $latest_backup = $file;
    }
}

// Check if backups table exists
$table_check = mysqli_query($conn, "SHOW TABLES LIKE 'backups'");
$backup_log = [];
if (mysqli_num_rows($table_check) > 0) {
    $backup_log = mysqli_query($conn, "SELECT * FROM backups ORDER BY created_at DESC LIMIT 10");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup Manager - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .backup-stats {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .stat-card {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            margin: 10px 0;
        }
        .action-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            height: 100%;
        }
        .file-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .file-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #eee;
            transition: all 0.3s;
        }
        .file-item:hover {
            background: #f8f9fa;
        }
        .file-item:last-child {
            border-bottom: none;
        }
        .file-info {
            flex: 1;
        }
        .file-name {
            font-weight: 600;
            color: #333;
        }
        .file-meta {
            font-size: 12px;
            color: #666;
        }
        .file-actions {
            display: flex;
            gap: 8px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-database"></i> Backup Manager</h2>
                <p>Create, restore, and manage database backups</p>
            </div>
        </div>
        
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Backup Statistics -->
        <div class="backup-stats">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-database fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo count($backup_files); ?></div>
                        <div>Total Backups</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-hdd fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo round($total_size / (1024 * 1024), 2); ?> MB</div>
                        <div>Total Size</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <div class="stat-number">
                            <?php 
                            if ($latest_backup) {
                                echo date('d M H:i', filemtime($latest_backup));
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </div>
                        <div>Latest Backup</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-folder-open fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo is_writable($backup_path) ? 'Yes' : 'No'; ?></div>
                        <div>Writable</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Create Backup -->
            <div class="col-md-4">
                <div class="action-card">
                    <h5 class="mb-3"><i class="fas fa-plus-circle text-primary"></i> Create New Backup</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Backup Type</label>
                            <select class="form-control" name="backup_type" required>
                                <option value="full">Full Database Backup</option>
                                <option value="structure">Structure Only</option>
                                <option value="data">Data Only</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Backup Location</label>
                            <div class="input-group">
                                <input type="text" class="form-control" value="<?php echo $backup_path; ?>" readonly>
                                <span class="input-group-text <?php echo is_writable($backup_path) ? 'bg-success text-white' : 'bg-danger text-white'; ?>">
                                    <i class="fas fa-<?php echo is_writable($backup_path) ? 'check' : 'times'; ?>"></i>
                                </span>
                            </div>
                            <small class="text-muted">Make sure this directory is writable</small>
                        </div>
                        
                        <button type="submit" name="create_backup" class="btn btn-primary w-100">
                            <i class="fas fa-play"></i> Create Backup Now
                        </button>
                    </form>
                    
                    <hr>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 
                        <strong>Auto Backup Settings:</strong><br>
                        <?php if (isset($settings['auto_backup']) && $settings['auto_backup']): ?>
                            Frequency: <?php echo ucfirst($settings['backup_frequency'] ?? 'daily'); ?><br>
                            Retain: <?php echo $settings['retain_backups'] ?? '30'; ?> days
                        <?php else: ?>
                            Automatic backups are disabled. Enable in System Settings.
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Backup Files -->
            <div class="col-md-8">
                <div class="action-card">
                    <h5 class="mb-3"><i class="fas fa-list text-success"></i> Available Backups</h5>
                    
                    <?php if (!empty($backup_files)): ?>
                        <div class="file-list">
                            <?php foreach($backup_files as $file): 
                                $file_size = filesize($file);
                                $file_date = filemtime($file);
                                $file_name = basename($file);
                            ?>
                                <div class="file-item">
                                    <div class="file-info">
                                        <div class="file-name">
                                            <i class="fas fa-file-archive text-primary me-2"></i>
                                            <?php echo $file_name; ?>
                                        </div>
                                        <div class="file-meta">
                                            <span class="me-3">
                                                <i class="far fa-calendar"></i> <?php echo date('d M Y H:i:s', $file_date); ?>
                                            </span>
                                            <span>
                                                <i class="far fa-file"></i> <?php echo round($file_size / 1024, 2); ?> KB
                                            </span>
                                        </div>
                                    </div>
                                    <div class="file-actions">
                                        <a href="?download=<?php echo urlencode($file_name); ?>" 
                                           class="btn btn-sm btn-success" title="Download">
                                            <i class="fas fa-download"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-warning" 
                                                onclick="restoreBackup('<?php echo $file_name; ?>')" title="Restore">
                                            <i class="fas fa-undo"></i>
                                        </button>
                                        <a href="?delete=<?php echo urlencode($file_name); ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Are you sure you want to delete this backup?')"
                                           title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                            <p class="text-muted">No backup files found</p>
                            <p class="small text-muted">Create your first backup using the form on the left</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Restore Confirmation Modal -->
    <div class="modal fade" id="restoreModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Restore Backup</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="backup_file" id="restore_file">
                        
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i>
                            <strong>Warning!</strong> Restoring a backup will overwrite your current database. 
                            This action cannot be undone.
                        </div>
                        
                        <p>Are you sure you want to restore the backup: <strong id="restore_filename"></strong>?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="restore_backup" class="btn btn-warning">Restore Backup</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function restoreBackup(filename) {
            document.getElementById('restore_file').value = filename;
            document.getElementById('restore_filename').textContent = filename;
            $('#restoreModal').modal('show');
        }
    </script>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>