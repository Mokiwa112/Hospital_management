<?php
require_once 'config.php';

// Require patient login
requirePatientLogin();

$conn = getConnection();
$patient_id = $_SESSION['patient_id'];

// Fetch patient details
$patient_query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$patient_result = mysqli_query($conn, $patient_query);

if (!$patient_result || mysqli_num_rows($patient_result) == 0) {
    $_SESSION['error'] = "Patient record not found";
    redirect('patient_portal.php');
}

$patient = mysqli_fetch_assoc($patient_result);

// Fetch appointments
$appointments = mysqli_query($conn,
    "SELECT a.*, u.full_name as doctor_name, u.department 
     FROM appointments a
     JOIN users u ON a.doctor_id = u.user_id
     WHERE a.patient_id = $patient_id 
     ORDER BY a.appointment_date DESC"
);

// Fetch lab results
$lab_results = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.normal_range, lt.unit 
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = $patient_id 
     ORDER BY lr.request_date DESC"
);

// Fetch prescriptions with items
$prescriptions = mysqli_query($conn,
    "SELECT p.*, u.full_name as doctor_name 
     FROM prescriptions p
     JOIN users u ON p.doctor_id = u.user_id
     WHERE p.patient_id = $patient_id 
     ORDER BY p.prescription_date DESC"
);

// Fetch prescription items
$prescription_items = [];
if (mysqli_num_rows($prescriptions) > 0) {
    $prescription_ids = [];
    while($pres = mysqli_fetch_assoc($prescriptions)) {
        $prescription_ids[] = $pres['prescription_id'];
    }
    
    if (!empty($prescription_ids)) {
        $ids_string = implode(',', $prescription_ids);
        $items_query = "SELECT * FROM prescription_items WHERE prescription_id IN ($ids_string)";
        $items_result = mysqli_query($conn, $items_query);
        while($item = mysqli_fetch_assoc($items_result)) {
            $prescription_items[$item['prescription_id']][] = $item;
        }
    }
    
    // Reset prescription pointer
    mysqli_data_seek($prescriptions, 0);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Record - <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @media print {
            .no-print, .btn, .navbar {
                display: none !important;
            }
            body {
                background: white;
                font-size: 12pt;
            }
            .card {
                border: 1px solid #ddd !important;
                break-inside: avoid;
            }
        }
        .record-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #007bff;
        }
        .section-title {
            background: #007bff;
            color: white;
            padding: 10px;
            margin: 20px 0 10px;
            border-radius: 5px;
        }
        .info-label {
            font-weight: bold;
            color: #666;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4 mb-5">
        <div class="no-print mb-3">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Record
            </button>
            <a href="patient_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <!-- Record Header -->
        <div class="record-header">
            <h2><?php echo SITE_NAME; ?></h2>
            <h3>Complete Medical Record</h3>
        </div>
        
        <!-- Patient Information -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-user"></i> Patient Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <span class="info-label">Patient Name:</span><br>
                        <strong><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></strong>
                    </div>
                    <div class="col-md-2">
                        <span class="info-label">Patient #:</span><br>
                        <strong><?php echo htmlspecialchars($patient['patient_number']); ?></strong>
                    </div>
                    <div class="col-md-2">
                        <span class="info-label">Date of Birth:</span><br>
                        <strong><?php echo date('d M Y', strtotime($patient['date_of_birth'])); ?></strong>
                    </div>
                    <div class="col-md-2">
                        <span class="info-label">Blood Group:</span><br>
                        <strong><?php echo htmlspecialchars($patient['blood_group'] ?: 'Not specified'); ?></strong>
                    </div>
                    <div class="col-md-3">
                        <span class="info-label">Contact:</span><br>
                        <strong><?php echo htmlspecialchars($patient['phone']); ?></strong>
                    </div>
                </div>
                <?php if($patient['allergies']): ?>
                <div class="row mt-3">
                    <div class="col-12">
                        <span class="info-label">Allergies/Medical Conditions:</span><br>
                        <strong class="text-danger"><?php echo htmlspecialchars($patient['allergies']); ?></strong>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Appointments History -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="fas fa-calendar-check"></i> Appointment History</h5>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($appointments) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Doctor</th>
                                    <th>Department</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($apt = mysqli_fetch_assoc($appointments)): ?>
                                    <tr>
                                        <td><?php echo date('d M Y', strtotime($apt['appointment_date'])); ?></td>
                                        <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                        <td>Dr. <?php echo htmlspecialchars($apt['doctor_name']); ?></td>
                                        <td><?php echo htmlspecialchars($apt['department']); ?></td>
                                        <td><?php echo htmlspecialchars($apt['reason']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $apt['status'] == 'completed' ? 'success' : 
                                                    ($apt['status'] == 'scheduled' ? 'primary' : 'warning'); 
                                            ?>">
                                                <?php echo ucfirst($apt['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No appointment history</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Lab Results -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-flask"></i> Laboratory Results</h5>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($lab_results) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Test Name</th>
                                    <th>Result</th>
                                    <th>Normal Range</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($lab = mysqli_fetch_assoc($lab_results)): ?>
                                    <tr>
                                        <td><?php echo date('d M Y', strtotime($lab['request_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($lab['test_name']); ?></td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($lab['result_value'] ?: 'Pending'); ?></strong>
                                            <?php if($lab['unit']): ?> <small><?php echo $lab['unit']; ?></small><?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($lab['normal_range'] ?: 'N/A'); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $lab['status'] == 'completed' ? 'success' : 'warning'; 
                                            ?>">
                                                <?php echo ucfirst($lab['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No lab results available</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Prescriptions -->
        <div class="card mb-4">
            <div class="card-header bg-warning">
                <h5 class="mb-0"><i class="fas fa-prescription"></i> Prescriptions</h5>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($prescriptions) > 0): ?>
                    <?php while($pres = mysqli_fetch_assoc($prescriptions)): ?>
                        <div class="mb-4 p-3 border rounded">
                            <div class="row">
                                <div class="col-md-4">
                                    <strong>Date:</strong> <?php echo date('d M Y', strtotime($pres['prescription_date'])); ?>
                                </div>
                                <div class="col-md-4">
                                    <strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($pres['doctor_name']); ?>
                                </div>
                                <div class="col-md-4">
                                    <strong>Diagnosis:</strong> <?php echo htmlspecialchars($pres['diagnosis']); ?>
                                </div>
                            </div>
                            
                            <?php if(isset($prescription_items[$pres['prescription_id']])): ?>
                                <table class="table table-sm mt-3">
                                    <thead>
                                        <tr>
                                            <th>Medication</th>
                                            <th>Dosage</th>
                                            <th>Frequency</th>
                                            <th>Duration</th>
                                            <th>Instructions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($prescription_items[$pres['prescription_id']] as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                                                <td><?php echo htmlspecialchars($item['dosage']); ?></td>
                                                <td><?php echo htmlspecialchars($item['frequency']); ?></td>
                                                <td><?php echo htmlspecialchars($item['duration']); ?></td>
                                                <td><?php echo htmlspecialchars($item['instructions']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-muted">No prescriptions available</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center text-muted mt-4">
            <small>Generated on: <?php echo date('d M Y h:i A'); ?></small><br>
            <small>This is a computer generated document.</small>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>