<?php
require_once 'config.php';

// If patient is already logged in, redirect to dashboard
if (isset($_SESSION['patient_id'])) {
    header("Location: patient_dashboard.php");
    exit();
}

$conn = getConnection();
$error = '';

// Handle patient login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['patient_login'])) {
    $patient_number = sanitize($_POST['patient_number']);
    $dob = sanitize($_POST['date_of_birth']);
    
    $stmt = mysqli_prepare($conn, "SELECT patient_id, first_name, last_name, patient_number, email FROM patients WHERE patient_number = ? AND date_of_birth = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "ss", $patient_number, $dob);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($result && mysqli_num_rows($result) == 1) {
        $patient = mysqli_fetch_assoc($result);
        session_regenerate_id(true);
        $_SESSION['patient_id'] = $patient['patient_id'];
        $_SESSION['patient_name'] = $patient['first_name'] . ' ' . $patient['last_name'];
        $_SESSION['patient_number'] = $patient['patient_number'];
        $_SESSION['patient_email'] = $patient['email'];
        
        header("Location: patient_dashboard.php");
        exit();
    } else {
        $error = "Invalid Patient Number or Date of Birth";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Portal - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(145deg, #eaf1f7 0%, #dfe8f2 55%, #e9eff6 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .portal-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        .welcome-card {
            background: linear-gradient(140deg, #2f5f9e 0%, #2f7a6a 100%);
            color: #ffffff;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 20px 50px rgba(24, 45, 72, 0.24);
        }
        .login-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 18px 40px rgba(24, 45, 72, 0.16);
        }
        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 30px 20px;
            text-align: center;
            transition: all 0.3s;
            height: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .feature-icon {
            font-size: 48px;
            color: #2f5f9e;
            margin-bottom: 20px;
        }
        .btn-portal {
            background: linear-gradient(140deg, #2f5f9e 0%, #2f7a6a 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s;
            width: 100%;
        }
        .btn-portal:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(47, 95, 158, 0.3);
            color: white;
        }
        .stat-box {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
            padding: 20px;
            color: white;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.25);
        }
        .stat-number {
            font-size: 36px;
            font-weight: bold;
        }
        .info-note {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        .welcome-card .lead {
            color: rgba(255, 255, 255, 0.95);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="portal-container">
        <!-- Welcome Section -->
        <div class="welcome-card">
            <i class="fas fa-hospital-alt fa-4x mb-3" style="color: #ffffff;"></i>
            <h1 class="display-4">Welcome to Patient Portal</h1>
            <p class="lead">Access your medical records, book appointments, and manage your healthcare online</p>
            
            <!-- Quick Stats -->
            <div class="row mt-5">
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number">24/7</div>
                        <div>Online Access</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number">10+</div>
                        <div>Specialist Doctors</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-box">
                        <div class="stat-number">1000+</div>
                        <div>Happy Patients</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Login Form -->
            <div class="col-md-5">
                <div class="login-card">
                    <h3 class="text-center mb-4"><i class="fas fa-sign-in-alt"></i> Patient Login</h3>
                    
                    <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-4">
                            <label class="form-label">Patient Number</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                                <input type="text" class="form-control form-control-lg" 
                                       name="patient_number" required 
                                       placeholder="Enter your patient number">
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Date of Birth</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                <input type="date" class="form-control form-control-lg" 
                                       name="date_of_birth" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="patient_login" class="btn btn-portal btn-lg">
                            <i class="fas fa-arrow-right"></i> Access Portal
                        </button>
                    </form>
                    
                    <div class="info-note">
                        <p class="mb-0">
                            <i class="fas fa-info-circle text-info"></i> 
                            Please use the patient number and date of birth provided during registration.
                        </p>
                        <p class="mb-0 mt-2">
                            <small>Contact our reception desk if you need assistance.</small>
                        </p>
                    </div>
                    
                    <hr class="my-4">
                    
                    <div class="text-center">
                        <p class="text-muted">New patient (first visit)? Book appointment without login.</p>
                        <a href="first_visit_appointment.php" class="btn btn-primary">
                            <i class="fas fa-calendar-plus"></i> First Visit Appointment
                        </a>
                        <p class="text-muted mt-3 mb-2">Already registered but need help?</p>
                        <a href="tel:+1234567890" class="btn btn-outline-primary">
                            <i class="fas fa-phone"></i> Call Us
                        </a>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-home"></i> Back to Home
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Features -->
            <div class="col-md-7">
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <h5>Book Appointments</h5>
                            <p class="text-muted">Schedule appointments with our specialist doctors at your convenience</p>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="fas fa-file-medical"></i>
                            </div>
                            <h5>Medical Records</h5>
                            <p class="text-muted">View your complete medical history, prescriptions, and lab results</p>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="fas fa-flask"></i>
                            </div>
                            <h5>Lab Results</h5>
                            <p class="text-muted">Access your laboratory test results online as soon as they're ready</p>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i class="fas fa-prescription"></i>
                            </div>
                            <h5>Prescriptions</h5>
                            <p class="text-muted">View and download your current and past prescriptions</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- How It Works -->
        <div class="row mt-5">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">
                        <h3 class="text-center mb-5">How It Works</h3>
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <div class="display-1 text-primary mb-3">1</div>
                                <h5>Get Patient Number</h5>
                                <p class="text-muted">Register at our reception desk</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="display-1 text-primary mb-3">2</div>
                                <h5>Login to Portal</h5>
                                <p class="text-muted">Use your credentials to access</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="display-1 text-primary mb-3">3</div>
                                <h5>Book Appointment</h5>
                                <p class="text-muted">Choose doctor and time slot</p>
                            </div>
                            <div class="col-md-3 text-center">
                                <div class="display-1 text-primary mb-3">4</div>
                                <h5>View Records</h5>
                                <p class="text-muted">Access all your health information</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
