<?php
require_once 'config.php';
requireInventoryAccess(false);

$conn = getConnection();
$item_id = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;

if ($item_id <= 0) {
    $_SESSION['error'] = "Invalid inventory item";
    redirect('inventory.php');
}

$item_result = mysqli_query($conn, "SELECT * FROM inventory_items WHERE item_id = $item_id");
if (!$item_result || mysqli_num_rows($item_result) === 0) {
    $_SESSION['error'] = "Inventory item not found";
    redirect('inventory.php');
}
$item = mysqli_fetch_assoc($item_result);

$history = mysqli_query(
    $conn,
    "SELECT it.*, u.full_name
     FROM inventory_transactions it
     LEFT JOIN users u ON it.performed_by = u.user_id
     WHERE it.item_id = $item_id
     ORDER BY it.transaction_date DESC"
);
$has_from_location = tableHasColumn('inventory_transactions', 'from_location');
$has_to_location = tableHasColumn('inventory_transactions', 'to_location');
$has_balance_after = tableHasColumn('inventory_transactions', 'balance_after');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory History - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3><i class="fas fa-history"></i> Inventory History</h3>
                <p class="mb-0">
                    <?php echo htmlspecialchars($item['item_name']); ?> (<?php echo htmlspecialchars($item['item_code']); ?>)
                </p>
            </div>
            <a href="inventory.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <?php if($has_from_location): ?><th>From</th><?php endif; ?>
                                <?php if($has_to_location): ?><th>To</th><?php endif; ?>
                                <?php if($has_balance_after): ?><th>Balance After</th><?php endif; ?>
                                <th>Performed By</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($history && mysqli_num_rows($history) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($history)): ?>
                                    <tr>
                                        <td><?php echo date('d M Y h:i A', strtotime($row['transaction_date'])); ?></td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $row['transaction_type'])); ?></td>
                                        <td><?php echo (int)$row['quantity']; ?></td>
                                        <?php if($has_from_location): ?><td><?php echo htmlspecialchars($row['from_location'] ?? ''); ?></td><?php endif; ?>
                                        <?php if($has_to_location): ?><td><?php echo htmlspecialchars($row['to_location'] ?? ''); ?></td><?php endif; ?>
                                        <?php if($has_balance_after): ?><td><?php echo number_format((float)($row['balance_after'] ?? 0), 2); ?></td><?php endif; ?>
                                        <td><?php echo htmlspecialchars($row['full_name'] ?? 'Unknown'); ?></td>
                                        <td><?php echo htmlspecialchars($row['notes'] ?? ''); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="<?php echo 5 + ($has_from_location ? 1 : 0) + ($has_to_location ? 1 : 0) + ($has_balance_after ? 1 : 0); ?>" class="text-center text-muted">No transaction history found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
