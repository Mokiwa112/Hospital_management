<?php
require_once 'config.php';

$conn = getConnection();

echo "<h2>Seeding Database with Fresh Data...</h2>";

// Insert insurance providers
$providers = [
    ["Blue Cross Blue Shield", "BC001", "John Agent", "800-555-0100", "bcbs@insurance.com", "123 Insurance Ave, New York, NY 10001", 80.00],
    ["United Health", "UH001", "Sarah Manager", "800-555-0101", "united@insurance.com", "456 Health St, Los Angeles, CA 90001", 75.00],
    ["Aetna", "AE001", "Mike Wilson", "800-555-0102", "aetna@insurance.com", "789 Care Blvd, Chicago, IL 60601", 70.00],
    ["Cigna", "CG001", "Lisa Brown", "800-555-0103", "cigna@insurance.com", "321 Wellness Way, Houston, TX 77001", 85.00],
    ["Humana", "HM001", "David Lee", "800-555-0104", "humana@insurance.com", "654 Medical Dr, Phoenix, AZ 85001", 65.00]
];

foreach($providers as $p) {
    $query = "INSERT INTO insurance_providers (provider_name, provider_code, contact_person, phone, email, address, coverage_percentage) 
              VALUES ('$p[0]', '$p[1]', '$p[2]', '$p[3]', '$p[4]', '$p[5]', $p[6])";
    mysqli_query($conn, $query);
}
echo "✓ Insurance providers added<br>";

// Insert users with hashed passwords
$users = [
    // Admin
    ["admin", password_hash("Admin@123", PASSWORD_DEFAULT), "Joseph Mwita", "admin@hospital.local", "+255710000100", "Administration Block", "admin", "Administration", "ADM001"],
    
    // Doctors
    ["dr.magesa", password_hash("Doctor@123", PASSWORD_DEFAULT), "Neema Magesa", "dr.magesa@hospital.local", "+255710000101", "Doctors Wing", "doctor", "Cardiology", "DOC001"],
    ["dr.nkya", password_hash("Doctor@123", PASSWORD_DEFAULT), "Elias Nkya", "dr.nkya@hospital.local", "+255710000102", "Doctors Wing", "doctor", "Pediatrics", "DOC002"],
    ["dr.mhando", password_hash("Doctor@123", PASSWORD_DEFAULT), "Rehema Mhando", "dr.mhando@hospital.local", "+255710000103", "Doctors Wing", "doctor", "Neurology", "DOC003"],
    ["dr.mwakalinga", password_hash("Doctor@123", PASSWORD_DEFAULT), "Leonard Mwakalinga", "dr.mwakalinga@hospital.local", "+255710000104", "Doctors Wing", "doctor", "Orthopedics", "DOC004"],
    ["dr.rashid", password_hash("Doctor@123", PASSWORD_DEFAULT), "Zainabu Rashid", "dr.rashid@hospital.local", "+255710000105", "Doctors Wing", "doctor", "Dermatology", "DOC005"],
    
    // Nurses
    ["nurse.bulugu", password_hash("Nurse@123", PASSWORD_DEFAULT), "Agatha Bulugu", "nurse.bulugu@hospital.local", "+255710000106", "Nurses Station", "nurse", "ICU", "NUR001"],
    ["nurse.selemani", password_hash("Nurse@123", PASSWORD_DEFAULT), "Halima Selemani", "nurse.selemani@hospital.local", "+255710000107", "Nurses Station", "nurse", "Emergency", "NUR002"],
    ["nurse.mushi", password_hash("Nurse@123", PASSWORD_DEFAULT), "Joyce Mushi", "nurse.mushi@hospital.local", "+255710000108", "Nurses Station", "nurse", "Pediatrics", "NUR003"],
    
    // Receptionists
    ["reception.mbwana", password_hash("Reception@123", PASSWORD_DEFAULT), "Happiness Mbwana", "reception.mbwana@hospital.local", "+255710000109", "Front Desk", "receptionist", "Front Office", "REC001"],
    ["reception.ngwana", password_hash("Reception@123", PASSWORD_DEFAULT), "Ezekiel Ng'wana", "reception.ngwana@hospital.local", "+255710000110", "Front Desk", "receptionist", "Appointments", "REC002"],
    
    // Lab Technicians
    ["lab.shija", password_hash("Lab@123", PASSWORD_DEFAULT), "Deus Shija", "lab.shija@hospital.local", "+255710000111", "Laboratory", "lab_tech", "Hematology", "LAB001"],
    ["lab.mwansasu", password_hash("Lab@123", PASSWORD_DEFAULT), "Prisca Mwansasu", "lab.mwansasu@hospital.local", "+255710000112", "Laboratory", "lab_tech", "Radiology", "LAB002"],
    
    // Pharmacists
    ["pharma.nyoni", password_hash("Pharma@123", PASSWORD_DEFAULT), "Selemani Nyoni", "pharma.nyoni@hospital.local", "+255710000113", "Pharmacy", "pharmacist", "Pharmacy", "PHR001"],
    ["pharma.kweka", password_hash("Pharma@123", PASSWORD_DEFAULT), "Upendo Kweka", "pharma.kweka@hospital.local", "+255710000114", "Pharmacy", "pharmacist", "Clinical Pharmacy", "PHR002"],
    
    // Accountants
    ["account.masanja", password_hash("Account@123", PASSWORD_DEFAULT), "Daudi Masanja", "account.masanja@hospital.local", "+255710000115", "Finance Office", "accountant", "Billing", "ACC001"],
    ["account.mgaya", password_hash("Account@123", PASSWORD_DEFAULT), "Beatrice Mgaya", "account.mgaya@hospital.local", "+255710000116", "Finance Office", "accountant", "Insurance", "ACC002"],
    
    // Human Resources
    ["hr.luhanga", password_hash("HR@123", PASSWORD_DEFAULT), "Flora Luhanga", "hr.luhanga@hospital.local", "+255710000117", "HR Office", "hr_admin", "Human Resources", "HR001"],
    ["hr.mboya", password_hash("HR@123", PASSWORD_DEFAULT), "Raymond Mboya", "hr.mboya@hospital.local", "+255710000118", "HR Office", "hr_admin", "Human Resources", "HR002"]
];

foreach($users as $u) {
    $query = "INSERT INTO users (username, password, full_name, email, phone, address, user_type, department, employee_id) 
              VALUES ('$u[0]', '$u[1]', '$u[2]', '$u[3]', '$u[4]', '$u[5]', '$u[6]', '$u[7]', '$u[8]')";
    mysqli_query($conn, $query);
}
echo "✓ Users added<br>";

// Insert lab tests
$lab_tests = [
    ["CBC001", "Complete Blood Count", "Hematology", "Complete blood count analysis including RBC, WBC, platelets", "Fasting not required", "4.5-11.0 x10^9/L", "test", 50.00],
    ["BMP001", "Basic Metabolic Panel", "Chemistry", "Blood glucose, calcium, electrolyte tests", "Fasting for 8 hours required", "Glucose: 70-99 mg/dL", "panel", 120.00],
    ["LIP001", "Lipid Panel", "Chemistry", "Cholesterol and triglycerides", "Fasting for 12 hours required", "Total Chol: <200 mg/dL", "panel", 80.00],
    ["UA001", "Urinalysis", "Clinical Pathology", "Complete urine analysis", "Clean catch mid-stream sample", "Clear, no abnormalities", "test", 35.00],
    ["XRY001", "Chest X-Ray", "Radiology", "2-view chest X-ray", "Remove metal objects", "Normal findings", "procedure", 150.00],
    ["MRI001", "Brain MRI", "Radiology", "Magnetic resonance imaging of brain", "No metal implants", "Normal findings", "procedure", 1200.00],
    ["EKG001", "Electrocardiogram", "Cardiology", "Heart electrical activity", "No caffeine 4 hours prior", "Normal sinus rhythm", "test", 75.00],
    ["COVID001", "COVID-19 PCR", "Molecular", "SARS-CoV-2 detection", "Nasopharyngeal swab", "Negative", "test", 100.00],
    ["TSH001", "Thyroid Stimulating Hormone", "Endocrinology", "Thyroid function test", "Fasting recommended", "0.4-4.0 mIU/L", "test", 65.00],
    ["VITD001", "Vitamin D Test", "Endocrinology", "25-hydroxy vitamin D", "No special preparation", "30-100 ng/mL", "test", 85.00]
];

foreach($lab_tests as $lt) {
    $lab_cost = (float)$lt[7];
    if ($lab_cost > 0 && $lab_cost < 5000) {
        $lab_cost *= 1000;
    }
    $query = "INSERT INTO lab_tests (test_code, test_name, category, description, preparation_instructions, normal_range, unit, cost) 
              VALUES ('$lt[0]', '$lt[1]', '$lt[2]', '$lt[3]', '$lt[4]', '$lt[5]', '$lt[6]', $lab_cost)";
    mysqli_query($conn, $query);
}
echo "✓ Lab tests added<br>";

// Insert patients
$patients = [
    ["PAT001", "Juma", "Mhando", "1985-03-15", "M", "+255720000101", "juma.mhando@email.com", "123 Main St, Apt 4B, New York, NY 10001", "555-2001", "Jane Doe", "O+", "Penicillin", "outpatient", 1, "POL001234"],
    ["PAT002", "Neema", "Mushi", "1990-07-22", "F", "+255720000102", "neema.mushi@email.com", "456 Oak Ave, Suite 5, New York, NY 10002", "555-2002", "Tom Smith", "A+", "Sulfa drugs", "inpatient", 2, "POL005678"],
    ["PAT003", "Paulo", "Mwansasu", "1978-11-30", "M", "+255720000103", "paulo.mwansasu@email.com", "789 Pine Rd, New York, NY 10003", "555-2003", "Sarah Johnson", "B-", "Latex", "inpatient", 3, "POL009876"],
    ["PAT004", "Rehema", "Bulugu", "1995-05-10", "F", "+255720000104", "rehema.bulugu@email.com", "321 Elm St, New York, NY 10004", "555-2004", "Mike Williams", "AB+", "None", "outpatient", 4, "POL004321"],
    ["PAT005", "Abdallah", "Nyoni", "1982-09-18", "M", "+255720000105", "abdallah.nyoni@email.com", "654 Cedar Ln, New York, NY 10005", "555-2005", "Lisa Brown", "A-", "Ibuprofen", "outpatient", 5, "POL007654"],
    ["PAT006", "Fatuma", "Selemani", "1988-12-03", "F", "+255720000106", "fatuma.selemani@email.com", "987 Birch St, New York, NY 10006", "555-2006", "Carlos Garcia", "O-", "Shellfish", "inpatient", 1, "POL003456"],
    ["PAT007", "Isack", "Ng'wana", "1975-06-25", "M", "+255720000107", "isack.ngwana@email.com", "147 Spruce Ave, New York, NY 10007", "555-2007", "Elena Martinez", "B+", "Codeine", "outpatient", 2, "POL008765"],
    ["PAT008", "Agnes", "Kweka", "1992-08-14", "F", "+255720000108", "agnes.kweka@email.com", "258 Maple Dr, New York, NY 10008", "555-2008", "James Taylor", "AB-", "Peanuts", "inpatient", NULL, NULL],
    ["PAT009", "Leonard", "Masanja", "1980-04-19", "M", "+255720000109", "leonard.masanja@email.com", "369 Walnut Ct, New York, NY 10009", "555-2009", "Susan Anderson", "A+", "None", "outpatient", 3, "POL002468"],
    ["PAT010", "Zawadi", "Mgaya", "1993-11-07", "F", "+255720000110", "zawadi.mgaya@email.com", "741 Cherry Ln, New York, NY 10010", "555-2010", "Robert Thomas", "O+", "Dust", "inpatient", 4, "POL013579"]
];

foreach($patients as $p) {
    $insurance = $p[13] ? $p[13] : "NULL";
    $policy = isset($p[14]) && $p[14] ? "'$p[14]'" : "NULL";
    
    $query = "INSERT INTO patients (patient_number, first_name, last_name, date_of_birth, gender, phone, email, address, 
              emergency_contact, emergency_contact_name, blood_group, allergies, patient_type, insurance_provider_id, insurance_policy_number) 
              VALUES ('$p[0]', '$p[1]', '$p[2]', '$p[3]', '$p[4]', '$p[5]', '$p[6]', '$p[7]', 
              '$p[8]', '$p[9]', '$p[10]', '$p[11]', '$p[12]', $insurance, $policy)";
    mysqli_query($conn, $query);
}
echo "✓ Patients added<br>";

// Insert inventory items
$inventory = [
    ["MED001", "Paracetamol 500mg", "Medicine", "Pain reliever and fever reducer", "tablet", 1000, 100, 0.50, "PharmaCorp", "2025-12-31"],
    ["MED002", "Amoxicillin 250mg", "Medicine", "Antibiotic for bacterial infections", "capsule", 500, 50, 1.20, "MediSupply", "2025-06-30"],
    ["MED003", "Lisinopril 10mg", "Medicine", "Blood pressure medication", "tablet", 300, 50, 0.80, "HealthPharma", "2025-09-30"],
    ["MED004", "Metformin 500mg", "Medicine", "Diabetes medication", "tablet", 600, 75, 0.60, "DiabetesCare", "2025-08-15"],
    ["MED005", "Ibuprofen 400mg", "Medicine", "Anti-inflammatory pain reliever", "tablet", 800, 100, 0.45, "PharmaCorp", "2025-11-30"],
    ["MED006", "Azithromycin 250mg", "Medicine", "Antibiotic", "tablet", 400, 40, 2.50, "MediSupply", "2025-07-31"],
    ["EQP001", "Surgical Gloves", "Equipment", "Sterile latex gloves", "pair", 5000, 500, 0.30, "SurgiCare", NULL],
    ["EQP002", "Syringes 5ml", "Equipment", "Disposable syringes", "piece", 2000, 200, 0.25, "MedSupply", NULL],
    ["EQP003", "Blood Pressure Monitor", "Equipment", "Digital BP monitor", "unit", 25, 5, 45.00, "HealthTech", NULL],
    ["CON001", "Bandages", "Consumable", "Adhesive bandages assorted", "box", 150, 30, 2.50, "FirstAid Co", "2026-01-31"],
    ["CON002", "Antiseptic Solution", "Consumable", "Povidone-iodine solution", "bottle", 80, 20, 4.00, "CleanMed", "2025-08-31"],
    ["CON003", "Face Masks", "Consumable", "Surgical masks", "box", 1000, 200, 8.00, "SafetyFirst", "2026-03-31"]
];

foreach($inventory as $inv) {
    $expiry = $inv[9] ? "'$inv[9]'" : "NULL";
    $unit_price = (float)$inv[7];
    if ($unit_price > 0 && $unit_price < 1000) {
        $unit_price *= 1000;
    }
    $query = "INSERT INTO inventory_items (item_code, item_name, category, description, unit, quantity, reorder_level, unit_price, supplier, expiry_date) 
              VALUES ('$inv[0]', '$inv[1]', '$inv[2]', '$inv[3]', '$inv[4]', $inv[5], $inv[6], $unit_price, '$inv[8]', $expiry)";
    mysqli_query($conn, $query);
}
echo "✓ Inventory items added<br>";

// Insert sample appointments
$appointments = [
    ["PAT001", "DOC001", date('Y-m-d', strtotime('+1 day')), "09:00:00", "scheduled", "Annual physical examination", "Patient reports feeling well"],
    ["PAT002", "DOC002", date('Y-m-d', strtotime('+2 days')), "10:30:00", "scheduled", "Follow-up after lab tests", "Review blood work results"],
    ["PAT003", "DOC003", date('Y-m-d'), "14:00:00", "scheduled", "Persistent headache", "MRI results ready"],
    ["PAT004", "DOC004", date('Y-m-d', strtotime('-1 day')), "11:15:00", "completed", "Vaccination", "Flu shot administered"],
    ["PAT005", "DOC005", date('Y-m-d', strtotime('-2 days')), "15:30:00", "completed", "Skin rash", "Prescribed topical cream"],
    ["PAT006", "DOC001", date('Y-m-d', strtotime('+3 days')), "09:30:00", "scheduled", "Chest pain evaluation", "EKG required"],
    ["PAT007", "DOC002", date('Y-m-d', strtotime('+4 days')), "11:00:00", "scheduled", "Pediatric checkup", "Growth monitoring"],
    ["PAT008", "DOC003", date('Y-m-d', strtotime('+5 days')), "13:30:00", "scheduled", "Neurology consultation", "Migraine treatment"],
    ["PAT009", "DOC004", date('Y-m-d', strtotime('-3 days')), "10:00:00", "completed", "Back pain", "Physical therapy recommended"],
    ["PAT010", "DOC005", date('Y-m-d', strtotime('-4 days')), "16:00:00", "completed", "Acne treatment", "Prescribed medication"]
];

foreach($appointments as $a) {
    $patient = mysqli_fetch_assoc(mysqli_query($conn, "SELECT patient_id FROM patients WHERE patient_number='$a[0]'"));
    $doctor = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id FROM users WHERE employee_id='$a[1]'"));
    
    if ($patient && $doctor) {
        $apt_number = 'APT' . date('Ymd') . rand(100, 999);
        $query = "INSERT INTO appointments (appointment_number, patient_id, doctor_id, appointment_date, appointment_time, status, reason, notes, created_by) 
                  VALUES ('$apt_number', {$patient['patient_id']}, {$doctor['user_id']}, '$a[2]', '$a[3]', '$a[4]', '$a[5]', '$a[6]', 1)";
        mysqli_query($conn, $query);
    }
}
echo "✓ Appointments added<br>";

// Insert lab requests
$lab_requests = [
    ["PAT001", "DOC001", "CBC001", "pending", NULL, NULL],
    ["PAT002", "DOC002", "BMP001", "processing", date('Y-m-d H:i:s', strtotime('-1 hour')), NULL],
    ["PAT003", "DOC003", "MRI001", "completed", date('Y-m-d H:i:s', strtotime('-2 days')), "Normal brain activity"],
    ["PAT004", "DOC004", "COVID001", "completed", date('Y-m-d H:i:s', strtotime('-5 days')), "Negative"],
    ["PAT005", "DOC005", "LIP001", "pending", NULL, NULL],
    ["PAT006", "DOC001", "EKG001", "processing", date('Y-m-d H:i:s', strtotime('-3 hours')), NULL],
    ["PAT007", "DOC002", "VITD001", "completed", date('Y-m-d H:i:s', strtotime('-1 day')), "35 ng/mL"]
];

foreach($lab_requests as $lr) {
    $patient = mysqli_fetch_assoc(mysqli_query($conn, "SELECT patient_id FROM patients WHERE patient_number='$lr[0]'"));
    $doctor = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id FROM users WHERE employee_id='$lr[1]'"));
    $test = mysqli_fetch_assoc(mysqli_query($conn, "SELECT test_id FROM lab_tests WHERE test_code='$lr[2]'"));
    
    if ($patient && $doctor && $test) {
        $req_number = 'LAB' . date('Ymd') . rand(100, 999);
        $result = $lr[5] ? "'$lr[5]'" : "NULL";
        $query = "INSERT INTO lab_requests (request_number, patient_id, doctor_id, test_id, status, result_date, result_value, created_by) 
                  VALUES ('$req_number', {$patient['patient_id']}, {$doctor['user_id']}, {$test['test_id']}, '$lr[3]', " . ($lr[4] ? "'$lr[4]'" : "NULL") . ", $result, 1)";
        mysqli_query($conn, $query);
    }
}
echo "✓ Lab requests added<br>";

echo "<h3>Database seeding completed successfully!</h3>";
echo "<p>All fresh data has been inserted. Check the credentials.txt file for login information.</p>";
?>
