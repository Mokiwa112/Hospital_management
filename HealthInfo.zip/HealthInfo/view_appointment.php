<?php
require_once 'config.php';
requireRole('doctor');
require_once 'billing_auto_helper.php';
require_once 'lab_test_catalog_helper.php';

$conn = getConnection();
seed_regional_lab_tests($conn);
$doctor_id = $_SESSION['user_id'];
$appointment_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');

// Fetch appointment details with proper authorization check
$query = "SELECT a.*, 
          p.first_name, p.last_name, p.patient_number, p.date_of_birth, p.phone, p.email, p.address,
          p.blood_group, p.allergies, p.emergency_contact, p.emergency_contact_name,
          u.full_name as doctor_name
          FROM appointments a
          JOIN patients p ON a.patient_id = p.patient_id
          JOIN users u ON a.doctor_id = u.user_id
          WHERE a.appointment_id = $appointment_id AND a.doctor_id = $doctor_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Appointment not found or you don't have permission to view it";
    header("Location: doctor_dashboard.php");
    exit();
}

$appointment = mysqli_fetch_assoc($result);

// Handle appointment status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $new_status = sanitize($_POST['status']);
    
    $update_query = "UPDATE appointments SET status = '$new_status' WHERE appointment_id = $appointment_id";
    
    if (mysqli_query($conn, $update_query)) {
        $_SESSION['success'] = "Appointment status updated to " . ucfirst($new_status);

        if ($new_status === 'completed') {
            $auto_notes = "Auto-generated bill for uninsured patient after treatment completion (Appointment ID: $appointment_id).";
            $auto_bill = create_auto_bill_for_uninsured_patient($conn, (int)$appointment['patient_id'], $doctor_id, $auto_notes);
            if (!empty($auto_bill['created'])) {
                $_SESSION['success'] .= " | Bill " . $auto_bill['bill_number'] . " created automatically. <a href='print_bill.php?id=" . (int)$auto_bill['bill_id'] . "' target='_blank'>Print Transcript</a>";
            }
        }

        header("Location: view_appointment.php?id=$appointment_id");
        exit();
    } else {
        $error = "Error updating status: " . mysqli_error($conn);
    }
}

// Handle lab request creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_lab'])) {
    $test_ids_raw = $_POST['test_ids'] ?? [];
    if (!is_array($test_ids_raw) && isset($_POST['test_id'])) {
        $test_ids_raw = [$_POST['test_id']];
    }
    $test_ids = [];
    foreach ((array)$test_ids_raw as $tid) {
        $tid = (int)sanitize($tid);
        if ($tid > 0 && !in_array($tid, $test_ids, true)) {
            $test_ids[] = $tid;
        }
    }
    $notes = sanitize($_POST['lab_notes']);
    if (empty($test_ids)) {
        $error = "Please select at least one lab test";
    } else {
        mysqli_begin_transaction($conn);
        try {
            $created_count = 0;
            $notes_column = firstExistingColumn('lab_requests', ['notes', 'lab_notes']);
            foreach ($test_ids as $test_id) {
                $request_number = generateUniqueId('LAB', 'lab_requests', 'request_number');
                $columns = ['request_number', 'patient_id', 'doctor_id', 'test_id'];
                $values = ["'$request_number'", (int)$appointment['patient_id'], $doctor_id, $test_id];
                if ($notes_column !== null) {
                    $columns[] = $notes_column;
                    $values[] = "'$notes'";
                }
                if (tableHasColumn('lab_requests', 'status')) {
                    $columns[] = 'status';
                    $values[] = "'pending'";
                }
                if (tableHasColumn('lab_requests', 'created_by')) {
                    $columns[] = 'created_by';
                    $values[] = $doctor_id;
                }
                $lab_query = "INSERT INTO lab_requests (" . implode(', ', $columns) . ")
                              VALUES (" . implode(', ', $values) . ")";
                if (!mysqli_query($conn, $lab_query)) {
                    throw new Exception(mysqli_error($conn));
                }
                $created_count++;
            }
            mysqli_commit($conn);

            $_SESSION['success'] = $created_count . " lab request(s) created successfully!";
        $auto_notes = "Auto-generated bill for uninsured patient after lab request creation (Appointment ID: $appointment_id).";
        $auto_bill = create_auto_bill_for_uninsured_patient(
            $conn,
            (int)$appointment['patient_id'],
            $doctor_id,
            $auto_notes,
            ['include_requested_lab' => true]
        );
        if (!empty($auto_bill['created'])) {
            $_SESSION['success'] .= " | Bill " . $auto_bill['bill_number'] . " was created automatically.";
        }
        header("Location: view_appointment.php?id=$appointment_id");
        exit();
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Error creating lab request: " . $e->getMessage();
        }
    }
}

// Fetch patient's previous appointments
$history_query = "SELECT a.*, u.full_name as doctor_name 
                  FROM appointments a
                  JOIN users u ON a.doctor_id = u.user_id
                  WHERE a.patient_id = {$appointment['patient_id']} 
                  AND a.appointment_id != $appointment_id
                  ORDER BY a.appointment_date DESC
                  LIMIT 5";
$history = mysqli_query($conn, $history_query);

// Fetch patient's lab results
$lab_results = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.normal_range, lt.unit 
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = {$appointment['patient_id']}
     ORDER BY lr.request_date DESC
     LIMIT 10"
);

// Fetch available lab tests
$lab_tests = mysqli_query($conn, "SELECT test_id, test_name, category,
    CASE
        WHEN COALESCE(cost, 0) > 0 AND COALESCE(cost, 0) < 5000 THEN cost * 1000
        ELSE cost
    END AS cost
    FROM lab_tests
    ORDER BY test_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointment - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .section-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .patient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
        }
        .status-scheduled { background: #cce5ff; color: #004085; }
        .status-in_progress { background: #fff3cd; color: #856404; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-no_show { background: #e2e3e5; color: #383d41; }
        
        .info-row {
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .info-label {
            font-weight: 600;
            color: #666;
            width: 120px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-calendar-check"></i> Appointment Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="doctor_dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
        
        <!-- Patient Header -->
        <div class="patient-header">
            <div class="row">
                <div class="col-md-8">
                    <h3><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></h3>
                    <p class="mb-0">
                        <i class="fas fa-id-card"></i> Patient #: <?php echo $appointment['patient_number']; ?> |
                        <i class="fas fa-calendar"></i> DOB: <?php echo date('d-m-Y', strtotime($appointment['date_of_birth'])); ?> |
                        <i class="fas fa-tint"></i> Blood Group: <?php echo $appointment['blood_group'] ?: 'N/A'; ?>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="status-badge status-<?php echo $appointment['status']; ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $appointment['status'])); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Left Column - Appointment Info & Actions -->
            <div class="col-md-4">
                <!-- Appointment Details -->
                <div class="section-card">
                    <h5><i class="fas fa-info-circle"></i> Appointment Information</h5>
                    <hr>
                    <div class="info-row">
                        <span class="info-label">Date:</span>
                        <span><?php echo date('l, d M Y', strtotime($appointment['appointment_date'])); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Time:</span>
                        <span><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Doctor:</span>
                        <span>Dr. <?php echo $appointment['doctor_name']; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Reason:</span>
                        <span><?php echo htmlspecialchars($appointment['reason']); ?></span>
                    </div>
                    <?php if($appointment['notes']): ?>
                    <div class="info-row">
                        <span class="info-label">Notes:</span>
                        <span><?php echo htmlspecialchars($appointment['notes']); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Update Status -->
                <div class="section-card">
                    <h5><i class="fas fa-edit"></i> Update Status</h5>
                    <hr>
                    <form method="POST">
                        <div class="mb-3">
                            <select class="form-control" name="status">
                                <option value="scheduled" <?php echo $appointment['status'] == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                                <option value="in_progress" <?php echo $appointment['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                <option value="completed" <?php echo $appointment['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="cancelled" <?php echo $appointment['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                <option value="no_show" <?php echo $appointment['status'] == 'no_show' ? 'selected' : ''; ?>>No Show</option>
                            </select>
                        </div>
                        <button type="submit" name="update_status" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> Update Status
                        </button>
                    </form>
                </div>
                
                <!-- Quick Actions -->
                <div class="section-card">
                    <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
                    <hr>
                    <div class="d-grid gap-2">
                        <a href="create_prescription.php?patient_id=<?php echo $appointment['patient_id']; ?>" 
                           class="btn btn-success">
                            <i class="fas fa-prescription"></i> Write Prescription
                        </a>
                        <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#labRequestModal">
                            <i class="fas fa-flask"></i> Request Lab Test
                        </button>
                        <a href="patient_history.php?patient_id=<?php echo $appointment['patient_id']; ?>" 
                           class="btn btn-warning">
                            <i class="fas fa-history"></i> Full Patient History
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Middle Column - Patient Contact & Medical Info -->
            <div class="col-md-4">
                <!-- Contact Information -->
                <div class="section-card">
                    <h5><i class="fas fa-address-card"></i> Contact Information</h5>
                    <hr>
                    <div class="info-row">
                        <span class="info-label">Phone:</span>
                        <span><?php echo $appointment['phone']; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span><?php echo $appointment['email'] ?: 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Address:</span>
                        <span><?php echo $appointment['address'] ?: 'N/A'; ?></span>
                    </div>
                </div>
                
                <!-- Medical Information -->
                <div class="section-card">
                    <h5><i class="fas fa-notes-medical"></i> Medical Information</h5>
                    <hr>
                    <div class="info-row">
                        <span class="info-label">Allergies:</span>
                        <span><?php echo $appointment['allergies'] ?: 'None reported'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Emergency Contact:</span>
                        <span><?php echo $appointment['emergency_contact_name'] ?: 'N/A'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Emergency Phone:</span>
                        <span><?php echo $appointment['emergency_contact'] ?: 'N/A'; ?></span>
                    </div>
                </div>
                
                <!-- Previous Appointments -->
                <div class="section-card">
                    <h5><i class="fas fa-history"></i> Previous Appointments</h5>
                    <hr>
                    <?php if($history && mysqli_num_rows($history) > 0): ?>
                        <?php while($prev = mysqli_fetch_assoc($history)): ?>
                            <div class="border-bottom pb-2 mb-2">
                                <div class="d-flex justify-content-between">
                                    <strong><?php echo date('d M Y', strtotime($prev['appointment_date'])); ?></strong>
                                    <span class="badge bg-<?php echo $prev['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($prev['status']); ?>
                                    </span>
                                </div>
                                <p class="mb-0">Dr. <?php echo $prev['doctor_name']; ?></p>
                                <small><?php echo $prev['reason']; ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted">No previous appointments</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column - Lab Results -->
            <div class="col-md-4">
                <div class="section-card">
                    <h5><i class="fas fa-flask"></i> Recent Lab Results</h5>
                    <hr>
                    <?php if($lab_results && mysqli_num_rows($lab_results) > 0): ?>
                        <?php while($lab = mysqli_fetch_assoc($lab_results)): ?>
                            <div class="border-bottom pb-2 mb-2">
                                <div class="d-flex justify-content-between">
                                    <strong><?php echo $lab['test_name']; ?></strong>
                                    <span class="badge bg-<?php echo $lab['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($lab['status']); ?>
                                    </span>
                                </div>
                                <?php if($lab['status'] == 'completed'): ?>
                                    <p class="mb-0">
                                        Result: <strong><?php echo $lab['result_value'] . ' ' . $lab['unit']; ?></strong>
                                        <br><small>Normal: <?php echo $lab['normal_range']; ?></small>
                                    </p>
                                    <?php if($has_doctor_approval && empty($lab['approved_by_doctor'])): ?>
                                        <a href="review_lab_result.php?id=<?php echo $lab['request_id']; ?>" 
                                           class="btn btn-sm btn-warning mt-1">
                                            <i class="fas fa-check-circle"></i> Review Result
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p class="text-muted">Pending results</p>
                                <?php endif; ?>
                                <small class="text-muted">Requested: <?php echo date('d M Y', strtotime($lab['request_date'])); ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted">No lab results available</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Lab Request Modal -->
    <div class="modal fade" id="labRequestModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-flask"></i> Request Lab Test</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Select Test(s) *</label>
                            <select class="form-control" name="test_ids[]" required multiple size="10">
                                <?php 
                                mysqli_data_seek($lab_tests, 0);
                                while($test = mysqli_fetch_assoc($lab_tests)): 
                                ?>
                                    <option value="<?php echo $test['test_id']; ?>">
                                        <?php echo htmlspecialchars($test['test_name']); ?> (<?php echo htmlspecialchars($test['category']); ?>) - <?php echo format_currency($test['cost']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <small class="text-muted">Use Ctrl/Command to select multiple tests.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Clinical Notes</label>
                            <textarea class="form-control" name="lab_notes" rows="3" 
                                      placeholder="Any specific instructions or notes for the lab technician"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="request_lab" class="btn btn-info">Request Test</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
