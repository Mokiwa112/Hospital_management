<?php
require_once 'config.php';
requireRole('doctor');

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$appointment_id = isset($_GET['appointment_id']) ? (int)$_GET['appointment_id'] : 0;

// Update appointment status to in_progress
$update_query = "UPDATE appointments SET status = 'in_progress' WHERE appointment_id = $appointment_id AND doctor_id = $doctor_id";
mysqli_query($conn, $update_query);

// Redirect to consultation page or back to dashboard
header("Location: view_appointment.php?id=$appointment_id");
exit();
?>