<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor', 'receptionist']);

$conn = getConnection();
$user_type = $_SESSION['user_type'];

// Get filter parameters
$filter_date = isset($_GET['date']) ? $_GET['date'] : '';
$filter_doctor = isset($_GET['doctor']) ? (int)$_GET['doctor'] : 0;
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';

// Build query
$where = ["1=1"];

if (!empty($filter_date)) {
    $where[] = "a.appointment_date = '$filter_date'";
}
if ($filter_doctor > 0) {
    $where[] = "a.doctor_id = $filter_doctor";
}
if (!empty($filter_status)) {
    $where[] = "a.status = '$filter_status'";
}

// Doctors see only their appointments
if ($user_type == 'doctor') {
    $where[] = "a.doctor_id = {$_SESSION['user_id']}";
}

$where_clause = implode(' AND ', $where);

// Fetch appointments
$query = "SELECT a.*, 
          p.first_name, p.last_name, p.patient_number, p.date_of_birth, p.patient_id,
          u.full_name as doctor_name
          FROM appointments a
          JOIN patients p ON a.patient_id = p.patient_id
          JOIN users u ON a.doctor_id = u.user_id
          WHERE $where_clause
          ORDER BY a.appointment_date DESC, a.appointment_time DESC";
$appointments = mysqli_query($conn, $query);

// Fetch doctors for filter
$doctors = mysqli_query($conn, "SELECT user_id, full_name FROM users WHERE user_type='doctor'");

// Calendar data
$calendar_month = isset($_GET['calendar_month']) ? (int)$_GET['calendar_month'] : (int)date('m');
$calendar_year = isset($_GET['calendar_year']) ? (int)$_GET['calendar_year'] : (int)date('Y');

$month_start = date('Y-m-01', strtotime("$calendar_year-$calendar_month-01"));
$month_end = date('Y-m-t', strtotime("$calendar_year-$calendar_month-01"));

$calendar_query = "SELECT appointment_date, status, COUNT(*) as count 
                   FROM appointments 
                   WHERE appointment_date BETWEEN '$month_start' AND '$month_end'
                   GROUP BY appointment_date, status";
$calendar_result = mysqli_query($conn, $calendar_query);

$calendar_data = [];
while($row = mysqli_fetch_assoc($calendar_result)) {
    $day = (int)date('j', strtotime($row['appointment_date']));
    if (!isset($calendar_data[$day])) {
        $calendar_data[$day] = ['scheduled'=>0, 'in_progress'=>0, 'completed'=>0, 'cancelled'=>0, 'no_show'=>0];
    }
    $calendar_data[$day][$row['status']] = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
        }
        .status-scheduled { background: #cce5ff; color: #004085; }
        .status-in_progress { background: #fff3cd; color: #856404; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-no_show { background: #e2e3e5; color: #383d41; }
        
        .calendar-day {
            min-height: 100px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 10px;
        }
        .calendar-day.today {
            background: #e3f2fd;
            border: 2px solid #2196f3;
        }
        .appointment-dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        .dot-scheduled { background: #007bff; }
        .dot-in_progress { background: #ffc107; }
        .dot-completed { background: #28a745; }
        .dot-cancelled { background: #dc3545; }
        .dot-no_show { background: #6c757d; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2>Appointments</h2>
        
        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row">
                    <div class="col-md-3">
                        <input type="date" class="form-control" name="date" value="<?php echo $filter_date; ?>">
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="doctor">
                            <option value="">All Doctors</option>
                            <?php while($doc = mysqli_fetch_assoc($doctors)): ?>
                                <option value="<?php echo $doc['user_id']; ?>" <?php echo $filter_doctor==$doc['user_id']?'selected':''; ?>>
                                    Dr. <?php echo $doc['full_name']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="status">
                            <option value="">All Status</option>
                            <option value="scheduled" <?php echo $filter_status=='scheduled'?'selected':''; ?>>Scheduled</option>
                            <option value="in_progress" <?php echo $filter_status=='in_progress'?'selected':''; ?>>In Progress</option>
                            <option value="completed" <?php echo $filter_status=='completed'?'selected':''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $filter_status=='cancelled'?'selected':''; ?>>Cancelled</option>
                            <option value="no_show" <?php echo $filter_status=='no_show'?'selected':''; ?>>No Show</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">Filter</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Tabs -->
        <ul class="nav nav-tabs mb-3">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#list">List View</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#calendar">Calendar View</a>
            </li>
        </ul>
        
        <div class="tab-content">
            <!-- List View -->
            <div class="tab-pane active" id="list">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Date/Time</th>
                                <th>Patient</th>
                                <th>Doctor</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($appointments && mysqli_num_rows($appointments) > 0): ?>
                                <?php while($apt = mysqli_fetch_assoc($appointments)): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo date('d M Y', strtotime($apt['appointment_date'])); ?></strong><br>
                                        <small><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></small>
                                    </td>
                                    <td>
                                        <strong><?php echo $apt['first_name'] . ' ' . $apt['last_name']; ?></strong><br>
                                        <small><?php echo $apt['patient_number']; ?></small>
                                    </td>
                                    <td>Dr. <?php echo $apt['doctor_name']; ?></td>
                                    <td><?php echo $apt['reason']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $apt['status']; ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $apt['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_appointment.php?id=<?php echo $apt['appointment_id']; ?>" 
                                           class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        
                                        <?php 
                                        // FIXED: Check if patient_id exists and is valid
                                        if(isset($apt['patient_id']) && !empty($apt['patient_id']) && $apt['patient_id'] > 0): 
                                        ?>
                                        <a href="patient_history.php?patient_id=<?php echo (int)$apt['patient_id']; ?>" 
                                           class="btn btn-sm btn-secondary">
                                            <i class="fas fa-history"></i> History
                                        </a>
                                        <?php endif; ?>
                                        
                                        <!-- NO DELETE BUTTON - REMOVED COMPLETELY -->
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <p class="text-muted">No appointments found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Calendar View -->
            <div class="tab-pane" id="calendar">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4>
                                <?php 
                                $months = ['January','February','March','April','May','June',
                                          'July','August','September','October','November','December'];
                                echo $months[$calendar_month-1] . ' ' . $calendar_year;
                                ?>
                            </h4>
                            <div>
                                <?php
                                $prev_month = $calendar_month - 1;
                                $prev_year = $calendar_year;
                                if($prev_month < 1) { 
                                    $prev_month = 12; 
                                    $prev_year--; 
                                }
                                
                                $next_month = $calendar_month + 1;
                                $next_year = $calendar_year;
                                if($next_month > 12) { 
                                    $next_month = 1; 
                                    $next_year++; 
                                }
                                ?>
                                <a href="?calendar_month=<?php echo $prev_month; ?>&calendar_year=<?php echo $prev_year; ?>" 
                                   class="btn btn-sm btn-outline-primary">Previous</a>
                                <a href="?calendar_month=<?php echo date('m'); ?>&calendar_year=<?php echo date('Y'); ?>" 
                                   class="btn btn-sm btn-outline-primary">Today</a>
                                <a href="?calendar_month=<?php echo $next_month; ?>&calendar_year=<?php echo $next_year; ?>" 
                                   class="btn btn-sm btn-outline-primary">Next</a>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <?php 
                            $weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                            foreach($weekdays as $day): 
                            ?>
                                <div class="col text-center fw-bold"><?php echo $day; ?></div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="row">
                            <?php
                            $first_day = date('w', strtotime("$calendar_year-$calendar_month-01"));
                            $days_in_month = date('t', strtotime("$calendar_year-$calendar_month-01"));
                            
                            // Empty cells before first day
                            for($i=0; $i<$first_day; $i++):
                            ?>
                                <div class="col calendar-day"></div>
                            <?php endfor; ?>
                            
                            <!-- Days of the month -->
                            <?php for($day=1; $day<=$days_in_month; $day++): 
                                $is_today = ($day == date('j') && $calendar_month == date('m') && $calendar_year == date('Y'));
                                $today_class = $is_today ? 'today' : '';
                            ?>
                                <div class="col calendar-day <?php echo $today_class; ?>">
                                    <strong><?php echo $day; ?></strong>
                                    <?php if(isset($calendar_data[$day])): ?>
                                        <?php foreach($calendar_data[$day] as $status => $count): ?>
                                            <?php if($count > 0): ?>
                                                <div class="small">
                                                    <span class="appointment-dot dot-<?php echo $status; ?>"></span>
                                                    <?php echo $count; ?> <?php echo ucfirst($status); ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
