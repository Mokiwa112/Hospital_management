﻿
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hospital_management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `hospital_management`;
DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicants` (
  `applicant_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_posting_id` int(11) DEFAULT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `resume_path` varchar(300) DEFAULT NULL,
  `status` enum('applied','shortlisted','interviewed','offered','hired','rejected') NOT NULL DEFAULT 'applied',
  `applied_date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`applicant_id`),
  KEY `idx_applicant_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `applicants` WRITE;
/*!40000 ALTER TABLE `applicants` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_number` varchar(20) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `status` enum('scheduled','completed','cancelled','no_show') DEFAULT 'scheduled',
  `reason` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`appointment_id`),
  UNIQUE KEY `appointment_number` (`appointment_number`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_appointment_date` (`appointment_date`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,'APT20260213227',1,2,'2026-02-14','09:00:00','completed','Annual physical examination','Patient reports feeling well',1,'2026-02-13 18:41:16'),(2,'APT20260213648',2,3,'2026-02-15','10:30:00','scheduled','Follow-up after lab tests','Review blood work results',1,'2026-02-13 18:41:17'),(3,'APT20260213215',3,4,'2026-02-13','14:00:00','scheduled','Persistent headache','MRI results ready',1,'2026-02-13 18:41:17'),(4,'APT20260213783',4,5,'2026-02-12','11:15:00','completed','Vaccination','Flu shot administered',1,'2026-02-13 18:41:17'),(5,'APT20260213179',5,6,'2026-02-11','15:30:00','completed','Skin rash','Prescribed topical cream',1,'2026-02-13 18:41:17'),(7,'APT20260213467',7,3,'2026-02-17','11:00:00','scheduled','Pediatric checkup','Growth monitoring',1,'2026-02-13 18:41:18'),(8,'APT20260213330',8,4,'2026-02-18','13:30:00','scheduled','Neurology consultation','Migraine treatment',1,'2026-02-13 18:41:18'),(9,'APT20260213161',9,5,'2026-02-10','10:00:00','completed','Back pain','Physical therapy recommended',1,'2026-02-13 18:41:18'),(10,'APT20260213475',10,6,'2026-02-09','16:00:00','completed','Acne treatment','Prescribed medication',1,'2026-02-13 18:41:18');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late','half_day') DEFAULT 'present',
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `scheduled_start` datetime DEFAULT NULL,
  `scheduled_end` datetime DEFAULT NULL,
  `overtime_hours` decimal(5,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `requires_approval` tinyint(1) DEFAULT 1,
  `approval_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `unique_attendance` (`user_id`,`date`),
  KEY `idx_attendance_status` (`approval_status`,`date`),
  KEY `idx_attendance_user_date` (`user_id`,`date`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_attendance_shift_id` (`shift_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fk_attendance_shift` FOREIGN KEY (`shift_id`) REFERENCES `shift_definitions` (`shift_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (1,1,NULL,'2026-02-13','late','19:45:48','23:38:02',NULL,NULL,235.87,NULL,1,'approved',1,'2026-02-16 10:46:55'),(2,10,NULL,'2026-02-10','late','22:10:55','22:11:01',NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-16 10:46:48'),(3,12,NULL,'2026-02-10','late','22:14:03',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-16 10:46:52'),(4,2,NULL,'2026-02-16','present','08:35:04','21:31:34',NULL,NULL,4.93,NULL,1,'approved',1,'2026-02-16 10:46:44'),(5,1,NULL,'2026-02-16','late','09:25:38','21:22:58',NULL,NULL,3.95,NULL,1,'approved',1,'2026-02-16 11:26:04'),(6,7,NULL,'2026-02-16','late','09:27:52','22:14:40',NULL,NULL,4.77,NULL,1,'approved',1,'2026-02-16 20:19:31'),(7,10,NULL,'2026-02-16','late','09:29:59','22:24:10',NULL,NULL,4.90,NULL,1,'approved',1,'2026-02-16 20:19:23'),(8,12,NULL,'2026-02-16','late','09:31:43','22:20:10',NULL,NULL,4.80,NULL,1,'approved',1,'2026-02-16 20:19:27'),(9,14,NULL,'2026-02-16','late','09:32:57',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-16 20:19:35'),(10,16,NULL,'2026-02-16','late','09:35:23','21:09:29',NULL,NULL,171.57,NULL,1,'approved',1,'2026-02-16 20:19:19'),(11,17,NULL,'2026-02-16','late','22:13:18',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-21 08:21:14'),(12,15,NULL,'2026-02-16','late','22:17:38',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-21 08:20:44'),(13,1,NULL,'2026-02-21','present','08:23:30','17:10:30',NULL,NULL,48.78,NULL,1,'approved',1,'2026-02-21 08:23:39'),(14,2,NULL,'2026-02-21','present','08:40:40','11:09:45',NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-21 08:56:51'),(15,7,NULL,'2026-02-21','present','06:49:45','17:26:51',NULL,NULL,50.62,NULL,1,'approved',1,'2026-02-23 19:57:17'),(16,10,NULL,'2026-02-21','present','06:51:23','13:31:00',NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-23 19:57:26'),(17,15,NULL,'2026-02-21','present','07:16:01',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-23 19:57:21'),(18,17,NULL,'2026-02-21','present','07:36:29',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-21 16:48:21'),(19,19,NULL,'2026-02-21','late','10:57:08',NULL,NULL,NULL,0.00,NULL,1,'approved',1,'2026-02-21 16:48:16');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `attendance_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_approvals` (
  `approval_id` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approval_date` datetime DEFAULT current_timestamp(),
  `status` enum('approved','rejected') DEFAULT 'approved',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`approval_id`),
  KEY `attendance_id` (`attendance_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `attendance_approvals_ibfk_1` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`attendance_id`),
  CONSTRAINT `attendance_approvals_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `attendance_approvals` WRITE;
/*!40000 ALTER TABLE `attendance_approvals` DISABLE KEYS */;
INSERT INTO `attendance_approvals` VALUES (1,4,1,'2026-02-16 10:46:44','approved','Approved by admin'),(2,2,1,'2026-02-16 10:46:48','approved','Approved by admin'),(3,3,1,'2026-02-16 10:46:52','approved','Approved by admin'),(4,1,1,'2026-02-16 10:46:55','approved','Approved by admin'),(5,5,1,'2026-02-16 11:26:04','approved','Approved by admin'),(6,10,1,'2026-02-16 20:19:19','approved','Approved by admin'),(7,7,1,'2026-02-16 20:19:23','approved','Approved by admin'),(8,8,1,'2026-02-16 20:19:27','approved','Approved by admin'),(9,6,1,'2026-02-16 20:19:31','approved','Approved by admin'),(10,9,1,'2026-02-16 20:19:35','approved','Approved by admin');
/*!40000 ALTER TABLE `attendance_approvals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_type` varchar(50) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`backup_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
INSERT INTO `backups` VALUES (1,'backup_2026-02-21_08-48-17.sql','full',44646,1,'2026-02-21 05:48:19'),(2,'backup_2026-02-21_15-24-55.sql','full',67739,1,'2026-02-21 15:24:57'),(3,'backup_2026-02-23_23-41-16.sql','full',110468,1,'2026-02-23 23:41:18');
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_number` varchar(20) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `bill_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `tax` decimal(10,2) DEFAULT 0.00,
  `net_amount` decimal(10,2) DEFAULT NULL,
  `payment_status` enum('pending','partial','paid') DEFAULT 'pending',
  `payment_method` enum('cash','card','insurance','bank_transfer') DEFAULT NULL,
  `insurance_claim_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`bill_id`),
  UNIQUE KEY `bill_number` (`bill_number`),
  KEY `patient_id` (`patient_id`),
  KEY `insurance_claim_id` (`insurance_claim_id`),
  CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `billing_ibfk_2` FOREIGN KEY (`insurance_claim_id`) REFERENCES `insurance_claims` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `billing` WRITE;
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
INSERT INTO `billing` VALUES (1,'BILL202602217992',6,'2026-02-21 09:45:17',1200.00,0.00,0.00,1200.00,'paid','insurance',NULL,''),(2,'BILL202602238880',11,'2026-02-23 22:55:21',80000.00,0.00,0.00,80000.00,'paid','cash',NULL,''),(3,'BILL202602233729',25,'2026-02-23 23:05:42',450000.00,0.00,0.00,450000.00,'paid','bank_transfer',NULL,''),(4,'BILL202602233741',25,'2026-02-23 23:38:21',18085.00,0.00,0.00,18085.00,'paid','cash',NULL,'Auto-generated bill for uninsured patient after lab request creation (Request #: LAB202602235901).'),(5,'BILL202602239336',11,'2026-02-24 02:45:58',95000.00,0.00,0.00,95000.00,'pending',NULL,NULL,'Auto-generated bill for uninsured patient after lab request creation (multi-test request).');
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `billing_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_items` (
  `billing_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) DEFAULT NULL,
  `item_type` enum('consultation','lab_test','medicine','procedure','other') NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`billing_item_id`),
  KEY `bill_id` (`bill_id`),
  CONSTRAINT `billing_items_ibfk_1` FOREIGN KEY (`bill_id`) REFERENCES `billing` (`bill_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `billing_items` WRITE;
/*!40000 ALTER TABLE `billing_items` DISABLE KEYS */;
INSERT INTO `billing_items` VALUES (1,1,'medicine',1,'dawa',1,1200.00,1200.00),(2,2,'other',101,'Emergency Consultation',1,80000.00,80000.00),(3,3,'other',104,'ICU Bed Charge (Per Day)',1,450000.00,450000.00),(4,4,'lab_test',12,'Vitamin D Test - 23 Feb 2026',1,85000.00,85000.00),(5,4,'lab_test',14,'Widal Test - 23 Feb 2026',1,18000.00,18000.00),(6,5,'lab_test',15,'Blood Culture and Sensitivity - 24 Feb 2026',1,95000.00,95000.00);
/*!40000 ALTER TABLE `billing_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `billing_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billing_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_id` int(11) NOT NULL,
  `amount_paid` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(30) NOT NULL,
  `payment_reference` varchar(120) DEFAULT NULL,
  `payment_notes` text DEFAULT NULL,
  `paid_by` int(11) DEFAULT NULL,
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`payment_id`),
  KEY `idx_bill_id` (`bill_id`),
  KEY `idx_paid_at` (`paid_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `billing_payments` WRITE;
/*!40000 ALTER TABLE `billing_payments` DISABLE KEYS */;
INSERT INTO `billing_payments` VALUES (1,4,18085.00,'cash',NULL,NULL,10,'2026-02-24 00:36:41');
/*!40000 ALTER TABLE `billing_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `disciplinary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disciplinary_records` (
  `disciplinary_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(120) NOT NULL,
  `action_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `compliance_notes` text DEFAULT NULL,
  `confidential_remarks` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`disciplinary_id`),
  KEY `idx_disciplinary_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `disciplinary_records` WRITE;
/*!40000 ALTER TABLE `disciplinary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `disciplinary_records` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employee_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_documents` (
  `document_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `document_type` varchar(80) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employee_documents` WRITE;
/*!40000 ALTER TABLE `employee_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employee_employment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_employment_details` (
  `emp_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `employment_type` enum('full_time','part_time','contract','intern') NOT NULL DEFAULT 'full_time',
  `status` enum('active','inactive','terminated') NOT NULL DEFAULT 'active',
  `deactivation_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`emp_detail_id`),
  UNIQUE KEY `uniq_emp_user` (`user_id`),
  KEY `idx_emp_dept` (`department_id`),
  KEY `idx_emp_position` (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employee_employment_details` WRITE;
/*!40000 ALTER TABLE `employee_employment_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_employment_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employee_salary_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_salary_structures` (
  `structure_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `basic_salary` decimal(12,2) NOT NULL DEFAULT 0.00,
  `allowances` decimal(12,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pay_frequency` enum('monthly','weekly') NOT NULL DEFAULT 'monthly',
  `effective_from` date NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`structure_id`),
  KEY `idx_salary_user` (`user_id`),
  KEY `idx_salary_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employee_salary_structures` WRITE;
/*!40000 ALTER TABLE `employee_salary_structures` DISABLE KEYS */;
INSERT INTO `employee_salary_structures` VALUES (1,13,1200000.00,1200.00,12333.00,'monthly','2026-02-21',1,17,'2026-02-21 08:01:04');
/*!40000 ALTER TABLE `employee_salary_structures` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `first_visit_email_otps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `first_visit_email_otps` (
  `otp_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `consumed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`otp_id`),
  KEY `idx_email` (`email`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `first_visit_email_otps` WRITE;
/*!40000 ALTER TABLE `first_visit_email_otps` DISABLE KEYS */;
INSERT INTO `first_visit_email_otps` VALUES (6,'mokiwamohamedi66@gmail.com','$2y$10$B8AX.f5sLt6e/G5NigpIUuaSDggIyi39jqmS0vdVnOw9ExsRVUPNC','2026-02-23 23:04:55',0,1,'2026-02-24 01:54:55'),(7,'mokiwamohamedi66@gmail.com','$2y$10$VaCQjKcpGbJKydI8HV0PiuzJzVF/xpvX9153OzMygjSV4d7ps1cuy','2026-02-23 23:09:03',0,1,'2026-02-24 01:59:03'),(8,'mokiwa1305@gmail.com','$2y$10$5ztrk0j8y3.QYTE7JemRveYBt/Flcb1JDqZHAmpMIn.MbyDcZ4gxe','2026-02-23 23:15:11',0,1,'2026-02-24 02:05:11'),(9,'mokiwa1305@gmail.com','$2y$10$EoE13tv.GP2kbqolN5wRyuQL3VskrjI6n6GreBq88Hppd2gAQ76Cq','2026-02-23 23:24:41',0,1,'2026-02-24 02:14:41'),(10,'mokiwa1305@gmail.com','$2y$10$ucVuUoaPX9Nd01XRuuL3Wuy1HBFMQAkkBY/D8u3cxKQfPtwr1wNve','2026-02-23 23:24:49',0,0,'2026-02-24 02:14:49'),(11,'mokiwamohamedi66@gmail.com','$2y$10$1qHC0JUEOPAR4I5pSxbeA.y2BgnQeKpqML97bAE8yaSOl3gEY07ju','2026-02-23 23:25:59',0,0,'2026-02-24 02:15:59');
/*!40000 ALTER TABLE `first_visit_email_otps` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `hr_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hr_departments` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`department_id`),
  UNIQUE KEY `uniq_hr_department_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `hr_departments` WRITE;
/*!40000 ALTER TABLE `hr_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `hr_departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `hr_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hr_positions` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) DEFAULT NULL,
  `title` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`position_id`),
  KEY `idx_hr_positions_dept` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `hr_positions` WRITE;
/*!40000 ALTER TABLE `hr_positions` DISABLE KEYS */;
/*!40000 ALTER TABLE `hr_positions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `insurance_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_claims` (
  `claim_id` int(11) NOT NULL AUTO_INCREMENT,
  `claim_number` varchar(20) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `claim_amount` decimal(10,2) DEFAULT NULL,
  `claim_date` date DEFAULT curdate(),
  `status` enum('pending','approved','rejected','processing') DEFAULT 'pending',
  `documents` text DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_date` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  PRIMARY KEY (`claim_id`),
  UNIQUE KEY `claim_number` (`claim_number`),
  KEY `patient_id` (`patient_id`),
  KEY `provider_id` (`provider_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `insurance_claims_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `insurance_claims_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `insurance_providers` (`provider_id`),
  CONSTRAINT `insurance_claims_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `insurance_claims` WRITE;
/*!40000 ALTER TABLE `insurance_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_claims` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `insurance_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_providers` (
  `provider_id` int(11) NOT NULL AUTO_INCREMENT,
  `provider_name` varchar(200) NOT NULL,
  `provider_code` varchar(20) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `coverage_percentage` decimal(5,2) DEFAULT NULL,
  `terms_conditions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`provider_id`),
  UNIQUE KEY `provider_code` (`provider_code`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `insurance_providers` WRITE;
/*!40000 ALTER TABLE `insurance_providers` DISABLE KEYS */;
INSERT INTO `insurance_providers` VALUES (6,'National Insurance Corporation (NIC)','NIC001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(7,'Jubilee Insurance','JUB001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(8,'Alliance Insurance Tanzania','ALI001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(9,'Sanlam Tanzania','SAN001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(10,'Britam Insurance Tanzania','BRI001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(11,'Strategis Insurance Tanzania','STR001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(12,'Heritage Insurance Tanzania','HER001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(13,'Mayfair Insurance Tanzania','MAY001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(14,'Phoenix Insurance Tanzania','PHX001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(15,'Golden Crescent Insurance','GCI001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(16,'MGen Tanzania Insurance','MGT001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(17,'APA Insurance Tanzania','APA001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(18,'Zanzibar Insurance Corporation (ZIC)','ZIC001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(19,'Milvik Tanzania','MLV001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44'),(20,'Tanzania Agricultural Insurance Scheme (TAIS)','TAI001',NULL,NULL,NULL,NULL,0.00,NULL,'2026-02-21 13:37:44');
/*!40000 ALTER TABLE `insurance_providers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `interviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interviews` (
  `interview_id` int(11) NOT NULL AUTO_INCREMENT,
  `applicant_id` int(11) NOT NULL,
  `interview_date` datetime NOT NULL,
  `interviewer_id` int(11) DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `interviews` WRITE;
/*!40000 ALTER TABLE `interviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `interviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `inventory_class` enum('medical_supplies','pharmacy_drugs','laboratory','medical_equipment','consumables_office','it_system') DEFAULT 'medical_supplies',
  `description` text DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `reorder_level` int(11) DEFAULT 10,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `supplier` varchar(200) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `location` varchar(120) DEFAULT NULL,
  `status` enum('active','inactive','expired','damaged') DEFAULT 'active',
  `item_condition` enum('good','faulty','under_repair') DEFAULT NULL,
  `batch_number` varchar(80) DEFAULT NULL,
  `strength` varchar(80) DEFAULT NULL,
  `drug_type` varchar(80) DEFAULT NULL,
  `lab_test_type` varchar(120) DEFAULT NULL,
  `reagent_name` varchar(150) DEFAULT NULL,
  `storage_condition` varchar(150) DEFAULT NULL,
  `serial_number` varchar(120) DEFAULT NULL,
  `assigned_department` varchar(120) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `maintenance_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_updated` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `idx_inventory_expiry` (`expiry_date`),
  KEY `idx_inv_class` (`inventory_class`),
  KEY `idx_inv_status` (`status`),
  KEY `idx_inv_low_stock` (`quantity`,`reorder_level`),
  KEY `idx_inv_expiry` (`expiry_date`),
  KEY `idx_inv_supplier_id` (`supplier_id`),
  KEY `idx_inv_department` (`assigned_department`),
  CONSTRAINT `fk_inventory_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `inventory_suppliers` (`supplier_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES (1,'INV202602169557','dawa','Medicine','medical_supplies','Dawa za malaria','20 boxes',-418,2,1200.00,'MSD',NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-07','2026-02-16 17:22:00',NULL),(2,'MS001','Syringes 2ml','Syringes','medical_supplies','Disposable syringes 2ml','box',120,30,12000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-12-31','2026-02-23 17:00:15',NULL),(3,'MS002','Syringes 5ml','Syringes','medical_supplies','Disposable syringes 5ml','box',150,40,14500.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-12-31','2026-02-23 17:00:15',NULL),(4,'MS003','Syringes 10ml','Syringes','medical_supplies','Disposable syringes 10ml','box',90,25,18000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-12-31','2026-02-23 17:00:15',NULL),(5,'MS004','Needles Assorted','Needles','medical_supplies','Sterile needles mixed sizes','box',110,35,10000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-08-30','2026-02-23 17:00:15',NULL),(6,'MS005','IV Fluid Normal Saline 500ml','IV Fluids','medical_supplies','IV normal saline 500ml','bottle',220,60,3500.00,'Medline Tanzania',NULL,'Pharmacy Store','active','good','IVNS2401',NULL,NULL,NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-09-30','2026-02-23 17:00:15',NULL),(7,'MS006','IV Fluid Dextrose 5% 500ml','IV Fluids','medical_supplies','IV dextrose solution','bottle',180,50,3900.00,'Medline Tanzania',NULL,'Pharmacy Store','active','good','IVDX2403',NULL,NULL,NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-08-31','2026-02-23 17:00:15',NULL),(8,'MS007','IV Fluid Ringer Lactate 500ml','IV Fluids','medical_supplies','IV RL solution','bottle',160,45,4200.00,'Medline Tanzania',NULL,'Pharmacy Store','active','good','IVRL2402',NULL,NULL,NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-10-31','2026-02-23 17:00:15',NULL),(9,'MS008','Latex Gloves','Gloves','medical_supplies','Examination gloves latex','box',260,80,21000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-06-30','2026-02-23 17:00:15',NULL),(10,'MS009','Face Masks','Face Masks','medical_supplies','Surgical face masks','box',320,100,15000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-05-31','2026-02-23 17:00:15',NULL),(11,'MS010','Bandages','Bandages','medical_supplies','Elastic bandages','pack',140,35,9000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2029-01-31','2026-02-23 17:00:15',NULL),(12,'MS011','Cotton Wool','Cotton Wool','medical_supplies','Absorbent cotton wool','roll',180,40,4500.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2029-01-31','2026-02-23 17:00:15',NULL),(13,'MS012','Alcohol Swabs','Antiseptics','medical_supplies','Pre-injection alcohol swabs','box',200,50,11000.00,'Medline Tanzania',NULL,'Main Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nursing',NULL,NULL,NULL,'2028-11-30','2026-02-23 17:00:15',NULL),(14,'DR001','Paracetamol','Drug','pharmacy_drugs','Analgesic','box',300,90,7500.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','PARA2401','500mg','Tablet',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-12-31','2026-02-23 17:00:15',NULL),(15,'DR002','Amoxicillin','Drug','pharmacy_drugs','Antibiotic','box',220,70,14500.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','AMOX2402','500mg','Capsule',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-10-31','2026-02-23 17:00:15',NULL),(16,'DR003','Ciprofloxacin','Drug','pharmacy_drugs','Antibiotic','box',180,55,18000.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','CIPR2401','500mg','Tablet',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-09-30','2026-02-23 17:00:15',NULL),(17,'DR004','Metronidazole','Drug','pharmacy_drugs','Antiprotozoal','box',210,60,9500.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','METR2401','400mg','Tablet',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-08-31','2026-02-23 17:00:15',NULL),(18,'DR005','Ibuprofen','Drug','pharmacy_drugs','NSAID','box',190,50,9800.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','IBUP2402','400mg','Tablet',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-11-30','2026-02-23 17:00:15',NULL),(19,'DR006','Insulin','Drug','pharmacy_drugs','Diabetes management insulin','vial',70,25,32000.00,'PharmaHub Ltd',NULL,'Cold Chain','active','good','INSU2401','100IU/ml','Injection',NULL,NULL,'2-8 C',NULL,'Pharmacy',NULL,NULL,NULL,'2026-12-31','2026-02-23 17:00:15',NULL),(20,'DR007','Salbutamol Syrup','Drug','pharmacy_drugs','Bronchodilator syrup','bottle',120,35,7000.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','SALB2401','2mg/5ml','Syrup',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-07-31','2026-02-23 17:00:15',NULL),(21,'DR008','Omeprazole','Drug','pharmacy_drugs','PPI','box',140,40,12500.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','OMEP2401','20mg','Capsule',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-06-30','2026-02-23 17:00:15',NULL),(22,'DR009','ALu','Drug','pharmacy_drugs','Antimalarial ALu','box',160,45,16000.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','ALU2401','20/120mg','Tablet',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2027-09-30','2026-02-23 17:00:15',NULL),(23,'DR010','ORS Sachets','Drug','pharmacy_drugs','Oral rehydration salts','box',250,70,6000.00,'PharmaHub Ltd',NULL,'Pharmacy','active','good','ORS2401','N/A','Powder',NULL,NULL,NULL,NULL,'Pharmacy',NULL,NULL,NULL,'2028-03-31','2026-02-23 17:00:15',NULL),(24,'LB001','Blood Test Kits','Lab Reagent','laboratory','Routine blood test kits','box',85,25,45000.00,'LabTech East Africa',NULL,'Laboratory','active','good','LBK2401',NULL,NULL,'Blood',NULL,'2-8 C',NULL,'Laboratory',NULL,NULL,NULL,'2027-05-31','2026-02-23 17:00:15',NULL),(25,'LB002','Urine Test Kits','Lab Reagent','laboratory','Urinalysis strips and kits','box',95,30,38000.00,'LabTech East Africa',NULL,'Laboratory','active','good','LUK2401',NULL,NULL,'Urine',NULL,'Room temp',NULL,'Laboratory',NULL,NULL,NULL,'2027-04-30','2026-02-23 17:00:15',NULL),(26,'LB003','Microscope Slides','Lab Reagent','laboratory','Glass slides','box',140,40,12000.00,'LabTech East Africa',NULL,'Laboratory','active','good',NULL,NULL,NULL,'Microscopy',NULL,'Dry place',NULL,'Laboratory',NULL,NULL,NULL,'2029-12-31','2026-02-23 17:00:15',NULL),(27,'LB004','Rapid HIV Test Kits','Lab Reagent','laboratory','Rapid diagnostic tests HIV','box',70,20,52000.00,'LabTech East Africa',NULL,'Laboratory','active','good','HIV2401',NULL,NULL,'Rapid Test','HIV Rapid','2-30 C',NULL,'Laboratory',NULL,NULL,NULL,'2026-11-30','2026-02-23 17:00:15',NULL),(28,'LB005','Rapid Malaria Test Kits','Lab Reagent','laboratory','Rapid diagnostic tests malaria','box',90,25,47000.00,'LabTech East Africa',NULL,'Laboratory','active','good','MAL2401',NULL,NULL,'Rapid Test','Malaria Rapid','2-30 C',NULL,'Laboratory',NULL,NULL,NULL,'2026-12-31','2026-02-23 17:00:15',NULL),(29,'EQ001','Blood Pressure Machine','Medical Equipment','medical_equipment','Digital BP machine','unit',12,3,95000.00,'BioEquip Systems',NULL,'Ward A','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'BP-24001','Nursing',NULL,'2025-01-15','2026-12-01',NULL,'2026-02-23 17:00:15',NULL),(30,'EQ002','Thermometer Digital','Medical Equipment','medical_equipment','Digital thermometer','unit',25,8,18000.00,'BioEquip Systems',NULL,'Ward A','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'TH-24005','Nursing',NULL,'2025-02-10','2026-11-20',NULL,'2026-02-23 17:00:15',NULL),(31,'EQ003','Glucometer','Medical Equipment','medical_equipment','Blood glucose meter','unit',10,3,75000.00,'BioEquip Systems',NULL,'Laboratory','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'GL-24008','Laboratory',NULL,'2025-03-05','2026-10-15',NULL,'2026-02-23 17:00:15',NULL),(32,'EQ004','Oxygen Cylinder','Medical Equipment','medical_equipment','Portable oxygen cylinder','unit',8,2,420000.00,'BioEquip Systems',NULL,'Emergency','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'OX-24011','Emergency',NULL,'2024-12-20','2026-09-30',NULL,'2026-02-23 17:00:15',NULL),(33,'EQ005','Wheelchair','Medical Equipment','medical_equipment','Hospital wheelchair','unit',6,2,380000.00,'BioEquip Systems',NULL,'Reception','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'WH-24003','General',NULL,'2025-04-01','2026-08-30',NULL,'2026-02-23 17:00:15',NULL),(34,'CO001','Printer Paper A4','Office Supplies','consumables_office','A4 copy paper','ream',210,60,18000.00,'OfficePlus Supplies',NULL,'Admin Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Administration',NULL,NULL,NULL,NULL,'2026-02-23 17:00:15',NULL),(35,'CO002','Ink Toner Black','Office Supplies','consumables_office','Printer toner cartridge','piece',40,10,65000.00,'OfficePlus Supplies',NULL,'Admin Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Administration',NULL,NULL,NULL,NULL,'2026-02-23 17:00:15',NULL),(36,'CO003','Appointment Cards','Office Supplies','consumables_office','Patient appointment cards','pack',120,35,7000.00,'OfficePlus Supplies',NULL,'Reception','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Reception',NULL,NULL,NULL,NULL,'2026-02-23 17:00:15',NULL),(37,'CO004','Receipt Books','Office Supplies','consumables_office','Billing receipt books','book',90,25,5000.00,'OfficePlus Supplies',NULL,'Accounts','active','good',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Accounts',NULL,NULL,NULL,NULL,'2026-02-23 17:00:15',NULL),(38,'IT001','Desktop Computer','IT Device','it_system','Front office desktop','unit',14,4,1350000.00,'ITCare Solutions',NULL,'IT Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'DT-24001','IT',NULL,'2025-05-20','2026-07-01',NULL,'2026-02-23 17:00:15',NULL),(39,'IT002','Laptop','IT Device','it_system','Portable laptop','unit',9,3,2200000.00,'ITCare Solutions',NULL,'IT Store','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'LP-24004','IT',NULL,'2025-06-15','2026-07-15',NULL,'2026-02-23 17:00:15',NULL),(40,'IT003','Server','IT Device','it_system','Application server','unit',2,1,8500000.00,'ITCare Solutions',NULL,'Server Room','active','good',NULL,NULL,NULL,NULL,NULL,'192.168.1.10','SV-24001','IT',NULL,'2025-01-05','2026-06-30',NULL,'2026-02-23 17:00:15',NULL),(41,'IT004','Router','IT Device','it_system','Network router','unit',6,2,420000.00,'ITCare Solutions',NULL,'Server Room','active','good',NULL,NULL,NULL,NULL,NULL,'192.168.1.1','RT-24003','IT',NULL,'2025-02-25','2026-06-20',NULL,'2026-02-23 17:00:15',NULL),(42,'IT005','Barcode Scanner','IT Device','it_system','Pharmacy barcode scanner','unit',7,2,210000.00,'ITCare Solutions',NULL,'Pharmacy','active','good',NULL,NULL,NULL,NULL,NULL,NULL,'BC-24006','Pharmacy',NULL,'2025-03-18','2026-06-25',NULL,'2026-02-23 17:00:15',NULL);
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(200) NOT NULL,
  `contact_person` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `items_supplied` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `uniq_supplier_name` (`supplier_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_suppliers` WRITE;
/*!40000 ALTER TABLE `inventory_suppliers` DISABLE KEYS */;
INSERT INTO `inventory_suppliers` VALUES (1,'Medline Tanzania','Asha Medline','+255754100001','info@medline.tz','Medical supplies, PPE, disposables',1,'2026-02-23 17:00:15'),(2,'PharmaHub Ltd','Juma Pharma','+255754100002','sales@pharmahub.tz','Prescription and OTC drugs',1,'2026-02-23 17:00:15'),(3,'LabTech East Africa','Neema Lab','+255754100003','contact@labtechea.tz','Lab reagents and kits',1,'2026-02-23 17:00:15'),(4,'BioEquip Systems','Paul Bio','+255754100004','support@bioequip.tz','Medical equipment',1,'2026-02-23 17:00:15'),(5,'OfficePlus Supplies','Halima Office','+255754100005','hello@officeplus.tz','Consumables and office stock',1,'2026-02-23 17:00:15'),(6,'ITCare Solutions','Leonard IT','+255754100006','admin@itcare.tz','IT devices and networking',1,'2026-02-23 17:00:15');
/*!40000 ALTER TABLE `inventory_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `transaction_type` enum('purchase','issue','return','adjustment','stock_in','stock_out','stock_transfer','expired','damaged') NOT NULL,
  `quantity` int(11) NOT NULL,
  `balance_after` decimal(12,2) DEFAULT NULL,
  `transaction_date` datetime DEFAULT current_timestamp(),
  `performed_by` int(11) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `from_location` varchar(120) DEFAULT NULL,
  `to_location` varchar(120) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `item_id` (`item_id`),
  KEY `performed_by` (`performed_by`),
  KEY `idx_inv_tx_type_date` (`transaction_type`,`transaction_date`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`item_id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
INSERT INTO `inventory_transactions` VALUES (1,1,'purchase',10,NULL,'2026-02-16 20:22:18',1,NULL,NULL,NULL,''),(2,1,'adjustment',432,NULL,'2026-02-21 18:10:28',1,NULL,NULL,NULL,'hiii'),(3,1,'stock_in',-418,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(4,40,'stock_in',2,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(5,33,'stock_in',6,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(6,41,'stock_in',6,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(7,42,'stock_in',7,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(8,32,'stock_in',8,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(9,39,'stock_in',9,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(10,31,'stock_in',10,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(11,29,'stock_in',12,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(12,38,'stock_in',14,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(13,30,'stock_in',25,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(14,35,'stock_in',40,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(15,27,'stock_in',70,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(16,19,'stock_in',70,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(17,24,'stock_in',85,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(18,4,'stock_in',90,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(19,28,'stock_in',90,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(20,37,'stock_in',90,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(21,25,'stock_in',95,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(22,5,'stock_in',110,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(23,2,'stock_in',120,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(24,20,'stock_in',120,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(25,36,'stock_in',120,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(26,11,'stock_in',140,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(27,21,'stock_in',140,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(28,26,'stock_in',140,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(29,3,'stock_in',150,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(30,8,'stock_in',160,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(31,22,'stock_in',160,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(32,12,'stock_in',180,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(33,7,'stock_in',180,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(34,16,'stock_in',180,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(35,18,'stock_in',190,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(36,13,'stock_in',200,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(37,17,'stock_in',210,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(38,34,'stock_in',210,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(39,6,'stock_in',220,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(40,15,'stock_in',220,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(41,23,'stock_in',250,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(42,9,'stock_in',260,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(43,14,'stock_in',300,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed'),(44,10,'stock_in',320,NULL,'2026-02-23 20:05:28',1,NULL,NULL,NULL,'Initial stock seed');
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_user_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_user_access` (
  `access_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `granted_by` int(11) DEFAULT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`access_id`),
  UNIQUE KEY `uniq_inventory_access_user` (`user_id`),
  KEY `idx_inventory_access_edit` (`can_edit`),
  KEY `fk_inventory_access_granted_by` (`granted_by`),
  CONSTRAINT `fk_inventory_access_granted_by` FOREIGN KEY (`granted_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_inventory_access_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_user_access` WRITE;
/*!40000 ALTER TABLE `inventory_user_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_user_access` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_postings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_postings` (
  `job_posting_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `posted_date` date NOT NULL,
  `closed_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`job_posting_id`),
  KEY `idx_job_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_postings` WRITE;
/*!40000 ALTER TABLE `job_postings` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_postings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lab_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lab_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_number` varchar(20) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `request_date` datetime DEFAULT current_timestamp(),
  `status` enum('pending','collected','processing','completed','cancelled') DEFAULT 'pending',
  `sample_collected_date` datetime DEFAULT NULL,
  `result_date` datetime DEFAULT NULL,
  `result_value` text DEFAULT NULL,
  `result_notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `approved_by_doctor` tinyint(1) DEFAULT 0,
  `doctor_approval_date` datetime DEFAULT NULL,
  `lab_tech_id` int(11) DEFAULT NULL,
  `lab_approval_date` datetime DEFAULT NULL,
  `lab_notes` text DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `request_number` (`request_number`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `test_id` (`test_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_lab_status` (`status`),
  KEY `lab_tech_id` (`lab_tech_id`),
  CONSTRAINT `lab_requests_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `lab_requests_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `lab_requests_ibfk_3` FOREIGN KEY (`test_id`) REFERENCES `lab_tests` (`test_id`),
  CONSTRAINT `lab_requests_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  CONSTRAINT `lab_requests_ibfk_5` FOREIGN KEY (`lab_tech_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lab_requests` WRITE;
/*!40000 ALTER TABLE `lab_requests` DISABLE KEYS */;
INSERT INTO `lab_requests` VALUES (1,'LAB20260213288',1,2,1,'2026-02-13 21:41:18','completed','2026-02-16 20:30:56','2026-02-16 20:31:31','negative','',1,1,'2026-02-16 21:46:30',1,NULL,'\nSample collected: 2026-02-16 20:30:56 - '),(2,'LAB20260213218',2,3,2,'2026-02-13 21:41:19','completed',NULL,'2026-02-24 00:02:06','Normal','',1,0,NULL,13,NULL,NULL),(3,'LAB20260213867',3,4,6,'2026-02-13 21:41:19','completed',NULL,'2026-02-11 19:41:18','Normal brain activity',NULL,1,0,NULL,NULL,NULL,NULL),(4,'LAB20260213526',4,5,8,'2026-02-13 21:41:19','completed',NULL,'2026-02-08 19:41:18','Negative',NULL,1,1,'2026-02-21 17:00:33',NULL,NULL,NULL),(5,'LAB20260213679',5,6,3,'2026-02-13 21:41:19','completed','2026-02-16 11:31:16','2026-02-23 23:57:27','Positive','',1,0,NULL,13,NULL,NULL),(6,'LAB20260213819',6,2,7,'2026-02-13 21:41:19','completed',NULL,'2026-02-21 08:37:02','negative','',1,1,'2026-02-21 08:40:29',1,NULL,NULL),(7,'LAB20260213433',7,3,10,'2026-02-13 21:41:20','completed',NULL,'2026-02-12 19:41:18','35 ng/mL',NULL,1,0,NULL,NULL,NULL,NULL),(8,'LAB202602213368',9,2,6,'2026-02-21 08:41:06','completed','2026-02-21 09:48:23','2026-02-21 09:53:43','positive','',2,1,'2026-02-21 10:05:34',12,NULL,'\nSample collected: 2026-02-21 09:48:23 - '),(9,'LAB202602219346',1,2,6,'2026-02-21 08:42:02','completed','2026-02-21 09:47:42','2026-02-21 09:53:02','negative','',2,1,'2026-02-21 10:04:29',12,NULL,'\nSample collected: 2026-02-21 09:47:42 - '),(10,'LAB202602217877',12,2,2,'2026-02-21 17:17:03','completed','2026-02-21 17:17:27','2026-02-21 17:20:08','Negative test with strong health','This client has a strong immunuty',2,1,'2026-02-21 17:21:21',12,NULL,'\nSample collected: 2026-02-21 17:17:27 - '),(11,'LAB202602210039',2,1,2,'2026-02-21 18:45:40','completed','2026-02-23 20:47:50','2026-02-23 20:48:01','negative','',1,0,NULL,12,NULL,'Huyu mgonjwa ameshapona ameruhusiwa kurudi nyumbani'),(12,'LAB202602236403',25,2,10,'2026-02-23 20:43:09','completed','2026-02-23 20:44:20','2026-02-23 20:47:26','normal','',2,1,'2026-02-23 20:50:33',12,NULL,'\nSample collected: 2026-02-23 20:44:20 - '),(13,'LAB202602238964',27,2,2,'2026-02-23 23:10:12','completed','2026-02-23 23:15:39','2026-02-23 23:16:22','Negative test with small uti','The patient does not consume much water',2,1,'2026-02-23 23:18:26',13,NULL,'\nSample collected: 2026-02-23 23:15:39 - Collection gone fine'),(14,'LAB202602235901',25,2,25,'2026-02-23 23:38:20','completed','2026-02-23 23:41:04','2026-02-23 23:41:29','Negative','',2,1,'2026-02-23 23:41:59',13,NULL,'\nSample collected: 2026-02-23 23:41:04 - Urine, feases'),(15,'LAB202602236357',11,2,40,'2026-02-24 02:45:58','completed','2026-02-24 02:58:51','2026-02-24 03:00:14','normal','##LAB_PARAMS_JSON##{\"version\":1,\"parameters\":[{\"name\":\"urine\",\"value\":\"13.2\",\"unit\":\"g\\/l\",\"reference\":\"10-15\",\"flag\":\"Normal\"}]}',2,1,'2026-02-24 03:01:23',12,NULL,'Mpime malaria\nSample Collection: Sample Type: Urine | Container: Urine Cup | Priority: routine | Fasting: fasting | Condition: good | Collection Site: Lab');
/*!40000 ALTER TABLE `lab_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lab_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lab_tests` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_code` varchar(20) NOT NULL,
  `test_name` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `preparation_instructions` text DEFAULT NULL,
  `normal_range` varchar(100) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`test_id`),
  UNIQUE KEY `test_code` (`test_code`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lab_tests` WRITE;
/*!40000 ALTER TABLE `lab_tests` DISABLE KEYS */;
INSERT INTO `lab_tests` VALUES (1,'CBC001','Complete Blood Count','Hematology','Complete blood count analysis including RBC, WBC, platelets','Fasting not required','4.5-11.0 x10^9/L','test',50000.00,'2026-02-13 18:41:14'),(2,'BMP001','Basic Metabolic Panel','Chemistry','Blood glucose, calcium, electrolyte tests','Fasting for 8 hours required','Glucose: 70-99 mg/dL','panel',120000.00,'2026-02-13 18:41:15'),(3,'LIP001','Lipid Panel','Chemistry','Cholesterol and triglycerides','Fasting for 12 hours required','Total Chol: <200 mg/dL','panel',80000.00,'2026-02-13 18:41:15'),(4,'UA001','Urinalysis','Clinical Pathology','Complete urine analysis','Clean catch mid-stream sample','Clear, no abnormalities','test',35000.00,'2026-02-13 18:41:15'),(5,'XRY001','Chest X-Ray','Radiology','2-view chest X-ray','Remove metal objects','Normal findings','procedure',150000.00,'2026-02-13 18:41:15'),(6,'MRI001','Brain MRI','Radiology','Magnetic resonance imaging of brain','No metal implants','Normal findings','procedure',1200000.00,'2026-02-13 18:41:15'),(7,'EKG001','Electrocardiogram','Cardiology','Heart electrical activity','No caffeine 4 hours prior','Normal sinus rhythm','test',75000.00,'2026-02-13 18:41:15'),(8,'COVID001','COVID-19 PCR','Molecular','SARS-CoV-2 detection','Nasopharyngeal swab','Negative','test',100000.00,'2026-02-13 18:41:15'),(9,'TSH001','Thyroid Stimulating Hormone','Endocrinology','Thyroid function test','Fasting recommended','0.4-4.0 mIU/L','test',65000.00,'2026-02-13 18:41:15'),(10,'VITD001','Vitamin D Test','Endocrinology','25-hydroxy vitamin D','No special preparation','30-100 ng/mL','test',85000.00,'2026-02-13 18:41:15'),(11,'MAL001','Malaria Rapid Test','Parasitology','Rapid antigen detection for malaria','No fasting required','Negative','test',18000.00,'2026-02-23 20:36:44'),(12,'MAL002','Malaria Blood Smear','Parasitology','Microscopy thick and thin film for malaria parasites','No fasting required','No parasites seen','test',22000.00,'2026-02-23 20:36:44'),(13,'FBS001','Fasting Blood Sugar','Chemistry','Fasting plasma glucose level','Fast for 8-10 hours','3.9-5.5 mmol/L','mmol/L',15000.00,'2026-02-23 20:36:44'),(14,'RBS001','Random Blood Sugar','Chemistry','Random glucose test','No fasting required','<7.8 mmol/L','mmol/L',12000.00,'2026-02-23 20:36:44'),(15,'HBA001','HbA1c','Chemistry','Average glucose level over 3 months','No fasting required','<5.7%','%',45000.00,'2026-02-23 20:36:44'),(16,'LFT001','Liver Function Test','Chemistry','Panel for liver enzymes and bilirubin','No alcohol 24 hours prior','Within reference','panel',65000.00,'2026-02-23 20:36:44'),(17,'RFT001','Renal Function Test','Chemistry','Kidney function panel (urea, creatinine, electrolytes)','No fasting required','Within reference','panel',70000.00,'2026-02-23 20:36:44'),(18,'ELC001','Electrolytes (Na, K, Cl)','Chemistry','Serum electrolyte panel','No fasting required','Within reference','panel',55000.00,'2026-02-23 20:36:44'),(19,'URC001','Uric Acid','Chemistry','Serum uric acid test','No high-purine meal prior','3.4-7.0 mg/dL','mg/dL',22000.00,'2026-02-23 20:36:44'),(20,'LIP002','Lipid Profile','Chemistry','Total cholesterol, HDL, LDL, triglycerides','Fast for 12 hours','Within reference','panel',55000.00,'2026-02-23 20:36:44'),(21,'ESR001','Erythrocyte Sedimentation Rate (ESR)','Hematology','Inflammation screening test','No fasting required','0-20 mm/hr','mm/hr',12000.00,'2026-02-23 20:36:44'),(22,'CRP001','C-Reactive Protein (CRP)','Immunology','Inflammatory marker','No fasting required','<5 mg/L','mg/L',35000.00,'2026-02-23 20:36:44'),(23,'BGR001','Blood Group and Rh','Hematology','ABO and Rh blood grouping','No fasting required','ABO/Rh typed','test',20000.00,'2026-02-23 20:36:44'),(24,'CMT001','Crossmatch Test','Hematology','Donor-recipient compatibility test','As advised','Compatible','test',35000.00,'2026-02-23 20:36:44'),(25,'WID001','Widal Test','Microbiology','Typhoid serology','No fasting required','Negative','test',18000.00,'2026-02-23 20:36:45'),(26,'HIV001','HIV Rapid Test','Serology','Rapid HIV 1/2 antibody screening','Counseling recommended','Non-reactive','test',15000.00,'2026-02-23 20:36:45'),(27,'HBV001','HBsAg (Hepatitis B)','Serology','Hepatitis B surface antigen test','No fasting required','Negative','test',25000.00,'2026-02-23 20:36:45'),(28,'HCV001','Hepatitis C Antibody','Serology','HCV antibody screening','No fasting required','Negative','test',28000.00,'2026-02-23 20:36:45'),(29,'VDR001','VDRL / RPR','Serology','Syphilis screening test','No fasting required','Non-reactive','test',20000.00,'2026-02-23 20:36:45'),(30,'UPT001','Urine Pregnancy Test','Clinical Pathology','hCG qualitative urine test','Morning sample preferred','Negative','test',12000.00,'2026-02-23 20:36:45'),(31,'URN001','Urine Microscopy','Clinical Pathology','Microscopy for urine sediments','Clean catch sample','Within reference','test',16000.00,'2026-02-23 20:36:45'),(32,'STL001','Stool Analysis','Clinical Pathology','Routine stool microscopy and occult blood','Fresh stool sample','No abnormalities','test',18000.00,'2026-02-23 20:36:45'),(33,'BUN001','Blood Urea Nitrogen','Chemistry','BUN kidney assessment','No fasting required','7-20 mg/dL','mg/dL',18000.00,'2026-02-23 20:36:45'),(34,'CRE001','Serum Creatinine','Chemistry','Kidney marker test','No fasting required','0.6-1.3 mg/dL','mg/dL',18000.00,'2026-02-23 20:36:46'),(35,'PSA001','Prostate Specific Antigen (PSA)','Chemistry','PSA level test','Avoid ejaculation 48 hours','<4 ng/mL','ng/mL',50000.00,'2026-02-23 20:36:46'),(36,'TSH002','TSH','Endocrinology','Thyroid stimulating hormone level','No fasting required','0.4-4.0 mIU/L','mIU/L',32000.00,'2026-02-23 20:36:46'),(37,'FT4001','Free T4','Endocrinology','Free thyroxine level','No fasting required','0.8-1.8 ng/dL','ng/dL',42000.00,'2026-02-23 20:36:46'),(38,'DRE001','Dengue Rapid Test','Serology','Dengue NS1/IgM rapid test','No fasting required','Negative','test',38000.00,'2026-02-23 20:36:46'),(39,'TBX001','GeneXpert MTB/RIF','Molecular','Rapid TB molecular test','Sputum sample','Not Detected','test',120000.00,'2026-02-23 20:36:46'),(40,'BCT001','Blood Culture and Sensitivity','Microbiology','Detect bloodstream infection and sensitivity','Sample before antibiotics','No growth','test',95000.00,'2026-02-23 20:36:46');
/*!40000 ALTER TABLE `lab_tests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_requests` (
  `leave_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `approval_comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`leave_request_id`),
  KEY `idx_leave_user` (`user_id`),
  KEY `idx_leave_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
INSERT INTO `leave_requests` VALUES (1,5,1,'2026-02-21','2026-02-26',6.00,'I need to have a rest','approved',1,'2026-02-21 17:08:50','','2026-02-21 14:01:11');
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_types` (
  `leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_name` varchar(80) NOT NULL,
  `days_per_year` decimal(6,2) NOT NULL DEFAULT 0.00,
  `is_paid` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`leave_type_id`),
  UNIQUE KEY `uniq_leave_name` (`leave_name`)
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES (1,'Annual Leave',28.00,1,1,'2026-02-21 08:48:42'),(2,'Sick Leave',14.00,1,1,'2026-02-21 08:48:42'),(3,'Maternity Leave',90.00,1,1,'2026-02-21 08:48:42'),(4,'Unpaid Leave',30.00,0,1,'2026-02-21 08:48:42'),(129,'Uchovu',12.00,1,0,'2026-02-21 15:35:54');
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_number` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('M','F','O') NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `emergency_contact` varchar(15) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `patient_type` enum('inpatient','outpatient') NOT NULL,
  `registration_date` datetime DEFAULT current_timestamp(),
  `insurance_provider_id` int(11) DEFAULT NULL,
  `insurance_policy_number` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `patient_number` (`patient_number`),
  KEY `created_by` (`created_by`),
  KEY `idx_patient_type` (`patient_type`),
  CONSTRAINT `patients_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'PAT001','Juma','Mhando','1985-03-15','M','+255720000101','juma.mhando@email.com','Dar es Salaam, Tanzania','+255754000101','Asha Mhando','O+','Penicillin','outpatient','2026-02-13 21:41:16',1,'POL001234',NULL),(2,'PAT002','Neema','Mushi','1990-07-22','F','+255720000102','neema.mushi@email.com','Moshi, Tanzania','+255754000102','Juma Mushi','A+','Sulfa drugs','inpatient','2026-02-13 21:41:16',2,'POL005678',NULL),(3,'PAT003','Paulo','Mwansasu','1978-11-30','M','+255720000103','paulo.mwansasu@email.com','Mbeya, Tanzania','+255754000103','Neema Paulo','B-','Latex','inpatient','2026-02-13 21:41:16',3,'POL009876',NULL),(4,'PAT004','Rehema','Bulugu','1995-05-10','F','+255720000104','rehema.bulugu@email.com','Arusha, Tanzania','+255754000104','Doto Bulugu','AB+','None','outpatient','2026-02-13 21:41:16',4,'POL004321',NULL),(5,'PAT005','Abdallah','Nyoni','1982-09-18','M','+255720000105','abdallah.nyoni@email.com','Dodoma, Tanzania','+255754000105','Amina Nyoni','A-','Ibuprofen','outpatient','2026-02-13 21:41:16',5,'POL007654',NULL),(6,'PAT006','Fatuma','Selemani','1988-12-03','F','+255720000106','fatuma.selemani@email.com','Tanga, Tanzania','+255754000106','Omary Selemani','O-','Shellfish','inpatient','2026-02-13 21:41:16',1,'POL003456',NULL),(7,'PAT007','Isack','Ng\'wana','1975-06-25','M','+255720000107','isack.ngwana@email.com','Mwanza, Tanzania','+255754000107','Ruth Ng\'wana','B+','Codeine','outpatient','2026-02-13 21:41:16',2,'POL008765',NULL),(8,'PAT008','Agnes','Kweka','1992-08-14','F','+255720000108','agnes.kweka@email.com','Iringa, Tanzania','+255754000108','Paulo Kweka','AB-','Peanuts','inpatient','2026-02-13 21:41:16',NULL,NULL,NULL),(9,'PAT009','Leonard','Masanja','1980-04-19','M','+255720000109','leonard.masanja@email.com','Morogoro, Tanzania','+255754000109','Asha Masanja','A+','None','outpatient','2026-02-13 21:41:16',3,'POL002468',NULL),(10,'PAT010','Zawadi','Mgaya','1993-11-07','F','+255720000110','zawadi.mgaya@email.com','Kilimanjaro, Tanzania','+255754000110','Musa Mgaya','O+','Dust','inpatient','2026-02-13 21:41:16',4,'POL013579',NULL),(11,'PAT202602219173','ELISHA PETER','STANLEY','2022-12-02','M','0772586321','elly@gmail.com','Singida','0785693231','Elly','','','outpatient','2026-02-21 16:20:39',NULL,'',7),(12,'PAT202602216913','MOHAMEDI','MOKIWA','2003-05-13','M','0778110851','mokiwamohamedi66@gmail.com','Tanga tanzania','0785693231','Mohamedi Mokiwa','O+','','outpatient','2026-02-21 17:14:46',6,'2',7),(13,'PAT202602213176','WILLISON STANLEY','MNAYA','2003-01-07','M','0778420118','epmanstanley2003@gmail.com','Manyoni Singida','0745245485','Help','A+','Ppopo','inpatient','2026-02-21 18:40:05',8,'0882727263',1),(14,'PAT202602215685','KABILI','MSUKUMA','2000-09-20','M','0758963586','jac@234','E comer','0758742563','Pqw wanjera','B-','Dust','outpatient','2026-02-21 18:51:20',17,'43789986',1),(25,'PAT202602235058','MOHAMEDI JUMA','MOKIWA','2003-05-13','M','0778110851','','Mikanjuni tanga','0778110851','Mokiwa','O+','','inpatient','2026-02-23 20:38:44',NULL,'',10),(26,'PAT202602230654','REGINA','LUKUMBIJA','2003-12-07','F','0711122334','regina1@gmail.com','Mwanza Tanzania','0778110851','Mokiwa','AB+','','outpatient','2026-02-23 23:04:02',6,'2',10),(27,'PAT202602237641','SHABANI','NASORO','2002-05-13','M','0645632456','shaba@gmail.com','Daresalaam Tanzania','0778110851','Mokiwa','AB-','','outpatient','2026-02-23 23:08:30',NULL,'',10);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payroll_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_records` (
  `payroll_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `pay_month` tinyint(2) NOT NULL,
  `pay_year` smallint(4) NOT NULL,
  `present_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `half_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `absent_days` decimal(6,2) NOT NULL DEFAULT 0.00,
  `gross_salary` decimal(12,2) NOT NULL DEFAULT 0.00,
  `allowances` decimal(12,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(12,2) NOT NULL DEFAULT 0.00,
  `net_salary` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('generated','paid') NOT NULL DEFAULT 'generated',
  `payment_method` enum('cash','bank_transfer','mobile_money','cheque') DEFAULT NULL,
  `paid_date` datetime DEFAULT NULL,
  `paid_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`payroll_id`),
  UNIQUE KEY `uniq_payroll_period` (`user_id`,`pay_month`,`pay_year`),
  KEY `idx_payroll_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payroll_records` WRITE;
/*!40000 ALTER TABLE `payroll_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_records` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `performance_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `performance_reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `score` decimal(5,2) NOT NULL DEFAULT 0.00,
  `comments` text DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `evaluation_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`review_id`),
  KEY `idx_review_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `performance_reviews` WRITE;
/*!40000 ALTER TABLE `performance_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescription_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_id` int(11) DEFAULT NULL,
  `medicine_name` varchar(200) NOT NULL,
  `dosage` varchar(50) DEFAULT NULL,
  `frequency` varchar(100) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `prescription_id` (`prescription_id`),
  CONSTRAINT `prescription_items_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`prescription_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescription_items` WRITE;
/*!40000 ALTER TABLE `prescription_items` DISABLE KEYS */;
INSERT INTO `prescription_items` VALUES (1,1,'mseto','100gm','2x3','7',2,'Take after meal'),(2,1,'paracetamol','500gm','3xdaily','7days',3,''),(3,2,'pen v','12gm','2x daily','6days',1,''),(4,3,'penicilin','34','2x daily','7',2,'after meals'),(5,4,'penicilin','23','2x daily','5 days',2,'after meals'),(6,5,'paracetamol','5gm','3x daily','4',1,'take after meal'),(7,6,'paracetamol','120mg','3xdaily','7days',2,'take after meal');
/*!40000 ALTER TABLE `prescription_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescriptions` (
  `prescription_id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_number` varchar(20) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `prescription_date` datetime DEFAULT current_timestamp(),
  `diagnosis` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('active','dispensed','cancelled') DEFAULT 'active',
  PRIMARY KEY (`prescription_id`),
  UNIQUE KEY `prescription_number` (`prescription_number`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `prescriptions_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescriptions` WRITE;
/*!40000 ALTER TABLE `prescriptions` DISABLE KEYS */;
INSERT INTO `prescriptions` VALUES (1,'RX202602168007',9,2,'2026-02-16 10:39:06','Malaria','',''),(2,'RX202602217119',1,2,'2026-02-21 08:43:25','tonsils','',''),(3,'RX202602213108',1,2,'2026-02-21 10:06:29','malaria','',''),(4,'RX202602217805',1,2,'2026-02-21 10:28:44','malaria','\nDispense: ','dispensed'),(5,'RX202602239998',27,2,'2026-02-23 23:18:26','Small UTI','\nDispense: ','dispensed'),(6,'RX202602249147',11,2,'2026-02-24 03:03:26','uti','\nDispense: ','dispensed');
/*!40000 ALTER TABLE `prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `report_name` varchar(200) NOT NULL,
  `report_type` varchar(50) DEFAULT NULL,
  `parameters` text DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `generated_by` int(11) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`report_id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,'appointment_20260216_084829','appointment','{\"date_from\":\"2026-02-01\",\"date_to\":\"2026-02-16\"}',NULL,1,'2026-02-16 07:48:29'),(2,'billing_20260221_131513','billing','{\"date_from\":\"2026-02-01\",\"date_to\":\"2026-02-21\"}',NULL,1,'2026-02-21 13:15:13'),(3,'worker_20260223_162000','worker','{\"date_from\":\"2026-02-01\",\"date_to\":\"2026-02-23\"}',NULL,1,'2026-02-23 16:20:00');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shift_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_definitions` (
  `shift_id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_name` varchar(50) NOT NULL,
  `shift_code` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `duration_hours` tinyint(4) NOT NULL DEFAULT 8,
  `is_overnight` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`shift_id`),
  UNIQUE KEY `uniq_shift_name` (`shift_name`),
  UNIQUE KEY `uniq_shift_code` (`shift_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shift_definitions` WRITE;
/*!40000 ALTER TABLE `shift_definitions` DISABLE KEYS */;
INSERT INTO `shift_definitions` VALUES (1,'Morning Shift','SHIFT-1','06:00:00','14:00:00',8,0,1,'2026-02-21 13:54:32'),(2,'Evening Shift','SHIFT-2','14:00:00','22:00:00',8,0,1,'2026-02-21 13:54:32'),(3,'Night Shift','SHIFT-3','22:00:00','06:00:00',8,1,1,'2026-02-21 13:54:32');
/*!40000 ALTER TABLE `shift_definitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_queries` (
  `query_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('pending','in_progress','resolved') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`query_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `support_queries_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_queries` WRITE;
/*!40000 ALTER TABLE `support_queries` DISABLE KEYS */;
INSERT INTO `support_queries` VALUES (1,2,'appointment','edrftgy','pending','2026-02-13 17:18:19',NULL);
/*!40000 ALTER TABLE `support_queries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`task_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`user_id`),
  CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'Ufanyaji usafi','Wafanyakazi wote wa usafi mnapaswa kuhudhuria eneo la usafi',2,1,'high','completed','2026-02-20','2026-02-13 14:02:20','2026-02-13 18:35:31');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `log_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_logs` WRITE;
/*!40000 ALTER TABLE `user_logs` DISABLE KEYS */;
INSERT INTO `user_logs` VALUES (1,1,'login','::1','2026-02-13 18:44:30'),(2,2,'login','::1','2026-02-13 18:46:37'),(3,7,'login','::1','2026-02-13 18:47:34'),(4,1,'login','::1','2026-02-10 21:06:21'),(5,10,'login','::1','2026-02-10 21:09:33'),(6,12,'login','::1','2026-02-10 21:12:08'),(7,2,'login','::1','2026-02-16 07:31:55'),(8,1,'login','::1','2026-02-16 07:46:22'),(9,1,'attendance_approve','::1','2026-02-16 07:46:44'),(10,1,'attendance_approve','::1','2026-02-16 07:46:49'),(11,1,'attendance_approve','::1','2026-02-16 07:46:52'),(12,1,'attendance_approve','::1','2026-02-16 07:46:55'),(13,1,'attendance_approve','::1','2026-02-16 08:26:04'),(14,7,'login','::1','2026-02-16 08:27:19'),(15,10,'login','::1','2026-02-16 08:29:19'),(16,12,'login','::1','2026-02-16 08:30:49'),(17,14,'login','::1','2026-02-16 08:32:19'),(18,16,'login','::1','2026-02-16 08:33:40'),(19,1,'login','::1','2026-02-16 16:42:49'),(20,1,'login','::1','2026-02-16 17:16:17'),(21,1,'attendance_approve','::1','2026-02-16 17:19:19'),(22,1,'attendance_approve','::1','2026-02-16 17:19:23'),(23,1,'attendance_approve','::1','2026-02-16 17:19:27'),(24,1,'attendance_approve','::1','2026-02-16 17:19:31'),(25,1,'attendance_approve','::1','2026-02-16 17:19:35'),(26,2,'login','::1','2026-02-16 18:30:00'),(27,1,'login','::1','2026-02-16 19:05:14'),(28,2,'login','::1','2026-02-16 19:08:04'),(29,17,'login','::1','2026-02-16 19:11:48'),(30,7,'login','::1','2026-02-16 19:14:18'),(31,15,'login','::1','2026-02-16 19:17:06'),(32,12,'login','::1','2026-02-16 19:19:35'),(33,10,'login','::1','2026-02-16 19:22:33'),(34,2,'login','::1','2026-02-21 05:13:12'),(35,1,'login','::1','2026-02-21 05:20:31'),(36,2,'login','::1','2026-02-21 05:39:56'),(37,1,'login','::1','2026-02-21 05:47:10'),(38,1,'login','::1','2026-02-21 06:31:38'),(39,2,'login','::1','2026-02-21 06:46:52'),(40,7,'login','::1','2026-02-21 06:49:35'),(41,10,'login','::1','2026-02-21 06:50:57'),(42,12,'login','::1','2026-02-21 06:52:25'),(43,14,'login','::1','2026-02-21 06:55:32'),(44,2,'login','::1','2026-02-21 07:04:09'),(45,15,'login','::1','2026-02-21 07:07:22'),(46,2,'login','::1','2026-02-21 07:18:44'),(47,15,'login','::1','2026-02-21 07:29:37'),(48,17,'login','::1','2026-02-21 07:36:03'),(49,17,'login','::1','2026-02-21 07:46:52'),(50,17,'login','::1','2026-02-21 08:00:20'),(51,19,'login','::1','2026-02-21 08:48:39'),(52,2,'login','::1','2026-02-21 11:08:15'),(53,1,'login','192.168.1.107','2026-02-21 13:14:38'),(54,7,'login','192.168.1.107','2026-02-21 13:17:44'),(55,10,'login','192.168.1.107','2026-02-21 13:22:45'),(56,1,'login','192.168.1.107','2026-02-21 13:46:04'),(57,5,'login','192.168.1.107','2026-02-21 14:00:04'),(58,1,'login','192.168.1.107','2026-02-21 14:04:09'),(59,7,'login','192.168.1.107','2026-02-21 14:09:50'),(60,2,'login','192.168.1.107','2026-02-21 14:16:22'),(61,12,'login','192.168.1.107','2026-02-21 14:18:40'),(62,2,'login','192.168.1.107','2026-02-21 14:20:51'),(63,1,'login','192.168.1.107','2026-02-21 14:24:16'),(64,1,'login','::1','2026-02-21 15:04:17'),(65,1,'shift_assign','::1','2026-02-21 15:08:22'),(66,1,'login','::1','2026-02-21 15:21:39'),(67,1,'login','::1','2026-02-21 15:34:56'),(68,1,'login','::1','2026-02-21 15:42:15'),(69,1,'login','::1','2026-02-21 17:37:25'),(70,1,'login','::1','2026-02-21 19:05:14'),(71,2,'login','::1','2026-02-21 19:24:22'),(72,2,'login','::1','2026-02-23 16:09:02'),(73,1,'login','::1','2026-02-23 16:16:25'),(74,1,'login','::1','2026-02-23 16:52:44'),(75,2,'login','::1','2026-02-23 17:00:51'),(76,1,'login','::1','2026-02-23 17:02:26'),(77,1,'attendance_check_out','::1','2026-02-23 17:10:31'),(78,2,'login','::1','2026-02-23 17:14:27'),(79,1,'login','::1','2026-02-23 17:16:57'),(80,2,'login','::1','2026-02-23 17:23:10'),(81,7,'login','::1','2026-02-23 17:26:41'),(82,7,'attendance_check_out','::1','2026-02-23 17:26:51'),(83,10,'login','::1','2026-02-23 17:31:03'),(84,10,'login','::1','2026-02-23 17:37:26'),(85,2,'login','::1','2026-02-23 17:39:20'),(86,12,'login','::1','2026-02-23 17:46:37'),(87,6,'login','::1','2026-02-23 17:48:45'),(88,2,'login','::1','2026-02-23 17:50:18'),(89,14,'login','::1','2026-02-23 17:59:41'),(90,1,'login','::1','2026-02-23 18:11:39'),(91,12,'login','::1','2026-02-23 18:26:10'),(92,1,'login','::1','2026-02-23 18:33:03'),(93,1,'login','::1','2026-02-23 18:33:14'),(94,1,'login','::1','2026-02-23 18:51:23'),(95,1,'login','::1','2026-02-23 19:04:04'),(96,1,'login','::1','2026-02-23 19:52:32'),(97,19,'login','::1','2026-02-23 19:59:27'),(98,10,'login','::1','2026-02-23 20:01:50'),(99,2,'login','::1','2026-02-23 20:09:02'),(100,13,'login','::1','2026-02-23 20:13:19'),(101,1,'login','::1','2026-02-23 20:34:27'),(102,13,'login','::1','2026-02-23 20:39:38'),(103,10,'login','::1','2026-02-23 21:02:51'),(104,16,'login','127.0.0.1','2026-02-23 21:07:16'),(105,16,'attendance_check_out','127.0.0.1','2026-02-23 21:09:30'),(106,1,'login','::1','2026-02-23 23:27:06'),(107,1,'attendance_check_out','::1','2026-02-23 23:38:02'),(108,1,'shift_assign','::1','2026-02-23 23:39:47'),(109,2,'login','::1','2026-02-23 23:43:16'),(110,12,'login','::1','2026-02-23 23:57:21'),(111,2,'login','::1','2026-02-24 00:01:05'),(112,14,'login','::1','2026-02-24 00:05:44'),(113,2,'login','::1','2026-02-24 00:14:41');
/*!40000 ALTER TABLE `user_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_shift_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_shift_assignments` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `shift_date` date NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`assignment_id`),
  UNIQUE KEY `uniq_user_shift_date` (`user_id`,`shift_date`),
  KEY `idx_shift_date` (`shift_date`),
  KEY `idx_shift_user` (`user_id`),
  KEY `idx_shift_id` (`shift_id`),
  KEY `idx_assigned_by` (`assigned_by`),
  CONSTRAINT `fk_shift_assignment_admin` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_shift_assignment_shift` FOREIGN KEY (`shift_id`) REFERENCES `shift_definitions` (`shift_id`),
  CONSTRAINT `fk_shift_assignment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_shift_assignments` WRITE;
/*!40000 ALTER TABLE `user_shift_assignments` DISABLE KEYS */;
INSERT INTO `user_shift_assignments` VALUES (1,3,1,'2026-02-21',1,'','2026-02-21 14:24:58'),(3,19,1,'2026-02-23',1,'','2026-02-23 23:39:42'),(4,19,1,'2026-02-24',1,'','2026-02-23 23:39:42'),(5,19,1,'2026-02-25',1,'','2026-02-23 23:39:42'),(6,19,1,'2026-02-26',1,'','2026-02-23 23:39:43'),(7,19,1,'2026-02-27',1,'','2026-02-23 23:39:43'),(8,19,1,'2026-02-28',1,'','2026-02-23 23:39:43'),(9,19,1,'2026-03-01',1,'','2026-02-23 23:39:43'),(10,19,1,'2026-03-02',1,'','2026-02-23 23:39:43'),(11,19,1,'2026-03-03',1,'','2026-02-23 23:39:44'),(12,19,1,'2026-03-04',1,'','2026-02-23 23:39:44'),(13,19,1,'2026-03-05',1,'','2026-02-23 23:39:44'),(14,19,1,'2026-03-06',1,'','2026-02-23 23:39:44'),(15,19,1,'2026-03-07',1,'','2026-02-23 23:39:44'),(16,19,1,'2026-03-08',1,'','2026-02-23 23:39:44'),(17,19,1,'2026-03-09',1,'','2026-02-23 23:39:44'),(18,19,1,'2026-03-10',1,'','2026-02-23 23:39:44'),(19,19,1,'2026-03-11',1,'','2026-02-23 23:39:44'),(20,19,1,'2026-03-12',1,'','2026-02-23 23:39:44'),(21,19,1,'2026-03-13',1,'','2026-02-23 23:39:44'),(22,19,1,'2026-03-14',1,'','2026-02-23 23:39:44'),(23,19,1,'2026-03-15',1,'','2026-02-23 23:39:44'),(24,19,1,'2026-03-16',1,'','2026-02-23 23:39:44'),(25,19,1,'2026-03-17',1,'','2026-02-23 23:39:44'),(26,19,1,'2026-03-18',1,'','2026-02-23 23:39:44'),(27,19,1,'2026-03-19',1,'','2026-02-23 23:39:44'),(28,19,1,'2026-03-20',1,'','2026-02-23 23:39:44'),(29,19,1,'2026-03-21',1,'','2026-02-23 23:39:45'),(30,19,1,'2026-03-22',1,'','2026-02-23 23:39:45'),(31,19,1,'2026-03-23',1,'','2026-02-23 23:39:45'),(32,19,1,'2026-03-24',1,'','2026-02-23 23:39:45'),(33,19,1,'2026-03-25',1,'','2026-02-23 23:39:45'),(34,19,1,'2026-03-26',1,'','2026-02-23 23:39:45'),(35,19,1,'2026-03-27',1,'','2026-02-23 23:39:45'),(36,19,1,'2026-03-28',1,'','2026-02-23 23:39:45'),(37,19,1,'2026-03-29',1,'','2026-02-23 23:39:45'),(38,19,1,'2026-03-30',1,'','2026-02-23 23:39:45'),(39,19,1,'2026-03-31',1,'','2026-02-23 23:39:45'),(40,19,1,'2026-04-01',1,'','2026-02-23 23:39:45'),(41,19,1,'2026-04-02',1,'','2026-02-23 23:39:45'),(42,19,1,'2026-04-03',1,'','2026-02-23 23:39:45'),(43,19,1,'2026-04-04',1,'','2026-02-23 23:39:45'),(44,19,1,'2026-04-05',1,'','2026-02-23 23:39:46'),(45,19,1,'2026-04-06',1,'','2026-02-23 23:39:46'),(46,19,1,'2026-04-07',1,'','2026-02-23 23:39:46'),(47,19,1,'2026-04-08',1,'','2026-02-23 23:39:46'),(48,19,1,'2026-04-09',1,'','2026-02-23 23:39:46'),(49,19,1,'2026-04-10',1,'','2026-02-23 23:39:46'),(50,19,1,'2026-04-11',1,'','2026-02-23 23:39:46'),(51,19,1,'2026-04-12',1,'','2026-02-23 23:39:46'),(52,19,1,'2026-04-13',1,'','2026-02-23 23:39:46'),(53,19,1,'2026-04-14',1,'','2026-02-23 23:39:46'),(54,19,1,'2026-04-15',1,'','2026-02-23 23:39:46'),(55,19,1,'2026-04-16',1,'','2026-02-23 23:39:46'),(56,19,1,'2026-04-17',1,'','2026-02-23 23:39:46'),(57,19,1,'2026-04-18',1,'','2026-02-23 23:39:46'),(58,19,1,'2026-04-19',1,'','2026-02-23 23:39:46'),(59,19,1,'2026-04-20',1,'','2026-02-23 23:39:46'),(60,19,1,'2026-04-21',1,'','2026-02-23 23:39:46'),(61,19,1,'2026-04-22',1,'','2026-02-23 23:39:47'),(62,19,1,'2026-04-23',1,'','2026-02-23 23:39:47');
/*!40000 ALTER TABLE `user_shift_assignments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(500) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `user_type` enum('admin','doctor','nurse','receptionist','pharmacist','lab_tech','accountant','hr_admin') NOT NULL,
  `department` varchar(50) DEFAULT NULL,
  `employee_id` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$lVb1PrhlSRZX59MGqrkW..lql7uf2CcBG7qE8HvpQwWa1w1IcnsOC',NULL,'Joseph Mwita','admin@hospital.local','+255710000100','Administration Block','admin','Administration','ADM001','2026-02-21 08:45:33'),(2,'dr.magesa','$2y$10$fUsPBtPueSy0hXgSyIRvsOBHjSVtIPFUSGjflIdyROEj8Bg1o7mI.',NULL,'Neema Magesa','dr.magesa@hospital.local','+255710000101','Doctors Wing','doctor','Cardiology','DOC001','2026-02-21 08:45:34'),(3,'dr.nkya','$2y$10$fUsPBtPueSy0hXgSyIRvsOBHjSVtIPFUSGjflIdyROEj8Bg1o7mI.',NULL,'Elias Nkya','dr.nkya@hospital.local','+255710000102','Doctors Wing','doctor','Pediatrics','DOC002','2026-02-21 08:45:34'),(4,'dr.mhando','$2y$10$fUsPBtPueSy0hXgSyIRvsOBHjSVtIPFUSGjflIdyROEj8Bg1o7mI.',NULL,'Rehema Mhando','dr.mhando@hospital.local','+255710000103','Doctors Wing','doctor','Neurology','DOC003','2026-02-21 08:45:34'),(5,'dr.mwakalinga','$2y$10$fUsPBtPueSy0hXgSyIRvsOBHjSVtIPFUSGjflIdyROEj8Bg1o7mI.',NULL,'Leonard Mwakalinga','dr.mwakalinga@hospital.local','+255710000104','Doctors Wing','doctor','Orthopedics','DOC004','2026-02-21 08:45:34'),(6,'dr.rashid','$2y$10$fUsPBtPueSy0hXgSyIRvsOBHjSVtIPFUSGjflIdyROEj8Bg1o7mI.',NULL,'Zainabu Rashid','dr.rashid@hospital.local','+255710000105','Doctors Wing','doctor','Dermatology','DOC005','2026-02-21 08:45:34'),(7,'nurse.bulugu','$2y$10$pncBUOF/rk6IClV4LyGYKeOwqg/ZESSMD7kNFlOygMLynacHN0LpO',NULL,'Agatha Bulugu','nurse.bulugu@hospital.local','+255710000106','Nurses Station','nurse','ICU','NUR001','2026-02-21 08:45:34'),(8,'nurse.selemani','$2y$10$pncBUOF/rk6IClV4LyGYKeOwqg/ZESSMD7kNFlOygMLynacHN0LpO',NULL,'Halima Selemani','nurse.selemani@hospital.local','+255710000107','Nurses Station','nurse','Emergency','NUR002','2026-02-21 08:45:35'),(9,'nurse.mushi','$2y$10$pncBUOF/rk6IClV4LyGYKeOwqg/ZESSMD7kNFlOygMLynacHN0LpO',NULL,'Joyce Mushi','nurse.mushi@hospital.local','+255710000108','Nurses Station','nurse','Pediatrics','NUR003','2026-02-21 08:45:35'),(10,'reception.mbwana','$2y$10$bMwawypXx77nf/Fh9HDsheWkzP.LRMG4VOTWN6UQzzz7x7PMXQBJy',NULL,'Happiness Mbwana','reception.mbwana@hospital.local','+255710000109','Front Desk','receptionist','Front Office','REC001','2026-02-21 08:45:35'),(11,'reception.ngwana','$2y$10$bMwawypXx77nf/Fh9HDsheWkzP.LRMG4VOTWN6UQzzz7x7PMXQBJy',NULL,'Ezekiel Ng\'wana','reception.ngwana@hospital.local','+255710000110','Front Desk','receptionist','Appointments','REC002','2026-02-21 08:45:35'),(12,'lab.shija','$2y$10$RqXptnHz8hRKzKtxaYdw6e6CgWRnq6qtbHIHLJW1VIm.kdqRAhG1i',NULL,'Deus Shija','lab.shija@hospital.local','+255710000111','Laboratory','lab_tech','Hematology','LAB001','2026-02-21 08:45:35'),(13,'lab.mwansasu','$2y$10$RqXptnHz8hRKzKtxaYdw6e6CgWRnq6qtbHIHLJW1VIm.kdqRAhG1i',NULL,'Prisca Mwansasu','lab.mwansasu@hospital.local','+255710000112','Laboratory','lab_tech','Radiology','LAB002','2026-02-21 08:45:35'),(14,'pharma.nyoni','$2y$10$ji9AYYxAvy3zMeePYQM88.t0wvumeIgAb6wdKtS5Z1nghMQg3HPo2',NULL,'Selemani Nyoni','pharma.nyoni@hospital.local','+255710000113','Pharmacy','pharmacist','Pharmacy','PHR001','2026-02-21 08:45:36'),(15,'pharma.kweka','$2y$10$ji9AYYxAvy3zMeePYQM88.t0wvumeIgAb6wdKtS5Z1nghMQg3HPo2',NULL,'Upendo Kweka','pharma.kweka@hospital.local','+255710000114','Pharmacy','pharmacist','Clinical Pharmacy','PHR002','2026-02-21 08:45:36'),(16,'account.masanja','$2y$10$DzDdP6nEcbMVobxxlW2VfOjn13lYBrx.FmGQwvCuLh0Vyf.VbtcCO',NULL,'Daudi Masanja','account.masanja@hospital.local','+255710000115','Finance Office','accountant','Billing','ACC001','2026-02-21 08:45:36'),(17,'account.mgaya','$2y$10$DzDdP6nEcbMVobxxlW2VfOjn13lYBrx.FmGQwvCuLh0Vyf.VbtcCO',NULL,'Beatrice Mgaya','account.mgaya@hospital.local','+255710000116','Finance Office','accountant','Insurance','ACC002','2026-02-21 08:45:36'),(18,'hr.luhanga','$2y$10$xqzlbIsf8ImawaQfRyqqdOogi4f38.R2.GTrEwkqVuozpAMSwmMnW',NULL,'Flora Luhanga','hr.luhanga@hospital.local','+255710000117','HR Office','hr_admin','Human Resources','HR001','2026-02-21 08:45:36'),(19,'hr.mboya','$2y$10$xqzlbIsf8ImawaQfRyqqdOogi4f38.R2.GTrEwkqVuozpAMSwmMnW',NULL,'Raymond Mboya','hr.mboya@hospital.local','+255710000118','HR Office','hr_admin','Human Resources','HR002','2026-02-21 08:45:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vw_inventory_expiry_alert`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_expiry_alert`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_inventory_expiry_alert` AS SELECT
 1 AS `item_id`,
  1 AS `item_code`,
  1 AS `item_name`,
  1 AS `inventory_class`,
  1 AS `category`,
  1 AS `expiry_date`,
  1 AS `days_to_expiry`,
  1 AS `quantity`,
  1 AS `unit` */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `vw_inventory_low_stock`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_low_stock`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_inventory_low_stock` AS SELECT
 1 AS `item_id`,
  1 AS `item_code`,
  1 AS `item_name`,
  1 AS `inventory_class`,
  1 AS `category`,
  1 AS `quantity`,
  1 AS `reorder_level`,
  1 AS `unit`,
  1 AS `supplier`,
  1 AS `expiry_date` */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `vw_inventory_monthly_consumption`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_monthly_consumption`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_inventory_monthly_consumption` AS SELECT
 1 AS `period_month`,
  1 AS `item_id`,
  1 AS `total_consumed` */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `vw_inventory_stock_summary`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_stock_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_inventory_stock_summary` AS SELECT
 1 AS `inventory_class`,
  1 AS `category`,
  1 AS `total_items`,
  1 AS `total_quantity`,
  1 AS `estimated_stock_value` */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `workflow_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_steps` (
  `step_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_type` varchar(50) DEFAULT NULL,
  `request_id` int(11) DEFAULT NULL,
  `step_name` varchar(100) DEFAULT NULL,
  `performed_by` int(11) DEFAULT NULL,
  `performed_date` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`step_id`),
  KEY `performed_by` (`performed_by`),
  CONSTRAINT `workflow_steps_ibfk_1` FOREIGN KEY (`performed_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `workflow_steps` WRITE;
/*!40000 ALTER TABLE `workflow_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_steps` ENABLE KEYS */;
UNLOCK TABLES;

USE `hospital_management`;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_expiry_alert`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50001 VIEW `vw_inventory_expiry_alert` AS select `inventory_items`.`item_id` AS `item_id`,`inventory_items`.`item_code` AS `item_code`,`inventory_items`.`item_name` AS `item_name`,`inventory_items`.`inventory_class` AS `inventory_class`,`inventory_items`.`category` AS `category`,`inventory_items`.`expiry_date` AS `expiry_date`,to_days(`inventory_items`.`expiry_date`) - to_days(curdate()) AS `days_to_expiry`,`inventory_items`.`quantity` AS `quantity`,`inventory_items`.`unit` AS `unit` from `inventory_items` where `inventory_items`.`expiry_date` is not null and `inventory_items`.`expiry_date` <= curdate() + interval 90 day */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_low_stock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50001 VIEW `vw_inventory_low_stock` AS select `inventory_items`.`item_id` AS `item_id`,`inventory_items`.`item_code` AS `item_code`,`inventory_items`.`item_name` AS `item_name`,`inventory_items`.`inventory_class` AS `inventory_class`,`inventory_items`.`category` AS `category`,`inventory_items`.`quantity` AS `quantity`,`inventory_items`.`reorder_level` AS `reorder_level`,`inventory_items`.`unit` AS `unit`,`inventory_items`.`supplier` AS `supplier`,`inventory_items`.`expiry_date` AS `expiry_date` from `inventory_items` where `inventory_items`.`quantity` <= `inventory_items`.`reorder_level` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_monthly_consumption`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50001 VIEW `vw_inventory_monthly_consumption` AS select date_format(`inventory_transactions`.`transaction_date`,'%Y-%m') AS `period_month`,`inventory_transactions`.`item_id` AS `item_id`,sum(case when `inventory_transactions`.`transaction_type` in ('issue','stock_out','expired','damaged') then `inventory_transactions`.`quantity` else 0 end) AS `total_consumed` from `inventory_transactions` group by date_format(`inventory_transactions`.`transaction_date`,'%Y-%m'),`inventory_transactions`.`item_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `vw_inventory_stock_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50001 VIEW `vw_inventory_stock_summary` AS select `inventory_items`.`inventory_class` AS `inventory_class`,`inventory_items`.`category` AS `category`,count(0) AS `total_items`,sum(`inventory_items`.`quantity`) AS `total_quantity`,sum(`inventory_items`.`quantity` * `inventory_items`.`unit_price`) AS `estimated_stock_value` from `inventory_items` group by `inventory_items`.`inventory_class`,`inventory_items`.`category` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


