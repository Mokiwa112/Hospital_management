<?php
require_once 'config.php';

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_portal.php");
    exit();
}

$conn = getConnection();
$patient_id = $_SESSION['patient_id'];
$success = '';
$error = '';

// Fetch current patient data
$query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    session_destroy();
    header("Location: patient_portal.php");
    exit();
}

$patient = mysqli_fetch_assoc($result);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $emergency_contact = sanitize($_POST['emergency_contact']);
    $emergency_name = sanitize($_POST['emergency_name']);

    if (!isValidPhoneNumber($phone)) {
        $error = getPhoneValidationMessage();
    } elseif (!empty($emergency_contact) && !isValidPhoneNumber($emergency_contact)) {
        $error = "Emergency contact: " . getPhoneValidationMessage();
    } else {
        $update_query = "UPDATE patients SET 
                         phone = '$phone',
                         email = '$email',
                         address = '$address',
                         emergency_contact = '$emergency_contact',
                         emergency_contact_name = '$emergency_name'
                         WHERE patient_id = $patient_id";
        
        if (mysqli_query($conn, $update_query)) {
            $success = "Profile updated successfully!";
            // Refresh patient data
            $result = mysqli_query($conn, $query);
            $patient = mysqli_fetch_assoc($result);
        } else {
            $error = "Error updating profile: " . mysqli_error($conn);
        }
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    if ($new != $confirm) {
        $error = "New passwords do not match";
    } elseif (strlen($new) < 6) {
        $error = "Password must be at least 6 characters long";
    } else {
        // In a real system, you'd verify the current password against the database
        // For demo, we'll just show success
        $success = "Password changed successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .info-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .readonly-field {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <!-- Profile Header -->
        <div class="profile-header">
            <h2><i class="fas fa-user-circle"></i> My Profile</h2>
            <p class="mb-0">Manage your personal information and account settings</p>
        </div>
        
        <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Left Column - Read-only Information -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-id-card text-primary"></i> Patient Information</h5>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Patient Number</small>
                        <div class="fw-bold"><?php echo htmlspecialchars($patient['patient_number']); ?></div>
                    </div>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Full Name</small>
                        <div class="fw-bold"><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></div>
                    </div>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Date of Birth</small>
                        <div class="fw-bold"><?php echo date('d F Y', strtotime($patient['date_of_birth'])); ?></div>
                    </div>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Gender</small>
                        <div class="fw-bold">
                            <?php 
                            if($patient['gender'] == 'M') echo 'Male';
                            elseif($patient['gender'] == 'F') echo 'Female';
                            else echo 'Other';
                            ?>
                        </div>
                    </div>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Blood Group</small>
                        <div class="fw-bold"><?php echo $patient['blood_group'] ?: 'Not specified'; ?></div>
                    </div>
                    
                    <div class="readonly-field">
                        <small class="text-muted">Registration Date</small>
                        <div class="fw-bold"><?php echo date('d F Y', strtotime($patient['registration_date'])); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Middle Column - Editable Information -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-edit text-success"></i> Edit Contact Information</h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" name="phone" 
                                   value="<?php echo htmlspecialchars($patient['phone'] ?? ''); ?>" required
                                   pattern="^(0\d{9}|\+\d{11,12})$"
                                   title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" 
                                   value="<?php echo htmlspecialchars($patient['email'] ?? ''); ?>">
                            <small class="text-muted">Optional but recommended for notifications</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($patient['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <h6 class="mt-4 mb-3">Emergency Contact</h6>
                        
                        <div class="mb-3">
                            <label class="form-label">Emergency Contact Name</label>
                            <input type="text" class="form-control" name="emergency_name" 
                                   value="<?php echo htmlspecialchars($patient['emergency_contact_name'] ?? ''); ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Emergency Contact Phone</label>
                            <input type="tel" class="form-control" name="emergency_contact" 
                                   value="<?php echo htmlspecialchars($patient['emergency_contact'] ?? ''); ?>"
                                   pattern="^(0\d{9}|\+\d{11,12})$"
                                   title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-success w-100">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Right Column - Change Password -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-key text-warning"></i> Change Password</h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" name="new_password" 
                                   minlength="6" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" name="change_password" class="btn btn-warning w-100">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                    
                    <hr>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        <small>For security, always use a strong password with a mix of letters, numbers, and symbols.</small>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-link"></i> Quick Links</h5>
                    <div class="d-grid gap-2">
                        <a href="patient_dashboard.php" class="btn btn-outline-primary">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a href="view_medical_record.php" class="btn btn-outline-info">
                            <i class="fas fa-file-medical"></i> Medical Records
                        </a>
                        <a href="patient_billing.php" class="btn btn-outline-success">
                            <i class="fas fa-file-invoice"></i> Billing History
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

