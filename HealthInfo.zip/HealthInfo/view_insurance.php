<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$claim_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch claim details
$query = "SELECT c.*, p.first_name, p.last_name, p.patient_number, p.phone, p.email,
          ip.provider_name, ip.coverage_percentage, ip.contact_person, ip.phone as provider_phone
          FROM insurance_claims c
          JOIN patients p ON c.patient_id = p.patient_id
          JOIN insurance_providers ip ON c.provider_id = ip.provider_id
          WHERE c.claim_id = $claim_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Insurance claim not found";
    header("Location: insurance.php");
    exit();
}

$claim = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Claim Details - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .status-processing { background: #cce5ff; color: #004085; }
        
        .info-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-shield-alt"></i> Insurance Claim Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="insurance.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Claims
                </a>
                <a href="print_claim.php?id=<?php echo $claim_id; ?>" class="btn btn-info" target="_blank">
                    <i class="fas fa-print"></i> Print
                </a>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <!-- Claim Information -->
                <div class="info-card">
                    <h5 class="mb-3">Claim Information</h5>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Claim Number:</strong><br> <?php echo $claim['claim_number']; ?></p>
                            <p><strong>Claim Date:</strong><br> <?php echo date('d M Y', strtotime($claim['claim_date'])); ?></p>
                            <p><strong>Claim Amount:</strong><br> TSh <?php echo number_format($claim['claim_amount'], 2); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Status:</strong><br> 
                                <span class="status-badge status-<?php echo $claim['status']; ?>">
                                    <?php echo ucfirst($claim['status']); ?>
                                </span>
                            </p>
                            <p><strong>Coverage:</strong><br> <?php echo $claim['coverage_percentage']; ?>%</p>
                        </div>
                    </div>
                    
                    <?php if($claim['remarks']): ?>
                        <div class="mt-3">
                            <strong>Remarks:</strong>
                            <p><?php echo nl2br(htmlspecialchars($claim['remarks'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Patient Information -->
                <div class="info-card">
                    <h5 class="mb-3">Patient Information</h5>
                    
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($claim['first_name'] . ' ' . $claim['last_name']); ?></p>
                    <p><strong>Patient Number:</strong> <?php echo $claim['patient_number']; ?></p>
                    <p><strong>Phone:</strong> <?php echo $claim['phone']; ?></p>
                    <p><strong>Email:</strong> <?php echo $claim['email'] ?: 'N/A'; ?></p>
                </div>
            </div>
            
            <div class="col-md-6">
                <!-- Insurance Provider Information -->
                <div class="info-card">
                    <h5 class="mb-3">Insurance Provider</h5>
                    
                    <p><strong>Provider Name:</strong> <?php echo htmlspecialchars($claim['provider_name']); ?></p>
                    <p><strong>Contact Person:</strong> <?php echo htmlspecialchars($claim['contact_person']); ?></p>
                    <p><strong>Provider Phone:</strong> <?php echo $claim['provider_phone']; ?></p>
                    <p><strong>Coverage Percentage:</strong> <?php echo $claim['coverage_percentage']; ?>%</p>
                </div>
                
                <!-- Actions -->
                <?php if($claim['status'] == 'pending'): ?>
                <div class="info-card">
                    <h5 class="mb-3">Actions</h5>
                    
                    <div class="d-grid gap-2">
                        <a href="process_claim.php?id=<?php echo $claim_id; ?>&action=approve" 
                           class="btn btn-success"
                           onclick="return confirm('Approve this insurance claim?')">
                            <i class="fas fa-check-circle"></i> Approve Claim
                        </a>
                        <a href="process_claim.php?id=<?php echo $claim_id; ?>&action=reject" 
                           class="btn btn-danger"
                           onclick="return confirm('Reject this insurance claim?')">
                            <i class="fas fa-times-circle"></i> Reject Claim
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>