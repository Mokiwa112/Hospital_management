<?php
require_once 'config.php';

// Check if user is logged in - SIMPLE CHECK, NO REDIRECT LOOPS
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// Handle filters
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$employee_filter = isset($_GET['employee']) ? (int)$_GET['employee'] : 0;

// Build query
$where = ["YEAR(a.date) = $year", "MONTH(a.date) = $month"];

if ($user_type != 'admin') {
    $where[] = "a.user_id = $user_id";
} elseif ($employee_filter > 0) {
    $where[] = "a.user_id = $employee_filter";
}

if (!empty($status_filter)) {
    $where[] = "a.status = '$status_filter'";
}

$where_clause = implode(' AND ', $where);

// Fetch attendance records
$query = "SELECT a.*, u.full_name, u.employee_id, u.department 
          FROM attendance a
          JOIN users u ON a.user_id = u.user_id
          WHERE $where_clause
          ORDER BY a.date DESC, a.check_in DESC";
$attendance = mysqli_query($conn, $query);

// Get months
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];

// Get employees for admin filter
$employees = [];
if ($user_type == 'admin') {
    $emp_query = "SELECT user_id, full_name, employee_id FROM users ORDER BY full_name";
    $emp_result = mysqli_query($conn, $emp_query);
    while($emp = mysqli_fetch_assoc($emp_result)) {
        $employees[] = $emp;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-present { background: #d4edda; color: #155724; }
        .status-absent { background: #f8d7da; color: #721c24; }
        .status-late { background: #fff3cd; color: #856404; }
        .status-half_day { background: #cce5ff; color: #004085; }
        
        .approval-approved { background: #d4edda; color: #155724; }
        .approval-pending { background: #fff3cd; color: #856404; }
        .approval-rejected { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Attendance History</h2>
            <a href="worker_attendance.php" class="btn btn-primary">
                <i class="fas fa-clock"></i> Back to Attendance
            </a>
        </div>
        
        <!-- Filter Form -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Filters</h5>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">Month</label>
                        <select class="form-control" name="month">
                            <?php foreach($months as $num => $name): ?>
                                <option value="<?php echo $num; ?>" <?php echo $month == $num ? 'selected' : ''; ?>>
                                    <?php echo $name; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Year</label>
                        <select class="form-control" name="year">
                            <option value="<?php echo date('Y'); ?>" <?php echo $year == date('Y') ? 'selected' : ''; ?>>
                                <?php echo date('Y'); ?>
                            </option>
                            <option value="<?php echo date('Y')-1; ?>" <?php echo $year == date('Y')-1 ? 'selected' : ''; ?>>
                                <?php echo date('Y')-1; ?>
                            </option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                        <select class="form-control" name="status">
                            <option value="">All</option>
                            <option value="present" <?php echo $status_filter == 'present' ? 'selected' : ''; ?>>Present</option>
                            <option value="absent" <?php echo $status_filter == 'absent' ? 'selected' : ''; ?>>Absent</option>
                            <option value="late" <?php echo $status_filter == 'late' ? 'selected' : ''; ?>>Late</option>
                            <option value="half_day" <?php echo $status_filter == 'half_day' ? 'selected' : ''; ?>>Half Day</option>
                        </select>
                    </div>
                    <?php if($user_type == 'admin'): ?>
                    <div class="col-md-3">
                        <label class="form-label">Employee</label>
                        <select class="form-control" name="employee">
                            <option value="0">All Employees</option>
                            <?php foreach($employees as $emp): ?>
                                <option value="<?php echo $emp['user_id']; ?>" <?php echo $employee_filter == $emp['user_id'] ? 'selected' : ''; ?>>
                                    <?php echo $emp['full_name']; ?> (<?php echo $emp['employee_id']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="col-md-<?php echo $user_type == 'admin' ? '3' : '4'; ?>">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Attendance Records -->
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Attendance Records</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Date</th>
                                <?php if($user_type == 'admin'): ?>
                                    <th>Employee</th>
                                    <th>ID</th>
                                <?php endif; ?>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Hours</th>
                                <th>Status</th>
                                <th>Approval</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($attendance && mysqli_num_rows($attendance) > 0): ?>
                                <?php while($record = mysqli_fetch_assoc($attendance)): 
                                    $check_in = $record['check_in'] ? strtotime($record['check_in']) : null;
                                    $check_out = $record['check_out'] ? strtotime($record['check_out']) : null;
                                    
                                    $hours = 0;
                                    if ($check_in && $check_out) {
                                        $hours = round(($check_out - $check_in) / 3600, 2);
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo date('d M Y', strtotime($record['date'])); ?></td>
                                        
                                        <?php if($user_type == 'admin'): ?>
                                            <td><?php echo $record['full_name']; ?></td>
                                            <td><?php echo $record['employee_id']; ?></td>
                                        <?php endif; ?>
                                        
                                        <td>
                                            <?php if($record['check_in']): ?>
                                                <?php echo date('h:i A', strtotime($record['check_in'])); ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td>
                                            <?php if($record['check_out']): ?>
                                                <?php echo date('h:i A', strtotime($record['check_out'])); ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td>
                                            <?php if($hours > 0): ?>
                                                <?php echo $hours; ?> hrs
                                                <?php if($record['overtime_hours'] > 0): ?>
                                                    <br><small class="text-success">+<?php echo $record['overtime_hours']; ?> OT</small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        
                                        <td>
                                            <span class="status-badge status-<?php echo $record['status']; ?>">
                                                <?php echo ucfirst($record['status']); ?>
                                            </span>
                                        </td>
                                        
                                        <td>
                                            <span class="badge bg-<?php 
                                                $approval = $record['approval_status'] ?? 'pending';
                                                if ($approval == 'approved') echo 'success';
                                                elseif ($approval == 'rejected') echo 'danger';
                                                else echo 'warning';
                                            ?>">
                                                <?php echo ucfirst($approval); ?>
                                            </span>
                                        </td>
                                        
                                        <td>
                                            <!-- SIMPLE VIEW BUTTON - NO REDIRECT LOOP -->
                                            <a href="view_attendance.php?id=<?php echo $record['attendance_id']; ?>" 
                                               class="btn btn-sm btn-info">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                            
                                            <?php if($user_type == 'admin' && ($record['approval_status'] ?? 'pending') == 'pending'): ?>
                                                <a href="process_attendance.php?id=<?php echo $record['attendance_id']; ?>&action=approve" 
                                                   class="btn btn-sm btn-success"
                                                   onclick="return confirm('Approve this attendance?')">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <a href="process_attendance.php?id=<?php echo $record['attendance_id']; ?>&action=reject" 
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Reject this attendance?')">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="<?php echo $user_type == 'admin' ? 9 : 7; ?>" class="text-center py-4">
                                        <p class="text-muted">No attendance records found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
