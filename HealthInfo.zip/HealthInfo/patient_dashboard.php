<?php
require_once 'config.php';

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_portal.php");
    exit();
}

$conn = getConnection();
$patient_id = $_SESSION['patient_id'];

// Fetch patient details
$patient_query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$patient_result = mysqli_query($conn, $patient_query);

if (!$patient_result || mysqli_num_rows($patient_result) == 0) {
    session_destroy();
    header("Location: patient_portal.php");
    exit();
}

$patient = mysqli_fetch_assoc($patient_result);

// Fetch upcoming appointments
$appointments = mysqli_query($conn,
    "SELECT a.*, u.full_name as doctor_name, u.department 
     FROM appointments a
     JOIN users u ON a.doctor_id = u.user_id
     WHERE a.patient_id = $patient_id 
     AND a.appointment_date >= CURDATE()
     AND a.status = 'scheduled'
     ORDER BY a.appointment_date ASC, a.appointment_time ASC"
);

// Fetch recent lab results
$lab_results = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.normal_range, lt.unit 
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = $patient_id 
     AND lr.status = 'completed'
     ORDER BY lr.result_date DESC
     LIMIT 10"
);

// Fetch prescriptions
$prescriptions = mysqli_query($conn,
    "SELECT p.*, u.full_name as doctor_name
     FROM prescriptions p
     JOIN users u ON p.doctor_id = u.user_id
     WHERE p.patient_id = $patient_id 
     ORDER BY p.prescription_date DESC
     LIMIT 10"
);

// Fetch prescription items
$prescription_items = [];
if ($prescriptions && mysqli_num_rows($prescriptions) > 0) {
    $pres_ids = [];
    while($pres = mysqli_fetch_assoc($prescriptions)) {
        $pres_ids[] = $pres['prescription_id'];
    }
    mysqli_data_seek($prescriptions, 0);
    
    if (!empty($pres_ids)) {
        $ids = implode(',', $pres_ids);
        $items_query = "SELECT * FROM prescription_items WHERE prescription_id IN ($ids)";
        $items_result = mysqli_query($conn, $items_query);
        while($item = mysqli_fetch_assoc($items_result)) {
            $prescription_items[$item['prescription_id']][] = $item;
        }
    }
}

// Fetch billing history
$bills = mysqli_query($conn,
    "SELECT * FROM billing 
     WHERE patient_id = $patient_id 
     ORDER BY bill_date DESC
     LIMIT 10"
);

// Get doctors for appointment booking
$doctors = mysqli_query($conn, "SELECT user_id, full_name, department FROM users WHERE user_type = 'doctor' ORDER BY full_name");

// Calculate statistics
$stats = [];
$stats_query = "SELECT 
    (SELECT COUNT(*) FROM appointments WHERE patient_id = $patient_id) as total_appointments,
    (SELECT COUNT(*) FROM lab_requests WHERE patient_id = $patient_id) as total_lab_tests,
    (SELECT COUNT(*) FROM prescriptions WHERE patient_id = $patient_id) as total_prescriptions,
    (SELECT SUM(net_amount) FROM billing WHERE patient_id = $patient_id AND payment_status = 'paid') as total_paid
";
$stats_result = mysqli_query($conn, $stats_query);
if ($stats_result) {
    $stats = mysqli_fetch_assoc($stats_result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        .info-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .info-card h5 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        .appointment-item {
            border-left: 4px solid #667eea;
            padding: 15px;
            margin-bottom: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .quick-action-btn {
            width: 100%;
            text-align: left;
            padding: 15px 20px;
            margin-bottom: 10px;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            transition: all 0.3s;
            background: white;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        .quick-action-btn:hover {
            background: #f8f9fa;
            transform: translateX(5px);
            border-left: 4px solid #667eea;
            text-decoration: none;
            color: inherit;
        }
        .badge-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-scheduled { background: #cce5ff; color: #004085; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2><i class="fas fa-user-circle"></i> Welcome back, <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?>!</h2>
                    <p class="mb-0">
                        <i class="fas fa-id-card"></i> Patient #: <?php echo htmlspecialchars($patient['patient_number']); ?> |
                        <i class="fas fa-calendar"></i> Member since: <?php echo date('d M Y', strtotime($patient['registration_date'])); ?>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-light btn-lg" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                        <i class="fas fa-calendar-plus"></i> Book Appointment
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_appointments'] ?? 0; ?></div>
                    <div class="text-muted">Total Appointments</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_lab_tests'] ?? 0; ?></div>
                    <div class="text-muted">Lab Tests</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_prescriptions'] ?? 0; ?></div>
                    <div class="text-muted">Prescriptions</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo format_currency($stats['total_paid'] ?? 0); ?></div>
                    <div class="text-muted">Total Paid</div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Left Column - Quick Actions & Personal Info -->
            <div class="col-md-3">
                <div class="info-card">
                    <h5><i class="fas fa-id-card"></i> Personal Info</h5>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($patient['phone']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($patient['email'] ?: 'Not provided'); ?></p>
                    <p><strong>Blood Group:</strong> <?php echo htmlspecialchars($patient['blood_group'] ?: 'Not specified'); ?></p>
                    <p><strong>Address:</strong> <?php echo htmlspecialchars($patient['address'] ?: 'Not provided'); ?></p>
                </div>
                
                <div class="info-card">
                    <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
                    
                    <a href="#" class="quick-action-btn" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                        <i class="fas fa-calendar-plus text-primary"></i> 
                        <strong>Book New Appointment</strong>
                        <br><small class="text-muted">Schedule a visit with our doctors</small>
                    </a>
                    
                    <a href="view_medical_record.php" class="quick-action-btn">
                        <i class="fas fa-file-medical text-success"></i> 
                        <strong>View Medical Records</strong>
                        <br><small class="text-muted">Access your complete medical history</small>
                    </a>
                    
                    <a href="patient_profile.php" class="quick-action-btn">
                        <i class="fas fa-user-edit text-info"></i> 
                        <strong>Update Profile</strong>
                        <br><small class="text-muted">Edit your personal information</small>
                    </a>
                    
                    <a href="contact_support.php" class="quick-action-btn">
                        <i class="fas fa-headset text-warning"></i> 
                        <strong>Contact Support</strong>
                        <br><small class="text-muted">Get help or ask questions</small>
                    </a>

                    <a href="patient_billing.php" class="quick-action-btn">
                        <i class="fas fa-file-invoice-dollar text-warning"></i> 
                        <strong>Billing History</strong>
                        <br><small class="text-muted">View your bills and payment history</small>
                    </a>
                </div>
            </div>
            
            <!-- Middle Column - Appointments & Lab Results -->
            <div class="col-md-6">
                <!-- Upcoming Appointments -->
                <div class="info-card">
                    <h5><i class="fas fa-calendar-check"></i> Upcoming Appointments</h5>
                    
                    <?php if($appointments && mysqli_num_rows($appointments) > 0): ?>
                        <?php while($apt = mysqli_fetch_assoc($appointments)): ?>
                            <div class="appointment-item">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="mb-0">
                                        <?php echo date('l, d M Y', strtotime($apt['appointment_date'])); ?>
                                    </h6>
                                    <span class="badge-status badge-scheduled">
                                        <?php echo date('h:i A', strtotime($apt['appointment_time'])); ?>
                                    </span>
                                </div>
                                <p class="mb-1">
                                    <i class="fas fa-user-md"></i> Dr. <?php echo htmlspecialchars($apt['doctor_name']); ?>
                                    <small class="text-muted">(<?php echo htmlspecialchars($apt['department']); ?>)</small>
                                </p>
                                <p class="mb-0 text-muted">
                                    <small><i class="fas fa-notes-medical"></i> <?php echo htmlspecialchars($apt['reason']); ?></small>
                                </p>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No upcoming appointments</p>
                    <?php endif; ?>
                </div>
                
                <!-- Recent Lab Results -->
                <div class="info-card">
                    <h5><i class="fas fa-flask"></i> Recent Lab Results</h5>
                    
                    <?php if($lab_results && mysqli_num_rows($lab_results) > 0): ?>
                        <?php while($lab = mysqli_fetch_assoc($lab_results)): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between">
                                    <strong><?php echo htmlspecialchars($lab['test_name']); ?></strong>
                                    <small class="text-muted"><?php echo date('d M Y', strtotime($lab['result_date'])); ?></small>
                                </div>
                                <p class="mb-1">
                                    Result: <strong><?php echo htmlspecialchars($lab['result_value'] . ' ' . $lab['unit']); ?></strong>
                                </p>
                                <small class="text-muted">Normal Range: <?php echo htmlspecialchars($lab['normal_range']); ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No lab results available</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column - Prescriptions & Billing -->
            <div class="col-md-3">
                <!-- Recent Prescriptions -->
                <div class="info-card">
                    <h5><i class="fas fa-prescription"></i> Recent Prescriptions</h5>
                    
                    <?php if($prescriptions && mysqli_num_rows($prescriptions) > 0): ?>
                        <?php while($pres = mysqli_fetch_assoc($prescriptions)): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between">
                                    <strong><?php echo date('d M Y', strtotime($pres['prescription_date'])); ?></strong>
                                    <span class="badge bg-<?php echo $pres['status'] == 'dispensed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($pres['status']); ?>
                                    </span>
                                </div>
                                <p class="mb-1">Dr. <?php echo htmlspecialchars($pres['doctor_name']); ?></p>
                                <p class="mb-0"><small><?php echo htmlspecialchars($pres['diagnosis']); ?></small></p>
                                <?php if(isset($prescription_items[$pres['prescription_id']])): ?>
                                    <small class="text-muted">
                                        <?php echo count($prescription_items[$pres['prescription_id']]); ?> medication(s)
                                    </small>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No prescriptions</p>
                    <?php endif; ?>
                </div>
                
                <!-- Recent Bills -->
                <div class="info-card">
                    <h5><i class="fas fa-file-invoice"></i> Recent Bills</h5>
                    
                    <?php if($bills && mysqli_num_rows($bills) > 0): ?>
                        <?php while($bill = mysqli_fetch_assoc($bills)): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between">
                                    <strong>#<?php echo htmlspecialchars($bill['bill_number']); ?></strong>
                                    <span class="badge bg-<?php echo $bill['payment_status'] == 'paid' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($bill['payment_status']); ?>
                                    </span>
                                </div>
                                <p class="mb-1">Amount: <strong><?php echo format_currency($bill['net_amount']); ?></strong></p>
                                <small class="text-muted"><?php echo date('d M Y', strtotime($bill['bill_date'])); ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No billing history</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Book Appointment Modal -->
    <div class="modal fade" id="bookAppointmentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-calendar-plus"></i> Book New Appointment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="appointmentForm">
                    <div class="modal-body">
                        <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Select Doctor *</label>
                                <select class="form-control" name="doctor_id" id="doctorSelect" required>
                                    <option value="">Choose a doctor</option>
                                    <?php while($doc = mysqli_fetch_assoc($doctors)): ?>
                                        <option value="<?php echo $doc['user_id']; ?>">
                                            Dr. <?php echo htmlspecialchars($doc['full_name']); ?> (<?php echo htmlspecialchars($doc['department']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date *</label>
                                <input type="date" class="form-control" name="appointment_date" 
                                       id="appointmentDate"
                                       min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" 
                                       max="<?php echo date('Y-m-d', strtotime('+3 months')); ?>" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Preferred Time *</label>
                                <select class="form-control" name="appointment_time" id="timeSelect" required>
                                    <option value="">Select time</option>
                                    <option value="09:00:00">09:00 AM</option>
                                    <option value="10:00:00">10:00 AM</option>
                                    <option value="11:00:00">11:00 AM</option>
                                    <option value="14:00:00">02:00 PM</option>
                                    <option value="15:00:00">03:00 PM</option>
                                    <option value="16:00:00">04:00 PM</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Reason for Visit *</label>
                                <input type="text" class="form-control" name="reason" 
                                       placeholder="e.g., Checkup, Consultation, Follow-up" required>
                            </div>
                        </div>
                        
                        <div class="alert alert-info" id="availabilityMessage" style="display: none;"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Book Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Check availability when doctor and date are selected
        $('#doctorSelect, #appointmentDate').change(function() {
            const doctorId = $('#doctorSelect').val();
            const date = $('#appointmentDate').val();
            
            if (doctorId && date) {
                $.ajax({
                    url: 'check_availability.php',
                    method: 'POST',
                    data: { doctor_id: doctorId, date: date },
                    dataType: 'json',
                    success: function(bookedSlots) {
                        // Reset all time options
                        $('#timeSelect option').each(function() {
                            $(this).prop('disabled', false);
                        });
                        
                        // Disable booked slots
                        bookedSlots.forEach(function(time) {
                            $('#timeSelect option[value="' + time + '"]').prop('disabled', true);
                        });
                        
                        if (bookedSlots.length > 0) {
                            $('#availabilityMessage').html(
                                '<i class="fas fa-info-circle"></i> ' + 
                                bookedSlots.length + ' time slot(s) already booked for this date'
                            ).show();
                        } else {
                            $('#availabilityMessage').hide();
                        }
                    }
                });
            }
        });
        
        // Handle form submission
        $('#appointmentForm').submit(function(e) {
            e.preventDefault();
            
            const submitBtn = $(this).find('button[type="submit"]');
            submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Booking...').prop('disabled', true);
            
            $.ajax({
                url: 'patient_portal.php',
                method: 'POST',
                data: $(this).serialize() + '&book_appointment=true',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('Appointment booked successfully!');
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                        submitBtn.html('Book Appointment').prop('disabled', false);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                    submitBtn.html('Book Appointment').prop('disabled', false);
                }
            });
        });
    </script>
</body>
</html>
