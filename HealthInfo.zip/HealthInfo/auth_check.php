<?php
// Authentication check for staff pages
function requireStaffLogin() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = "Please login to access this page";
        header("Location: login.php");
        exit();
    }
}

// Authentication check for patient portal
function requirePatientLogin() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['patient_id'])) {
        header("Location: patient_portal.php");
        exit();
    }
}

// Check if user has specific role
function hasRole($role) {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] == $role;
}

// Redirect if not authorized
function requireRole($role) {
    requireStaffLogin();
    if (!hasRole($role) && $_SESSION['user_type'] != 'admin') {
        $_SESSION['error'] = "You don't have permission to access this page";
        header("Location: " . getRoleHomePage());
        exit();
    }
}

// Allow one of many roles (admin always allowed)
function requireAnyRole($roles) {
    requireStaffLogin();
    $user_type = $_SESSION['user_type'] ?? '';
    if ($user_type === 'admin') {
        return;
    }
    if (!is_array($roles)) {
        $roles = [$roles];
    }
    if (!in_array($user_type, $roles, true)) {
        $_SESSION['error'] = "You don't have permission to access this page";
        header("Location: " . getRoleHomePage());
        exit();
    }
}

// Inventory access control.
// Rules:
// - admin always allowed
// - if no explicit grants exist, fallback allows pharmacist (for backward compatibility)
// - once grants exist, only granted users can view/edit
function canAccessInventory($need_edit = false) {
    if (!isset($_SESSION['user_id'])) return false;

    $user_id = (int)$_SESSION['user_id'];
    $user_type = $_SESSION['user_type'] ?? '';
    if ($user_type === 'admin') return true;

    $conn = getConnection();
    $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'inventory_user_access'");
    if (!$table_exists || mysqli_num_rows($table_exists) === 0) {
        return $user_type === 'pharmacist';
    }

    $total_grants_rs = mysqli_query($conn, "SELECT COUNT(*) AS c FROM inventory_user_access");
    $total_grants = $total_grants_rs ? (int)(mysqli_fetch_assoc($total_grants_rs)['c'] ?? 0) : 0;
    if ($total_grants === 0) {
        return $user_type === 'pharmacist';
    }

    $rs = mysqli_query(
        $conn,
        "SELECT can_view, can_edit
         FROM inventory_user_access
         WHERE user_id = $user_id
         LIMIT 1"
    );
    if (!$rs || mysqli_num_rows($rs) === 0) return false;
    $row = mysqli_fetch_assoc($rs);
    $can_view = ((int)($row['can_view'] ?? 0) === 1);
    $can_edit = ((int)($row['can_edit'] ?? 0) === 1);

    if ($need_edit) return $can_edit;
    return $can_view || $can_edit;
}

function requireInventoryAccess($need_edit = false) {
    requireStaffLogin();
    if (!canAccessInventory($need_edit)) {
        $_SESSION['error'] = $need_edit
            ? "You don't have permission to update inventory"
            : "You don't have permission to access inventory";
        header("Location: " . getRoleHomePage());
        exit();
    }
}
?>
