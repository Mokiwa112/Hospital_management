<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();

// Handle report generation
if (isset($_POST['generate_report'])) {
    $report_type = sanitize($_POST['report_type']);
    $date_from = sanitize($_POST['date_from']);
    $date_to = sanitize($_POST['date_to']);
    $format = sanitize($_POST['format'] ?? 'html');
    
    $report_name = $report_type . '_' . date('Ymd_His');
    $params = json_encode(['date_from' => $date_from, 'date_to' => $date_to]);
    
    // Save report record if reports table exists
    $report_id = 0;
    if (tableHasColumn('reports', 'report_id')) {
        $query = "INSERT INTO reports (report_name, report_type, parameters, generated_by) 
                  VALUES ('$report_name', '$report_type', '$params', {$_SESSION['user_id']})";
        mysqli_query($conn, $query);
        $report_id = mysqli_insert_id($conn);
    }
    
    // Generate report based on type
    generateReport($report_type, $date_from, $date_to, $format, $report_id);
}

function generateReport($type, $from, $to, $format, $report_id) {
    global $conn;
    
    $data = [];
    
    switch($type) {
        case 'patient':
            $query = "SELECT * FROM patients WHERE registration_date BETWEEN '$from' AND '$to' ORDER BY registration_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Patient Registration Report';
            $data['headers'] = ['Patient #', 'Name', 'Type', 'Registration Date', 'Contact', 'Insurance'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['patient_number'],
                    $row['first_name'] . ' ' . $row['last_name'],
                    $row['patient_type'],
                    date('d-m-Y', strtotime($row['registration_date'])),
                    $row['phone'],
                    $row['insurance_policy_number'] ?: 'None'
                ];
            }
            break;
            
        case 'appointment':
            $query = "SELECT a.*, p.first_name, p.last_name, p.patient_number, u.full_name as doctor_name 
                     FROM appointments a
                     JOIN patients p ON a.patient_id = p.patient_id
                     JOIN users u ON a.doctor_id = u.user_id
                     WHERE a.appointment_date BETWEEN '$from' AND '$to'
                     ORDER BY a.appointment_date, a.appointment_time";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Appointments Report';
            $data['headers'] = ['Date', 'Time', 'Patient', 'Doctor', 'Status', 'Reason'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    date('d-m-Y', strtotime($row['appointment_date'])),
                    date('h:i A', strtotime($row['appointment_time'])),
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    'Dr. ' . $row['doctor_name'],
                    $row['status'],
                    $row['reason']
                ];
            }
            break;
            
        case 'billing':
            $query = "SELECT b.*, p.first_name, p.last_name, p.patient_number 
                     FROM billing b
                     JOIN patients p ON b.patient_id = p.patient_id
                     WHERE b.bill_date BETWEEN '$from' AND '$to'
                     ORDER BY b.bill_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Billing Report';
            $data['headers'] = ['Bill #', 'Patient', 'Date', 'Total', 'Discount', 'Net', 'Status'];
            $data['rows'] = [];
            $total_amount = 0;
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['bill_number'],
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    date('d-m-Y', strtotime($row['bill_date'])),
                    format_currency($row['total_amount']),
                    format_currency($row['discount']),
                    format_currency($row['net_amount']),
                    $row['payment_status']
                ];
                $total_amount += $row['net_amount'];
            }
            $data['summary'] = ['Total Revenue: ' . format_currency($total_amount)];
            break;
            
        case 'inventory':
            $query = "SELECT * FROM inventory_items ORDER BY category, item_name";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Inventory Status Report';
            $data['headers'] = ['Item Code', 'Item Name', 'Category', 'Quantity', 'Unit', 'Reorder Level', 'Unit Price', 'Expiry Date'];
            $data['rows'] = [];
            $total_value = 0;
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['item_code'],
                    $row['item_name'],
                    $row['category'],
                    $row['quantity'],
                    $row['unit'],
                    $row['reorder_level'],
                    format_currency($row['unit_price']),
                    $row['expiry_date'] ? date('d-m-Y', strtotime($row['expiry_date'])) : 'N/A'
                ];
                $total_value += $row['quantity'] * $row['unit_price'];
            }
            $data['summary'] = ['Total Inventory Value: ' . format_currency($total_value)];
            break;
            
        case 'lab':
            $query = "SELECT lr.*, p.first_name, p.last_name, p.patient_number, lt.test_name, u.full_name as doctor_name 
                     FROM lab_requests lr
                     JOIN patients p ON lr.patient_id = p.patient_id
                     JOIN lab_tests lt ON lr.test_id = lt.test_id
                     JOIN users u ON lr.doctor_id = u.user_id
                     WHERE lr.request_date BETWEEN '$from' AND '$to'
                     ORDER BY lr.request_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Laboratory Report';
            $data['headers'] = ['Request #', 'Date', 'Patient', 'Test', 'Doctor', 'Status', 'Result'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['request_number'],
                    date('d-m-Y H:i', strtotime($row['request_date'])),
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    $row['test_name'],
                    'Dr. ' . $row['doctor_name'],
                    $row['status'],
                    $row['result_value'] ?: 'Pending'
                ];
            }
            break;
            
        case 'worker':
            $query = "SELECT u.*, COUNT(DISTINCT a.appointment_id) as appointments,
                     COUNT(DISTINCT lr.request_id) as lab_requests
                     FROM users u
                     LEFT JOIN appointments a ON u.user_id = a.doctor_id AND a.appointment_date BETWEEN '$from' AND '$to'
                     LEFT JOIN lab_requests lr ON u.user_id = lr.doctor_id AND lr.request_date BETWEEN '$from' AND '$to'
                     GROUP BY u.user_id
                     ORDER BY u.user_type, u.full_name";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Worker Performance Report';
            $data['headers'] = ['Employee ID', 'Name', 'Type', 'Department', 'Appointments', 'Lab Requests', 'Contact'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['employee_id'],
                    $row['full_name'],
                    ucfirst($row['user_type']),
                    $row['department'] ?: 'N/A',
                    $row['appointments'],
                    $row['lab_requests'],
                    $row['phone']
                ];
            }
            break;
    }
    
    // Output based on format
    if ($format == 'pdf') {
        generatePDF($data, $report_id);
    } elseif ($format == 'excel') {
        generateExcel($data, $report_id);
    } else {
        // HTML output
        displayReportHTML($data);
    }
}

function displayReportHTML($data) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title><?php echo $data['title']; ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            @media print {
                .no-print { display: none; }
                body { font-size: 12pt; }
            }
            .report-header {
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 2px solid #333;
            }
            .summary-box {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 5px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="container mt-4">
            <div class="no-print mb-3">
                <button onclick="window.print()" class="btn btn-primary">
                    <i class="fas fa-print"></i> Print
                </button>
                <button onclick="window.close()" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
            
            <div class="report-header">
                <h2><?php echo SITE_NAME; ?></h2>
                <h3><?php echo $data['title']; ?></h3>
                <p>Generated on: <?php echo date('d-m-Y H:i:s'); ?></p>
            </div>
            
            <?php if(isset($data['summary'])): ?>
                <div class="summary-box">
                    <h5>Summary</h5>
                    <?php foreach($data['summary'] as $summary): ?>
                        <p class="mb-1"><?php echo $summary; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <?php foreach($data['headers'] as $header): ?>
                            <th><?php echo $header; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data['rows'] as $row): ?>
                        <tr>
                            <?php foreach($row as $cell): ?>
                                <td><?php echo $cell; ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="text-muted mt-3">
                <small>Total Records: <?php echo count($data['rows']); ?></small>
            </div>
        </div>
        
        <script src="https://kit.fontawesome.com/your-code.js"></script>
    </body>
    </html>
    <?php
    exit();
}

function generatePDF($data, $report_id) {
    // You'll need to include a PDF library like TCPDF or FPDF
    // For now, we'll redirect to HTML print version
    displayReportHTML($data);
}

function generateExcel($data, $report_id) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="report_' . $report_id . '.xls"');
    
    echo '<html>';
    echo '<head><meta charset="UTF-8"></head>';
    echo '<body>';
    echo '<table border="1">';
    
    // Headers
    echo '<tr>';
    foreach($data['headers'] as $header) {
        echo '<th>' . $header . '</th>';
    }
    echo '</tr>';
    
    // Data
    foreach($data['rows'] as $row) {
        echo '<tr>';
        foreach($row as $cell) {
            echo '<td>' . $cell . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</table>';
    echo '</body>';
    echo '</html>';
    exit();
}

// Fetch existing reports when reports table exists
$reports = false;
if (tableHasColumn('reports', 'report_id')) {
    $reports = mysqli_query($conn, 
        "SELECT r.*, u.full_name as generated_by_name 
         FROM reports r
         JOIN users u ON r.generated_by = u.user_id
         ORDER BY r.generated_at DESC"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-4">
                <!-- Report Generation Form -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-chart-bar"></i> Generate Report</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Report Type *</label>
                                <select class="form-control" name="report_type" required>
                                    <option value="">Select Report Type</option>
                                    <option value="patient">Patient Registration Report</option>
                                    <option value="appointment">Appointments Report</option>
                                    <option value="billing">Billing Report</option>
                                    <option value="inventory">Inventory Status Report</option>
                                    <option value="lab">Laboratory Report</option>
                                    <option value="worker">Worker Performance Report</option>
                                </select>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date From *</label>
                                    <input type="date" class="form-control" name="date_from" 
                                           value="<?php echo date('Y-m-01'); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date To *</label>
                                    <input type="date" class="form-control" name="date_to" 
                                           value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Output Format</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="format" value="html" checked>
                                    <label class="form-check-label">HTML (View in Browser)</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="format" value="excel">
                                    <label class="form-check-label">Excel (Download)</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="format" value="pdf">
                                    <label class="form-check-label">PDF (Download)</label>
                                </div>
                            </div>
                            
                            <button type="submit" name="generate_report" class="btn btn-primary w-100">
                                <i class="fas fa-file-export"></i> Generate Report
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Quick Reports -->
                <div class="card mt-3">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-bolt"></i> Quick Reports</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <a href="?quick=today_appointments" class="list-group-item list-group-item-action">
                                <i class="fas fa-calendar-day"></i> Today's Appointments
                            </a>
                            <a href="?quick=low_stock" class="list-group-item list-group-item-action">
                                <i class="fas fa-exclamation-triangle"></i> Low Stock Items
                            </a>
                            <a href="?quick=pending_lab" class="list-group-item list-group-item-action">
                                <i class="fas fa-flask"></i> Pending Lab Tests
                            </a>
                            <a href="?quick=unpaid_bills" class="list-group-item list-group-item-action">
                                <i class="fas fa-money-bill"></i> Unpaid Bills
                            </a>
                            <a href="?quick=worker_attendance" class="list-group-item list-group-item-action">
                                <i class="fas fa-clock"></i> Today's Attendance
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <!-- Report History -->
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-history"></i> Report History</h5>
                    </div>
                    <div class="card-body">
                        <table id="reportsTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Report Name</th>
                                    <th>Type</th>
                                    <th>Generated By</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($reports && mysqli_num_rows($reports) > 0): ?>
                                    <?php while($report = mysqli_fetch_assoc($reports)): ?>
                                        <tr>
                                            <td><?php echo $report['report_name']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $report['report_type'] == 'patient' ? 'primary' : 
                                                        ($report['report_type'] == 'billing' ? 'success' : 
                                                        ($report['report_type'] == 'inventory' ? 'warning' : 'info')); 
                                                ?>">
                                                    <?php echo ucfirst($report['report_type']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo $report['generated_by_name']; ?></td>
                                            <td><?php echo date('d-m-Y H:i', strtotime($report['generated_at'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-info" onclick="viewReport(<?php echo $report['report_id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-success" onclick="downloadReport(<?php echo $report['report_id']; ?>, 'excel')">
                                                    <i class="fas fa-file-excel"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger" onclick="downloadReport(<?php echo $report['report_id']; ?>, 'pdf')">
                                                    <i class="fas fa-file-pdf"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">No saved reports yet</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#reportsTable').DataTable({
                order: [[3, 'desc']],
                pageLength: 10
            });
        });
        
        function viewReport(id) {
            window.open('view_report.php?id=' + id, '_blank');
        }
        
        function downloadReport(id, format) {
            window.location.href = 'download_report.php?id=' + id + '&format=' + format;
        }
    </script>
</body>
</html>
