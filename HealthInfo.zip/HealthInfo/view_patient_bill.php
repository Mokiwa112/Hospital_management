<?php
require_once 'config.php';

if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_portal.php");
    exit();
}

$conn = getConnection();
$patient_id = (int)$_SESSION['patient_id'];
$bill_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_notes = tableHasColumn('billing', 'notes');

if ($bill_id <= 0) {
    $_SESSION['error'] = "Invalid bill reference";
    header("Location: patient_billing.php");
    exit();
}

$query = "SELECT b.*, p.first_name, p.last_name, p.patient_number, p.address, p.phone
          FROM billing b
          JOIN patients p ON b.patient_id = p.patient_id
          WHERE b.bill_id = $bill_id AND b.patient_id = $patient_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    $_SESSION['error'] = "Bill not found";
    header("Location: patient_billing.php");
    exit();
}

$bill = mysqli_fetch_assoc($result);
$items_result = mysqli_query($conn, "SELECT * FROM billing_items WHERE bill_id = $bill_id ORDER BY billing_item_id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bill #<?php echo htmlspecialchars($bill['bill_number']); ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-file-invoice"></i> Bill Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <button type="button" onclick="window.print()" class="btn btn-primary">
                    <i class="fas fa-print"></i> Print Bill
                </button>
                <a href="patient_billing.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Bill Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Bill Number:</strong><br>
                        <?php echo htmlspecialchars($bill['bill_number']); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Bill Date:</strong><br>
                        <?php echo date('d-m-Y h:i A', strtotime($bill['bill_date'])); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Payment Status:</strong><br>
                        <span class="badge bg-<?php echo $bill['payment_status'] === 'paid' ? 'success' : 'warning'; ?>">
                            <?php echo ucfirst($bill['payment_status']); ?>
                        </span>
                    </div>
                    <div class="col-md-3">
                        <strong>Payment Method:</strong><br>
                        <?php echo !empty($bill['payment_method']) ? ucfirst($bill['payment_method']) : 'Not specified'; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Patient Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Name:</strong><br>
                        <?php echo htmlspecialchars($bill['first_name'] . ' ' . $bill['last_name']); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Patient #:</strong><br>
                        <?php echo htmlspecialchars($bill['patient_number']); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Phone:</strong><br>
                        <?php echo htmlspecialchars($bill['phone']); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Address:</strong><br>
                        <?php echo !empty($bill['address']) ? htmlspecialchars($bill['address']) : 'N/A'; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Bill Items</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $subtotal = 0.0;
                            while ($item = mysqli_fetch_assoc($items_result)):
                                $line_total = ((float)$item['quantity']) * ((float)$item['unit_price']);
                                $subtotal += $line_total;
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['description']); ?></td>
                                <td><?php echo ucfirst(str_replace('_', ' ', $item['item_type'])); ?></td>
                                <td><?php echo (int)$item['quantity']; ?></td>
                                <td><?php echo format_currency($item['unit_price']); ?></td>
                                <td><?php echo format_currency($line_total); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="4" class="text-end">Subtotal:</th>
                                <th><?php echo format_currency($subtotal); ?></th>
                            </tr>
                            <?php if ((float)$bill['discount'] > 0): ?>
                            <tr>
                                <th colspan="4" class="text-end">Discount:</th>
                                <th>-<?php echo format_currency($bill['discount']); ?></th>
                            </tr>
                            <?php endif; ?>
                            <?php if ((float)$bill['tax'] > 0): ?>
                            <tr>
                                <th colspan="4" class="text-end">Tax:</th>
                                <th>+<?php echo format_currency($bill['tax']); ?></th>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th colspan="4" class="text-end">Total Amount:</th>
                                <th class="text-success"><?php echo format_currency($bill['net_amount']); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <?php if ($has_notes && !empty($bill['notes'])): ?>
                <div class="mt-3">
                    <strong>Notes:</strong>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($bill['notes'])); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
