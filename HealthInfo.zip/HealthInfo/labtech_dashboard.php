<?php
require_once 'config.php';
requireRole('lab_tech');

$conn = getConnection();
$labtech_id = $_SESSION['user_id'];

// Get pending lab requests
$pending_requests = mysqli_query($conn,
    "SELECT lr.*, p.first_name, p.last_name, p.patient_number, 
            lt.test_name, lt.normal_range, lt.unit,
            u.full_name as doctor_name
     FROM lab_requests lr
     JOIN patients p ON lr.patient_id = p.patient_id
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     JOIN users u ON lr.doctor_id = u.user_id
     WHERE lr.status = 'pending'
     ORDER BY lr.request_date"
);

// Get samples to collect
$samples_to_collect = mysqli_query($conn,
    "SELECT lr.*, p.first_name, p.last_name, p.patient_number, lt.test_name
     FROM lab_requests lr
     JOIN patients p ON lr.patient_id = p.patient_id
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.status = 'pending' 
     AND lr.sample_collected_date IS NULL"
);

// Get processing requests
$processing = mysqli_query($conn,
    "SELECT lr.*, p.first_name, p.last_name, p.patient_number, lt.test_name
     FROM lab_requests lr
     JOIN patients p ON lr.patient_id = p.patient_id
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.status = 'processing' 
     AND lr.lab_tech_id = $labtech_id"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Technician Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-flask"></i> Lab Technician Dashboard</h2>
        <p>Welcome, <?php echo $_SESSION['full_name']; ?></p>
        
        <div class="row">
            <!-- Samples to Collect -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-syringe"></i> Samples to Collect</h5>
                        <span class="badge bg-light text-dark"><?php echo mysqli_num_rows($samples_to_collect); ?></span>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($samples_to_collect) > 0): ?>
                            <div class="list-group">
                                <?php while($sample = mysqli_fetch_assoc($samples_to_collect)): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo $sample['patient_number']; ?></strong>
                                            <small><?php echo date('h:i A', strtotime($sample['request_date'])); ?></small>
                                        </div>
                                        <p><?php echo $sample['first_name'] . ' ' . $sample['last_name']; ?></p>
                                        <p><strong>Test:</strong> <?php echo $sample['test_name']; ?></p>
                                        <button class="btn btn-sm btn-success" onclick="collectSample(<?php echo $sample['request_id']; ?>)">
                                            <i class="fas fa-check"></i> Sample Collected
                                        </button>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No samples to collect</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Pending Lab Requests -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5><i class="fas fa-clock"></i> Pending Tests</h5>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($pending_requests) > 0): ?>
                            <div class="list-group">
                                <?php while($req = mysqli_fetch_assoc($pending_requests)): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo $req['patient_number']; ?></strong>
                                            <small>Dr. <?php echo $req['doctor_name']; ?></small>
                                        </div>
                                        <p><?php echo $req['first_name'] . ' ' . $req['last_name']; ?></p>
                                        <p><strong>Test:</strong> <?php echo $req['test_name']; ?></p>
                                        <button class="btn btn-sm btn-primary" onclick="startTest(<?php echo $req['request_id']; ?>)">
                                            <i class="fas fa-play"></i> Start Processing
                                        </button>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No pending tests</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Currently Processing -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-cogs"></i> Currently Processing</h5>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($processing) > 0): ?>
                            <div class="list-group">
                                <?php while($proc = mysqli_fetch_assoc($processing)): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo $proc['patient_number']; ?></strong>
                                            <small><?php echo $proc['test_name']; ?></small>
                                        </div>
                                        <p><?php echo $proc['first_name'] . ' ' . $proc['last_name']; ?></p>
                                        <button class="btn btn-sm btn-success" onclick="addResult(<?php echo $proc['request_id']; ?>)">
                                            <i class="fas fa-pen"></i> Add Result
                                        </button>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No tests in progress</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function collectSample(id) {
            window.location.href = 'collect_sample.php?id=' + id;
        }
        
        function startTest(id) {
            window.location.href = 'collect_sample.php?id=' + id;
        }
        
        function addResult(id) {
            window.location.href = 'add_lab_result.php?id=' + id;
        }
    </script>
</body>
</html>
