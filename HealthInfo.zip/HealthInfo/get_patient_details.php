<?php
require_once 'config.php';

if (isset($_POST['patient_id'])) {
    $patient_id = sanitize($_POST['patient_id']);
    $conn = getConnection();
    
    $query = "SELECT p.*, ip.provider_name, ip.coverage_percentage 
              FROM patients p
              LEFT JOIN insurance_providers ip ON p.insurance_provider_id = ip.provider_id
              WHERE p.patient_id = $patient_id";
    $result = mysqli_query($conn, $query);
    
    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode($row);
    }
    
    mysqli_close($conn);
}
?>