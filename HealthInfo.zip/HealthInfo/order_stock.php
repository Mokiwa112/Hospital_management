<?php
require_once 'config.php';
requireInventoryAccess(true);

$conn = getConnection();
$item_id = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;
$user_id = (int)$_SESSION['user_id'];

if ($item_id <= 0) {
    $_SESSION['error'] = "Invalid inventory item";
    redirect('inventory.php');
}

$item_result = mysqli_query($conn, "SELECT * FROM inventory_items WHERE item_id = $item_id");
if (!$item_result || mysqli_num_rows($item_result) === 0) {
    $_SESSION['error'] = "Inventory item not found";
    redirect('inventory.php');
}
$item = mysqli_fetch_assoc($item_result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $quantity = max(1, (int)($_POST['quantity'] ?? 0));
    $notes = sanitize($_POST['notes'] ?? '');

    mysqli_begin_transaction($conn);
    try {
        mysqli_query($conn, "UPDATE inventory_items SET quantity = quantity + $quantity WHERE item_id = $item_id");
        mysqli_query(
            $conn,
            "INSERT INTO inventory_transactions (item_id, transaction_type, quantity, performed_by, notes)
             VALUES ($item_id, 'stock_in', $quantity, $user_id, '$notes')"
        );
        mysqli_commit($conn);
        $_SESSION['success'] = "Stock order recorded successfully";
        redirect('inventory.php');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error = "Failed to record stock order";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Stock - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-shopping-cart"></i> Record Stock Order</h5>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <p><strong>Item:</strong> <?php echo htmlspecialchars($item['item_name']); ?> (<?php echo htmlspecialchars($item['item_code']); ?>)</p>
                <p><strong>Current Quantity:</strong> <?php echo (int)$item['quantity']; ?> <?php echo htmlspecialchars($item['unit']); ?></p>
                <p><strong>Reorder Level:</strong> <?php echo (int)$item['reorder_level']; ?></p>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Order Quantity *</label>
                        <input type="number" name="quantity" class="form-control" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" class="form-control" rows="3" placeholder="Supplier / purchase reference"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                    <a href="inventory.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
