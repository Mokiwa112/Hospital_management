<?php
require_once 'config.php';

// Check if user is logged in and is doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'doctor') {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($request_id == 0) {
    header("Location: doctor_dashboard.php");
    exit();
}

if (tableHasColumn('lab_requests', 'approved_by_doctor')) {
    $updates = ["approved_by_doctor = 1"];
    if (tableHasColumn('lab_requests', 'doctor_approval_date')) {
        $updates[] = "doctor_approval_date = NOW()";
    }
    $query = "UPDATE lab_requests SET 
              " . implode(', ', $updates) . "
              WHERE request_id = $request_id AND doctor_id = $doctor_id";
} else {
    $query = "UPDATE lab_requests SET request_id = request_id WHERE request_id = $request_id AND doctor_id = $doctor_id";
}

mysqli_query($conn, $query);

header("Location: doctor_dashboard.php");
exit();
?>
