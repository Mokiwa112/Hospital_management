<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();
$admin_id = (int)($_SESSION['user_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign_shift'])) {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $shift_id = (int)($_POST['shift_id'] ?? 0);
        $start_date = sanitize($_POST['start_date'] ?? '');
        $end_date = sanitize($_POST['end_date'] ?? '');
        $notes = sanitize($_POST['notes'] ?? '');

        if ($user_id <= 0 || $shift_id <= 0 || empty($start_date) || empty($end_date)) {
            $_SESSION['error'] = "Please fill all required fields";
            redirect('shift_management.php');
        }
        if ($end_date < $start_date) {
            $_SESSION['error'] = "End date cannot be before start date";
            redirect('shift_management.php');
        }

        $days = ((strtotime($end_date) - strtotime($start_date)) / 86400) + 1;
        if ($days > 60) {
            $_SESSION['error'] = "Date range is too large. Maximum is 60 days per assignment.";
            redirect('shift_management.php');
        }

        $current = strtotime($start_date);
        $end = strtotime($end_date);
        $count = 0;
        while ($current <= $end) {
            $shift_date = date('Y-m-d', $current);
            $query = "INSERT INTO user_shift_assignments (user_id, shift_id, shift_date, assigned_by, notes)
                      VALUES ($user_id, $shift_id, '$shift_date', $admin_id, '$notes')
                      ON DUPLICATE KEY UPDATE
                        shift_id = VALUES(shift_id),
                        assigned_by = VALUES(assigned_by),
                        notes = VALUES(notes)";
            if (mysqli_query($conn, $query)) {
                $count++;
            }
            $current = strtotime('+1 day', $current);
        }
        $_SESSION['success'] = "Shift assigned for $count day(s).";
        app_log_action($admin_id, 'shift_assign');
        redirect('shift_management.php');
    }

    if (isset($_POST['delete_assignment'])) {
        $assignment_id = (int)($_POST['assignment_id'] ?? 0);
        if ($assignment_id > 0) {
            mysqli_query($conn, "DELETE FROM user_shift_assignments WHERE assignment_id = $assignment_id");
            $_SESSION['success'] = "Shift assignment removed";
            app_log_action($admin_id, 'shift_delete');
        }
        redirect('shift_management.php');
    }
}

$workers = mysqli_query(
    $conn,
    "SELECT user_id, full_name, employee_id, user_type, department
     FROM users
     WHERE user_type <> 'admin'
     ORDER BY full_name"
);

$shifts = mysqli_query(
    $conn,
    "SELECT shift_id, shift_name, shift_code, start_time, end_time, is_overnight
     FROM shift_definitions
     WHERE is_active = 1
     ORDER BY shift_id"
);

$assignments = mysqli_query(
    $conn,
    "SELECT usa.assignment_id, usa.shift_date, usa.notes, usa.created_at,
            u.full_name, u.employee_id, u.department,
            sd.shift_name, sd.shift_code, sd.start_time, sd.end_time, sd.is_overnight,
            a.full_name AS assigned_by_name
     FROM user_shift_assignments usa
     JOIN users u ON u.user_id = usa.user_id
     JOIN shift_definitions sd ON sd.shift_id = usa.shift_id
     LEFT JOIN users a ON a.user_id = usa.assigned_by
     WHERE usa.shift_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
     ORDER BY usa.shift_date DESC, sd.shift_id, u.full_name"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Management - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .shift-badge { font-size: 12px; padding: 6px 10px; }
        .shift-card { border-radius: 10px; border: 1px solid #e5e5e5; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid mt-4">
    <div class="row mb-3">
        <div class="col-md-8">
            <h3><i class="fas fa-business-time"></i> Shift Management</h3>
            <p class="text-muted mb-0">Three 8-hour shifts: 06:00-14:00, 14:00-22:00, 22:00-06:00.</p>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <?php mysqli_data_seek($shifts, 0); while ($s = mysqli_fetch_assoc($shifts)): ?>
            <div class="col-md-4">
                <div class="card shift-card">
                    <div class="card-body">
                        <h5 class="mb-1"><?php echo htmlspecialchars($s['shift_name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($s['shift_code']); ?>)</small></h5>
                        <div>
                            <span class="badge bg-primary shift-badge"><?php echo substr($s['start_time'], 0, 5); ?> - <?php echo substr($s['end_time'], 0, 5); ?></span>
                            <?php if ((int)$s['is_overnight'] === 1): ?>
                                <span class="badge bg-dark shift-badge">Overnight</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plus-circle"></i> Assign Shift</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Worker *</label>
                            <select class="form-select" name="user_id" required>
                                <option value="">Select worker</option>
                                <?php while ($w = mysqli_fetch_assoc($workers)): ?>
                                    <option value="<?php echo (int)$w['user_id']; ?>">
                                        <?php echo htmlspecialchars($w['full_name']); ?> (<?php echo htmlspecialchars($w['employee_id'] ?: 'N/A'); ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Shift *</label>
                            <select class="form-select" name="shift_id" required>
                                <option value="">Select shift</option>
                                <?php mysqli_data_seek($shifts, 0); while ($s = mysqli_fetch_assoc($shifts)): ?>
                                    <option value="<?php echo (int)$s['shift_id']; ?>">
                                        <?php echo htmlspecialchars($s['shift_name']); ?> (<?php echo substr($s['start_time'], 0, 5); ?>-<?php echo substr($s['end_time'], 0, 5); ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Start Date *</label>
                                <input type="date" class="form-control" name="start_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">End Date *</label>
                                <input type="date" class="form-control" name="end_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="Optional note"></textarea>
                        </div>
                        <button type="submit" name="assign_shift" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> Save Assignment
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-list"></i> Shift Assignments (Last 7 days to next 30 days)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Employee</th>
                                    <th>Shift</th>
                                    <th>Notes</th>
                                    <th>Assigned By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($assignments && mysqli_num_rows($assignments) > 0): ?>
                                    <?php while ($a = mysqli_fetch_assoc($assignments)): ?>
                                        <tr>
                                            <td><?php echo date('d-m-Y', strtotime($a['shift_date'])); ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($a['full_name']); ?></strong><br>
                                                <small><?php echo htmlspecialchars($a['employee_id'] ?: 'N/A'); ?> | <?php echo htmlspecialchars($a['department'] ?: 'N/A'); ?></small>
                                            </td>
                                            <td>
                                                <span class="badge bg-primary"><?php echo htmlspecialchars($a['shift_code']); ?></span>
                                                <?php echo htmlspecialchars($a['shift_name']); ?><br>
                                                <small><?php echo substr($a['start_time'], 0, 5); ?>-<?php echo substr($a['end_time'], 0, 5); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($a['notes'] ?: '-'); ?></td>
                                            <td><?php echo htmlspecialchars($a['assigned_by_name'] ?: '-'); ?></td>
                                            <td>
                                                <form method="POST" onsubmit="return confirm('Delete this assignment?');">
                                                    <input type="hidden" name="assignment_id" value="<?php echo (int)$a['assignment_id']; ?>">
                                                    <button type="submit" name="delete_assignment" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" class="text-center">No assignments found</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
