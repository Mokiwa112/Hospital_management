<?php
require_once 'config.php';
requireRole('lab_tech');

$conn = getConnection();
$user_id = $_SESSION['user_id'];
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch lab request details
$query = "SELECT lr.*, p.first_name, p.last_name, p.patient_number,
          lt.test_name
          FROM lab_requests lr
          JOIN patients p ON lr.patient_id = p.patient_id
          JOIN lab_tests lt ON lr.test_id = lt.test_id
          WHERE lr.request_id = $request_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Lab request not found";
    header("Location: lab_requests_list.php");
    exit();
}

$lab = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $collection_notes = sanitize($_POST['collection_notes']);
    $sample_type = sanitize($_POST['sample_type'] ?? '');
    $container_type = sanitize($_POST['container_type'] ?? '');
    $volume_ml = sanitize($_POST['volume_ml'] ?? '');
    $priority = sanitize($_POST['priority'] ?? 'routine');
    $fasting_status = sanitize($_POST['fasting_status'] ?? 'unknown');
    $sample_condition = sanitize($_POST['sample_condition'] ?? 'good');
    $collection_site = sanitize($_POST['collection_site'] ?? '');
    $collected_at_raw = sanitize($_POST['collected_at'] ?? '');
    $collected_at = '';
    if (!empty($collected_at_raw)) {
        $collected_at = str_replace('T', ' ', $collected_at_raw) . ':00';
    }

    if ($sample_type === '' || $container_type === '') {
        $error = "Sample type and container are required";
    } else {
        $summary_parts = [];
        $summary_parts[] = "Sample Type: " . $sample_type;
        $summary_parts[] = "Container: " . $container_type;
        if ($volume_ml !== '') {
            $summary_parts[] = "Volume: " . $volume_ml . " ml";
        }
        $summary_parts[] = "Priority: " . $priority;
        $summary_parts[] = "Fasting: " . $fasting_status;
        $summary_parts[] = "Condition: " . $sample_condition;
        if ($collection_site !== '') {
            $summary_parts[] = "Collection Site: " . $collection_site;
        }
        if ($collection_notes !== '') {
            $summary_parts[] = "Notes: " . $collection_notes;
        }
        $collection_summary = sanitize(implode(' | ', $summary_parts));

        $updates = [];
        if (tableHasColumn('lab_requests', 'status')) {
            $updates[] = "status = 'processing'";
        }
        if (tableHasColumn('lab_requests', 'sample_collected_date')) {
            if ($collected_at !== '') {
                $updates[] = "sample_collected_date = '$collected_at'";
            } else {
                $updates[] = "sample_collected_date = NOW()";
            }
        }
        if (tableHasColumn('lab_requests', 'lab_tech_id')) {
            $updates[] = "lab_tech_id = $user_id";
        }
        $notes_column = firstExistingColumn('lab_requests', ['lab_notes', 'notes']);
        if ($notes_column !== null) {
            $updates[] = "$notes_column = CONCAT(IFNULL($notes_column, ''), '\nSample Collection: ', '$collection_summary')";
        }

        if (empty($updates)) {
            $updates[] = "request_id = request_id";
        }
        $update_query = "UPDATE lab_requests SET " . implode(', ', $updates) . " WHERE request_id = $request_id";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Sample collected successfully!";
            header("Location: view_lab_request.php?id=$request_id");
            exit();
        } else {
            $error = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collect Sample - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sample-card {
            max-width: 600px;
            margin: 50px auto;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .patient-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="sample-card">
            <div class="card-header bg-warning text-white">
                <h4 class="mb-0"><i class="fas fa-syringe"></i> Collect Sample</h4>
            </div>
            <div class="card-body">
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="patient-info">
                    <h5>Patient Information</h5>
                    <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($lab['first_name'] . ' ' . $lab['last_name']); ?></p>
                    <p class="mb-1"><strong>Patient #:</strong> <?php echo htmlspecialchars($lab['patient_number']); ?></p>
                    <p class="mb-0"><strong>Test:</strong> <?php echo htmlspecialchars($lab['test_name']); ?></p>
                </div>
                
                <form method="POST">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Sample Type *</label>
                            <select class="form-control" name="sample_type" required>
                                <option value="">Choose</option>
                                <option value="Blood">Blood</option>
                                <option value="Urine">Urine</option>
                                <option value="Stool">Stool</option>
                                <option value="Sputum">Sputum</option>
                                <option value="Swab">Swab</option>
                                <option value="Serum">Serum</option>
                                <option value="Plasma">Plasma</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Container Type *</label>
                            <select class="form-control" name="container_type" required>
                                <option value="">Choose</option>
                                <option value="EDTA Tube">EDTA Tube</option>
                                <option value="Plain Tube">Plain Tube</option>
                                <option value="Fluoride Tube">Fluoride Tube</option>
                                <option value="Urine Cup">Urine Cup</option>
                                <option value="Sterile Container">Sterile Container</option>
                                <option value="Swab Tube">Swab Tube</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Volume (ml)</label>
                            <input type="number" class="form-control" name="volume_ml" min="0" step="0.1" placeholder="e.g. 5">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Priority</label>
                            <select class="form-control" name="priority">
                                <option value="routine">Routine</option>
                                <option value="urgent">Urgent</option>
                                <option value="stat">STAT</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Collection Time</label>
                            <input type="datetime-local" class="form-control" name="collected_at">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Fasting Status</label>
                            <select class="form-control" name="fasting_status">
                                <option value="unknown">Unknown</option>
                                <option value="fasting">Fasting</option>
                                <option value="non-fasting">Non-fasting</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Sample Condition</label>
                            <select class="form-control" name="sample_condition">
                                <option value="good">Good</option>
                                <option value="hemolyzed">Hemolyzed</option>
                                <option value="insufficient">Insufficient</option>
                                <option value="clotted">Clotted</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Collection Site</label>
                        <input type="text" class="form-control" name="collection_site" placeholder="e.g. Left antecubital vein">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Collection Notes</label>
                        <textarea class="form-control" name="collection_notes" rows="3" 
                                  placeholder="Enter any notes about sample collection (e.g., time, condition, special handling)"></textarea>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i>
                        By confirming, you are verifying that the sample has been properly collected and labeled.
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-warning btn-lg">
                            <i class="fas fa-check-circle"></i> Confirm Sample Collection
                        </button>
                        <a href="view_lab_request.php?id=<?php echo $request_id; ?>" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
