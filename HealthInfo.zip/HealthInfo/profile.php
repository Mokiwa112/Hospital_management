<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Fetch current user data
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$user = mysqli_fetch_assoc($result);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $department = sanitize($_POST['department']);
    
    // Check if email already exists for another user
    $check_email = mysqli_query($conn, "SELECT user_id FROM users WHERE email = '$email' AND user_id != $user_id");
    if (mysqli_num_rows($check_email) > 0) {
        $error = "Email already in use by another user";
    } elseif (!isValidPhoneNumber($phone)) {
        $error = getPhoneValidationMessage();
    } else {
        $update_query = "UPDATE users SET 
                         full_name = '$full_name',
                         email = '$email',
                         phone = '$phone',
                         address = '$address',
                         department = '$department'
                         WHERE user_id = $user_id";
        
        if (mysqli_query($conn, $update_query)) {
            $success = "Profile updated successfully!";
            // Update session
            $_SESSION['full_name'] = $full_name;
            // Refresh user data
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);
        } else {
            $error = "Error updating profile: " . mysqli_error($conn);
        }
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    // Verify current password
    if (password_verify($current, $user['password']) || $current == $user['password']) {
        if ($new != $confirm) {
            $error = "New passwords do not match";
        } elseif (strlen($new) < 6) {
            $error = "Password must be at least 6 characters long";
        } else {
            $hashed = password_hash($new, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password = '$hashed' WHERE user_id = $user_id";
            
            if (mysqli_query($conn, $update_query)) {
                $success = "Password changed successfully!";
            } else {
                $error = "Error changing password: " . mysqli_error($conn);
            }
        }
    } else {
        $error = "Current password is incorrect";
    }
}

// Handle profile picture upload
if (isset($_POST['upload_photo'])) {
    if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_photo']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $new_filename = 'user_' . $user_id . '_' . time() . '.' . $ext;
            $upload_path = 'uploads/profiles/' . $new_filename;
            
            // Create directory if it doesn't exist
            if (!is_dir('uploads/profiles')) {
                mkdir('uploads/profiles', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_path)) {
                // Delete old photo if exists
                if (!empty($user['profile_photo']) && file_exists($user['profile_photo'])) {
                    unlink($user['profile_photo']);
                }
                
                $update_query = "UPDATE users SET profile_photo = '$upload_path' WHERE user_id = $user_id";
                if (mysqli_query($conn, $update_query)) {
                    $success = "Profile photo updated successfully!";
                    // Refresh user data
                    $result = mysqli_query($conn, $query);
                    $user = mysqli_fetch_assoc($result);
                }
            } else {
                $error = "Error uploading file";
            }
        } else {
            $error = "Invalid file type. Allowed: jpg, jpeg, png, gif";
        }
    }
}

// Get user's recent activity
$activity_query = "SELECT * FROM user_logs WHERE user_id = $user_id ORDER BY log_time DESC LIMIT 10";
$activity_result = mysqli_query($conn, $activity_query);

// Get user's statistics based on role
$stats = [];
if ($user['user_type'] == 'doctor') {
    $stats_query = "SELECT 
        COUNT(*) as total_appointments,
        SUM(CASE WHEN appointment_date >= CURDATE() THEN 1 ELSE 0 END) as upcoming
        FROM appointments WHERE doctor_id = $user_id";
    $stats_result = mysqli_query($conn, $stats_query);
    $stats = mysqli_fetch_assoc($stats_result);
} elseif ($user['user_type'] == 'lab_tech') {
    $stats_query = "SELECT 
        COUNT(*) as total_tests,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM lab_requests WHERE lab_tech_id = $user_id OR (lab_tech_id IS NULL AND status = 'pending')";
    $stats_result = mysqli_query($conn, $stats_query);
    $stats = mysqli_fetch_assoc($stats_result);
} elseif ($user['user_type'] == 'pharmacist') {
    $stats_query = "SELECT 
        COUNT(*) as total_prescriptions,
        SUM(CASE WHEN status = 'sent_to_pharmacy' THEN 1 ELSE 0 END) as pending
        FROM prescriptions WHERE pharmacist_id = $user_id OR (pharmacist_id IS NULL AND status = 'sent_to_pharmacy')";
    $stats_result = mysqli_query($conn, $stats_query);
    $stats = mysqli_fetch_assoc($stats_result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .profile-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .profile-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            font-weight: bold;
            margin: 0 auto 20px;
            border: 5px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .info-label {
            font-weight: 600;
            color: #666;
            margin-bottom: 5px;
        }
        .info-value {
            font-size: 1.1rem;
            margin-bottom: 15px;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            margin-bottom: 15px;
        }
        .stat-number {
            font-size: 24px;
            font-weight: bold;
        }
        .stat-label {
            font-size: 13px;
            opacity: 0.9;
        }
        .activity-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .photo-upload {
            position: relative;
            width: 150px;
            height: 150px;
            margin: 0 auto 20px;
        }
        .photo-upload input {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }
        .photo-upload:hover .profile-avatar {
            opacity: 0.8;
            cursor: pointer;
        }
        .photo-upload::after {
            content: '\f030';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: #007bff;
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h2><i class="fas fa-id-card"></i> My Profile</h2>
                    <p class="mb-0">Manage your personal information and account settings</p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="badge bg-light text-dark p-2">
                        <i class="fas fa-calendar"></i> Member since: <?php echo date('d M Y', strtotime($user['created_at'] ?? 'now')); ?>
                    </span>
                </div>
            </div>
        </div>
        
        <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Left Column - Profile Photo & Basic Info -->
            <div class="col-md-3">
                <div class="profile-card text-center">
                    <form method="POST" enctype="multipart/form-data" id="photoForm">
                        <div class="photo-upload">
                            <div class="profile-avatar">
                                <?php if(!empty($user['profile_photo']) && file_exists($user['profile_photo'])): ?>
                                    <img src="<?php echo $user['profile_photo']; ?>" alt="Profile Photo">
                                <?php else: ?>
                                    <?php echo substr($user['full_name'], 0, 1) . (strpos($user['full_name'], ' ') ? substr($user['full_name'], strpos($user['full_name'], ' ') + 1, 1) : ''); ?>
                                <?php endif; ?>
                            </div>
                            <input type="file" name="profile_photo" accept="image/*" onchange="document.getElementById('photoForm').submit()">
                        </div>
                        <input type="hidden" name="upload_photo" value="1">
                    </form>
                    
                    <h4 class="mt-3"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                    <p class="text-muted">
                        <span class="badge bg-<?php 
                            $type = $user['user_type'];
                            if ($type == 'admin') echo 'danger';
                            elseif ($type == 'doctor') echo 'success';
                            elseif ($type == 'nurse') echo 'info';
                            elseif ($type == 'lab_tech') echo 'primary';
                            elseif ($type == 'pharmacist') echo 'warning';
                            else echo 'secondary';
                        ?> p-2">
                            <i class="fas fa-user-md"></i> <?php echo ucfirst(str_replace('_', ' ', $type)); ?>
                        </span>
                    </p>
                    
                    <hr>
                    
                    <div class="text-start">
                        <p class="mb-2"><i class="fas fa-id-card text-primary me-2"></i> <strong>Employee ID:</strong> <?php echo $user['employee_id']; ?></p>
                        <p class="mb-2"><i class="fas fa-building text-primary me-2"></i> <strong>Department:</strong> <?php echo $user['department'] ?: 'Not assigned'; ?></p>
                        <p class="mb-2"><i class="fas fa-clock text-primary me-2"></i> <strong>Last Login:</strong> <?php 
                            $last_login = mysqli_fetch_assoc(mysqli_query($conn, "SELECT log_time FROM user_logs WHERE user_id = $user_id AND action='login' ORDER BY log_time DESC LIMIT 1"));
                            echo $last_login ? date('d M Y h:i A', strtotime($last_login['log_time'])) : 'First login';
                        ?></p>
                    </div>
                </div>
                
                <!-- Role-specific Statistics -->
                <?php if(!empty($stats)): ?>
                    <div class="profile-card">
                        <h5 class="mb-3"><i class="fas fa-chart-bar"></i> Your Statistics</h5>
                        <?php if($user['user_type'] == 'doctor'): ?>
                            <div class="stat-card mb-3">
                                <div class="stat-number"><?php echo $stats['total_appointments'] ?? 0; ?></div>
                                <div class="stat-label">Total Appointments</div>
                            </div>
                            <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                                <div class="stat-number"><?php echo $stats['upcoming'] ?? 0; ?></div>
                                <div class="stat-label">Upcoming Appointments</div>
                            </div>
                        <?php elseif($user['user_type'] == 'lab_tech'): ?>
                            <div class="stat-card mb-3">
                                <div class="stat-number"><?php echo $stats['total_tests'] ?? 0; ?></div>
                                <div class="stat-label">Total Tests Processed</div>
                            </div>
                            <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                                <div class="stat-number"><?php echo $stats['pending'] ?? 0; ?></div>
                                <div class="stat-label">Pending Tests</div>
                            </div>
                        <?php elseif($user['user_type'] == 'pharmacist'): ?>
                            <div class="stat-card mb-3">
                                <div class="stat-number"><?php echo $stats['total_prescriptions'] ?? 0; ?></div>
                                <div class="stat-label">Total Prescriptions</div>
                            </div>
                            <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                                <div class="stat-number"><?php echo $stats['pending'] ?? 0; ?></div>
                                <div class="stat-label">Pending Prescriptions</div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Middle Column - Edit Profile -->
            <div class="col-md-5">
                <div class="profile-card">
                    <h5 class="mb-3"><i class="fas fa-edit text-success"></i> Edit Profile</h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" 
                                   value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email Address</label>
                                <input type="email" class="form-control" name="email" 
                                       value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" name="phone" 
                                       value="<?php echo htmlspecialchars($user['phone']); ?>" required
                                       pattern="^(0\d{9}|\+\d{11,12})$"
                                       title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" name="address" rows="2"><?php echo htmlspecialchars($user['address']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Department</label>
                            <input type="text" class="form-control" name="department" 
                                   value="<?php echo htmlspecialchars($user['department']); ?>">
                            <small class="text-muted">Leave blank to keep current department</small>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Username:</strong> <?php echo $user['username']; ?> (cannot be changed)
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn btn-success w-100">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
                </div>
                
                <!-- Change Password -->
                <div class="profile-card">
                    <h5 class="mb-3"><i class="fas fa-key text-warning"></i> Change Password</h5>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" class="form-control" name="new_password" 
                                       minlength="6" required>
                                <small class="text-muted">Minimum 6 characters</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                        </div>
                        
                        <button type="submit" name="change_password" class="btn btn-warning w-100">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Right Column - Recent Activity -->
            <div class="col-md-4">
                <div class="profile-card">
                    <h5 class="mb-3"><i class="fas fa-history text-info"></i> Recent Activity</h5>
                    
                    <?php if($activity_result && mysqli_num_rows($activity_result) > 0): ?>
                        <div class="activity-list">
                            <?php while($activity = mysqli_fetch_assoc($activity_result)): ?>
                                <div class="activity-item">
                                    <div class="d-flex justify-content-between">
                                        <span>
                                            <i class="fas fa-<?php 
                                                echo $activity['action'] == 'login' ? 'sign-in-alt text-success' : 
                                                    ($activity['action'] == 'logout' ? 'sign-out-alt text-danger' : 'circle text-info'); 
                                            ?> me-2"></i>
                                            <?php echo ucfirst($activity['action']); ?>
                                        </span>
                                        <small class="text-muted">
                                            <?php echo date('d M H:i', strtotime($activity['log_time'])); ?>
                                        </small>
                                    </div>
                                    <small class="text-muted">
                                        IP: <?php echo $activity['ip_address']; ?>
                                    </small>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center py-4">No recent activity</p>
                    <?php endif; ?>
                    
                    <hr>
                    
                    <div class="text-center">
                        <a href="<?php echo $user['user_type'] === 'admin' ? 'attendance_history.php' : 'worker_attendance.php'; ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-clock"></i> View Attendance
                        </a>
                        <a href="attendance_history.php" class="btn btn-outline-info btn-sm">
                            <i class="fas fa-list"></i> Full Activity Log
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="profile-card">
                    <h5 class="mb-3"><i class="fas fa-link"></i> Quick Links</h5>
                    
                    <div class="list-group">
                        <?php if($user['user_type'] == 'admin'): ?>
                            <a href="system_settings.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-cog text-primary"></i> System Settings
                            </a>
                            <a href="backup.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-database text-success"></i> Backup Manager
                            </a>
                        <?php endif; ?>
                        
                        <?php if($user['user_type'] == 'doctor'): ?>
                            <a href="my_appointments.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-calendar-check text-primary"></i> My Appointments
                            </a>
                        <?php endif; ?>
                        
                        <a href="<?php echo $user['user_type'] === 'admin' ? 'attendance_history.php' : 'worker_attendance.php'; ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-clock text-warning"></i> Daily Attendance
                        </a>
                        
                        <a href="change_password.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-key text-danger"></i> Change Password
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Preview image before upload
        document.querySelector('input[name="profile_photo"]').addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.querySelector('.profile-avatar').innerHTML = 
                        '<img src="' + e.target.result + '" style="width:100%; height:100%; object-fit:cover;">';
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>
</body>
</html>

