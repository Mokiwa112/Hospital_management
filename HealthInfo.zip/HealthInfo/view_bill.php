<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$bill_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_created_by = tableHasColumn('billing', 'created_by');
$has_notes = tableHasColumn('billing', 'notes');

function ensureBillingPaymentsTable($conn) {
    static $ready = false;
    if ($ready) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS billing_payments (
                payment_id INT AUTO_INCREMENT PRIMARY KEY,
                bill_id INT NOT NULL,
                amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                payment_method VARCHAR(30) NOT NULL,
                payment_reference VARCHAR(120) NULL,
                payment_notes TEXT NULL,
                paid_by INT NULL,
                paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_bill_id (bill_id),
                INDEX idx_paid_at (paid_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    mysqli_query($conn, $sql);
    $ready = true;
}
ensureBillingPaymentsTable($conn);

// Fetch bill details
$query = "SELECT b.*, p.first_name, p.last_name, p.patient_number, p.address, p.phone";
if ($has_created_by) {
    $query .= ", u.full_name as created_by_name";
} else {
    $query .= ", 'System' as created_by_name";
}
$query .= " FROM billing b
            JOIN patients p ON b.patient_id = p.patient_id";
if ($has_created_by) {
    $query .= " LEFT JOIN users u ON b.created_by = u.user_id";
}
$query .= " WHERE b.bill_id = $bill_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Bill not found";
    header("Location: billing.php");
    exit();
}

$bill = mysqli_fetch_assoc($result);
$bill_total = max(0, (float)($bill['net_amount'] ?? 0));

$payments_result = mysqli_query(
    $conn,
    "SELECT bp.*, u.full_name AS paid_by_name
     FROM billing_payments bp
     LEFT JOIN users u ON bp.paid_by = u.user_id
     WHERE bp.bill_id = $bill_id
     ORDER BY bp.paid_at DESC, bp.payment_id DESC"
);

$paid_total = 0.0;
if ($payments_result) {
    while ($pay = mysqli_fetch_assoc($payments_result)) {
        $paid_total += (float)($pay['amount_paid'] ?? 0);
        $payment_rows[] = $pay;
    }
}
$payment_rows = $payment_rows ?? [];
if ($paid_total <= 0 && ($bill['payment_status'] ?? '') === 'paid') {
    $paid_total = $bill_total;
}
$remaining_balance = max(0, $bill_total - $paid_total);

// Fetch bill items
$items_query = "SELECT * FROM billing_items WHERE bill_id = $bill_id";
$items_result = mysqli_query($conn, $items_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Bill #<?php echo $bill['bill_number']; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-file-invoice"></i> Bill Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="print_bill.php?id=<?php echo $bill_id; ?>" target="_blank" class="btn btn-primary">
                    <i class="fas fa-print"></i> Print Bill
                </a>
                <a href="billing.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Bill Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Bill Number:</strong><br>
                        <?php echo $bill['bill_number']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Bill Date:</strong><br>
                        <?php echo date('d-m-Y h:i A', strtotime($bill['bill_date'])); ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Payment Status:</strong><br>
                        <span class="badge bg-<?php echo $bill['payment_status'] == 'paid' ? 'success' : 'warning'; ?>">
                            <?php echo ucfirst($bill['payment_status']); ?>
                        </span>
                    </div>
                    <div class="col-md-3">
                        <strong>Payment Method:</strong><br>
                        <?php echo $bill['payment_method'] ? ucfirst($bill['payment_method']) : 'Not specified'; ?>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-4">
                        <strong>Total Bill:</strong><br>
                        <?php echo format_currency($bill_total); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Total Paid:</strong><br>
                        <?php echo format_currency($paid_total); ?>
                    </div>
                    <div class="col-md-4">
                        <strong>Remaining Balance:</strong><br>
                        <span class="<?php echo $remaining_balance > 0 ? 'text-danger' : 'text-success'; ?>">
                            <?php echo format_currency($remaining_balance); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Patient Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Name:</strong><br>
                        <?php echo $bill['first_name'] . ' ' . $bill['last_name']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Patient #:</strong><br>
                        <?php echo $bill['patient_number']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Phone:</strong><br>
                        <?php echo $bill['phone']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Address:</strong><br>
                        <?php echo $bill['address'] ?: 'N/A'; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Bill Items</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Type</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $subtotal = 0;
                            while($item = mysqli_fetch_assoc($items_result)): 
                                $total = $item['quantity'] * $item['unit_price'];
                                $subtotal += $total;
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['description']); ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $item['item_type'])); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td><?php echo format_currency($item['unit_price']); ?></td>
                                    <td><?php echo format_currency($total); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="4" class="text-end">Subtotal:</th>
                                <th><?php echo format_currency($subtotal); ?></th>
                            </tr>
                            <?php if($bill['discount'] > 0): ?>
                            <tr>
                                <th colspan="4" class="text-end">Discount:</th>
                                <th>-<?php echo format_currency($bill['discount']); ?></th>
                            </tr>
                            <?php endif; ?>
                            <?php if($bill['tax'] > 0): ?>
                            <tr>
                                <th colspan="4" class="text-end">Tax:</th>
                                <th>+<?php echo format_currency($bill['tax']); ?></th>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th colspan="4" class="text-end">Total Amount:</th>
                                <th class="text-success"><?php echo format_currency($bill['net_amount']); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <?php if($has_notes && !empty($bill['notes'])): ?>
                <div class="mt-3">
                    <strong>Notes:</strong>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($bill['notes'])); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header bg-secondary text-white">
                <h5 class="mb-0">Payment History</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($payment_rows)): ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Method</th>
                                    <th>Reference</th>
                                    <th>Amount</th>
                                    <th>Processed By</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($payment_rows as $pay): ?>
                                    <tr>
                                        <td><?php echo date('d-m-Y h:i A', strtotime($pay['paid_at'])); ?></td>
                                        <td><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $pay['payment_method']))); ?></td>
                                        <td><?php echo htmlspecialchars($pay['payment_reference'] ?: '-'); ?></td>
                                        <td><?php echo format_currency($pay['amount_paid']); ?></td>
                                        <td><?php echo htmlspecialchars($pay['paid_by_name'] ?: 'System'); ?></td>
                                        <td><?php echo htmlspecialchars($pay['payment_notes'] ?: '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">No payments recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Payment Actions -->
        <?php if($remaining_balance > 0): ?>
        <div class="card mt-3">
            <div class="card-header bg-warning">
                <h5 class="mb-0">Process Payment</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="process_payment.php">
                    <input type="hidden" name="bill_id" value="<?php echo $bill_id; ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <select class="form-control" name="payment_method" required>
                                <option value="">Select Payment Method</option>
                                <option value="cash">Cash</option>
                                <option value="card">Credit/Debit Card</option>
                                <option value="insurance">Insurance</option>
                                <option value="bank_transfer">Bank Transfer</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="number" class="form-control" name="amount_paid" 
                                   placeholder="Amount" step="0.01" min="0.01" max="<?php echo htmlspecialchars((string)$remaining_balance); ?>" required>
                            <small class="text-muted">Allowed range: 0.01 to <?php echo format_currency($remaining_balance); ?></small>
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" name="payment_reference" placeholder="Reference">
                        </div>
                        <div class="col-md-2">
                            <input type="text" class="form-control" name="payment_notes" placeholder="Notes (optional)">
                        </div>
                        <div class="col-md-12 mt-2">
                            <button type="submit" class="btn btn-success w-100">
                                <i class="fas fa-credit-card"></i> Process Payment
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
