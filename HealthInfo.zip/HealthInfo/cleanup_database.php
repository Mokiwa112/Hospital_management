<?php
require_once 'config.php';

$conn = getConnection();

// Disable foreign key checks temporarily
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");

// List of tables to truncate in correct order
$tables = [
    'attendance_approvals',
    'attendance',
    'billing_items',
    'billing',
    'insurance_claims',
    'prescription_items',
    'prescriptions',
    'lab_requests',
    'appointments',
    'inventory_items',
    'lab_tests',
    'insurance_providers',
    'patients',
    'user_logs',
    'reports',
    'users'
];

// Truncate all tables
foreach ($tables as $table) {
    $check = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($check) > 0) {
        mysqli_query($conn, "TRUNCATE TABLE $table");
        echo "Truncated table: $table<br>";
    }
}

// Re-enable foreign key checks
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");

echo "<h3>Database cleaned successfully!</h3>";
echo "<p>All tables have been cleared. Now you can run the seed_database.php script to add fresh data.</p>";
echo '<a href="seed_database.php" class="btn btn-primary">Run Seed Database</a>';
?>