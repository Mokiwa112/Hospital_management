<?php
require_once 'config.php';
requireRole('doctor');

$conn = getConnection();
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$where = "";
if ($search) {
    $where = "WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR patient_number LIKE '%$search%' OR phone LIKE '%$search%'";
}

$patients = mysqli_query($conn, "SELECT * FROM patients $where ORDER BY first_name LIMIT 50");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Patients - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4><i class="fas fa-search"></i> Search Patients</h4>
            </div>
            <div class="card-body">
                <form method="GET" class="mb-4">
                    <div class="input-group">
                        <input type="text" class="form-control form-control-lg" 
                               name="search" placeholder="Search by name, patient number, or phone..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                </form>
                
                <?php if($search): ?>
                    <h5>Search Results for "<?php echo htmlspecialchars($search); ?>"</h5>
                    <hr>
                    
                    <?php if(mysqli_num_rows($patients) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Patient #</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Last Visit</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($patient = mysqli_fetch_assoc($patients)): 
                                        $last_visit = mysqli_fetch_assoc(mysqli_query($conn, 
                                            "SELECT MAX(appointment_date) as last FROM appointments WHERE patient_id = {$patient['patient_id']}"
                                        ));
                                    ?>
                                        <tr>
                                            <td><?php echo $patient['patient_number']; ?></td>
                                            <td><?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?></td>
                                            <td><?php echo $patient['phone']; ?></td>
                                            <td><?php echo $last_visit['last'] ? date('d-m-Y', strtotime($last_visit['last'])) : 'No visits'; ?></td>
                                            <td>
                                                <a href="view_patient.php?id=<?php echo $patient['patient_id']; ?>" 
                                                   class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                                <a href="create_prescription.php?patient_id=<?php echo $patient['patient_id']; ?>" 
                                                   class="btn btn-sm btn-success">
                                                    <i class="fas fa-prescription"></i> Prescribe
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No patients found matching your search.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>