<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$bill_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_created_by = tableHasColumn('billing', 'created_by');
$has_notes = tableHasColumn('billing', 'notes');

// Fetch bill details
$query = "SELECT b.*, p.first_name, p.last_name, p.patient_number, p.address, p.phone";
if ($has_created_by) {
    $query .= ", u.full_name as created_by_name";
} else {
    $query .= ", 'System' as created_by_name";
}
$query .= " FROM billing b
            JOIN patients p ON b.patient_id = p.patient_id";
if ($has_created_by) {
    $query .= " LEFT JOIN users u ON b.created_by = u.user_id";
}
$query .= " WHERE b.bill_id = $bill_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Bill not found";
    header("Location: billing.php");
    exit();
}

$bill = mysqli_fetch_assoc($result);

// Fetch bill items
$items_query = "SELECT * FROM billing_items WHERE bill_id = $bill_id";
$items_result = mysqli_query($conn, $items_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill #<?php echo $bill['bill_number']; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
            body { font-size: 12pt; }
        }
        .bill-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #333;
        }
        .hospital-name {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .bill-title {
            font-size: 20px;
            margin-top: 10px;
        }
        .bill-info {
            margin-bottom: 30px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .bill-info table {
            width: 100%;
        }
        .bill-info td {
            padding: 5px;
        }
        .bill-info td:first-child {
            font-weight: bold;
            width: 150px;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th {
            background: #333;
            color: white;
            padding: 10px;
            text-align: left;
        }
        .items-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .items-table tr:last-child td {
            border-bottom: none;
        }
        .total-section {
            text-align: right;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #333;
        }
        .total-row {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .grand-total {
            font-size: 24px;
            font-weight: bold;
            color: #28a745;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            color: #666;
            font-size: 11px;
        }
        .payment-status {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        .status-paid { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-partial { background: #cce5ff; color: #004085; }
    </style>
</head>
<body>
    <div class="container mt-4 mb-4">
        <div class="no-print text-end mb-3">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Bill
            </button>
            <a href="billing.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Billing
            </a>
        </div>
        
        <!-- Bill Header -->
        <div class="bill-header">
            <div class="hospital-name"><?php echo SITE_NAME; ?></div>
            <div class="bill-title">INVOICE</div>
            <div>Bill #: <?php echo $bill['bill_number']; ?></div>
            <div>Date: <?php echo date('d F Y h:i A', strtotime($bill['bill_date'])); ?></div>
        </div>
        
        <!-- Patient Information -->
        <div class="bill-info">
            <table>
                <tr>
                    <td>Patient Name:</td>
                    <td><strong><?php echo $bill['first_name'] . ' ' . $bill['last_name']; ?></strong></td>
                </tr>
                <tr>
                    <td>Patient ID:</td>
                    <td><?php echo $bill['patient_number']; ?></td>
                </tr>
                <tr>
                    <td>Phone:</td>
                    <td><?php echo $bill['phone']; ?></td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td><?php echo $bill['address'] ?: 'N/A'; ?></td>
                </tr>
                <tr>
                    <td>Payment Status:</td>
                    <td>
                        <span class="payment-status status-<?php echo $bill['payment_status']; ?>">
                            <?php echo ucfirst($bill['payment_status']); ?>
                        </span>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- Items Table -->
        <table class="items-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Type</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $subtotal = 0;
                while($item = mysqli_fetch_assoc($items_result)): 
                    $total = $item['quantity'] * $item['unit_price'];
                    $subtotal += $total;
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['description']); ?></td>
                        <td><?php echo ucfirst(str_replace('_', ' ', $item['item_type'])); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td><?php echo format_currency($item['unit_price']); ?></td>
                        <td><?php echo format_currency($total); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
        <!-- Totals -->
        <div class="total-section">
            <div class="total-row">
                Subtotal: <?php echo format_currency($subtotal); ?>
            </div>
            <?php if($bill['discount'] > 0): ?>
            <div class="total-row">
                Discount: -<?php echo format_currency($bill['discount']); ?>
            </div>
            <?php endif; ?>
            <?php if($bill['tax'] > 0): ?>
            <div class="total-row">
                Tax: +<?php echo format_currency($bill['tax']); ?>
            </div>
            <?php endif; ?>
            <div class="grand-total">
                Total Amount: <?php echo format_currency($bill['net_amount']); ?>
            </div>
            <?php if($has_notes && !empty($bill['notes'])): ?>
            <div class="mt-3 text-muted">
                <strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($bill['notes'])); ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>This is a computer generated invoice. No signature required.</p>
            <p>Generated by: <?php echo $bill['created_by_name'] ?: 'System'; ?> on <?php echo date('d F Y h:i A'); ?></p>
            <p>Thank you for choosing <?php echo SITE_NAME; ?></p>
        </div>
    </div>
    
    <script src="https://kit.fontawesome.com/your-code.js"></script>
</body>
</html>
