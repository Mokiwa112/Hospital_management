<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor', 'nurse', 'receptionist', 'accountant']);

$conn = getConnection();
$patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch patient details
$query = "SELECT p.*, u.full_name as registered_by_name 
          FROM patients p
          LEFT JOIN users u ON p.created_by = u.user_id
          WHERE p.patient_id = $patient_id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Patient not found";
    redirect('patients.php');
}

$patient = mysqli_fetch_assoc($result);

// Fetch patient's appointments
$appointments = mysqli_query($conn,
    "SELECT a.*, u.full_name as doctor_name 
     FROM appointments a
     JOIN users u ON a.doctor_id = u.user_id
     WHERE a.patient_id = $patient_id
     ORDER BY a.appointment_date DESC, a.appointment_time DESC"
);

// Fetch patient's lab requests
$lab_requests = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.category 
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = $patient_id
     ORDER BY lr.request_date DESC"
);

// Fetch patient's bills
$bills = mysqli_query($conn,
    "SELECT * FROM billing 
     WHERE patient_id = $patient_id
     ORDER BY bill_date DESC"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Patient - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-user-circle"></i> Patient Details: <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="edit_patient.php?id=<?php echo $patient_id; ?>" class="btn btn-warning">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="schedule_appointment.php?patient_id=<?php echo $patient_id; ?>" class="btn btn-primary">
                    <i class="fas fa-calendar-plus"></i> New Appointment
                </a>
                <?php if(($_SESSION['user_type'] ?? '') === 'doctor'): ?>
                <a href="create_prescription.php?patient_id=<?php echo $patient_id; ?>" class="btn btn-secondary">
                    <i class="fas fa-prescription"></i> Prescription
                </a>
                <?php endif; ?>
                <?php if(($_SESSION['user_type'] ?? '') === 'doctor'): ?>
                <a href="lab_request.php?patient_id=<?php echo $patient_id; ?>" class="btn btn-info">
                    <i class="fas fa-flask"></i> New Lab Test
                </a>
                <?php endif; ?>
                <a href="patients.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        
        <!-- Patient Information Card -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Personal Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Patient Number:</strong><br>
                        <?php echo $patient['patient_number']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Full Name:</strong><br>
                        <?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Date of Birth:</strong><br>
                        <?php echo date('d-m-Y', strtotime($patient['date_of_birth'])); ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Gender:</strong><br>
                        <?php echo $patient['gender'] == 'M' ? 'Male' : ($patient['gender'] == 'F' ? 'Female' : 'Other'); ?>
                    </div>
                    <div class="col-md-2">
                        <strong>Blood Group:</strong><br>
                        <?php echo $patient['blood_group'] ?: 'N/A'; ?>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-3">
                        <strong>Phone:</strong><br>
                        <?php echo $patient['phone']; ?>
                    </div>
                    <div class="col-md-3">
                        <strong>Email:</strong><br>
                        <?php echo $patient['email'] ?: 'N/A'; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Address:</strong><br>
                        <?php echo $patient['address'] ?: 'N/A'; ?>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <strong>Emergency Contact:</strong><br>
                        <?php echo $patient['emergency_contact_name'] ?: 'N/A'; ?> (<?php echo $patient['emergency_contact'] ?: 'N/A'; ?>)
                    </div>
                    <div class="col-md-6">
                        <strong>Allergies/Medical History:</strong><br>
                        <?php echo $patient['allergies'] ?: 'None reported'; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabs for different sections -->
        <ul class="nav nav-tabs" id="patientTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="appointments-tab" data-bs-toggle="tab" data-bs-target="#appointments">
                    Appointments
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="lab-tab" data-bs-toggle="tab" data-bs-target="#lab">
                    Lab Tests
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="bills-tab" data-bs-toggle="tab" data-bs-target="#bills">
                    Bills
                </button>
            </li>
        </ul>
        
        <div class="tab-content mt-3">
            <!-- Appointments Tab -->
            <div class="tab-pane fade show active" id="appointments">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Doctor</th>
                                <th>Reason</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($apt = mysqli_fetch_assoc($appointments)): ?>
                                <tr>
                                    <td><?php echo date('d-m-Y', strtotime($apt['appointment_date'])); ?></td>
                                    <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                    <td>Dr. <?php echo $apt['doctor_name']; ?></td>
                                    <td><?php echo $apt['reason']; ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $apt['status'] == 'completed' ? 'success' : 'primary'; ?>">
                                            <?php echo ucfirst($apt['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Lab Tests Tab -->
            <div class="tab-pane fade" id="lab">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Test</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($lab = mysqli_fetch_assoc($lab_requests)): ?>
                                <tr>
                                    <td><?php echo date('d-m-Y', strtotime($lab['request_date'])); ?></td>
                                    <td><?php echo $lab['test_name']; ?></td>
                                    <td><?php echo $lab['category']; ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $lab['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($lab['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $lab['result_value'] ?: 'Pending'; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Bills Tab -->
            <div class="tab-pane fade" id="bills">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Bill #</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Discount</th>
                                <th>Net Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($bill = mysqli_fetch_assoc($bills)): ?>
                                <tr>
                                    <td><?php echo $bill['bill_number']; ?></td>
                                    <td><?php echo date('d-m-Y', strtotime($bill['bill_date'])); ?></td>
                                    <td><?php echo format_currency($bill['total_amount']); ?></td>
                                    <td><?php echo format_currency($bill['discount']); ?></td>
                                    <td><strong><?php echo format_currency($bill['net_amount']); ?></strong></td>
                                    <td>
                                        <span class="badge bg-<?php echo $bill['payment_status'] == 'paid' ? 'success' : 'warning'; ?>">
                                            <?php echo ucfirst($bill['payment_status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
