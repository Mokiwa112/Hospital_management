# Hospital Management System - Technical Documentation
Last updated: 2026-02-23

## 1. System Overview
HealthInfo is a role-based Hospital Management System built with:
- PHP (procedural architecture)
- MySQL/MariaDB
- Bootstrap 5 + Font Awesome + DataTables
- XAMPP local environment

Main purpose:
- Manage patients, appointments, laboratory workflows, prescriptions, pharmacy/inventory, billing, insurance, attendance, and HR operations.

## 2. Core Functional Modules

### 2.1 Authentication and Access Control
- Staff login and patient portal login.
- Session-based authentication and role routing.
- Role authorization helpers:
  - `requireStaffLogin()`
  - `requireRole($role)`
  - `requireAnyRole($roles)`
- Inventory-specific access helpers:
  - `canAccessInventory($need_edit = false)`
  - `requireInventoryAccess($need_edit = false)`

### 2.2 Dashboards
- `dashboard.php` (admin + staff summary views)
- `doctor_dashboard.php`
- `labtech_dashboard.php`
- `pharmacist_dashboard.php`
- `patient_dashboard.php`
- `hr_dashboard.php`

### 2.3 Patient Management
- Register, edit, search, and view patients.
- Patient history and profile management.
- Patient portal authentication via patient number + date of birth.
- Patient list now supports action-driven workflow for clinicians:
  - View details
  - Edit
  - Appointment creation
  - Doctor-only prescription and lab request actions

### 2.4 Appointment Management
- Schedule and manage appointments.
- Doctor-facing appointment detail workflow (`view_appointment.php`).
- Status lifecycle:
  - `scheduled`
  - `in_progress`
  - `completed`
  - `cancelled`
  - `no_show`

### 2.5 Laboratory Management
- Lab request creation (`lab_request.php`)
- Request listing, filtering, and role-aware processing (`lab_requests_list.php`)
- Sample collection and result entry
- Doctor review/approval workflow for completed results
- Patient-specific lab result tracking for doctors via patient filters

### 2.6 Prescriptions and Pharmacy
- Doctors create prescriptions directly per patient (appointment is not required).
- Prescription items include dosage, frequency, duration, quantity, and instructions.
- Pharmacists process and dispense pending prescriptions.
- Prescription status handling is schema-safe.

### 2.7 Inventory Management
- Expanded inventory structure with category-aware fields and transaction logging.
- Supports stock in, stock out, adjustments, transfers, expiry and low-stock monitoring.
- Inventory module is self-contained with role/grant-based access controls.
- Access management is handled from inside inventory UI (admin-managed).

### 2.8 Billing and Insurance
- Bill creation from unbilled services (consultations, labs, medicines, procedures).
- Billing history and payment processing.
- Insurance provider and claims workflows.
- Auto-billing for uninsured patients:
  - Triggered when treatment/appointment is marked `completed`.
  - Controlled by system setting `auto_billing_uninsured`.
  - Pending auto-generated uninsured bills are surfaced in staff dashboards and billing page.

### 2.9 HR, Attendance, Shifts, and Leave
- Attendance tracking and approvals.
- Shift assignment and shift-aware check-in/check-out.
- Leave request and approval workflow.
- HR core operations and payroll support data.

## 3. Role Matrix and Permission Model

Supported roles:
- `admin`
- `doctor`
- `nurse`
- `receptionist`
- `lab_tech`
- `pharmacist`
- `accountant`
- `hr_admin`

Role home routing:
- Defined via `getRoleHomePage()` in `config.php`.

Notable access boundaries:
- `insurance.php` restricted to accountant/admin flows.
- `billing.php` restricted to accountant/receptionist/admin flow (admin bypass through central role helper behavior).
- `lab_request.php` restricted to doctor role.
- `appointments.php` restricted to doctor and receptionist role scope.
- `patients.php` scoped to doctor, nurse, and receptionist.

## 4. Database Design Summary

### Core Tables
- `users`
- `patients`
- `appointments`
- `lab_requests`
- `lab_tests`
- `prescriptions`
- `prescription_items`
- `billing`
- `billing_items`
- `inventory_items`
- `inventory_transactions`
- `inventory_user_access`
- `insurance_claims`
- `attendance`
- `shift_definitions`
- `user_shift_assignments`

### HR-related Tables
- `hr_departments`
- `hr_positions`
- `employee_employment_details`
- `employee_documents`
- `leave_types`
- `leave_requests`
- `performance_reviews`
- `job_postings`
- `applicants`
- `interviews`
- `disciplinary_records`
- `employee_salary_structures`
- `payroll_records`

Schema/support files:
- `hospital_management.sql`
- `hr_full_schema.sql`
- `hr_module_schema.sql`
- `schema_shift_leave_update.sql`
- `inventory_structure_upgrade.sql`

## 5. Key Files and Responsibilities

- `config.php`: DB connection, utilities, settings loader, schema-safe helpers, role home mapping.
- `auth_check.php`: authentication and role enforcement helpers.
- `navbar.php`: shared navigation and role-driven menu rendering.
- `dashboard.php`: summary cards and quick actions per role.
- `doctor_dashboard.php`: appointment/lab/patient flow for doctors.
- `patients.php`: patient listing and action entry points.
- `view_appointment.php`: appointment details, status updates, lab request initiation, auto-billing trigger.
- `billing_auto_helper.php`: uninsured check, unbilled-service collection, auto bill creation.
- `billing.php` + `get_billable_services.php`: manual bill creation and unbilled-service retrieval.
- `inventory.php`: inventory management and access assignment UI.
- `system_settings.php`: operational settings including auto-billing toggle.

## 6. UI and Theme Notes

- Shared color system is centralized in `assets/theme.css`.
- Current palette prioritizes accessible, less aggressive tones for prolonged use.
- Admin navigation supports fixed left-sidebar behavior on desktop and responsive collapse on small devices.
- Login page uses softened gradients and low-strain contrast settings.

## 7. Security Controls

- Password hashing with PHP `password_hash`.
- Prepared statements in authentication-sensitive flows.
- Session hardening:
  - `HttpOnly`
  - `SameSite=Lax`
  - strict session mode
- Security headers:
  - `X-Frame-Options`
  - `X-Content-Type-Options`
  - `Referrer-Policy`
  - `Content-Security-Policy` (`frame-ancestors 'self'`)
- Same-origin guard for POST requests using Origin/Referer validation.
- Input sanitization through `sanitize()` and numeric casting for IDs.
- Schema-safe compatibility through:
  - `tableHasColumn()`
  - `firstExistingColumn()`
- Audit log helper:
  - `app_log_action()`

## 8. Deployment and Run Steps

1. Place project under XAMPP web root:
   - `C:\xampp\htdocs\HealthInfo`
2. Start Apache and MySQL in XAMPP.
3. Import base database:
   - `hospital_management.sql`
4. Optional schema updates:
   - `hr_full_schema.sql`
   - `schema_shift_leave_update.sql`
   - `inventory_structure_upgrade.sql`
5. Access URLs:
   - Staff: `http://localhost/HealthInfo/login.php`
   - Patient portal: `http://localhost/HealthInfo/patient_portal.php`

## 9. Test Data and Credential References

- `all_user_logins.txt`
- `reset_staff_users.sql`
- `seed_database.php`

Operational note:
- Test credentials are for local/staging use only and must be replaced in production.

## 10. Current Operational Notes

- Auto-billing for uninsured patients is configurable from system settings.
- Billing and inventory flows use schema-safe fallbacks to remain stable across DB revisions.
- Doctor workflow now supports lab requests and prescriptions directly from patient contexts, not only appointment contexts.
- Inventory access is controlled by explicit grants once any grant records exist.

## 11. Recommended Next Enhancements

1. Add CSRF tokens to all POST forms.
2. Expand centralized validation layer for all module forms.
3. Add more granular audit logs for billing, inventory, and clinical status changes.
4. Introduce automated smoke tests for:
   - Appointment to billing flow
   - Lab request to result approval flow
   - Prescription to dispense flow
   - Inventory transaction integrity
