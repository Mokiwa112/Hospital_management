<?php
require_once 'config.php';
requireRole('pharmacist');

$conn = getConnection();
$can_edit_inventory = canAccessInventory(true);
$has_dispensed_date = tableHasColumn('prescriptions', 'dispensed_date');
$has_inventory_class = tableHasColumn('inventory_items', 'inventory_class');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_drug_item'])) {
    requireInventoryAccess(true);
    $item_code = generateUniqueId('DRG', 'inventory_items', 'item_code');
    $item_name = sanitize($_POST['item_name'] ?? '');
    $strength = sanitize($_POST['strength'] ?? '');
    $drug_type = sanitize($_POST['drug_type'] ?? '');
    $batch_number = sanitize($_POST['batch_number'] ?? '');
    $quantity = max(0, (int)($_POST['quantity'] ?? 0));
    $reorder_level = max(0, (int)($_POST['reorder_level'] ?? 0));
    $unit_price = (float)($_POST['unit_price'] ?? 0);
    $supplier = sanitize($_POST['supplier'] ?? '');
    $expiry_date = !empty($_POST['expiry_date']) ? "'" . sanitize($_POST['expiry_date']) . "'" : "NULL";

    if ($item_name !== '') {
        $inventory_class_value = $has_inventory_class ? "'pharmacy_drugs'," : '';
        $inventory_class_col = $has_inventory_class ? "inventory_class," : '';
        $query = "INSERT INTO inventory_items (
                    item_code, item_name, category, $inventory_class_col description, unit, quantity, reorder_level, unit_price,
                    supplier, expiry_date, drug_type, strength, batch_number
                  ) VALUES (
                    '$item_code', '$item_name', 'Drug', $inventory_class_value 'Pharmacy drug item', 'unit', $quantity, $reorder_level, $unit_price,
                    '$supplier', $expiry_date, '$drug_type', '$strength', '$batch_number'
                  )";
        if (mysqli_query($conn, $query)) {
            $new_item_id = (int)mysqli_insert_id($conn);
            $uid = (int)($_SESSION['user_id'] ?? 0);
            mysqli_query(
                $conn,
                "INSERT INTO inventory_transactions (item_id, transaction_type, quantity, performed_by, notes)
                 VALUES ($new_item_id, 'stock_in', $quantity, $uid, 'Drug item created from pharmacist dashboard')"
            );
            $_SESSION['success'] = "Drug item added to inventory successfully.";
        } else {
            $_SESSION['error'] = "Failed to add drug item: " . mysqli_error($conn);
        }
    } else {
        $_SESSION['error'] = "Drug name is required.";
    }
    redirect('pharmacist_dashboard.php');
}

// Get pending prescriptions
$pending_prescriptions = mysqli_query($conn,
    "SELECT p.*, pt.first_name, pt.last_name, pt.patient_number,
            COUNT(pi.item_id) AS item_count,
            u.full_name as doctor_name
     FROM prescriptions p
     JOIN patients pt ON p.patient_id = pt.patient_id
     JOIN users u ON p.doctor_id = u.user_id
     LEFT JOIN prescription_items pi ON pi.prescription_id = p.prescription_id
     WHERE p.status IN ('sent_to_pharmacy', 'active')
     GROUP BY p.prescription_id
     ORDER BY p.prescription_date"
);

// Get dispensed prescriptions today
$dispensed_date_filter = $has_dispensed_date ? "DATE(p.dispensed_date) = CURDATE()" : "DATE(p.prescription_date) = CURDATE()";
$dispensed_order_by = $has_dispensed_date ? "p.dispensed_date DESC" : "p.prescription_date DESC";
$dispensed_today = mysqli_query($conn,
    "SELECT p.*, pt.first_name, pt.last_name, pt.patient_number
     FROM prescriptions p
     JOIN patients pt ON p.patient_id = pt.patient_id
     WHERE p.status = 'dispensed' 
     AND $dispensed_date_filter
     ORDER BY $dispensed_order_by"
);

// Get low stock alerts
$pharmacy_filter = $has_inventory_class
    ? "(inventory_class='pharmacy_drugs' OR category IN ('Medicine','Drug'))"
    : "category IN ('Medicine','Drug')";

$low_stock = mysqli_query($conn,
    "SELECT * FROM inventory_items 
     WHERE $pharmacy_filter
       AND quantity <= reorder_level
     ORDER BY quantity ASC"
);

$expiring_soon = mysqli_query($conn,
    "SELECT * FROM inventory_items
     WHERE $pharmacy_filter
       AND expiry_date IS NOT NULL
       AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
     ORDER BY expiry_date ASC"
);

$today_stock_out = mysqli_fetch_assoc(mysqli_query(
    $conn,
    "SELECT COUNT(*) AS c FROM inventory_transactions
     WHERE transaction_type IN ('issue','stock_out')
       AND DATE(transaction_date)=CURDATE()"
))['c'] ?? 0;

$recent_inventory_activity = mysqli_query(
    $conn,
    "SELECT it.transaction_date, it.transaction_type, it.quantity, i.item_name
     FROM inventory_transactions it
     JOIN inventory_items i ON i.item_id = it.item_id
     WHERE $pharmacy_filter
     ORDER BY it.transaction_date DESC
     LIMIT 8"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacist Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-pills"></i> Pharmacist Dashboard</h2>
        <p>Welcome, <?php echo $_SESSION['full_name']; ?></p>
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <div class="row mb-3">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <small class="text-muted">Low Stock Items</small>
                        <h4 class="mb-0"><?php echo mysqli_num_rows($low_stock); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <small class="text-muted">Expiring (30 days)</small>
                        <h4 class="mb-0"><?php echo mysqli_num_rows($expiring_soon); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <small class="text-muted">Stock Out Today</small>
                        <h4 class="mb-0"><?php echo (int)$today_stock_out; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3 d-flex align-items-stretch">
                <a href="inventory.php" class="btn btn-outline-primary w-100 d-flex align-items-center justify-content-center">
                    <i class="fas fa-boxes me-2"></i> Open Inventory Management
                </a>
            </div>
        </div>
        
        <div class="row">
            <!-- Pending Prescriptions -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5><i class="fas fa-prescription"></i> Pending Prescriptions</h5>
                        <span class="badge bg-light"><?php echo mysqli_num_rows($pending_prescriptions); ?></span>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($pending_prescriptions) > 0): ?>
                            <div class="list-group">
                                <?php while($rx = mysqli_fetch_assoc($pending_prescriptions)): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo $rx['patient_number']; ?></strong>
                                            <small><?php echo date('d-m-Y H:i', strtotime($rx['prescription_date'])); ?></small>
                                        </div>
                                        <p><?php echo $rx['first_name'] . ' ' . $rx['last_name']; ?></p>
                                        <p><strong>Diagnosis:</strong> <?php echo $rx['diagnosis']; ?></p>
                                        <p><strong>Medicines:</strong> <?php echo (int)$rx['item_count']; ?> item(s)</p>
                                        <p><small>Dr. <?php echo $rx['doctor_name']; ?></small></p>
                                        <button class="btn btn-sm btn-success" onclick="dispensePrescription(<?php echo $rx['prescription_id']; ?>)">
                                            <i class="fas fa-check"></i> Dispense
                                        </button>
                                        <button class="btn btn-sm btn-info" onclick="viewPrescription(<?php echo $rx['prescription_id']; ?>)">
                                            <i class="fas fa-eye"></i> View Details
                                        </button>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No pending prescriptions</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Low Stock Alerts -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h5><i class="fas fa-exclamation-triangle"></i> Low Stock Alerts</h5>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($low_stock) > 0): ?>
                            <div class="list-group">
                                <?php while($item = mysqli_fetch_assoc($low_stock)): ?>
                                    <div class="list-group-item list-group-item-warning">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo $item['item_name']; ?></strong>
                                            <span class="badge bg-danger">Stock: <?php echo $item['quantity']; ?></span>
                                        </div>
                                        <p>Reorder Level: <?php echo $item['reorder_level']; ?></p>
                                        <button class="btn btn-sm btn-primary" onclick="orderStock(<?php echo $item['item_id']; ?>)">
                                            <i class="fas fa-shopping-cart"></i> Order Now
                                        </button>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No low stock alerts</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Today's Dispensed -->
                <div class="card mt-3">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-check-circle"></i> Dispensed Today</h5>
                    </div>
                    <div class="card-body">
                        <?php if(mysqli_num_rows($dispensed_today) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Time</th>
                                            <th>Patient</th>
                                            <th>Prescription #</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($disp = mysqli_fetch_assoc($dispensed_today)): ?>
                                            <tr>
                                                <td><?php echo date('h:i A', strtotime($has_dispensed_date ? $disp['dispensed_date'] : $disp['prescription_date'])); ?></td>
                                                <td><?php echo $disp['first_name'] . ' ' . $disp['last_name']; ?></td>
                                                <td><?php echo $disp['prescription_number']; ?></td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No prescriptions dispensed today</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-stream"></i> Recent Pharmacy Inventory Activity</h5>
                    </div>
                    <div class="card-body">
                        <?php if($recent_inventory_activity && mysqli_num_rows($recent_inventory_activity) > 0): ?>
                            <ul class="list-group list-group-flush">
                                <?php while($act = mysqli_fetch_assoc($recent_inventory_activity)): ?>
                                    <li class="list-group-item px-0">
                                        <strong><?php echo htmlspecialchars($act['item_name']); ?></strong>
                                        <span class="badge bg-secondary ms-2"><?php echo htmlspecialchars(strtoupper($act['transaction_type'])); ?></span>
                                        <div class="small text-muted">
                                            Qty: <?php echo (int)$act['quantity']; ?> |
                                            <?php echo date('d-m-Y H:i', strtotime($act['transaction_date'])); ?>
                                        </div>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">No recent inventory transactions.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if($can_edit_inventory): ?>
        <div class="row mt-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-capsules"></i> Add Drug Directly to Inventory</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="add_drug_item" value="1">
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Drug Name *</label>
                                    <input type="text" class="form-control" name="item_name" required>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Strength</label>
                                    <input type="text" class="form-control" name="strength" placeholder="500mg">
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Drug Type</label>
                                    <select class="form-control" name="drug_type">
                                        <option value="Tablet">Tablet</option>
                                        <option value="Syrup">Syrup</option>
                                        <option value="Injection">Injection</option>
                                        <option value="Capsule">Capsule</option>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Batch #</label>
                                    <input type="text" class="form-control" name="batch_number">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Supplier</label>
                                    <input type="text" class="form-control" name="supplier">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Qty *</label>
                                    <input type="number" class="form-control" name="quantity" min="0" required>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label class="form-label">Reorder</label>
                                    <input type="number" class="form-control" name="reorder_level" min="0" value="10">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unit Price (TZS)</label>
                                    <input type="number" step="0.01" class="form-control" name="unit_price" min="0" value="0">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Expiry Date</label>
                                    <input type="date" class="form-control" name="expiry_date">
                                </div>
                                <div class="col-md-2 mb-3 d-flex align-items-end">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-save"></i> Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        function dispensePrescription(id) {
            window.location.href = 'dispense_prescription.php?id=' + id;
        }
        
        function viewPrescription(id) {
            window.location.href = 'view_prescription.php?id=' + id;
        }
        
        function orderStock(id) {
            window.location.href = 'order_stock.php?item_id=' + id;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
