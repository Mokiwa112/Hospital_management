<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['receptionist', 'nurse']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = getConnection();
    
    // Generate unique patient number
    $patient_number = generateUniqueId('PAT', 'patients', 'patient_number');
    
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $dob = sanitize($_POST['date_of_birth']);
    $gender = sanitize($_POST['gender']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $emergency_contact = sanitize($_POST['emergency_contact']);
    $emergency_name = sanitize($_POST['emergency_name']);
    $blood_group = sanitize($_POST['blood_group']);
    $allergies = sanitize($_POST['allergies']);
    $patient_type = sanitize($_POST['patient_type']);
    $insurance_provider = !empty($_POST['insurance_provider']) ? $_POST['insurance_provider'] : 'NULL';
    $policy_number = sanitize($_POST['policy_number'] ?? '');

    if (!isValidPhoneNumber($phone)) {
        $_SESSION['error'] = getPhoneValidationMessage();
    } elseif (!empty($emergency_contact) && !isValidPhoneNumber($emergency_contact)) {
        $_SESSION['error'] = "Emergency contact: " . getPhoneValidationMessage();
    } else {
    
        $query = "INSERT INTO patients (patient_number, first_name, last_name, date_of_birth, 
                  gender, phone, email, address, emergency_contact, emergency_contact_name, 
                  blood_group, allergies, patient_type, insurance_provider_id, insurance_policy_number, created_by) 
                  VALUES ('$patient_number', '$first_name', '$last_name', '$dob', '$gender', 
                  '$phone', '$email', '$address', '$emergency_contact', '$emergency_name', 
                  '$blood_group', '$allergies', '$patient_type', $insurance_provider, '$policy_number', {$_SESSION['user_id']})";
    
        if (mysqli_query($conn, $query)) {
            $patient_id = mysqli_insert_id($conn);

            if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $subject = SITE_NAME . " - Patient Portal Access Details";
                $message = "Hello " . $first_name . " " . $last_name . ",\n\n"
                         . "Your patient account has been registered successfully.\n"
                         . "Patient Number: " . $patient_number . "\n"
                         . "Date of Birth: " . $dob . "\n\n"
                         . "How to login:\n"
                         . "1. Open: " . SITE_URL . "/patient_portal.php\n"
                         . "2. Use Patient Number and Date of Birth.\n\n"
                         . "Keep these details safely.\n\n"
                         . SITE_NAME;
                @send_system_email($email, $subject, $message);
            }

            $_SESSION['success'] = "Patient registered successfully! Patient Number: $patient_number";
            redirect("view_patient.php?id=$patient_id");
        } else {
            $_SESSION['error'] = "Error: " . mysqli_error($conn);
        }
    }
    
    mysqli_close($conn);
}

// Fetch insurance providers for dropdown
$conn = getConnection();
$providers = mysqli_query($conn, "SELECT * FROM insurance_providers ORDER BY provider_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .registration-form {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        .type-selector {
            display: flex;
            gap: 20px;
            margin: 20px 0;
        }
        .type-card {
            flex: 1;
            padding: 20px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            cursor: pointer;
            text-align: center;
            transition: all 0.3s;
        }
        .type-card.selected {
            border-color: #0d6efd;
            background-color: #f0f8ff;
        }
        .type-card i {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .type-card h5 {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container">
        <div class="registration-form">
            <h2 class="text-center mb-4"><i class="fas fa-user-plus"></i> Patient Registration</h2>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            
            <form method="POST" id="patientForm" onsubmit="return validateForm()">
                <!-- Patient Type Selection -->
                <div class="mb-4">
                    <label class="form-label fw-bold">Patient Type *</label>
                    <div class="type-selector">
                        <div class="type-card <?php echo (isset($_POST['patient_type']) && $_POST['patient_type'] == 'outpatient') ? 'selected' : ''; ?>" 
                             onclick="selectType('outpatient')" id="outpatient-card">
                            <i class="fas fa-user"></i>
                            <h5>Out Patient</h5>
                            <small>Visits for consultation</small>
                        </div>
                        <div class="type-card <?php echo (isset($_POST['patient_type']) && $_POST['patient_type'] == 'inpatient') ? 'selected' : ''; ?>" 
                             onclick="selectType('inpatient')" id="inpatient-card">
                            <i class="fas fa-procedures"></i>
                            <h5>In Patient</h5>
                            <small>Requires admission</small>
                        </div>
                    </div>
                    <input type="hidden" name="patient_type" id="patient_type" required>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">First Name *</label>
                        <input type="text" class="form-control" name="first_name" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Last Name *</label>
                        <input type="text" class="form-control" name="last_name" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Date of Birth *</label>
                        <input type="text" class="form-control" name="date_of_birth" id="date_of_birth"
                               required placeholder="YYYY-MM-DD">
                        <small class="text-muted">Chagua kwenye kalenda au andika moja kwa moja (mfano: 1980-04-19)</small>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Gender *</label>
                        <select class="form-control" name="gender" required>
                            <option value="">Select Gender</option>
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                            <option value="O">Other</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Blood Group</label>
                        <select class="form-control" name="blood_group">
                            <option value="">Select</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Phone *</label>
                        <input type="tel" class="form-control" name="phone" required
                               pattern="^(0\d{9}|\+\d{11,12})$"
                               title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <textarea class="form-control" name="address" rows="2"></textarea>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Emergency Contact</label>
                        <input type="tel" class="form-control" name="emergency_contact"
                               pattern="^(0\d{9}|\+\d{11,12})$"
                               title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Emergency Contact Name</label>
                        <input type="text" class="form-control" name="emergency_name">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Allergies/Medical History</label>
                    <textarea class="form-control" name="allergies" rows="2"></textarea>
                </div>
                
                <div class="insurance-section">
                    <h5 class="mb-3">Insurance Information</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Insurance Provider</label>
                            <select class="form-control" name="insurance_provider" id="insurance_provider">
                                <option value="">None</option>
                                <?php while($provider = mysqli_fetch_assoc($providers)): ?>
                                    <option value="<?php echo $provider['provider_id']; ?>">
                                        <?php echo $provider['provider_name']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Policy Number</label>
                            <input type="text" class="form-control" name="policy_number" id="policy_number">
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Register Patient
                    </button>
                    <button type="reset" class="btn btn-secondary btn-lg">
                        <i class="fas fa-undo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    
    <script>
        // Patient type selection
        function selectType(type) {
            document.getElementById('patient_type').value = type;
            
            if (type === 'outpatient') {
                document.getElementById('outpatient-card').classList.add('selected');
                document.getElementById('inpatient-card').classList.remove('selected');
            } else {
                document.getElementById('inpatient-card').classList.add('selected');
                document.getElementById('outpatient-card').classList.remove('selected');
            }
        }
        
        // Form validation
        function validateForm() {
            const patientType = document.getElementById('patient_type').value;
            if (!patientType) {
                alert('Please select patient type');
                return false;
            }
            
            const phone = document.querySelector('input[name="phone"]').value;
            if (!/^(0\d{9}|\+\d{11,12})$/.test(phone)) {
                alert('Phone number must be 10 digits starting with 0, or start with + followed by 11-12 digits');
                return false;
            }

            const emergencyPhoneField = document.querySelector('input[name="emergency_contact"]');
            if (emergencyPhoneField.value && !/^(0\d{9}|\+\d{11,12})$/.test(emergencyPhoneField.value)) {
                alert('Emergency contact must be 10 digits starting with 0, or start with + followed by 11-12 digits');
                return false;
            }
            
            return true;
        }
        
        // Auto-capitalize name fields
        document.querySelector('input[name="first_name"]').addEventListener('input', function(e) {
            this.value = this.value.toUpperCase();
        });
        
        document.querySelector('input[name="last_name"]').addEventListener('input', function(e) {
            this.value = this.value.toUpperCase();
        });
        
        // Calculate age from DOB
        document.querySelector('input[name="date_of_birth"]').addEventListener('change', function() {
            const dob = new Date(this.value);
            if (isNaN(dob.getTime())) {
                alert('Tafadhali tumia format ya tarehe: YYYY-MM-DD');
                this.value = '';
                return;
            }
            const today = new Date();
            let age = today.getFullYear() - dob.getFullYear();
            const m = today.getMonth() - dob.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
                age--;
            }
            if (age > 150) {
                alert('Please enter a valid date of birth');
                this.value = '';
            }
        });
        
        // Insurance provider dependency
        document.getElementById('insurance_provider').addEventListener('change', function() {
            const policyInput = document.getElementById('policy_number');
            if (this.value) {
                policyInput.required = true;
                policyInput.setAttribute('required', 'required');
            } else {
                policyInput.required = false;
                policyInput.removeAttribute('required');
            }
        });
        
        // Live search for insurance provider
        $('#insurance_provider').select2({
            placeholder: 'Search insurance provider...',
            allowClear: true,
            width: '100%'
        });

        // Calendar with manual typing enabled for faster old-date entry
        flatpickr('#date_of_birth', {
            dateFormat: 'Y-m-d',
            allowInput: true,
            maxDate: 'today',
            defaultDate: null
        });
    </script>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</body>
</html>

