<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);
$now = new DateTime('now');
$today = $now->format('Y-m-d');
$yesterday = (new DateTime('yesterday'))->format('Y-m-d');

function shiftWindowDetails(array $row): array {
    $start = new DateTime($row['shift_date'] . ' ' . $row['start_time']);
    $end = new DateTime($row['shift_date'] . ' ' . $row['end_time']);
    if ((int)($row['is_overnight'] ?? 0) === 1 || $end <= $start) {
        $end->modify('+1 day');
    }

    $checkin_open = clone $start;
    $checkin_open->modify('-2 hours');
    $checkout_close = clone $end;
    $checkout_close->modify('+4 hours');

    $row['scheduled_start_obj'] = $start;
    $row['scheduled_end_obj'] = $end;
    $row['checkin_open_obj'] = $checkin_open;
    $row['checkout_close_obj'] = $checkout_close;
    return $row;
}

function getApplicableShift(mysqli $conn, int $user_id, DateTime $now, string $today, string $yesterday): ?array {
    $query = "SELECT usa.assignment_id, usa.shift_date, sd.shift_id, sd.shift_name, sd.shift_code, sd.start_time, sd.end_time, sd.is_overnight
              FROM user_shift_assignments usa
              JOIN shift_definitions sd ON sd.shift_id = usa.shift_id
              WHERE usa.user_id = $user_id
                AND usa.shift_date IN ('$today', '$yesterday')
              ORDER BY usa.shift_date DESC, sd.start_time DESC";
    $res = mysqli_query($conn, $query);
    if (!$res) {
        return null;
    }

    while ($row = mysqli_fetch_assoc($res)) {
        $row = shiftWindowDetails($row);
        $within_window = ($now >= $row['checkin_open_obj'] && $now <= $row['checkout_close_obj']);
        $can_check_in = ($now >= $row['checkin_open_obj'] && $now <= $row['scheduled_end_obj']);
        if ($within_window) {
            $row['within_window'] = true;
            $row['can_check_in'] = $can_check_in;
            return $row;
        }
    }
    return null;
}

$user_info = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT employee_id, department FROM users WHERE user_id = $user_id")
) ?: ['employee_id' => 'N/A', 'department' => 'N/A'];

$today_shift = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT usa.shift_date, sd.shift_name, sd.shift_code, sd.start_time, sd.end_time, sd.is_overnight
         FROM user_shift_assignments usa
         JOIN shift_definitions sd ON sd.shift_id = usa.shift_id
         WHERE usa.user_id = $user_id AND usa.shift_date = '$today'
         LIMIT 1"
    )
);

$next_shift = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT usa.shift_date, sd.shift_name, sd.shift_code, sd.start_time, sd.end_time, sd.is_overnight
         FROM user_shift_assignments usa
         JOIN shift_definitions sd ON sd.shift_id = usa.shift_id
         WHERE usa.user_id = $user_id AND usa.shift_date >= '$today'
         ORDER BY usa.shift_date ASC, sd.start_time ASC
         LIMIT 1"
    )
);

$applicable_shift = getApplicableShift($conn, $user_id, $now, $today, $yesterday);

$open_attendance = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT a.*, sd.shift_name, sd.shift_code, sd.start_time, sd.end_time
         FROM attendance a
         LEFT JOIN shift_definitions sd ON sd.shift_id = a.shift_id
         WHERE a.user_id = $user_id AND a.check_out IS NULL
         ORDER BY a.date DESC
         LIMIT 1"
    )
);

$today_record = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT a.*, sd.shift_name, sd.shift_code, sd.start_time, sd.end_time
         FROM attendance a
         LEFT JOIN shift_definitions sd ON sd.shift_id = a.shift_id
         WHERE a.user_id = $user_id AND a.date = '$today'
         ORDER BY a.attendance_id DESC
         LIMIT 1"
    )
);

$current_record = $open_attendance ?: $today_record;

if (isset($_POST['check_in'])) {
    if ($open_attendance) {
        $_SESSION['error'] = "You already have an open attendance record. Please check out first.";
        redirect('worker_attendance.php');
    }
    if (!$applicable_shift) {
        $_SESSION['error'] = "No active shift window now. Check your assigned shift and time.";
        redirect('worker_attendance.php');
    }
    if (empty($applicable_shift['can_check_in'])) {
        $_SESSION['error'] = "Check-in window for this shift is closed.";
        redirect('worker_attendance.php');
    }

    $attendance_date = $applicable_shift['shift_date'];
    $time = $now->format('H:i:s');
    $late_cutoff = clone $applicable_shift['scheduled_start_obj'];
    $late_cutoff->modify('+15 minutes');
    $status = ($now > $late_cutoff) ? 'late' : 'present';
    $scheduled_start = $applicable_shift['scheduled_start_obj']->format('Y-m-d H:i:s');
    $scheduled_end = $applicable_shift['scheduled_end_obj']->format('Y-m-d H:i:s');
    $shift_id = (int)$applicable_shift['shift_id'];

    $query = "INSERT INTO attendance (user_id, shift_id, date, check_in, status, scheduled_start, scheduled_end, requires_approval, approval_status)
              VALUES ($user_id, $shift_id, '$attendance_date', '$time', '$status', '$scheduled_start', '$scheduled_end', 1, 'pending')";
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Checked in successfully at " . $now->format('h:i A') . " for " . $applicable_shift['shift_name'] . ".";
        app_log_action($user_id, 'attendance_check_in');
    } else {
        $_SESSION['error'] = "Check-in failed: " . mysqli_error($conn);
    }
    redirect('worker_attendance.php');
}

if (isset($_POST['check_out'])) {
    if (!$open_attendance) {
        $_SESSION['error'] = "No open attendance record found for check-out.";
        redirect('worker_attendance.php');
    }

    $time = $now->format('H:i:s');
    $check_in_dt = new DateTime($open_attendance['date'] . ' ' . $open_attendance['check_in']);
    $check_out_dt = clone $now;
    if ($check_out_dt < $check_in_dt) {
        $check_out_dt->modify('+1 day');
    }
    $hours_worked = round(($check_out_dt->getTimestamp() - $check_in_dt->getTimestamp()) / 3600, 2);
    $overtime = max(0, $hours_worked - 8);
    $attendance_id = (int)$open_attendance['attendance_id'];

    $query = "UPDATE attendance
              SET check_out = '$time',
                  overtime_hours = $overtime
              WHERE attendance_id = $attendance_id";
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Checked out at " . $now->format('h:i A') . ". Total hours: " . $hours_worked;
        app_log_action($user_id, 'attendance_check_out');
    } else {
        $_SESSION['error'] = "Check-out failed: " . mysqli_error($conn);
    }
    redirect('worker_attendance.php');
}

$history = mysqli_query(
    $conn,
    "SELECT a.*, sd.shift_name, sd.shift_code
     FROM attendance a
     LEFT JOIN shift_definitions sd ON sd.shift_id = a.shift_id
     WHERE a.user_id = $user_id
     ORDER BY a.date DESC, a.check_in DESC
     LIMIT 10"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .attendance-card {
            max-width: 760px;
            margin: 20px auto;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            background: white;
        }
        .time-display {
            font-size: 44px;
            font-weight: bold;
            text-align: center;
            margin: 10px 0;
            color: #333;
            font-family: monospace;
        }
        .date-display {
            font-size: 16px;
            text-align: center;
            color: #666;
            margin-bottom: 20px;
        }
        .info-box {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 12px;
        }
        .status-pending { background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; text-align: center; }
        .status-approved { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; text-align: center; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
    <div class="attendance-card">
        <h2 class="text-center mb-3"><i class="fas fa-clock"></i> Daily Attendance</h2>
        <div class="time-display" id="currentTime"></div>
        <div class="date-display" id="currentDate"></div>

        <div class="info-box">
            <div class="row">
                <div class="col-md-6">
                    <strong><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['full_name']); ?></strong><br>
                    <small>Employee ID: <?php echo htmlspecialchars($user_info['employee_id'] ?? 'N/A'); ?></small><br>
                    <small>Department: <?php echo htmlspecialchars($user_info['department'] ?? 'N/A'); ?></small>
                </div>
                <div class="col-md-6">
                    <?php if ($today_shift): ?>
                        <strong>Today's Shift:</strong> <?php echo htmlspecialchars($today_shift['shift_name']); ?> (<?php echo htmlspecialchars($today_shift['shift_code']); ?>)<br>
                        <small>Time: <?php echo substr($today_shift['start_time'], 0, 5); ?> - <?php echo substr($today_shift['end_time'], 0, 5); ?><?php echo ((int)$today_shift['is_overnight'] === 1) ? ' (Overnight)' : ''; ?></small>
                    <?php elseif ($next_shift): ?>
                        <strong>Next Shift:</strong> <?php echo htmlspecialchars($next_shift['shift_name']); ?> on <?php echo date('d-m-Y', strtotime($next_shift['shift_date'])); ?><br>
                        <small>Time: <?php echo substr($next_shift['start_time'], 0, 5); ?> - <?php echo substr($next_shift['end_time'], 0, 5); ?></small>
                    <?php else: ?>
                        <strong>No shift assignment found</strong><br>
                        <small class="text-muted">Contact admin for shift assignment.</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!$current_record): ?>
            <?php if ($applicable_shift): ?>
                <div class="alert alert-info">
                    Current shift window: <strong><?php echo htmlspecialchars($applicable_shift['shift_name']); ?></strong>
                    (<?php echo $applicable_shift['scheduled_start_obj']->format('d-m-Y H:i'); ?> to <?php echo $applicable_shift['scheduled_end_obj']->format('d-m-Y H:i'); ?>)
                </div>
                <form method="POST">
                    <button type="submit" name="check_in" class="btn btn-success btn-lg w-100">
                        <i class="fas fa-sign-in-alt"></i> Check In
                    </button>
                </form>
            <?php else: ?>
                <div class="alert alert-warning">
                    You are outside your shift check-in window or no shift is assigned for now.
                </div>
            <?php endif; ?>
        <?php elseif (empty($current_record['check_out'])): ?>
            <div class="alert alert-info">
                <strong>Checked in at:</strong> <?php echo date('h:i A', strtotime($current_record['check_in'])); ?><br>
                <strong>Shift:</strong> <?php echo htmlspecialchars($current_record['shift_name'] ?: 'N/A'); ?>
                <?php if (($current_record['status'] ?? '') === 'late'): ?>
                    <span class="badge bg-warning ms-2">Late</span>
                <?php endif; ?>
            </div>

            <?php if (($current_record['approval_status'] ?? '') === 'pending'): ?>
                <div class="status-pending mb-3"><i class="fas fa-clock"></i> Waiting for admin approval</div>
            <?php elseif (($current_record['approval_status'] ?? '') === 'approved'): ?>
                <div class="status-approved mb-3"><i class="fas fa-check-circle"></i> Approved by admin</div>
            <?php endif; ?>

            <form method="POST">
                <button type="submit" name="check_out" class="btn btn-danger btn-lg w-100" onclick="return confirm('Are you sure you want to check out?')">
                    <i class="fas fa-sign-out-alt"></i> Check Out
                </button>
            </form>
        <?php else: ?>
            <div class="alert alert-success">
                <strong>Attendance Completed</strong><br>
                Shift: <?php echo htmlspecialchars($current_record['shift_name'] ?: 'N/A'); ?><br>
                Check In: <?php echo date('h:i A', strtotime($current_record['check_in'])); ?><br>
                Check Out: <?php echo date('h:i A', strtotime($current_record['check_out'])); ?>
                <?php if ((float)$current_record['overtime_hours'] > 0): ?>
                    <br><strong>Overtime:</strong> <?php echo round((float)$current_record['overtime_hours'], 2); ?> hours
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="mt-3 mb-2">
            <a href="leave_request.php" class="btn btn-outline-warning btn-sm">
                <i class="fas fa-calendar-minus"></i> Request Leave
            </a>
            <a href="attendance_history.php" class="btn btn-outline-primary btn-sm">
                <i class="fas fa-history"></i> Full Attendance History
            </a>
        </div>

        <hr class="my-3">
        <h5 class="mb-3">Recent Attendance</h5>
        <div class="table-responsive">
            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Shift</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Approval</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($history && mysqli_num_rows($history) > 0): ?>
                        <?php while ($record = mysqli_fetch_assoc($history)): ?>
                            <tr>
                                <td><?php echo date('d-m-Y', strtotime($record['date'])); ?></td>
                                <td><?php echo htmlspecialchars($record['shift_code'] ?: '-'); ?></td>
                                <td><?php echo !empty($record['check_in']) ? date('h:i A', strtotime($record['check_in'])) : '-'; ?></td>
                                <td><?php echo !empty($record['check_out']) ? date('h:i A', strtotime($record['check_out'])) : '-'; ?></td>
                                <td>
                                    <?php
                                    $approval = $record['approval_status'] ?? 'pending';
                                    $badge = $approval === 'approved' ? 'success' : ($approval === 'rejected' ? 'danger' : 'warning');
                                    ?>
                                    <span class="badge bg-<?php echo $badge; ?>"><?php echo ucfirst($approval); ?></span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center text-muted">No attendance history</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    const dateString = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    document.getElementById('currentTime').textContent = timeString;
    document.getElementById('currentDate').textContent = dateString;
}
updateTime();
setInterval(updateTime, 1000);
</script>
</body>
</html>
