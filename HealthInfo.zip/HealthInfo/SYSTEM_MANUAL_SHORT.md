# Hospital Management System - Quick User Manual

## 1. Login Access
- Staff login: `http://localhost/HealthInfo/login.php`
- Patient portal: `http://localhost/HealthInfo/patient_portal.php`
- Staff users log in with `username + password`.
- Patients log in with `Patient Number + Date of Birth`.
- After login, users are redirected to their role-specific dashboard.

## 2. User Roles and Responsibilities
### 2.1 Staff Roles
- `admin`
Main responsibilities: full system administration, user management, reports, settings, and backup control.
- `doctor`
Main responsibilities: patient consultation, lab test requests, prescription writing, and lab result review.
- `nurse`
Main responsibilities: patient care support, inpatient follow-up, and attendance-related tasks.
- `receptionist`
Main responsibilities: patient registration, appointment scheduling, and front-desk coordination.
- `lab_tech`
Main responsibilities: laboratory request processing, sample handling, and result entry.
- `pharmacist`
Main responsibilities: dispensing prescriptions and monitoring medicine inventory.
- `accountant`
Main responsibilities: billing, payment processing, and insurance claim tracking.
- `hr_admin`
Main responsibilities: attendance approvals, shift management, leave management, and staff records.

### 2.2 Patient Role
- `patient`
Main responsibilities: access personal profile, appointments, lab results, prescriptions, and billing history.

## 3. Core Modules
- `Patients`
Patient registration, profile updates, and medical history records.
- `Appointments`
Appointment booking, rescheduling, and status tracking (`scheduled`, `in_progress`, `completed`, `cancelled`, `no_show`).
- `Laboratory`
Lab request creation, sample collection, test processing, and result review.
- `Pharmacy & Inventory`
Prescription dispensing, stock tracking, low-stock alerts, and inventory updates.
- `Billing & Insurance`
Bill generation, payment status management, and insurance claim workflows.
- `HR`
Attendance, shifts, leave requests/approvals, and staff operations.
- `Reports`
Operational and financial reports for monitoring service performance.

## 4. Standard Service Workflow
1. Receptionist registers the patient and schedules an appointment.
2. Doctor consults the patient and requests lab tests or writes prescriptions if required.
3. Lab technician processes tests and submits results.
4. Doctor reviews results and finalizes treatment.
5. Pharmacist dispenses prescribed medicine.
6. Accountant processes billing and payment/insurance records.
7. Admin/HR monitor compliance, staffing, and system operations.

## 5. Credentials and Data Reset Reference
- Staff credentials file: `all_user_logins.txt`
- Staff/patient reset script: `reset_staff_users.sql`
- Sample seed file: `seed_database.php`

## 6. Security Guidelines
- Use only your own account.
- Change passwords regularly through `change_password.php`.
- Always log out after use.
- Do not share credentials.
- Admin should run regular backups through `backup.php`.
