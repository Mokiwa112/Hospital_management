<?php
require_once 'config.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    redirect(getRoleHomePage());
}

$conn = getConnection();
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    // Industrial standard: prepared statement + generic auth message
    $stmt = mysqli_prepare($conn, "SELECT user_id, username, password, full_name, user_type, employee_id FROM users WHERE username = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $check_result = mysqli_stmt_get_result($stmt);

    if ($check_result && mysqli_num_rows($check_result) == 1) {
        $user = mysqli_fetch_assoc($check_result);
        if (password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['employee_id'] = $user['employee_id'];
            
            app_log_action((int)$user['user_id'], 'login');
            
            redirect(getRoleHomePage($user['user_type']));
        } else {
            $error = "Invalid username or password";
        }
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(145deg, #eaf1f7 0%, #dfe8f2 55%, #e9eff6 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-container {
            max-width: 450px;
            width: 100%;
            padding: 20px;
        }
        .login-card {
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 14px 36px rgba(24, 45, 72, 0.16);
            overflow: hidden;
        }
        .login-header {
            background: linear-gradient(140deg, #2f5f9e 0%, #2f7a6a 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .login-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .login-header p {
            margin: 10px 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        .login-body {
            padding: 40px 30px;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        .form-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6b7280;
            z-index: 10;
        }
        .form-control {
            padding-left: 45px;
            height: 50px;
            border-radius: 25px;
            border: 1px solid #cfd8e3;
            font-size: 14px;
            background: #fbfdff;
            color: #1f2937;
        }
        .form-control:focus {
            box-shadow: none;
            border-color: #2f5f9e;
            background: #ffffff;
        }
        .btn-login {
            background: linear-gradient(140deg, #2f5f9e 0%, #276f8d 100%);
            border: none;
            color: white;
            height: 50px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 7px 18px rgba(47, 95, 158, 0.28);
        }
        .info-box {
            margin-top: 30px;
            background: #f4f8fc;
            border: 1px solid #d7e2ee;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
        }
        .info-box p {
            margin-bottom: 10px;
            color: #475569;
        }
        .info-box a {
            color: #2f5f9e;
            text-decoration: none;
            font-weight: 600;
        }
        .info-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <i class="fas fa-hospital-alt fa-3x mb-3"></i>
                <h2>Welcome to <?php echo SITE_NAME; ?></h2>
                <p>Please sign in with your credentials</p>
            </div>
            
            <div class="login-body">
                <?php if($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="loginForm">
                    <div class="form-group">
                        <i class="fas fa-user"></i>
                        <input type="text" class="form-control" name="username" placeholder="Username" required autofocus>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" class="form-control" name="password" placeholder="Password" required>
                    </div>
                    
                    <button type="submit" class="btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i> Sign In
                    </button>
                </form>
                
                <div class="info-box">
                    <p><i class="fas fa-info-circle text-info"></i> For authorized personnel only</p>
                    <p class="mb-0">
                        <a href="patient_portal.php">
                            <i class="fas fa-user"></i> Patient Portal
                        </a>
                        <span class="mx-2">|</span>
                        <a href="index.php">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.querySelector('.btn-login');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
            btn.disabled = true;
        });
    </script>
</body>
</html>
