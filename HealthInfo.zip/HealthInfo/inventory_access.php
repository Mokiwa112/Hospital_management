<?php
require_once 'config.php';
requireRole('admin');
redirect('inventory.php?access=1');

$conn = getConnection();
$admin_id = (int)($_SESSION['user_id'] ?? 0);

// Ensure access table exists (safe if already created by migration)
$create_table_sql = "CREATE TABLE IF NOT EXISTS inventory_user_access (
    access_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    can_view TINYINT(1) NOT NULL DEFAULT 1,
    can_edit TINYINT(1) NOT NULL DEFAULT 0,
    granted_by INT DEFAULT NULL,
    granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_inventory_access_user (user_id),
    KEY idx_inventory_access_edit (can_edit),
    CONSTRAINT fk_inventory_access_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_inventory_access_granted_by FOREIGN KEY (granted_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
@mysqli_query($conn, $create_table_sql);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_users = $_POST['users'] ?? [];
    $view_access = $_POST['can_view'] ?? [];
    $edit_access = $_POST['can_edit'] ?? [];

    mysqli_begin_transaction($conn);
    try {
        // Clear non-admin grants first, then reinsert selected rows.
        mysqli_query($conn, "DELETE ia FROM inventory_user_access ia
                             INNER JOIN users u ON ia.user_id = u.user_id
                             WHERE u.user_type <> 'admin'");

        foreach ($submitted_users as $uid_raw) {
            $uid = (int)$uid_raw;
            if ($uid <= 0) continue;

            $can_view = isset($view_access[$uid]) ? 1 : 0;
            $can_edit = isset($edit_access[$uid]) ? 1 : 0;
            if ($can_edit === 1) {
                $can_view = 1; // edit implies view
            }

            if ($can_view === 0 && $can_edit === 0) {
                continue;
            }

            $q = "INSERT INTO inventory_user_access (user_id, can_view, can_edit, granted_by)
                  VALUES ($uid, $can_view, $can_edit, $admin_id)";
            mysqli_query($conn, $q);
        }

        mysqli_commit($conn);
        $_SESSION['success'] = "Inventory access rights updated successfully.";
        redirect('inventory_access.php');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error = "Failed to save access rights.";
    }
}

$users_rs = mysqli_query(
    $conn,
    "SELECT u.user_id, u.full_name, u.username, u.user_type, u.department, u.employee_id,
            COALESCE(a.can_view, 0) AS can_view,
            COALESCE(a.can_edit, 0) AS can_edit
     FROM users u
     LEFT JOIN inventory_user_access a ON a.user_id = u.user_id
     WHERE u.user_type <> 'admin'
     ORDER BY u.user_type, u.full_name"
);

$success = $_SESSION['success'] ?? '';
unset($_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Access - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container-fluid mt-4">
    <div class="card">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-user-shield"></i> Inventory Access Management</h5>
            <a href="inventory.php" class="btn btn-light btn-sm">
                <i class="fas fa-boxes"></i> Open Inventory
            </a>
        </div>
        <div class="card-body">
            <?php if (!empty($success)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <div class="alert alert-info">
                <strong>How it works:</strong>
                `View` allows opening inventory pages. `Edit` allows adding items and changing stock.
            </div>

            <form method="POST">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>User</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th style="width: 120px;">View</th>
                                <th style="width: 120px;">Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($users_rs && mysqli_num_rows($users_rs) > 0): ?>
                                <?php while ($u = mysqli_fetch_assoc($users_rs)): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($u['full_name']); ?></strong><br>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($u['username']); ?> |
                                                <?php echo htmlspecialchars($u['employee_id']); ?>
                                            </small>
                                        </td>
                                        <td><?php echo htmlspecialchars(ucfirst($u['user_type'])); ?></td>
                                        <td><?php echo htmlspecialchars($u['department'] ?? 'N/A'); ?></td>
                                        <td class="text-center">
                                            <input type="hidden" name="users[]" value="<?php echo (int)$u['user_id']; ?>">
                                            <input class="form-check-input view-check" type="checkbox"
                                                   name="can_view[<?php echo (int)$u['user_id']; ?>]"
                                                   <?php echo ((int)$u['can_view'] === 1) ? 'checked' : ''; ?>>
                                        </td>
                                        <td class="text-center">
                                            <input class="form-check-input edit-check" type="checkbox"
                                                   data-user="<?php echo (int)$u['user_id']; ?>"
                                                   name="can_edit[<?php echo (int)$u['user_id']; ?>]"
                                                   <?php echo ((int)$u['can_edit'] === 1) ? 'checked' : ''; ?>>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted">No users found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Access Rights
                </button>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.edit-check').forEach(function(editCb) {
    editCb.addEventListener('change', function() {
        var uid = editCb.getAttribute('data-user');
        var viewCb = document.querySelector('input[name="can_view[' + uid + ']"]');
        if (editCb.checked && viewCb) {
            viewCb.checked = true;
        }
    });
});
</script>
</body>
</html>
