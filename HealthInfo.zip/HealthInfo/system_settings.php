<?php
require_once 'config.php';
requireRole('admin');

$settings_file = __DIR__ . '/settings.json';
$defaults = [
    'timezone' => 'Africa/Dar_es_Salaam',
    'currency' => 'TZS',
    'currency_symbol' => 'TSh',
    'backup_path' => __DIR__ . '/backups/',
    'auto_backup' => false,
    'backup_frequency' => 'daily',
    'retain_backups' => 30,
    'auto_billing_uninsured' => true
];

$settings = $defaults;
if (file_exists($settings_file)) {
    $decoded = json_decode(file_get_contents($settings_file), true);
    if (is_array($decoded)) {
        $settings = array_merge($defaults, $decoded);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $timezone = sanitize($_POST['timezone'] ?? $defaults['timezone']);
    $currency = strtoupper(sanitize($_POST['currency'] ?? $defaults['currency']));
    $currency_symbol = sanitize($_POST['currency_symbol'] ?? $defaults['currency_symbol']);
    $backup_frequency = sanitize($_POST['backup_frequency'] ?? $defaults['backup_frequency']);
    $retain_backups = (int)($_POST['retain_backups'] ?? $defaults['retain_backups']);
    $auto_backup = isset($_POST['auto_backup']);
    $auto_billing_uninsured = isset($_POST['auto_billing_uninsured']);

    $backup_path_input = trim($_POST['backup_path'] ?? $defaults['backup_path']);
    $backup_path = $backup_path_input === '' ? $defaults['backup_path'] : $backup_path_input;

    if (!in_array($backup_frequency, ['daily', 'weekly', 'monthly'], true)) {
        $backup_frequency = 'daily';
    }
    if ($retain_backups < 1) {
        $retain_backups = 1;
    }

    if (!in_array($timezone, timezone_identifiers_list(), true)) {
        $timezone = $defaults['timezone'];
    }

    $new_settings = [
        'timezone' => $timezone,
        'currency' => $currency ?: $defaults['currency'],
        'currency_symbol' => $currency_symbol ?: $defaults['currency_symbol'],
        'backup_path' => rtrim($backup_path, "\\/") . DIRECTORY_SEPARATOR,
        'auto_backup' => $auto_backup,
        'backup_frequency' => $backup_frequency,
        'retain_backups' => $retain_backups,
        'auto_billing_uninsured' => $auto_billing_uninsured
    ];

    if (!is_dir($new_settings['backup_path'])) {
        @mkdir($new_settings['backup_path'], 0777, true);
    }

    $saved = file_put_contents($settings_file, json_encode($new_settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    if ($saved !== false) {
        $_SESSION['success'] = "System settings updated successfully";
        redirect('system_settings.php');
    } else {
        $error = "Failed to save settings. Check file permissions.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3><i class="fas fa-cog"></i> System Settings</h3>
            <a href="backup.php" class="btn btn-outline-primary">
                <i class="fas fa-database"></i> Go to Backup Manager
            </a>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Timezone</label>
                        <select class="form-control" name="timezone" required>
                            <?php
                            $common_zones = ['Africa/Dar_es_Salaam', 'UTC', 'America/New_York', 'Europe/London', 'Asia/Dubai'];
                            foreach ($common_zones as $zone):
                            ?>
                                <option value="<?php echo $zone; ?>" <?php echo $settings['timezone'] === $zone ? 'selected' : ''; ?>>
                                    <?php echo $zone; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Currency Code</label>
                        <input type="text" class="form-control" name="currency" maxlength="6" value="<?php echo htmlspecialchars($settings['currency']); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Currency Symbol</label>
                        <input type="text" class="form-control" name="currency_symbol" maxlength="8" value="<?php echo htmlspecialchars($settings['currency_symbol']); ?>" required>
                    </div>

                    <div class="col-md-8">
                        <label class="form-label">Backup Path</label>
                        <input type="text" class="form-control" name="backup_path" value="<?php echo htmlspecialchars($settings['backup_path']); ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Frequency</label>
                        <select class="form-control" name="backup_frequency" required>
                            <option value="daily" <?php echo $settings['backup_frequency'] === 'daily' ? 'selected' : ''; ?>>Daily</option>
                            <option value="weekly" <?php echo $settings['backup_frequency'] === 'weekly' ? 'selected' : ''; ?>>Weekly</option>
                            <option value="monthly" <?php echo $settings['backup_frequency'] === 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Retain (days)</label>
                        <input type="number" class="form-control" name="retain_backups" min="1" value="<?php echo (int)$settings['retain_backups']; ?>" required>
                    </div>

                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="auto_backup" id="auto_backup" <?php echo !empty($settings['auto_backup']) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="auto_backup">Enable automatic backups</label>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="auto_billing_uninsured" id="auto_billing_uninsured" <?php echo !empty($settings['auto_billing_uninsured']) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="auto_billing_uninsured">
                                Enable automatic billing for uninsured patients after treatment completion
                            </label>
                        </div>
                    </div>

                    <div class="col-12">
                        <button type="submit" name="save_settings" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
