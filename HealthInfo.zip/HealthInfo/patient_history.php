<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor', 'nurse', 'receptionist']);

$conn = getConnection();
$patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

if ($patient_id == 0) {
    header("Location: patients.php");
    exit();
}

// Fetch patient details
$patient_query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$patient_result = mysqli_query($conn, $patient_query);

if (!$patient_result || mysqli_num_rows($patient_result) == 0) {
    header("Location: patients.php");
    exit();
}

$patient = mysqli_fetch_assoc($patient_result);

// Fetch appointments
$appointments = mysqli_query($conn,
    "SELECT a.*, u.full_name as doctor_name, u.department
     FROM appointments a
     JOIN users u ON a.doctor_id = u.user_id
     WHERE a.patient_id = $patient_id
     ORDER BY a.appointment_date DESC"
);

// Fetch lab results
$lab_results = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.category, lt.normal_range, lt.unit
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = $patient_id
     ORDER BY lr.request_date DESC"
);

// Fetch prescriptions
$prescriptions = mysqli_query($conn,
    "SELECT p.*, u.full_name as doctor_name
     FROM prescriptions p
     JOIN users u ON p.doctor_id = u.user_id
     WHERE p.patient_id = $patient_id
     ORDER BY p.prescription_date DESC"
);

$age = date_diff(date_create($patient['date_of_birth']), date_create('today'))->y;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .patient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .section-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .section-title {
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .status-badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .status-scheduled { background: #cce5ff; color: #004085; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-pending { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Patient Header -->
        <div class="patient-header">
            <div class="row">
                <div class="col-md-8">
                    <h2><?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?></h2>
                    <p class="mb-0">
                        Patient #: <?php echo $patient['patient_number']; ?> | 
                        DOB: <?php echo date('d-m-Y', strtotime($patient['date_of_birth'])); ?> (<?php echo $age; ?> years) |
                        Blood: <?php echo $patient['blood_group'] ?: 'N/A'; ?>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="view_patient.php?id=<?php echo $patient_id; ?>" class="btn btn-light">
                        Back to Patient
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Appointments -->
        <div class="section-card">
            <h4 class="section-title">Appointment History</h4>
            <?php if($appointments && mysqli_num_rows($appointments) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Doctor</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($apt = mysqli_fetch_assoc($appointments)): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($apt['appointment_date'])); ?></td>
                                <td><?php echo date('h:i A', strtotime($apt['appointment_time'])); ?></td>
                                <td>Dr. <?php echo $apt['doctor_name']; ?></td>
                                <td><?php echo $apt['reason']; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $apt['status']; ?>">
                                        <?php echo ucfirst($apt['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_appointment.php?id=<?php echo $apt['appointment_id']; ?>" 
                                       class="btn btn-sm btn-info">View</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">No appointment history</p>
            <?php endif; ?>
        </div>
        
        <!-- Lab Results -->
        <div class="section-card">
            <h4 class="section-title">Lab Results</h4>
            <?php if($lab_results && mysqli_num_rows($lab_results) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Test</th>
                            <th>Result</th>
                            <th>Normal Range</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($lab = mysqli_fetch_assoc($lab_results)): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($lab['request_date'])); ?></td>
                                <td><?php echo $lab['test_name']; ?></td>
                                <td>
                                    <?php if($lab['status'] == 'completed'): ?>
                                        <strong><?php echo $lab['result_value'] . ' ' . $lab['unit']; ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $lab['normal_range'] ?: 'N/A'; ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $lab['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($lab['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_lab_request.php?id=<?php echo $lab['request_id']; ?>" 
                                       class="btn btn-sm btn-info">View</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">No lab results</p>
            <?php endif; ?>
        </div>
        
        <!-- Prescriptions -->
        <div class="section-card">
            <h4 class="section-title">Prescriptions</h4>
            <?php if($prescriptions && mysqli_num_rows($prescriptions) > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Doctor</th>
                            <th>Diagnosis</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($pres = mysqli_fetch_assoc($prescriptions)): ?>
                            <tr>
                                <td><?php echo date('d M Y', strtotime($pres['prescription_date'])); ?></td>
                                <td>Dr. <?php echo $pres['doctor_name']; ?></td>
                                <td><?php echo $pres['diagnosis']; ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $pres['status'] == 'dispensed' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($pres['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view_prescription.php?id=<?php echo $pres['prescription_id']; ?>" 
                                       class="btn btn-sm btn-info">View</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">No prescriptions</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
