<?php
require_once 'config.php';
requireRole('doctor');

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');

function getPrescriptionStatusValues($conn) {
    $values = [];
    $res = mysqli_query($conn, "SHOW COLUMNS FROM prescriptions LIKE 'status'");
    if ($res && ($row = mysqli_fetch_assoc($res)) && !empty($row['Type'])) {
        if (preg_match("/^enum\\((.*)\\)$/i", $row['Type'], $m)) {
            $values = str_getcsv($m[1], ',', "'");
        }
    }
    return $values;
}

// If no patient ID, redirect to patient selection
if ($patient_id == 0) {
    $_SESSION['error'] = "Please select a patient first";
    redirect('select_patient_for_prescription.php');
}

// Get patient info with error checking
$patient_query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$patient_result = mysqli_query($conn, $patient_query);

if (!$patient_result || mysqli_num_rows($patient_result) == 0) {
    $_SESSION['error'] = "Patient not found";
    redirect('doctor_dashboard.php');
}
$patient = mysqli_fetch_assoc($patient_result);

// Get lab results for this patient
$approval_filter = $has_doctor_approval ? "AND lr.approved_by_doctor = FALSE" : "";
$lab_results = mysqli_query($conn,
    "SELECT lr.*, lt.test_name, lt.normal_range, lt.unit 
     FROM lab_requests lr
     JOIN lab_tests lt ON lr.test_id = lt.test_id
     WHERE lr.patient_id = $patient_id 
     AND lr.status = 'completed'
     $approval_filter
     ORDER BY lr.result_date DESC"
);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $prescription_number = generateUniqueId('RX', 'prescriptions', 'prescription_number');
    $diagnosis = sanitize($_POST['diagnosis']);
    $notes = sanitize($_POST['notes']);
    $medicines = json_decode($_POST['medicines'], true);
    
    // Check if medicines array is valid
    if (!is_array($medicines) || empty($medicines)) {
        $error = "Please add at least one medicine";
    } else {
        mysqli_begin_transaction($conn);
        
        try {
            $status_values = getPrescriptionStatusValues($conn);
            $pending_status = in_array('sent_to_pharmacy', $status_values, true) ? 'sent_to_pharmacy' : 'active';

            // Insert prescription
            $query = "INSERT INTO prescriptions (prescription_number, patient_id, doctor_id, diagnosis, notes, status) 
                      VALUES ('$prescription_number', $patient_id, $doctor_id, '$diagnosis', '$notes', '$pending_status')";
            
            if (!mysqli_query($conn, $query)) {
                throw new Exception("Error inserting prescription: " . mysqli_error($conn));
            }
            
            $prescription_id = mysqli_insert_id($conn);
            
            // Insert prescription items
            $inserted_items = 0;
            foreach($medicines as $medicine) {
                // Validate medicine data
                if (empty($medicine['name']) || empty($medicine['dosage'])) {
                    continue;
                }
                
                $item_query = "INSERT INTO prescription_items (prescription_id, medicine_name, dosage, frequency, duration, quantity, instructions) 
                              VALUES ($prescription_id, 
                              '" . sanitize($medicine['name']) . "', 
                              '" . sanitize($medicine['dosage']) . "', 
                              '" . sanitize($medicine['frequency']) . "', 
                              '" . sanitize($medicine['duration']) . "', 
                              " . (int)$medicine['quantity'] . ", 
                              '" . sanitize($medicine['instructions']) . "')";
                
                if (!mysqli_query($conn, $item_query)) {
                    throw new Exception("Error inserting medicine: " . mysqli_error($conn));
                }
                $inserted_items++;
            }

            if ($inserted_items === 0) {
                throw new Exception("No valid medicine items were provided");
            }
            
            // Update lab results as reviewed if any were selected
            if (isset($_POST['reviewed_labs']) && is_array($_POST['reviewed_labs'])) {
                foreach($_POST['reviewed_labs'] as $lab_id) {
                    $lab_id = (int)$lab_id;
                    if ($has_doctor_approval) {
                        $approval_updates = ["approved_by_doctor = TRUE"];
                        if (tableHasColumn('lab_requests', 'doctor_approval_date')) {
                            $approval_updates[] = "doctor_approval_date = NOW()";
                        }
                        $update_lab = "UPDATE lab_requests SET " . implode(', ', $approval_updates) . " 
                                      WHERE request_id = $lab_id";
                    } else {
                        $update_lab = "UPDATE lab_requests SET request_id = request_id WHERE request_id = $lab_id";
                    }
                    mysqli_query($conn, $update_lab);
                }
            }
            
            mysqli_commit($conn);
            $_SESSION['success'] = "Prescription created and sent to pharmacy!";
            redirect("doctor_dashboard.php");
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Prescription - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .medicine-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            border-left: 4px solid #007bff;
        }
        .lab-result-item {
            border-left: 4px solid #28a745;
            padding: 10px;
            margin-bottom: 10px;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-prescription"></i> Create Prescription</h4>
                    </div>
                    <div class="card-body">
                        <!-- Patient Info -->
                        <div class="alert alert-info">
                            <h5>Patient Information</h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <strong>Name:</strong> <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?>
                                </div>
                                <div class="col-md-2">
                                    <strong>Patient #:</strong> <?php echo htmlspecialchars($patient['patient_number']); ?>
                                </div>
                                <div class="col-md-2">
                                    <strong>Age:</strong> 
                                    <?php 
                                    $dob = new DateTime($patient['date_of_birth']);
                                    $now = new DateTime();
                                    echo $now->diff($dob)->y . ' years';
                                    ?>
                                </div>
                                <div class="col-md-2">
                                    <strong>Blood Group:</strong> <?php echo htmlspecialchars($patient['blood_group'] ?: 'N/A'); ?>
                                </div>
                                <div class="col-md-3">
                                    <strong>Phone:</strong> <?php echo htmlspecialchars($patient['phone']); ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if(isset($_SESSION['success'])): ?>
                            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                        <?php endif; ?>
                        
                        <!-- Lab Results Section -->
                        <?php if(mysqli_num_rows($lab_results) > 0): ?>
                            <div class="card mb-4">
                                <div class="card-header bg-warning">
                                    <h5><i class="fas fa-flask"></i> Pending Lab Results to Review</h5>
                                </div>
                                <div class="card-body">
                                    <form id="labReviewForm">
                                        <?php while($lab = mysqli_fetch_assoc($lab_results)): ?>
                                            <div class="lab-result-item">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="reviewed_labs[]" 
                                                           value="<?php echo $lab['request_id']; ?>" id="lab_<?php echo $lab['request_id']; ?>">
                                                    <label class="form-check-label" for="lab_<?php echo $lab['request_id']; ?>">
                                                        <strong><?php echo htmlspecialchars($lab['test_name']); ?></strong> - 
                                                        Result: <?php echo htmlspecialchars($lab['result_value'] . ' ' . $lab['unit']); ?>
                                                        (Normal: <?php echo htmlspecialchars($lab['normal_range']); ?>)
                                                        <br>
                                                        <small class="text-muted">Date: <?php echo date('d-m-Y', strtotime($lab['result_date'])); ?></small>
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Prescription Form -->
                        <form method="POST" id="prescriptionForm">
                            <div class="mb-3">
                                <label class="form-label">Diagnosis *</label>
                                <textarea class="form-control" name="diagnosis" rows="2" required 
                                          placeholder="Enter diagnosis based on examination and lab results"></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Medicines *</label>
                                <div id="medicinesList"></div>
                                <button type="button" class="btn btn-sm btn-success mt-2" onclick="addMedicine()">
                                    <i class="fas fa-plus"></i> Add Medicine
                                </button>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="notes" rows="2" 
                                          placeholder="Any special instructions for the patient or pharmacist"></textarea>
                            </div>
                            
                            <input type="hidden" name="medicines" id="medicinesInput">
                            
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane"></i> Send to Pharmacy
                                </button>
                                <a href="doctor_dashboard.php" class="btn btn-secondary btn-lg">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        let medicineCount = 0;
        
        function addMedicine() {
            medicineCount++;
            const medicineHtml = `
                <div class="medicine-item" id="medicine_${medicineCount}">
                    <div class="row">
                        <div class="col-md-4 mb-2">
                            <label class="form-label">Medicine Name *</label>
                            <input type="text" class="form-control medicine-name" placeholder="e.g., Amoxicillin" required>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="form-label">Dosage *</label>
                            <input type="text" class="form-control medicine-dosage" placeholder="e.g., 500mg" required>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="form-label">Frequency *</label>
                            <input type="text" class="form-control medicine-frequency" placeholder="e.g., 3x daily" required>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="form-label">Duration *</label>
                            <input type="text" class="form-control medicine-duration" placeholder="e.g., 7 days" required>
                        </div>
                        <div class="col-md-1 mb-2">
                            <label class="form-label">Quantity *</label>
                            <input type="number" class="form-control medicine-quantity" placeholder="Qty" required>
                        </div>
                        <div class="col-md-1 mb-2">
                            <label class="form-label">&nbsp;</label>
                            <button type="button" class="btn btn-sm btn-danger w-100" onclick="removeMedicine('medicine_${medicineCount}')">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <label class="form-label">Instructions</label>
                            <input type="text" class="form-control medicine-instructions" 
                                   placeholder="e.g., Take after meals">
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('medicinesList').insertAdjacentHTML('beforeend', medicineHtml);
        }
        
        function removeMedicine(id) {
            document.getElementById(id).remove();
        }
        
        // Add first medicine by default
        window.onload = function() {
            addMedicine();
        };
        
        document.getElementById('prescriptionForm').addEventListener('submit', function(e) {
            const medicineItems = document.querySelectorAll('.medicine-item');
            const medicines = [];
            
            for(let item of medicineItems) {
                const medicine = {
                    name: item.querySelector('.medicine-name').value,
                    dosage: item.querySelector('.medicine-dosage').value,
                    frequency: item.querySelector('.medicine-frequency').value,
                    duration: item.querySelector('.medicine-duration').value,
                    quantity: item.querySelector('.medicine-quantity').value,
                    instructions: item.querySelector('.medicine-instructions').value || ''
                };
                
                // Only add if required fields are filled
                if(medicine.name && medicine.dosage && medicine.frequency && medicine.duration && medicine.quantity) {
                    medicines.push(medicine);
                }
            }
            
            if(medicines.length === 0) {
                alert('Please add at least one medicine');
                e.preventDefault();
                return false;
            }
            
            document.getElementById('medicinesInput').value = JSON.stringify(medicines);
            
            // Collect checked labs
            const checkedLabs = [];
            document.querySelectorAll('input[name="reviewed_labs[]"]:checked').forEach(cb => {
                checkedLabs.push(cb.value);
            });
            
            // Add hidden inputs for reviewed labs
            checkedLabs.forEach(labId => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'reviewed_labs[]';
                input.value = labId;
                this.appendChild(input);
            });
        });
    </script>
</body>
</html>
