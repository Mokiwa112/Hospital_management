<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

// Verify patient exists
$patient_check = mysqli_query($conn, "SELECT * FROM patients WHERE patient_id = $patient_id");
if (mysqli_num_rows($patient_check) == 0) {
    $_SESSION['error'] = "Invalid patient selected";
    redirect('patients.php');
}
$patient = mysqli_fetch_assoc($patient_check);

// Get doctors list
$doctors = mysqli_query($conn, "SELECT user_id, full_name, department FROM users WHERE user_type = 'doctor' ORDER BY full_name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $appointment_number = generateUniqueId('APT', 'appointments', 'appointment_number');
    $doctor_id = sanitize($_POST['doctor_id']);
    $appointment_date = sanitize($_POST['appointment_date']);
    $appointment_time = sanitize($_POST['appointment_time']);
    $reason = sanitize($_POST['reason']);
    
    $query = "INSERT INTO appointments (appointment_number, patient_id, doctor_id, appointment_date, appointment_time, reason, created_by) 
              VALUES ('$appointment_number', $patient_id, $doctor_id, '$appointment_date', '$appointment_time', '$reason', {$_SESSION['user_id']})";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Appointment scheduled successfully!";
        redirect("view_patient.php?id=$patient_id");
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule Appointment - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-calendar-plus"></i> Schedule Appointment for <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Select Doctor</label>
                                <select class="form-control" name="doctor_id" required>
                                    <option value="">Choose doctor</option>
                                    <?php while($doc = mysqli_fetch_assoc($doctors)): ?>
                                        <option value="<?php echo $doc['user_id']; ?>">
                                            Dr. <?php echo $doc['full_name']; ?> (<?php echo $doc['department']; ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Appointment Date</label>
                                    <input type="date" class="form-control" name="appointment_date" 
                                           min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Appointment Time</label>
                                    <select class="form-control" name="appointment_time" required>
                                        <option value="">Select time</option>
                                        <option value="09:00:00">09:00 AM</option>
                                        <option value="10:00:00">10:00 AM</option>
                                        <option value="11:00:00">11:00 AM</option>
                                        <option value="14:00:00">02:00 PM</option>
                                        <option value="15:00:00">03:00 PM</option>
                                        <option value="16:00:00">04:00 PM</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Reason for Visit</label>
                                <input type="text" class="form-control" name="reason" required>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-calendar-check"></i> Schedule Appointment
                                </button>
                                <a href="view_patient.php?id=<?php echo $patient_id; ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>