<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_id = (int)$_SESSION['user_id'];
$user_type = $_SESSION['user_type'] ?? '';
$attendance_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($attendance_id <= 0) {
    $_SESSION['error'] = "Invalid attendance record selected";
    redirect('attendance_history.php');
}

$query = "SELECT a.*, u.full_name, u.employee_id, u.department, u.user_type
          FROM attendance a
          JOIN users u ON a.user_id = u.user_id
          WHERE a.attendance_id = $attendance_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    $_SESSION['error'] = "Attendance record not found";
    redirect('attendance_history.php');
}

$record = mysqli_fetch_assoc($result);

// Admin can view all records; other users can only view their own.
if ($user_type !== 'admin' && (int)$record['user_id'] !== $user_id) {
    $_SESSION['error'] = "You do not have permission to view this attendance record";
    redirect('attendance_history.php');
}

$hours_worked = 0;
if (!empty($record['check_in']) && !empty($record['check_out'])) {
    $check_in = strtotime($record['check_in']);
    $check_out = strtotime($record['check_out']);
    if ($check_out > $check_in) {
        $hours_worked = round(($check_out - $check_in) / 3600, 2);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Details - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3><i class="fas fa-user-clock"></i> Attendance Details</h3>
            <a href="attendance_history.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Attendance History
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <strong>Date</strong>
                        <div><?php echo date('l, d M Y', strtotime($record['date'])); ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Employee</strong>
                        <div><?php echo htmlspecialchars($record['full_name']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Employee ID</strong>
                        <div><?php echo htmlspecialchars($record['employee_id'] ?? 'N/A'); ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Department</strong>
                        <div><?php echo htmlspecialchars($record['department'] ?: 'N/A'); ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Check In</strong>
                        <div><?php echo $record['check_in'] ? date('h:i:s A', strtotime($record['check_in'])) : '-'; ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Check Out</strong>
                        <div><?php echo $record['check_out'] ? date('h:i:s A', strtotime($record['check_out'])) : '-'; ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Status</strong>
                        <div>
                            <span class="badge bg-<?php echo $record['status'] === 'present' ? 'success' : ($record['status'] === 'late' ? 'warning text-dark' : 'secondary'); ?>">
                                <?php echo ucfirst($record['status']); ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <strong>Approval</strong>
                        <div>
                            <?php $approval = $record['approval_status'] ?? 'pending'; ?>
                            <span class="badge bg-<?php echo $approval === 'approved' ? 'success' : ($approval === 'rejected' ? 'danger' : 'warning text-dark'); ?>">
                                <?php echo ucfirst($approval); ?>
                            </span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <strong>Total Hours</strong>
                        <div><?php echo $hours_worked > 0 ? $hours_worked . ' hrs' : '-'; ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Overtime</strong>
                        <div><?php echo !empty($record['overtime_hours']) ? round((float)$record['overtime_hours'], 2) . ' hrs' : '0 hrs'; ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Requires Approval</strong>
                        <div><?php echo !empty($record['requires_approval']) ? 'Yes' : 'No'; ?></div>
                    </div>
                    <div class="col-md-4">
                        <strong>Approval Date</strong>
                        <div><?php echo !empty($record['approval_date']) ? date('d M Y h:i A', strtotime($record['approval_date'])) : '-'; ?></div>
                    </div>
                </div>

                <?php if ($user_type === 'admin' && ($record['approval_status'] ?? 'pending') === 'pending'): ?>
                    <hr>
                    <div class="d-flex gap-2">
                        <a href="process_attendance.php?id=<?php echo $attendance_id; ?>&action=approve" class="btn btn-success" onclick="return confirm('Approve this attendance record?');">
                            <i class="fas fa-check"></i> Approve
                        </a>
                        <a href="process_attendance.php?id=<?php echo $attendance_id; ?>&action=reject" class="btn btn-danger" onclick="return confirm('Reject this attendance record?');">
                            <i class="fas fa-times"></i> Reject
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
