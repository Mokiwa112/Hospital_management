<?php
require_once 'config.php';
requireRole('doctor');

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];

// Handle appointment status update via AJAX
if (isset($_POST['update_status'])) {
    $appointment_id = sanitize($_POST['appointment_id']);
    $status = sanitize($_POST['status']);
    
    $query = "UPDATE appointments SET status = '$status' WHERE appointment_id = $appointment_id AND doctor_id = $doctor_id";
    
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => mysqli_error($conn)]);
    }
    exit();
}

// Get filter parameters
$filter_date = isset($_GET['date']) ? sanitize($_GET['date']) : '';
$filter_status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$filter_patient = isset($_GET['patient']) ? sanitize($_GET['patient']) : '';
$date_from = isset($_GET['date_from']) ? sanitize($_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? sanitize($_GET['date_to']) : '';

// Build query with filters
$where = ["a.doctor_id = $doctor_id"];

if ($filter_date) {
    $where[] = "a.appointment_date = '$filter_date'";
}

if ($filter_status) {
    $where[] = "a.status = '$filter_status'";
}

if ($filter_patient) {
    $where[] = "(p.first_name LIKE '%$filter_patient%' OR p.last_name LIKE '%$filter_patient%' OR p.patient_number LIKE '%$filter_patient%')";
}

if ($date_from) {
    $where[] = "a.appointment_date >= '$date_from'";
}

if ($date_to) {
    $where[] = "a.appointment_date <= '$date_to'";
}

$where_clause = implode(' AND ', $where);

// Fetch appointments
$query = "SELECT a.*, 
          p.first_name, p.last_name, p.patient_number, p.date_of_birth, p.phone, p.blood_group
          FROM appointments a
          JOIN patients p ON a.patient_id = p.patient_id
          WHERE $where_clause
          ORDER BY a.appointment_date DESC, a.appointment_time DESC";

$appointments = mysqli_query($conn, $query);

// Get statistics
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN a.status = 'scheduled' AND a.appointment_date >= CURDATE() THEN 1 ELSE 0 END) as upcoming,
    SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
    SUM(CASE WHEN a.status = 'no_show' THEN 1 ELSE 0 END) as no_show
    FROM appointments a
    WHERE a.doctor_id = $doctor_id";

$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);

// Get today's date for quick filters
$today = date('Y-m-d');
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$next_week = date('Y-m-d', strtotime('+7 days'));
$last_week = date('Y-m-d', strtotime('-7 days'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .filter-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid #dee2e6;
        }
        .appointment-row {
            transition: all 0.3s;
        }
        .appointment-row:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-scheduled { background: #cce5ff; color: #004085; }
        .status-in_progress { background: #fff3cd; color: #856404; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-no_show { background: #e2e3e5; color: #383d41; }
        
        .quick-filter-btn {
            margin-right: 5px;
            margin-bottom: 5px;
        }
        .patient-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-calendar-check"></i> My Appointments</h2>
                <p>Manage all your patient appointments</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="doctor_dashboard.php" class="btn btn-primary">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="appointments.php?doctor=<?php echo $doctor_id; ?>" class="btn btn-info">
                    <i class="fas fa-clock"></i> My Schedule
                </a>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                    <h3><?php echo $stats['total'] ?? 0; ?></h3>
                    <p class="mb-0">Total Appointments</p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                    <h3><?php echo $stats['upcoming'] ?? 0; ?></h3>
                    <p class="mb-0">Upcoming</p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                    <h3><?php echo $stats['completed'] ?? 0; ?></h3>
                    <p class="mb-0">Completed</p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                    <h3><?php 
                    $today_count = mysqli_fetch_assoc(mysqli_query($conn, 
                        "SELECT COUNT(*) as count FROM appointments 
                         WHERE doctor_id = $doctor_id AND appointment_date = CURDATE()"
                    ))['count'];
                    echo $today_count;
                    ?></h3>
                    <p class="mb-0">Today</p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #fa709a, #fee140);">
                    <h3><?php echo $stats['cancelled'] ?? 0; ?></h3>
                    <p class="mb-0">Cancelled</p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card" style="background: linear-gradient(135deg, #96e6a1, #d4fc79);">
                    <h3><?php echo $stats['no_show'] ?? 0; ?></h3>
                    <p class="mb-0">No Show</p>
                </div>
            </div>
        </div>
        
        <!-- Quick Filters -->
        <div class="filter-card">
            <h5 class="mb-3"><i class="fas fa-bolt"></i> Quick Filters</h5>
            <div class="btn-group flex-wrap">
                <a href="my_appointments.php?date=<?php echo $today; ?>" class="btn btn-outline-primary quick-filter-btn">
                    <i class="fas fa-calendar-day"></i> Today
                </a>
                <a href="my_appointments.php?date=<?php echo $tomorrow; ?>" class="btn btn-outline-primary quick-filter-btn">
                    <i class="fas fa-calendar-plus"></i> Tomorrow
                </a>
                <a href="my_appointments.php?date_from=<?php echo $today; ?>&date_to=<?php echo $next_week; ?>" class="btn btn-outline-primary quick-filter-btn">
                    <i class="fas fa-calendar-week"></i> Next 7 Days
                </a>
                <a href="my_appointments.php?date_from=<?php echo $last_week; ?>&date_to=<?php echo $today; ?>" class="btn btn-outline-primary quick-filter-btn">
                    <i class="fas fa-calendar-alt"></i> Last 7 Days
                </a>
                <a href="my_appointments.php?status=scheduled" class="btn btn-outline-warning quick-filter-btn">
                    <i class="fas fa-clock"></i> Scheduled
                </a>
                <a href="my_appointments.php?status=completed" class="btn btn-outline-success quick-filter-btn">
                    <i class="fas fa-check-circle"></i> Completed
                </a>
                <a href="my_appointments.php?status=cancelled" class="btn btn-outline-danger quick-filter-btn">
                    <i class="fas fa-times-circle"></i> Cancelled
                </a>
                <a href="my_appointments.php" class="btn btn-outline-secondary quick-filter-btn">
                    <i class="fas fa-undo"></i> Reset
                </a>
            </div>
        </div>
        
        <!-- Advanced Filters -->
        <div class="filter-card">
            <h5 class="mb-3"><i class="fas fa-filter"></i> Advanced Filters</h5>
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Date From</label>
                    <input type="date" class="form-control" name="date_from" value="<?php echo $date_from; ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date To</label>
                    <input type="date" class="form-control" name="date_to" value="<?php echo $date_to; ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select class="form-control" name="status">
                        <option value="">All</option>
                        <option value="scheduled" <?php echo $filter_status == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                        <option value="in_progress" <?php echo $filter_status == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                        <option value="completed" <?php echo $filter_status == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo $filter_status == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        <option value="no_show" <?php echo $filter_status == 'no_show' ? 'selected' : ''; ?>>No Show</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Search Patient</label>
                    <input type="text" class="form-control" name="patient" placeholder="Name or ID..." value="<?php echo htmlspecialchars($filter_patient); ?>">
                </div>
                <div class="col-md-1">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Appointments Table -->
        <div class="card">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-list"></i> Appointments List</h5>
                <span class="badge bg-light text-dark">Total: <?php echo mysqli_num_rows($appointments); ?></span>
            </div>
            <div class="card-body">
                <?php if(isset($_SESSION['success'])): ?>
                    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                <?php endif; ?>
                
                <?php if(isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                <?php endif; ?>
                
                <div class="table-responsive">
                    <table id="appointmentsTable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Date & Time</th>
                                <th>Patient</th>
                                <th>Contact</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($appointments && mysqli_num_rows($appointments) > 0): ?>
                                <?php while($apt = mysqli_fetch_assoc($appointments)): 
                                    $age = date_diff(date_create($apt['date_of_birth']), date_create('today'))->y;
                                ?>
                                    <tr class="appointment-row">
                                        <td>
                                            <strong><?php echo date('d M Y', strtotime($apt['appointment_date'])); ?></strong>
                                            <br>
                                            <span class="badge bg-info">
                                                <?php echo date('h:i A', strtotime($apt['appointment_time'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="patient-avatar me-2">
                                                    <?php echo substr($apt['first_name'], 0, 1) . substr($apt['last_name'], 0, 1); ?>
                                                </div>
                                                <div>
                                                    <strong><?php echo $apt['first_name'] . ' ' . $apt['last_name']; ?></strong>
                                                    <br>
                                                    <small class="text-muted">
                                                        #<?php echo $apt['patient_number']; ?> | <?php echo $age; ?> yrs
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <i class="fas fa-phone"></i> <?php echo $apt['phone']; ?>
                                            <br>
                                            <small><i class="fas fa-tint"></i> Blood: <?php echo $apt['blood_group'] ?: 'N/A'; ?></small>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($apt['reason']); ?>
                                            <?php if($apt['notes']): ?>
                                                <br><small class="text-muted"><?php echo htmlspecialchars($apt['notes']); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <select class="form-control form-control-sm status-select" 
                                                    onchange="updateStatus(<?php echo $apt['appointment_id']; ?>, this.value)">
                                                <option value="scheduled" <?php echo $apt['status'] == 'scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                                                <option value="in_progress" <?php echo $apt['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                                <option value="completed" <?php echo $apt['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                <option value="cancelled" <?php echo $apt['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                <option value="no_show" <?php echo $apt['status'] == 'no_show' ? 'selected' : ''; ?>>No Show</option>
                                            </select>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="view_appointment.php?id=<?php echo $apt['appointment_id']; ?>" 
                                                   class="btn btn-info" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="create_prescription.php?patient_id=<?php echo $apt['patient_id']; ?>" 
                                                   class="btn btn-success" title="Write Prescription">
                                                    <i class="fas fa-prescription"></i>
                                                </a>
                                                <a href="lab_request.php?patient_id=<?php echo $apt['patient_id']; ?>" 
                                                   class="btn btn-warning" title="Request Lab Test">
                                                    <i class="fas fa-flask"></i>
                                                </a>
                                                <a href="patient_history.php?patient_id=<?php echo $apt['patient_id']; ?>" 
                                                   class="btn btn-secondary" title="Patient History">
                                                    <i class="fas fa-history"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                        <p class="text-muted">No appointments found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            $('#appointmentsTable').DataTable({
                order: [[0, 'desc']],
                pageLength: 25,
                language: {
                    emptyTable: "No appointments found"
                }
            });
        });
        
        function updateStatus(appointmentId, status) {
            if (confirm('Are you sure you want to update the status to ' + status.replace('_', ' ') + '?')) {
                $.ajax({
                    url: 'my_appointments.php',
                    method: 'POST',
                    data: {
                        update_status: true,
                        appointment_id: appointmentId,
                        status: status
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Status updated successfully!');
                            location.reload();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                    }
                });
            } else {
                // Reset the select to previous value
                location.reload();
            }
        }
        
        // Auto-refresh every 5 minutes
        setTimeout(function() {
            location.reload();
        }, 300000);
    </script>
</body>
</html>
