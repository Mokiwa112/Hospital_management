<?php
require_once 'config.php';
requireStaffLogin();

header('Content-Type: application/json');

$conn = getConnection();

$query = "SELECT task_id, task_title, description, due_date, priority, status FROM tasks";
$result = mysqli_query($conn, $query);

$events = [];
if ($result) {
    while ($task = mysqli_fetch_assoc($result)) {
        $color = '#6c757d';
        if ($task['status'] === 'completed') {
            $color = '#28a745';
        } elseif ($task['status'] === 'in_progress') {
            $color = '#007bff';
        } elseif ($task['priority'] === 'urgent') {
            $color = '#dc3545';
        } elseif ($task['priority'] === 'high') {
            $color = '#fd7e14';
        } elseif ($task['priority'] === 'medium') {
            $color = '#ffc107';
        }

        $events[] = [
            'id' => (int)$task['task_id'],
            'title' => $task['task_title'],
            'start' => $task['due_date'],
            'color' => $color,
            'extendedProps' => [
                'description' => $task['description'] ?? '',
                'status' => $task['status'],
                'priority' => $task['priority']
            ]
        ];
    }
}

echo json_encode($events);
?>
