<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = getConnection();

$attendance_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($attendance_id && in_array($action, ['approve', 'reject'])) {
    $status = ($action == 'approve') ? 'approved' : 'rejected';
    
    $query = "UPDATE attendance SET 
              approval_status = '$status',
              approved_by = {$_SESSION['user_id']},
              approval_date = NOW()
              WHERE attendance_id = $attendance_id";
    
    mysqli_query($conn, $query);
}

// Simple redirect back to attendance history
header("Location: attendance_history.php");
exit();
?>