<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['admin', 'hr_admin']);

$conn = getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);
$user_type = $_SESSION['user_type'] ?? '';

function ensureHrSchema($conn) {
    $sql = [];
    $sql[] = "CREATE TABLE IF NOT EXISTS employee_salary_structures (
                structure_id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                basic_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                allowances DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                deductions DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                pay_frequency ENUM('monthly','weekly') NOT NULL DEFAULT 'monthly',
                effective_from DATE NOT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_by INT(11) DEFAULT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (structure_id),
                KEY idx_salary_user (user_id),
                KEY idx_salary_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $sql[] = "CREATE TABLE IF NOT EXISTS payroll_records (
                payroll_id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                pay_month TINYINT(2) NOT NULL,
                pay_year SMALLINT(4) NOT NULL,
                present_days DECIMAL(6,2) NOT NULL DEFAULT 0.00,
                half_days DECIMAL(6,2) NOT NULL DEFAULT 0.00,
                absent_days DECIMAL(6,2) NOT NULL DEFAULT 0.00,
                gross_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                allowances DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                deductions DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                net_salary DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                status ENUM('generated','paid') NOT NULL DEFAULT 'generated',
                payment_method ENUM('cash','bank_transfer','mobile_money','cheque') DEFAULT NULL,
                paid_date DATETIME DEFAULT NULL,
                paid_by INT(11) DEFAULT NULL,
                notes TEXT DEFAULT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (payroll_id),
                UNIQUE KEY uniq_payroll_period (user_id, pay_month, pay_year),
                KEY idx_payroll_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    foreach ($sql as $query) {
        mysqli_query($conn, $query);
    }
}

ensureHrSchema($conn);

function calculatePayroll($conn, $target_user_id, $month, $year) {
    $target_user_id = (int)$target_user_id;
    $month = (int)$month;
    $year = (int)$year;

    $salary_q = mysqli_query($conn, "SELECT * FROM employee_salary_structures
                                     WHERE user_id = $target_user_id AND is_active = 1
                                     ORDER BY effective_from DESC, structure_id DESC
                                     LIMIT 1");
    if (!$salary_q || mysqli_num_rows($salary_q) === 0) {
        return [false, "No active salary structure found for this employee", null];
    }
    $salary = mysqli_fetch_assoc($salary_q);

    $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
    $att_q = mysqli_query($conn, "SELECT status, COUNT(*) AS cnt
                                  FROM attendance
                                  WHERE user_id = $target_user_id
                                    AND YEAR(date) = $year
                                    AND MONTH(date) = $month
                                  GROUP BY status");

    $present_like = 0.0;
    $half_days = 0.0;
    $absent_days = 0.0;
    if ($att_q) {
        while ($row = mysqli_fetch_assoc($att_q)) {
            $cnt = (float)$row['cnt'];
            if ($row['status'] === 'present' || $row['status'] === 'late') {
                $present_like += $cnt;
            } elseif ($row['status'] === 'half_day') {
                $half_days += $cnt;
            } elseif ($row['status'] === 'absent') {
                $absent_days += $cnt;
            }
        }
    }

    $worked_days_equivalent = $present_like + ($half_days * 0.5);
    $daily_rate = $days_in_month > 0 ? ((float)$salary['basic_salary'] / $days_in_month) : 0.0;
    $gross_salary = $daily_rate * $worked_days_equivalent;
    $allowances = (float)$salary['allowances'];
    $deductions = (float)$salary['deductions'];
    $net_salary = $gross_salary + $allowances - $deductions;

    $data = [
        'present_days' => $present_like,
        'half_days' => $half_days,
        'absent_days' => $absent_days,
        'gross_salary' => round($gross_salary, 2),
        'allowances' => round($allowances, 2),
        'deductions' => round($deductions, 2),
        'net_salary' => round($net_salary, 2)
    ];

    return [true, null, $data];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_salary_structure'])) {
        $target_user_id = (int)($_POST['user_id'] ?? 0);
        $basic_salary = (float)($_POST['basic_salary'] ?? 0);
        $allowances = (float)($_POST['allowances'] ?? 0);
        $deductions = (float)($_POST['deductions'] ?? 0);
        $pay_frequency = sanitize($_POST['pay_frequency'] ?? 'monthly');
        $effective_from = sanitize($_POST['effective_from'] ?? date('Y-m-d'));

        if ($target_user_id <= 0 || $basic_salary <= 0) {
            $_SESSION['error'] = "Please select employee and enter valid salary";
            redirect('human_resource.php');
        }

        mysqli_begin_transaction($conn);
        try {
            mysqli_query($conn, "UPDATE employee_salary_structures
                                 SET is_active = 0
                                 WHERE user_id = $target_user_id");

            $insert_q = "INSERT INTO employee_salary_structures
                         (user_id, basic_salary, allowances, deductions, pay_frequency, effective_from, is_active, created_by)
                         VALUES ($target_user_id, $basic_salary, $allowances, $deductions, '$pay_frequency', '$effective_from', 1, $user_id)";
            if (!mysqli_query($conn, $insert_q)) {
                throw new Exception(mysqli_error($conn));
            }

            mysqli_commit($conn);
            $_SESSION['success'] = "Salary structure saved successfully";
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = "Failed to save salary structure: " . $e->getMessage();
        }
        redirect('human_resource.php');
    }

    if (isset($_POST['generate_payroll'])) {
        $target_user_id = (int)($_POST['user_id'] ?? 0);
        $pay_month = (int)($_POST['pay_month'] ?? date('n'));
        $pay_year = (int)($_POST['pay_year'] ?? date('Y'));

        if ($target_user_id <= 0 || $pay_month < 1 || $pay_month > 12 || $pay_year < 2000) {
            $_SESSION['error'] = "Invalid payroll parameters";
            redirect('human_resource.php');
        }

        list($ok, $err, $data) = calculatePayroll($conn, $target_user_id, $pay_month, $pay_year);
        if (!$ok) {
            $_SESSION['error'] = $err;
            redirect('human_resource.php');
        }

        $existing = mysqli_query($conn, "SELECT payroll_id, status FROM payroll_records
                                         WHERE user_id = $target_user_id
                                           AND pay_month = $pay_month
                                           AND pay_year = $pay_year
                                         LIMIT 1");
        if ($existing && mysqli_num_rows($existing) > 0) {
            $row = mysqli_fetch_assoc($existing);
            $payroll_id = (int)$row['payroll_id'];
            $update_q = "UPDATE payroll_records
                         SET present_days = {$data['present_days']},
                             half_days = {$data['half_days']},
                             absent_days = {$data['absent_days']},
                             gross_salary = {$data['gross_salary']},
                             allowances = {$data['allowances']},
                             deductions = {$data['deductions']},
                             net_salary = {$data['net_salary']}
                         WHERE payroll_id = $payroll_id";
            mysqli_query($conn, $update_q);
            $_SESSION['success'] = "Payroll recalculated for selected month";
        } else {
            $insert_q = "INSERT INTO payroll_records
                        (user_id, pay_month, pay_year, present_days, half_days, absent_days, gross_salary, allowances, deductions, net_salary, status)
                        VALUES
                        ($target_user_id, $pay_month, $pay_year, {$data['present_days']}, {$data['half_days']}, {$data['absent_days']}, {$data['gross_salary']}, {$data['allowances']}, {$data['deductions']}, {$data['net_salary']}, 'generated')";
            mysqli_query($conn, $insert_q);
            $_SESSION['success'] = "Payroll generated successfully";
        }
        redirect('human_resource.php');
    }

    if (isset($_POST['mark_paid'])) {
        $payroll_id = (int)($_POST['payroll_id'] ?? 0);
        $payment_method = sanitize($_POST['payment_method'] ?? 'bank_transfer');
        $notes = sanitize($_POST['payment_notes'] ?? '');

        if ($payroll_id <= 0) {
            $_SESSION['error'] = "Invalid payroll record";
            redirect('human_resource.php');
        }

        $update_q = "UPDATE payroll_records
                     SET status = 'paid',
                         payment_method = '$payment_method',
                         paid_date = NOW(),
                         paid_by = $user_id,
                         notes = '$notes'
                     WHERE payroll_id = $payroll_id";
        if (mysqli_query($conn, $update_q)) {
            $_SESSION['success'] = "Payroll marked as paid";
        } else {
            $_SESSION['error'] = "Failed to update payroll status";
        }
        redirect('human_resource.php');
    }
}

$employees = mysqli_query($conn, "SELECT user_id, full_name, employee_id, department, user_type
                                  FROM users
                                  WHERE user_type <> 'admin'
                                  ORDER BY full_name");

$salary_structures = mysqli_query($conn, "SELECT s.*, u.full_name, u.employee_id, u.department
                                          FROM employee_salary_structures s
                                          JOIN users u ON s.user_id = u.user_id
                                          WHERE s.is_active = 1
                                          ORDER BY u.full_name");

$payroll_records = mysqli_query($conn, "SELECT p.*, u.full_name, u.employee_id, u.department
                                        FROM payroll_records p
                                        JOIN users u ON p.user_id = u.user_id
                                        ORDER BY p.pay_year DESC, p.pay_month DESC, u.full_name");

$hr_stats = mysqli_query($conn, "SELECT
                                (SELECT COUNT(*) FROM users WHERE user_type <> 'admin') AS total_staff,
                                (SELECT COUNT(*) FROM employee_salary_structures WHERE is_active = 1) AS salary_profiles,
                                (SELECT COUNT(*) FROM payroll_records WHERE status = 'generated') AS pending_payroll,
                                (SELECT COALESCE(SUM(net_salary),0) FROM payroll_records WHERE status = 'paid' AND MONTH(paid_date)=MONTH(CURDATE()) AND YEAR(paid_date)=YEAR(CURDATE())) AS paid_this_month");
$stats = $hr_stats ? mysqli_fetch_assoc($hr_stats) : ['total_staff' => 0, 'salary_profiles' => 0, 'pending_payroll' => 0, 'paid_this_month' => 0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Human Resource - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .hr-card { border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .stat-card { border-radius: 10px; color: #fff; }
        .stat-title { font-size: 13px; opacity: 0.9; }
        .stat-value { font-size: 28px; font-weight: 700; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container-fluid mt-4">
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-people-group"></i> Human Resource & Payroll</h2>
                <p class="text-muted mb-0">Employee salary setup, payroll generation and payment tracking</p>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-primary">
                    <div class="card-body">
                        <div class="stat-title">Total Employees</div>
                        <div class="stat-value"><?php echo (int)$stats['total_staff']; ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-success">
                    <div class="card-body">
                        <div class="stat-title">Salary Profiles</div>
                        <div class="stat-value"><?php echo (int)$stats['salary_profiles']; ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-warning">
                    <div class="card-body">
                        <div class="stat-title">Pending Payroll</div>
                        <div class="stat-value"><?php echo (int)$stats['pending_payroll']; ?></div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-dark">
                    <div class="card-body">
                        <div class="stat-title">Paid This Month</div>
                        <div class="stat-value"><?php echo format_number($stats['paid_this_month'] ?? 0); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <ul class="nav nav-tabs mb-3" id="hrTabs" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#salaryTab" type="button">Salary Structure</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#payrollTab" type="button">Generate Payroll</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#historyTab" type="button">Payroll History</button></li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="salaryTab">
                <div class="row">
                    <div class="col-md-4">
                        <div class="card hr-card">
                            <div class="card-header bg-primary text-white"><strong>Set Salary Structure</strong></div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-2">
                                        <label class="form-label">Employee</label>
                                        <select class="form-select" name="user_id" required>
                                            <option value="">Select employee</option>
                                            <?php if($employees){ mysqli_data_seek($employees, 0); while($emp = mysqli_fetch_assoc($employees)): ?>
                                                <option value="<?php echo (int)$emp['user_id']; ?>">
                                                    <?php echo htmlspecialchars($emp['employee_id'] . ' - ' . $emp['full_name']); ?>
                                                </option>
                                            <?php endwhile; } ?>
                                        </select>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Basic Salary</label>
                                        <input type="number" step="0.01" min="0" class="form-control" name="basic_salary" required>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Allowances</label>
                                        <input type="number" step="0.01" min="0" class="form-control" name="allowances" value="0">
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Deductions</label>
                                        <input type="number" step="0.01" min="0" class="form-control" name="deductions" value="0">
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Frequency</label>
                                        <select class="form-select" name="pay_frequency">
                                            <option value="monthly">Monthly</option>
                                            <option value="weekly">Weekly</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Effective From</label>
                                        <input type="date" class="form-control" name="effective_from" value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                    <button class="btn btn-primary w-100" type="submit" name="save_salary_structure">
                                        <i class="fas fa-save"></i> Save Structure
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card hr-card">
                            <div class="card-header bg-light"><strong>Active Salary Structures</strong></div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="salaryTable">
                                        <thead>
                                            <tr>
                                                <th>Employee</th>
                                                <th>Department</th>
                                                <th>Basic</th>
                                                <th>Allowances</th>
                                                <th>Deductions</th>
                                                <th>Net Base</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($salary_structures): while($s = mysqli_fetch_assoc($salary_structures)): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($s['full_name'] . ' (' . $s['employee_id'] . ')'); ?></td>
                                                    <td><?php echo htmlspecialchars($s['department'] ?: '-'); ?></td>
                                                    <td><?php echo format_number($s['basic_salary']); ?></td>
                                                    <td><?php echo format_number($s['allowances']); ?></td>
                                                    <td><?php echo format_number($s['deductions']); ?></td>
                                                    <td><?php echo format_number(($s['basic_salary'] + $s['allowances']) - $s['deductions']); ?></td>
                                                </tr>
                                            <?php endwhile; endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="payrollTab">
                <div class="row">
                    <div class="col-md-5">
                        <div class="card hr-card">
                            <div class="card-header bg-success text-white"><strong>Generate Payroll</strong></div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-2">
                                        <label class="form-label">Employee</label>
                                        <select class="form-select" name="user_id" required>
                                            <option value="">Select employee</option>
                                            <?php if($employees){ mysqli_data_seek($employees, 0); while($emp = mysqli_fetch_assoc($employees)): ?>
                                                <option value="<?php echo (int)$emp['user_id']; ?>">
                                                    <?php echo htmlspecialchars($emp['employee_id'] . ' - ' . $emp['full_name']); ?>
                                                </option>
                                            <?php endwhile; } ?>
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 mb-2">
                                            <label class="form-label">Month</label>
                                            <select class="form-select" name="pay_month" required>
                                                <?php for($m=1;$m<=12;$m++): ?>
                                                    <option value="<?php echo $m; ?>" <?php echo $m==(int)date('n') ? 'selected' : ''; ?>>
                                                        <?php echo date('F', mktime(0,0,0,$m,1)); ?>
                                                    </option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <div class="col-6 mb-2">
                                            <label class="form-label">Year</label>
                                            <input type="number" class="form-control" name="pay_year" value="<?php echo date('Y'); ?>" min="2000" max="2100" required>
                                        </div>
                                    </div>
                                    <button class="btn btn-success w-100 mt-2" name="generate_payroll" type="submit">
                                        <i class="fas fa-calculator"></i> Generate / Recalculate
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="card hr-card">
                            <div class="card-header bg-light"><strong>How Payroll Is Calculated</strong></div>
                            <div class="card-body">
                                <p class="mb-2">This module calculates payroll from attendance and salary structure:</p>
                                <ul>
                                    <li><code>present</code> and <code>late</code> = 1 full day each</li>
                                    <li><code>half_day</code> = 0.5 day</li>
                                    <li><code>absent</code> = unpaid day</li>
                                    <li><code>gross_salary = (basic_salary / days_in_month) * worked_days_equivalent</code></li>
                                    <li><code>net_salary = gross_salary + allowances - deductions</code></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="historyTab">
                <div class="card hr-card">
                    <div class="card-header bg-dark text-white"><strong>Payroll Records</strong></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" id="payrollTable">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Period</th>
                                        <th>Present</th>
                                        <th>Half</th>
                                        <th>Absent</th>
                                        <th>Net Salary</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($payroll_records): while($p = mysqli_fetch_assoc($payroll_records)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($p['full_name'] . ' (' . $p['employee_id'] . ')'); ?></td>
                                            <td><?php echo date('F', mktime(0,0,0,(int)$p['pay_month'],1)) . ' ' . (int)$p['pay_year']; ?></td>
                                            <td><?php echo format_number($p['present_days']); ?></td>
                                            <td><?php echo format_number($p['half_days']); ?></td>
                                            <td><?php echo format_number($p['absent_days']); ?></td>
                                            <td><?php echo format_number($p['net_salary']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $p['status'] === 'paid' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($p['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if($p['status'] !== 'paid'): ?>
                                                    <button class="btn btn-sm btn-primary"
                                                            onclick="openPayModal(<?php echo (int)$p['payroll_id']; ?>)">
                                                        Mark Paid
                                                    </button>
                                                <?php else: ?>
                                                    <small><?php echo htmlspecialchars(($p['payment_method'] ?: '-') . ' | ' . ($p['paid_date'] ? date('d-m-Y', strtotime($p['paid_date'])) : '-')); ?></small>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="payModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Mark Payroll as Paid</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="payroll_id" id="payrollIdInput">
                        <div class="mb-2">
                            <label class="form-label">Payment Method</label>
                            <select class="form-select" name="payment_method" required>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="cash">Cash</option>
                                <option value="mobile_money">Mobile Money</option>
                                <option value="cheque">Cheque</option>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="payment_notes" rows="2" placeholder="Optional payment notes"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" name="mark_paid">Confirm Payment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(function () {
            $('#salaryTable').DataTable({ pageLength: 10 });
            $('#payrollTable').DataTable({ order: [[1, 'desc']], pageLength: 10 });
        });

        function openPayModal(payrollId) {
            document.getElementById('payrollIdInput').value = payrollId;
            var modal = new bootstrap.Modal(document.getElementById('payModal'));
            modal.show();
        }
    </script>
</body>
</html>
