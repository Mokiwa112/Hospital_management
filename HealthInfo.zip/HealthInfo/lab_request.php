<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor']);
require_once 'lab_test_catalog_helper.php';
require_once 'billing_auto_helper.php';

$conn = getConnection();
seed_regional_lab_tests($conn);

// Get patient_id from URL if passed
$selected_patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : '';

// Fetch patients for dropdown
$patients = mysqli_query($conn, "SELECT patient_id, patient_number, first_name, last_name FROM patients ORDER BY first_name");

// Fetch lab tests for dropdown
$lab_tests = mysqli_query($conn, "SELECT test_id, test_name,
    CASE
        WHEN COALESCE(cost, 0) > 0 AND COALESCE(cost, 0) < 5000 THEN cost * 1000
        ELSE cost
    END AS cost,
    category, description, preparation_instructions, normal_range, unit
    FROM lab_tests
    ORDER BY test_name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_request'])) {
    $patient_id = (int)sanitize($_POST['patient_id']);
    $doctor_id = (int)$_SESSION['user_id'];
    $notes = sanitize($_POST['notes'] ?? '');
    $test_ids_raw = $_POST['test_ids'] ?? [];
    if (!is_array($test_ids_raw) && isset($_POST['test_id'])) {
        $test_ids_raw = [$_POST['test_id']];
    }
    $test_ids = [];
    foreach ((array)$test_ids_raw as $tid) {
        $tid = (int)sanitize($tid);
        if ($tid > 0 && !in_array($tid, $test_ids, true)) {
            $test_ids[] = $tid;
        }
    }

    if ($patient_id <= 0 || empty($test_ids)) {
        $_SESSION['error'] = "Please select patient and at least one lab test";
        redirect('lab_request.php' . ($selected_patient_id ? ('?patient_id=' . (int)$selected_patient_id) : ''));
    }

    mysqli_begin_transaction($conn);
    try {
        $created_count = 0;
        $notes_column = firstExistingColumn('lab_requests', ['notes', 'lab_notes']);
        foreach ($test_ids as $test_id) {
            $request_number = generateUniqueId('LAB', 'lab_requests', 'request_number');
            $columns = ['request_number', 'patient_id', 'doctor_id', 'test_id'];
            $values = ["'$request_number'", $patient_id, $doctor_id, $test_id];

            if ($notes_column !== null) {
                $columns[] = $notes_column;
                $values[] = "'$notes'";
            }
            if (tableHasColumn('lab_requests', 'created_by')) {
                $columns[] = 'created_by';
                $values[] = (int)$_SESSION['user_id'];
            }
            if (tableHasColumn('lab_requests', 'status')) {
                $columns[] = 'status';
                $values[] = "'pending'";
            }

            $query = "INSERT INTO lab_requests (" . implode(', ', $columns) . ")
                      VALUES (" . implode(', ', $values) . ")";
            if (!mysqli_query($conn, $query)) {
                throw new Exception(mysqli_error($conn));
            }
            $created_count++;
        }

        mysqli_commit($conn);

        $auto_notes = "Auto-generated bill for uninsured patient after lab request creation (multi-test request).";
        $auto_bill = create_auto_bill_for_uninsured_patient(
            $conn,
            $patient_id,
            (int)$_SESSION['user_id'],
            $auto_notes,
            ['include_requested_lab' => true]
        );
        $_SESSION['success'] = $created_count . " lab request(s) created successfully.";
        if (!empty($auto_bill['created'])) {
            $_SESSION['success'] .= " Bill " . $auto_bill['bill_number'] . " was created automatically.";
        }
        redirect('lab_requests_list.php');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Lab Request - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .test-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            display: none;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-flask"></i> New Laboratory Request</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" id="labRequestForm">
                            <div class="mb-3">
                                <label class="form-label">Select Patient *</label>
                                <select class="form-control" name="patient_id" id="patient_id" required>
                                    <option value="">Choose patient</option>
                                    <?php while($patient = mysqli_fetch_assoc($patients)): ?>
                                        <option value="<?php echo $patient['patient_id']; ?>" 
                                            <?php echo ($selected_patient_id == $patient['patient_id']) ? 'selected' : ''; ?>>
                                            <?php echo $patient['patient_number'] . ' - ' . $patient['first_name'] . ' ' . $patient['last_name']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Select Test(s) *</label>
                                <select class="form-control" name="test_ids[]" id="test_ids" required multiple>
                                    <?php while($test = mysqli_fetch_assoc($lab_tests)): ?>
                                        <option value="<?php echo $test['test_id']; ?>">
                                            <?php echo htmlspecialchars($test['test_name']); ?> - <?php echo format_currency($test['cost']); ?> (<?php echo htmlspecialchars($test['category']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                                <small class="text-muted">You can select multiple tests for one patient request.</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="notes" rows="3" placeholder="Any specific instructions or notes..."></textarea>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" name="submit_request" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Submit Request
                                </button>
                                <a href="patients.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#patient_id').select2({ width: '100%' });
            $('#test_ids').select2({
                width: '100%',
                closeOnSelect: false,
                placeholder: 'Choose one or more tests'
            });
        });
    </script>
</body>
</html>
