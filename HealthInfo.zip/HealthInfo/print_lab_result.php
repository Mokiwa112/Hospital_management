<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch lab request details
$query = "SELECT lr.*, p.first_name, p.last_name, p.patient_number, p.date_of_birth, p.gender,
          lt.test_name, lt.category, lt.normal_range, lt.unit,
          u.full_name as doctor_name,
          tech.full_name as tech_name
          FROM lab_requests lr
          JOIN patients p ON lr.patient_id = p.patient_id
          JOIN lab_tests lt ON lr.test_id = lt.test_id
          LEFT JOIN users u ON lr.doctor_id = u.user_id
          LEFT JOIN users tech ON lr.lab_tech_id = tech.user_id
          WHERE lr.request_id = $request_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Lab request not found");
}

$lab = mysqli_fetch_assoc($result);
$print_notes = $lab['lab_notes'] ?? ($lab['result_notes'] ?? '');
$parsed_lab_notes = parseStructuredLabNotes($print_notes);
$display_lab_unit = normalizeLabUnit($lab['unit'] ?? '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab Result - <?php echo $lab['test_name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
            body { font-size: 12pt; }
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #333;
        }
        .patient-info {
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .result-box {
            padding: 30px;
            border: 2px solid #28a745;
            border-radius: 10px;
            margin: 30px 0;
            text-align: center;
        }
        .result-value {
            font-size: 36px;
            font-weight: bold;
            color: #28a745;
        }
        .normal-range {
            color: #666;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4 mb-4">
        <div class="no-print text-end mb-3">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print
            </button>
            <button onclick="window.close()" class="btn btn-secondary">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
        
        <div class="header">
            <h2><?php echo SITE_NAME; ?></h2>
            <h3>Laboratory Test Result</h3>
        </div>
        
        <div class="patient-info">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Patient Name:</strong> <?php echo $lab['first_name'] . ' ' . $lab['last_name']; ?></p>
                    <p><strong>Patient #:</strong> <?php echo $lab['patient_number']; ?></p>
                    <p><strong>Date of Birth:</strong> <?php echo date('d M Y', strtotime($lab['date_of_birth'])); ?></p>
                    <p><strong>Gender:</strong> <?php echo $lab['gender'] == 'M' ? 'Male' : ($lab['gender'] == 'F' ? 'Female' : 'Other'); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Test Name:</strong> <?php echo $lab['test_name']; ?></p>
                    <p><strong>Category:</strong> <?php echo $lab['category']; ?></p>
                    <p><strong>Requested By:</strong> Dr. <?php echo $lab['doctor_name']; ?></p>
                    <p><strong>Request Date:</strong> <?php echo date('d M Y', strtotime($lab['request_date'])); ?></p>
                </div>
            </div>
        </div>
        
        <?php if($lab['status'] == 'completed'): ?>
            <div class="result-box">
                <h4>Test Result</h4>
                <div class="result-value">
                    <?php echo htmlspecialchars($lab['result_value']); ?><?php echo $display_lab_unit !== '' ? ' ' . htmlspecialchars($display_lab_unit) : ''; ?>
                </div>
                <div class="normal-range">
                    Normal Range: <?php echo $lab['normal_range'] ?: 'Not specified'; ?>
                </div>
                <?php if($lab['result_date']): ?>
                    <p class="mt-3">
                        <small>Reported on: <?php echo date('d M Y h:i A', strtotime($lab['result_date'])); ?></small>
                    </p>
                <?php endif; ?>
            </div>
            
            <?php if(!empty($parsed_lab_notes['parameters'])): ?>
                <div class="mt-4">
                    <h5>Detailed Parameters</h5>
                    <table class="table table-bordered table-sm">
                        <thead>
                            <tr>
                                <th>Parameter</th>
                                <th>Value</th>
                                <th>Reference</th>
                                <th>Flag</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($parsed_lab_notes['parameters'] as $param): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($param['name']); ?></td>
                                    <td><?php echo htmlspecialchars($param['value'] . (!empty($param['unit']) ? ' ' . $param['unit'] : '')); ?></td>
                                    <td><?php echo htmlspecialchars($param['reference'] ?: '-'); ?></td>
                                    <td><?php echo htmlspecialchars($param['flag'] ?: '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <?php if(!empty($parsed_lab_notes['plain_notes'])): ?>
                <div class="mt-4">
                    <h5>Lab Notes</h5>
                    <p><?php echo nl2br(htmlspecialchars($parsed_lab_notes['plain_notes'])); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="mt-4">
                <p><strong>Processed by:</strong> <?php echo $lab['tech_name'] ?: 'N/A'; ?></p>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <h5>Test Not Completed</h5>
                <p>This test is still <?php echo $lab['status']; ?>. Results are not available yet.</p>
            </div>
        <?php endif; ?>
        
        <div class="footer text-center mt-5">
            <p>This is a computer generated laboratory report.</p>
        </div>
    </div>
</body>
</html>
