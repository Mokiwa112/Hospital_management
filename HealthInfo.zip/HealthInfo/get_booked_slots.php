<?php
require_once 'config.php';

if (isset($_POST['doctor_id']) && isset($_POST['date'])) {
    $doctor_id = sanitize($_POST['doctor_id']);
    $date = sanitize($_POST['date']);
    
    $conn = getConnection();
    
    $query = "SELECT appointment_time FROM appointments 
              WHERE doctor_id = $doctor_id 
              AND appointment_date = '$date' 
              AND status != 'cancelled'";
    
    $result = mysqli_query($conn, $query);
    
    $booked_slots = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $booked_slots[] = $row['appointment_time'];
    }
    
    echo json_encode($booked_slots);
    
    mysqli_close($conn);
}
?>