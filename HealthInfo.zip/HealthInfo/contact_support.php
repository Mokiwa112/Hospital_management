<?php
require_once 'config.php';

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_portal.php");
    exit();
}

$conn = getConnection();
$patient_id = $_SESSION['patient_id'];
$success = '';
$error = '';

// Handle support message submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);
    
    // In a real system, you'd save this to a database or send an email
    // For demo, we'll just show success
    $success = "Your message has been sent to support. We'll respond within 24 hours.";
    
    // Log the support request
    $log_query = "INSERT INTO support_queries (patient_id, subject, message, status) 
                  VALUES ($patient_id, '$subject', '$message', 'pending')";
    @mysqli_query($conn, $log_query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Support - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h4><i class="fas fa-headset"></i> Contact Support</h4>
                    </div>
                    <div class="card-body">
                        <?php if($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <?php if($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <div class="row mb-4">
                            <div class="col-md-4 text-center">
                                <i class="fas fa-phone-alt fa-3x text-primary mb-3"></i>
                                <h6>Phone Support</h6>
                                <p>+1 (555) 123-4567<br>Mon-Fri, 8am-8pm</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <i class="fas fa-envelope fa-3x text-primary mb-3"></i>
                                <h6>Email</h6>
                                <p>support@hospital.com<br>24/7 Response</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <i class="fas fa-clock fa-3x text-primary mb-3"></i>
                                <h6>Hospital</h6>
                                <p><?php echo SITE_NAME; ?></p>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h5 class="mb-3">Send us a message</h5>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Subject</label>
                                <select class="form-control" name="subject" required>
                                    <option value="">Select a topic</option>
                                    <option value="appointment">Appointment Issues</option>
                                    <option value="billing">Billing Questions</option>
                                    <option value="records">Medical Records</option>
                                    <option value="technical">Technical Support</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" name="message" rows="5" 
                                          placeholder="Please describe your issue or question..." required></textarea>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Send Message
                                </button>
                                <a href="patient_dashboard.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
