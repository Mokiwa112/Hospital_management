<?php

if (!function_exists('seed_regional_lab_tests')) {
    function seed_regional_lab_tests($conn) {
        // Normalize legacy low monetary values to realistic TZS scale.
        @mysqli_query($conn, "UPDATE lab_tests SET cost = cost * 1000 WHERE cost > 0 AND cost < 5000");
        @mysqli_query($conn, "UPDATE inventory_items SET unit_price = unit_price * 1000 WHERE unit_price > 0 AND unit_price < 1000");
        @mysqli_query($conn, "UPDATE billing_items SET unit_price = unit_price * 1000 WHERE unit_price > 0 AND unit_price < 1000");
        @mysqli_query($conn, "UPDATE billing_items SET total_price = total_price * 1000 WHERE total_price > 0 AND total_price < 1000");
        @mysqli_query($conn, "UPDATE billing SET total_amount = total_amount * 1000 WHERE total_amount > 0 AND total_amount < 1000");
        @mysqli_query($conn, "UPDATE billing SET discount = discount * 1000 WHERE discount > 0 AND discount < 1000");
        @mysqli_query($conn, "UPDATE billing SET tax = tax * 1000 WHERE tax > 0 AND tax < 1000");
        @mysqli_query($conn, "UPDATE billing SET net_amount = net_amount * 1000 WHERE net_amount > 0 AND net_amount < 1000");

        $tests = [
            ['code' => 'MAL001', 'name' => 'Malaria Rapid Test', 'category' => 'Parasitology', 'desc' => 'Rapid antigen detection for malaria', 'prep' => 'No fasting required', 'range' => 'Negative', 'unit' => 'test', 'cost' => 18000],
            ['code' => 'MAL002', 'name' => 'Malaria Blood Smear', 'category' => 'Parasitology', 'desc' => 'Microscopy thick and thin film for malaria parasites', 'prep' => 'No fasting required', 'range' => 'No parasites seen', 'unit' => 'test', 'cost' => 22000],
            ['code' => 'FBS001', 'name' => 'Fasting Blood Sugar', 'category' => 'Chemistry', 'desc' => 'Fasting plasma glucose level', 'prep' => 'Fast for 8-10 hours', 'range' => '3.9-5.5 mmol/L', 'unit' => 'mmol/L', 'cost' => 15000],
            ['code' => 'RBS001', 'name' => 'Random Blood Sugar', 'category' => 'Chemistry', 'desc' => 'Random glucose test', 'prep' => 'No fasting required', 'range' => '<7.8 mmol/L', 'unit' => 'mmol/L', 'cost' => 12000],
            ['code' => 'HBA001', 'name' => 'HbA1c', 'category' => 'Chemistry', 'desc' => 'Average glucose level over 3 months', 'prep' => 'No fasting required', 'range' => '<5.7%', 'unit' => '%', 'cost' => 45000],
            ['code' => 'LFT001', 'name' => 'Liver Function Test', 'category' => 'Chemistry', 'desc' => 'Panel for liver enzymes and bilirubin', 'prep' => 'No alcohol 24 hours prior', 'range' => 'Within reference', 'unit' => 'panel', 'cost' => 65000],
            ['code' => 'RFT001', 'name' => 'Renal Function Test', 'category' => 'Chemistry', 'desc' => 'Kidney function panel (urea, creatinine, electrolytes)', 'prep' => 'No fasting required', 'range' => 'Within reference', 'unit' => 'panel', 'cost' => 70000],
            ['code' => 'ELC001', 'name' => 'Electrolytes (Na, K, Cl)', 'category' => 'Chemistry', 'desc' => 'Serum electrolyte panel', 'prep' => 'No fasting required', 'range' => 'Within reference', 'unit' => 'panel', 'cost' => 55000],
            ['code' => 'URC001', 'name' => 'Uric Acid', 'category' => 'Chemistry', 'desc' => 'Serum uric acid test', 'prep' => 'No high-purine meal prior', 'range' => '3.4-7.0 mg/dL', 'unit' => 'mg/dL', 'cost' => 22000],
            ['code' => 'LIP002', 'name' => 'Lipid Profile', 'category' => 'Chemistry', 'desc' => 'Total cholesterol, HDL, LDL, triglycerides', 'prep' => 'Fast for 12 hours', 'range' => 'Within reference', 'unit' => 'panel', 'cost' => 55000],
            ['code' => 'ESR001', 'name' => 'Erythrocyte Sedimentation Rate (ESR)', 'category' => 'Hematology', 'desc' => 'Inflammation screening test', 'prep' => 'No fasting required', 'range' => '0-20 mm/hr', 'unit' => 'mm/hr', 'cost' => 12000],
            ['code' => 'CRP001', 'name' => 'C-Reactive Protein (CRP)', 'category' => 'Immunology', 'desc' => 'Inflammatory marker', 'prep' => 'No fasting required', 'range' => '<5 mg/L', 'unit' => 'mg/L', 'cost' => 35000],
            ['code' => 'BGR001', 'name' => 'Blood Group and Rh', 'category' => 'Hematology', 'desc' => 'ABO and Rh blood grouping', 'prep' => 'No fasting required', 'range' => 'ABO/Rh typed', 'unit' => 'test', 'cost' => 20000],
            ['code' => 'CMT001', 'name' => 'Crossmatch Test', 'category' => 'Hematology', 'desc' => 'Donor-recipient compatibility test', 'prep' => 'As advised', 'range' => 'Compatible', 'unit' => 'test', 'cost' => 35000],
            ['code' => 'WID001', 'name' => 'Widal Test', 'category' => 'Microbiology', 'desc' => 'Typhoid serology', 'prep' => 'No fasting required', 'range' => 'Negative', 'unit' => 'test', 'cost' => 18000],
            ['code' => 'HIV001', 'name' => 'HIV Rapid Test', 'category' => 'Serology', 'desc' => 'Rapid HIV 1/2 antibody screening', 'prep' => 'Counseling recommended', 'range' => 'Non-reactive', 'unit' => 'test', 'cost' => 15000],
            ['code' => 'HBV001', 'name' => 'HBsAg (Hepatitis B)', 'category' => 'Serology', 'desc' => 'Hepatitis B surface antigen test', 'prep' => 'No fasting required', 'range' => 'Negative', 'unit' => 'test', 'cost' => 25000],
            ['code' => 'HCV001', 'name' => 'Hepatitis C Antibody', 'category' => 'Serology', 'desc' => 'HCV antibody screening', 'prep' => 'No fasting required', 'range' => 'Negative', 'unit' => 'test', 'cost' => 28000],
            ['code' => 'VDR001', 'name' => 'VDRL / RPR', 'category' => 'Serology', 'desc' => 'Syphilis screening test', 'prep' => 'No fasting required', 'range' => 'Non-reactive', 'unit' => 'test', 'cost' => 20000],
            ['code' => 'UPT001', 'name' => 'Urine Pregnancy Test', 'category' => 'Clinical Pathology', 'desc' => 'hCG qualitative urine test', 'prep' => 'Morning sample preferred', 'range' => 'Negative', 'unit' => 'test', 'cost' => 12000],
            ['code' => 'URN001', 'name' => 'Urine Microscopy', 'category' => 'Clinical Pathology', 'desc' => 'Microscopy for urine sediments', 'prep' => 'Clean catch sample', 'range' => 'Within reference', 'unit' => 'test', 'cost' => 16000],
            ['code' => 'STL001', 'name' => 'Stool Analysis', 'category' => 'Clinical Pathology', 'desc' => 'Routine stool microscopy and occult blood', 'prep' => 'Fresh stool sample', 'range' => 'No abnormalities', 'unit' => 'test', 'cost' => 18000],
            ['code' => 'BUN001', 'name' => 'Blood Urea Nitrogen', 'category' => 'Chemistry', 'desc' => 'BUN kidney assessment', 'prep' => 'No fasting required', 'range' => '7-20 mg/dL', 'unit' => 'mg/dL', 'cost' => 18000],
            ['code' => 'CRE001', 'name' => 'Serum Creatinine', 'category' => 'Chemistry', 'desc' => 'Kidney marker test', 'prep' => 'No fasting required', 'range' => '0.6-1.3 mg/dL', 'unit' => 'mg/dL', 'cost' => 18000],
            ['code' => 'PSA001', 'name' => 'Prostate Specific Antigen (PSA)', 'category' => 'Chemistry', 'desc' => 'PSA level test', 'prep' => 'Avoid ejaculation 48 hours', 'range' => '<4 ng/mL', 'unit' => 'ng/mL', 'cost' => 50000],
            ['code' => 'TSH002', 'name' => 'TSH', 'category' => 'Endocrinology', 'desc' => 'Thyroid stimulating hormone level', 'prep' => 'No fasting required', 'range' => '0.4-4.0 mIU/L', 'unit' => 'mIU/L', 'cost' => 32000],
            ['code' => 'FT4001', 'name' => 'Free T4', 'category' => 'Endocrinology', 'desc' => 'Free thyroxine level', 'prep' => 'No fasting required', 'range' => '0.8-1.8 ng/dL', 'unit' => 'ng/dL', 'cost' => 42000],
            ['code' => 'DRE001', 'name' => 'Dengue Rapid Test', 'category' => 'Serology', 'desc' => 'Dengue NS1/IgM rapid test', 'prep' => 'No fasting required', 'range' => 'Negative', 'unit' => 'test', 'cost' => 38000],
            ['code' => 'TBX001', 'name' => 'GeneXpert MTB/RIF', 'category' => 'Molecular', 'desc' => 'Rapid TB molecular test', 'prep' => 'Sputum sample', 'range' => 'Not Detected', 'unit' => 'test', 'cost' => 120000],
            ['code' => 'BCT001', 'name' => 'Blood Culture and Sensitivity', 'category' => 'Microbiology', 'desc' => 'Detect bloodstream infection and sensitivity', 'prep' => 'Sample before antibiotics', 'range' => 'No growth', 'unit' => 'test', 'cost' => 95000]
        ];

        $inserted = 0;
        foreach ($tests as $t) {
            $code = sanitize($t['code']);
            $exists = mysqli_query($conn, "SELECT test_id FROM lab_tests WHERE test_code = '$code' LIMIT 1");
            if ($exists && mysqli_num_rows($exists) > 0) {
                continue;
            }

            $name = sanitize($t['name']);
            $category = sanitize($t['category']);
            $desc = sanitize($t['desc']);
            $prep = sanitize($t['prep']);
            $range = sanitize($t['range']);
            $unit = sanitize($t['unit']);
            $cost = (float)$t['cost'];

            $sql = "INSERT INTO lab_tests
                    (test_code, test_name, category, description, preparation_instructions, normal_range, unit, cost)
                    VALUES
                    ('$code', '$name', '$category', '$desc', '$prep', '$range', '$unit', $cost)";
            if (mysqli_query($conn, $sql)) {
                $inserted++;
            }
        }

        return $inserted;
    }
}

?>
