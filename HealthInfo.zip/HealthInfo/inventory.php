<?php
require_once 'config.php';
requireInventoryAccess(false);
$can_edit_inventory = canAccessInventory(true);
$is_admin_user = (($_SESSION['user_type'] ?? '') === 'admin');

function columnExists($table, $column) {
    return tableHasColumn($table, $column);
}

function dbValueOrNull($value) {
    if ($value === null || $value === '') return 'NULL';
    return "'" . sanitize($value) . "'";
}

function dbNumericOrZero($value) {
    if ($value === null || $value === '') return 0;
    return (float)$value;
}

// Handle AJAX requests
if (isset($_POST['action'])) {
    if ($_POST['action'] === 'save_access') {
        requireRole('admin');
        $conn = getConnection();
        @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS inventory_user_access (
            access_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            can_view TINYINT(1) NOT NULL DEFAULT 1,
            can_edit TINYINT(1) NOT NULL DEFAULT 0,
            granted_by INT DEFAULT NULL,
            granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_inventory_access_user (user_id),
            KEY idx_inventory_access_edit (can_edit),
            CONSTRAINT fk_inventory_access_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            CONSTRAINT fk_inventory_access_granted_by FOREIGN KEY (granted_by) REFERENCES users(user_id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $submitted_users = $_POST['users'] ?? [];
        $view_access = $_POST['can_view'] ?? [];
        $edit_access = $_POST['can_edit'] ?? [];
        $admin_id = (int)($_SESSION['user_id'] ?? 0);

        mysqli_begin_transaction($conn);
        try {
            mysqli_query($conn, "DELETE ia FROM inventory_user_access ia
                                 INNER JOIN users u ON ia.user_id = u.user_id
                                 WHERE u.user_type <> 'admin'");

            foreach ($submitted_users as $uid_raw) {
                $uid = (int)$uid_raw;
                if ($uid <= 0) continue;
                $can_view = isset($view_access[$uid]) ? 1 : 0;
                $can_edit = isset($edit_access[$uid]) ? 1 : 0;
                if ($can_edit === 1) $can_view = 1;
                if ($can_view === 0 && $can_edit === 0) continue;

                mysqli_query(
                    $conn,
                    "INSERT INTO inventory_user_access (user_id, can_view, can_edit, granted_by)
                     VALUES ($uid, $can_view, $can_edit, $admin_id)"
                );
            }

            mysqli_commit($conn);
            $_SESSION['success'] = 'Inventory access rights updated successfully.';
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $_SESSION['error'] = 'Failed to update inventory access rights.';
        }
        redirect('inventory.php?access=1');
    }

    requireInventoryAccess(true);
    $conn = getConnection();
    
    if ($_POST['action'] == 'add_item') {
        $item_code = generateUniqueId('INV', 'inventory_items', 'item_code');
        $item_name = sanitize($_POST['item_name']);
        $category = sanitize($_POST['category']);
        $inventory_class = sanitize($_POST['inventory_class'] ?? 'medical_supplies');
        $description = sanitize($_POST['description']);
        $unit = sanitize($_POST['unit']);
        $quantity = sanitize($_POST['quantity']);
        $reorder_level = sanitize($_POST['reorder_level']);
        $unit_price = sanitize($_POST['unit_price']);
        $supplier = sanitize($_POST['supplier']);
        $expiry_date = dbValueOrNull($_POST['expiry_date'] ?? null);

        $extraData = [
            'inventory_class' => $inventory_class,
            'drug_type' => sanitize($_POST['drug_type'] ?? ''),
            'strength' => sanitize($_POST['strength'] ?? ''),
            'batch_number' => sanitize($_POST['batch_number'] ?? ''),
            'lab_test_type' => sanitize($_POST['lab_test_type'] ?? ''),
            'reagent_name' => sanitize($_POST['reagent_name'] ?? ''),
            'storage_condition' => sanitize($_POST['storage_condition'] ?? ''),
            'serial_number' => sanitize($_POST['serial_number'] ?? ''),
            'assigned_department' => sanitize($_POST['assigned_department'] ?? ''),
            'ip_address' => sanitize($_POST['ip_address'] ?? ''),
            'item_condition' => sanitize($_POST['item_condition'] ?? ''),
            'purchase_date' => sanitize($_POST['purchase_date'] ?? ''),
            'maintenance_date' => sanitize($_POST['maintenance_date'] ?? ''),
            'status' => sanitize($_POST['status'] ?? 'active')
        ];

        $columns = ['item_code', 'item_name', 'category', 'description', 'unit', 'quantity', 'reorder_level', 'unit_price', 'supplier', 'expiry_date'];
        $values = [
            "'$item_code'",
            "'$item_name'",
            "'$category'",
            "'$description'",
            "'$unit'",
            (int)$quantity,
            (int)$reorder_level,
            dbNumericOrZero($unit_price),
            "'$supplier'",
            $expiry_date
        ];

        foreach ($extraData as $col => $val) {
            if (!columnExists('inventory_items', $col)) continue;
            $columns[] = $col;
            if (in_array($col, ['purchase_date', 'maintenance_date'], true)) {
                $values[] = dbValueOrNull($val);
            } else {
                $values[] = dbValueOrNull($val);
            }
        }

        $query = "INSERT INTO inventory_items (" . implode(',', $columns) . ") VALUES (" . implode(',', $values) . ")";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['success' => true, 'message' => 'Item added successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => mysqli_error($conn)]);
        }
    }
    
    elseif ($_POST['action'] == 'update_stock') {
        $item_id = sanitize($_POST['item_id']);
        $quantity = sanitize($_POST['quantity']);
        $type = sanitize($_POST['type']);
        $notes = sanitize($_POST['notes']);
        $from_location = sanitize($_POST['from_location'] ?? '');
        $to_location = sanitize($_POST['to_location'] ?? '');
        
        // Start transaction
        mysqli_begin_transaction($conn);
        
        try {
            // Update inventory
            if (in_array($type, ['purchase', 'return', 'stock_in'], true)) {
                $update = "UPDATE inventory_items SET quantity = quantity + $quantity WHERE item_id = $item_id";
            } else {
                $update = "UPDATE inventory_items SET quantity = quantity - $quantity WHERE item_id = $item_id";
            }
            mysqli_query($conn, $update);

            $balance = 0;
            $bal_result = mysqli_query($conn, "SELECT quantity FROM inventory_items WHERE item_id = $item_id LIMIT 1");
            if ($bal_result && mysqli_num_rows($bal_result) === 1) {
                $balance = (float)mysqli_fetch_assoc($bal_result)['quantity'];
            }
            
            // Record transaction
            $trans_columns = ['item_id', 'transaction_type', 'quantity', 'performed_by', 'notes'];
            $trans_values = [$item_id, "'$type'", (int)$quantity, (int)$_SESSION['user_id'], "'$notes'"];
            if (columnExists('inventory_transactions', 'from_location')) {
                $trans_columns[] = 'from_location';
                $trans_values[] = dbValueOrNull($from_location);
            }
            if (columnExists('inventory_transactions', 'to_location')) {
                $trans_columns[] = 'to_location';
                $trans_values[] = dbValueOrNull($to_location);
            }
            if (columnExists('inventory_transactions', 'balance_after')) {
                $trans_columns[] = 'balance_after';
                $trans_values[] = $balance;
            }

            $trans_query = "INSERT INTO inventory_transactions (" . implode(',', $trans_columns) . ")
                            VALUES (" . implode(',', $trans_values) . ")";
            mysqli_query($conn, $trans_query);
            
            mysqli_commit($conn);
            echo json_encode(['success' => true, 'message' => 'Stock updated successfully']);
        } catch (Exception $e) {
            mysqli_rollback($conn);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    mysqli_close($conn);
    exit();
}

// Fetch inventory items
$conn = getConnection();
$items = mysqli_query($conn, "SELECT * FROM inventory_items ORDER BY item_name");
$low_stock = mysqli_query($conn, "SELECT * FROM inventory_items WHERE quantity <= reorder_level");
$expiry_alerts = mysqli_query(
    $conn,
    "SELECT * FROM inventory_items
     WHERE expiry_date IS NOT NULL
       AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY)
     ORDER BY expiry_date ASC"
);
$supplier_names = [];
if (tableHasColumn('inventory_suppliers', 'supplier_name')) {
    $sup_rs = mysqli_query($conn, "SELECT supplier_name FROM inventory_suppliers WHERE is_active = 1 ORDER BY supplier_name");
    if ($sup_rs) {
        while ($s = mysqli_fetch_assoc($sup_rs)) {
            $supplier_names[] = $s['supplier_name'];
        }
    }
}
$class_summary = mysqli_query(
    $conn,
    "SELECT COALESCE(inventory_class, 'uncategorized') AS inventory_class, COUNT(*) AS total_items
     FROM inventory_items
     GROUP BY COALESCE(inventory_class, 'uncategorized')
     ORDER BY total_items DESC"
);

$access_users_rs = null;
if ($is_admin_user) {
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS inventory_user_access (
        access_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        can_view TINYINT(1) NOT NULL DEFAULT 1,
        can_edit TINYINT(1) NOT NULL DEFAULT 0,
        granted_by INT DEFAULT NULL,
        granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_inventory_access_user (user_id),
        KEY idx_inventory_access_edit (can_edit),
        CONSTRAINT fk_inventory_access_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
        CONSTRAINT fk_inventory_access_granted_by FOREIGN KEY (granted_by) REFERENCES users(user_id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $access_users_rs = mysqli_query(
        $conn,
        "SELECT u.user_id, u.full_name, u.username, u.user_type, u.department,
                COALESCE(a.can_view, 0) AS can_view,
                COALESCE(a.can_edit, 0) AS can_edit
         FROM users u
         LEFT JOIN inventory_user_access a ON a.user_id = u.user_id
         WHERE u.user_type <> 'admin'
        ORDER BY u.user_type, u.full_name"
    );
}

$page_success = $_SESSION['success'] ?? '';
$page_error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        #inventoryAccessModal .modal-body {
            max-height: calc(100vh - 220px);
            overflow-y: auto;
        }
        #inventoryAccessModal .modal-footer {
            position: sticky;
            bottom: 0;
            background: #fff;
            border-top: 1px solid #dee2e6;
            z-index: 2;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4><i class="fas fa-boxes"></i> Inventory Management</h4>
                        <div class="d-flex gap-2">
                            <?php if($is_admin_user): ?>
                                <a class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#inventoryAccessModal" role="button">
                                    <i class="fas fa-user-shield"></i> Inventory Access
                                </a>
                            <?php endif; ?>
                            <button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#addItemModal" <?php echo $can_edit_inventory ? '' : 'disabled'; ?>>
                                <i class="fas fa-plus"></i> Add New Item
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($page_success)): ?>
                            <div class="alert alert-success"><?php echo htmlspecialchars($page_success); ?></div>
                        <?php endif; ?>
                        <?php if (!empty($page_error)): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($page_error); ?></div>
                        <?php endif; ?>

                        <?php if($class_summary && mysqli_num_rows($class_summary) > 0): ?>
                            <div class="row mb-3">
                                <?php while($summary = mysqli_fetch_assoc($class_summary)): ?>
                                    <div class="col-md-4 col-lg-2 mb-2">
                                        <div class="border rounded p-2 bg-light h-100">
                                            <small class="text-muted d-block"><?php echo ucfirst(str_replace('_', ' ', $summary['inventory_class'])); ?></small>
                                            <strong><?php echo (int)$summary['total_items']; ?> items</strong>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php endif; ?>

                        <!-- Low Stock Alert -->
                        <?php if(mysqli_num_rows($low_stock) > 0): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong><i class="fas fa-exclamation-triangle"></i> Low Stock Alert!</strong>
                                <ul>
                                    <?php while($item = mysqli_fetch_assoc($low_stock)): ?>
                                        <li><?php echo $item['item_name']; ?> - Current: <?php echo $item['quantity']; ?> <?php echo $item['unit']; ?> (Reorder at: <?php echo $item['reorder_level']; ?>)</li>
                                    <?php endwhile; ?>
                                </ul>
                                <div class="small">Suggestion: reorder quantity = (reorder level x 2) - current stock.</div>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if($expiry_alerts && mysqli_num_rows($expiry_alerts) > 0): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><i class="fas fa-hourglass-half"></i> Expiry Alert (90 days)</strong>
                                <ul>
                                    <?php while($exp = mysqli_fetch_assoc($expiry_alerts)): ?>
                                        <li>
                                            <?php echo $exp['item_name']; ?> -
                                            Exp: <?php echo date('d-m-Y', strtotime($exp['expiry_date'])); ?>
                                        </li>
                                    <?php endwhile; ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Inventory Table -->
                        <table id="inventoryTable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Name</th>
                                    <th>Class</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Unit</th>
                                    <th>Reorder Level</th>
                                    <th>Unit Price</th>
                                    <th>Supplier</th>
                                    <th>Expiry Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($item = mysqli_fetch_assoc($items)): ?>
                                    <tr class="<?php echo ($item['quantity'] <= $item['reorder_level']) ? 'table-warning' : ''; ?>">
                                        <td><?php echo $item['item_code']; ?></td>
                                        <td><?php echo $item['item_name']; ?></td>
                                        <td><?php echo isset($item['inventory_class']) ? ucfirst(str_replace('_',' ', $item['inventory_class'])) : 'N/A'; ?></td>
                                        <td><?php echo $item['category']; ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td><?php echo $item['unit']; ?></td>
                                        <td><?php echo $item['reorder_level']; ?></td>
                                        <td><?php echo format_currency($item['unit_price']); ?></td>
                                        <td><?php echo $item['supplier']; ?></td>
                                        <td>
                                            <?php 
                                            if($item['expiry_date']) {
                                                $expiry = new DateTime($item['expiry_date']);
                                                $today = new DateTime();
                                                $diff = $today->diff($expiry)->days;
                                                $class = ($expiry < $today) ? 'text-danger' : (($diff < 30) ? 'text-warning' : '');
                                                echo "<span class='$class'>" . date('d-m-Y', strtotime($item['expiry_date'])) . "</span>";
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary mb-1" onclick="stockIn(<?php echo $item['item_id']; ?>, '<?php echo $item['item_name']; ?>')">
                                                <i class="fas fa-arrow-down"></i> Stock In
                                            </button>
                                            <button class="btn btn-sm btn-success" onclick="updateStock(<?php echo $item['item_id']; ?>, '<?php echo $item['item_name']; ?>')">
                                                <i class="fas fa-edit"></i> Stock
                                            </button>
                                            <button class="btn btn-sm btn-info" onclick="viewHistory(<?php echo $item['item_id']; ?>)">
                                                <i class="fas fa-history"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php if(!$can_edit_inventory): ?>
        <div class="container-fluid">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Una ruhusa ya kuangalia inventory tu. Kuongeza au kubadili stock, omba admin akupe <code>edit access</code>.
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Add Item Modal -->
    <div class="modal fade" id="addItemModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-plus-circle"></i> Add New Inventory Item</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="addItemForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Item Name *</label>
                            <input type="text" class="form-control" name="item_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Inventory Class *</label>
                            <select class="form-control" name="inventory_class" id="inventory_class" required>
                                <option value="medical_supplies">Medical Supplies</option>
                                <option value="pharmacy_drugs">Pharmacy / Drugs</option>
                                <option value="laboratory">Laboratory</option>
                                <option value="medical_equipment">Medical Equipment</option>
                                <option value="consumables_office">Consumables & Office</option>
                                <option value="it_system">IT & System</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category *</label>
                            <select class="form-control" name="category" required>
                                <option value="">Select Category</option>
                                <option value="Syringes">Syringes</option>
                                <option value="Needles">Needles</option>
                                <option value="IV Fluids">IV Fluids</option>
                                <option value="Gloves">Gloves</option>
                                <option value="Face Masks">Face Masks</option>
                                <option value="Bandages">Bandages</option>
                                <option value="Cotton Wool">Cotton Wool</option>
                                <option value="Gauze">Gauze</option>
                                <option value="Drug">Drug</option>
                                <option value="Lab Reagent">Lab Reagent</option>
                                <option value="Medical Equipment">Medical Equipment</option>
                                <option value="Office Supplies">Office Supplies</option>
                                <option value="IT Device">IT Device</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="2"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Unit *</label>
                                <input type="text" class="form-control" name="unit" placeholder="e.g., pcs, box, bottle" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Initial Quantity *</label>
                                <input type="number" class="form-control" name="quantity" min="0" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Reorder Level *</label>
                                <input type="number" class="form-control" name="reorder_level" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Unit Price (TZS) *</label>
                                <input type="number" step="0.01" class="form-control" name="unit_price" min="0" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Supplier</label>
                            <input type="text" list="supplierList" class="form-control" name="supplier">
                            <datalist id="supplierList">
                                <?php foreach($supplier_names as $sup): ?>
                                    <option value="<?php echo htmlspecialchars($sup); ?>"></option>
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Expiry Date</label>
                            <input type="date" class="form-control" name="expiry_date">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Batch Number</label>
                                <input type="text" class="form-control" name="batch_number" placeholder="For drugs/lab">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Strength</label>
                                <input type="text" class="form-control" name="strength" placeholder="e.g. 500mg">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Drug Type</label>
                                <select class="form-control" name="drug_type">
                                    <option value="">N/A</option>
                                    <option value="Tablet">Tablet</option>
                                    <option value="Syrup">Syrup</option>
                                    <option value="Injection">Injection</option>
                                    <option value="Capsule">Capsule</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Lab Test Type</label>
                                <input type="text" class="form-control" name="lab_test_type" placeholder="e.g. Blood Test">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reagent Name / Storage Condition</label>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <input type="text" class="form-control" name="reagent_name" placeholder="Reagent Name">
                                </div>
                                <div class="col-md-6 mb-2">
                                    <input type="text" class="form-control" name="storage_condition" placeholder="e.g. 2-8 C">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Serial Number</label>
                                <input type="text" class="form-control" name="serial_number" placeholder="Equipment/IT">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Assigned Department</label>
                                <input type="text" class="form-control" name="assigned_department" placeholder="e.g. Pharmacy">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">IP Address (IT)</label>
                                <input type="text" class="form-control" name="ip_address" placeholder="e.g. 192.168.1.10">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Condition</label>
                                <select class="form-control" name="item_condition">
                                    <option value="">N/A</option>
                                    <option value="good">Good</option>
                                    <option value="faulty">Faulty</option>
                                    <option value="under_repair">Under Repair</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Purchase Date</label>
                                <input type="date" class="form-control" name="purchase_date">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Maintenance Date</label>
                                <input type="date" class="form-control" name="maintenance_date">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Item</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Update Stock Modal -->
    <div class="modal fade" id="updateStockModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-exchange-alt"></i> Update Stock</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="updateStockForm">
                    <div class="modal-body">
                        <input type="hidden" name="item_id" id="stock_item_id">
                        <h5 id="stock_item_name"></h5>
                        <div class="mb-3">
                            <label class="form-label">Transaction Type *</label>
                            <select class="form-control" name="type" id="transaction_type" required>
                                <option value="">Select Type</option>
                                <option value="stock_in">Stock In (Receiving)</option>
                                <option value="stock_out">Stock Out (Usage/Dispensing)</option>
                                <option value="stock_transfer">Stock Transfer</option>
                                <option value="expired">Expired Items</option>
                                <option value="damaged">Damaged Items</option>
                                <option value="purchase">Purchase (Add Stock)</option>
                                <option value="issue">Issue (Remove Stock)</option>
                                <option value="return">Return (Add Stock)</option>
                                <option value="adjustment">Adjustment</option>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">From Location</label>
                                <input type="text" class="form-control" name="from_location">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">To Location</label>
                                <input type="text" class="form-control" name="to_location">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity *</label>
                            <input type="number" class="form-control" name="quantity" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update Stock</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <?php if($is_admin_user && $access_users_rs): ?>
    <div class="modal fade" id="inventoryAccessModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title"><i class="fas fa-user-shield"></i> Inventory Access Management</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="save_access">
                    <div class="modal-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>User</th>
                                        <th>Role</th>
                                        <th>Department</th>
                                        <th style="width:120px;">View</th>
                                        <th style="width:120px;">Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($u = mysqli_fetch_assoc($access_users_rs)): ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo htmlspecialchars($u['full_name']); ?></strong><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($u['username']); ?></small>
                                                <input type="hidden" name="users[]" value="<?php echo (int)$u['user_id']; ?>">
                                            </td>
                                            <td><?php echo htmlspecialchars(ucfirst($u['user_type'])); ?></td>
                                            <td><?php echo htmlspecialchars($u['department'] ?? 'N/A'); ?></td>
                                            <td class="text-center">
                                                <input class="form-check-input inv-view" type="checkbox"
                                                       name="can_view[<?php echo (int)$u['user_id']; ?>]"
                                                       <?php echo ((int)$u['can_view'] === 1) ? 'checked' : ''; ?>>
                                            </td>
                                            <td class="text-center">
                                                <input class="form-check-input inv-edit" type="checkbox"
                                                       data-user="<?php echo (int)$u['user_id']; ?>"
                                                       name="can_edit[<?php echo (int)$u['user_id']; ?>]"
                                                       <?php echo ((int)$u['can_edit'] === 1) ? 'checked' : ''; ?>>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Access Rights
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            $('#inventoryTable').DataTable({
                order: [[1, 'asc']],
                pageLength: 25
            });
            
            // Add Item Form Submit
            $('#addItemForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize() + '&action=add_item';
                
                $.ajax({
                    url: 'inventory.php',
                    method: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Item added successfully!');
                            location.reload();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    }
                });
            });
            
            // Update Stock Form Submit
            $('#updateStockForm').submit(function(e) {
                e.preventDefault();
                const formData = $(this).serialize() + '&action=update_stock';
                
                $.ajax({
                    url: 'inventory.php',
                    method: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Stock updated successfully!');
                            location.reload();
                        } else {
                            alert('Error: ' + response.message);
                        }
                    }
                });
            });
        });
        
        // Update Stock Function
        function updateStock(id, name) {
            document.getElementById('stock_item_id').value = id;
            document.getElementById('stock_item_name').innerHTML = 'Item: <strong>' + name + '</strong>';
            $('#updateStockModal').modal('show');
        }
        
        function stockIn(id, name) {
            updateStock(id, name);
            setTimeout(function() {
                const typeSelect = document.getElementById('transaction_type');
                if (typeSelect) {
                    typeSelect.value = 'stock_in';
                }
            }, 50);
        }
        
        // View Transaction History
        function viewHistory(id) {
            window.location.href = 'inventory_history.php?item_id=' + id;
        }
        
        // Validate transaction type
        $('#transaction_type').change(function() {
            const type = $(this).val();
            const quantityInput = $('input[name="quantity"]');
            
            if (type === 'issue') {
                quantityInput.attr('max', function() {
                    // Get current stock from table
                    const row = $('#stock_item_id').val();
                    // You might want to fetch current stock via AJAX
                });
            } else {
                quantityInput.removeAttr('max');
            }
        });

        // Edit implies view in access table
        $(document).on('change', '.inv-edit', function() {
            const userId = $(this).data('user');
            if ($(this).is(':checked')) {
                $('input[name="can_view[' + userId + ']"]').prop('checked', true);
            }
        });

        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('access') === '1') {
            const accessModalEl = document.getElementById('inventoryAccessModal');
            if (accessModalEl) {
                const accessModal = new bootstrap.Modal(accessModalEl);
                accessModal.show();
            }
        }
    </script>
</body>
</html>
