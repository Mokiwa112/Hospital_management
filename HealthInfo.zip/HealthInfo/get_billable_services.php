<?php
require_once 'config.php';
requireStaffLogin();

header('Content-Type: application/json');

if (!isset($_POST['patient_id'])) {
    echo json_encode(['appointments' => [], 'lab_tests' => []]);
    exit();
}

$conn = getConnection();
$patient_id = (int)sanitize($_POST['patient_id']);

$appointments = [];
$lab_tests = [];

if ($patient_id > 0) {
    $appointment_price_col = firstExistingColumn('appointments', ['consultation_fee', 'fee', 'amount', 'price']);
    $appointment_status_col = tableHasColumn('appointments', 'status');
    $appointment_reason_col = tableHasColumn('appointments', 'reason');
    $appointment_time_col = tableHasColumn('appointments', 'appointment_time');

    $lab_status_col = tableHasColumn('lab_requests', 'status');
    $lab_cost_col = firstExistingColumn('lab_tests', ['cost', 'price', 'amount']);

    // Unbilled appointments that were already received:
    // - completed/in_progress (preferred status flow), or
    // - scheduled but in the past (fallback for records not marked completed)
    $appt_price_expr = $appointment_price_col
        ? "CASE WHEN COALESCE(a.$appointment_price_col, 0) > 0 AND COALESCE(a.$appointment_price_col, 0) < 1000
                THEN COALESCE(a.$appointment_price_col, 0) * 1000
                ELSE COALESCE(a.$appointment_price_col, 50000.00)
           END"
        : "50000.00";
    $appt_reason_select = $appointment_reason_col ? "a.reason" : "'' AS reason";
    $appt_where = "a.patient_id = $patient_id";
    if ($appointment_status_col) {
        $appt_datetime_expr = $appointment_time_col
            ? "TIMESTAMP(a.appointment_date, a.appointment_time)"
            : "TIMESTAMP(a.appointment_date, '23:59:59')";
        $appt_where .= " AND (a.status IN ('completed', 'in_progress') OR (a.status = 'scheduled' AND $appt_datetime_expr < NOW()))";
    }
    $appt_query = "SELECT a.appointment_id, a.appointment_date, $appt_reason_select, $appt_price_expr AS service_price
                   FROM appointments a
                   WHERE $appt_where
                     AND NOT EXISTS (
                        SELECT 1
                        FROM billing_items bi
                        JOIN billing b ON b.bill_id = bi.bill_id
                        WHERE bi.item_type IN ('appointment', 'consultation')
                          AND bi.item_id = a.appointment_id
                          AND b.patient_id = $patient_id
                    )
                    ORDER BY a.appointment_date DESC
                    LIMIT 50";
    $appt_result = mysqli_query($conn, $appt_query);
    if ($appt_result) {
        while ($row = mysqli_fetch_assoc($appt_result)) {
            $label = 'Consultation - ' . date('d M Y', strtotime($row['appointment_date']));
            if (!empty($row['reason'])) {
                $label .= ' (' . $row['reason'] . ')';
            }
            $appointments[] = [
                'id' => (int)$row['appointment_id'],
                'name' => $label,
                'price' => (float)$row['service_price']
            ];
        }
    }

    // Unbilled lab requests (regional workflow):
    // - include pending/processing/completed so billing desk can prefill charges
    //   immediately after doctor request.
    // - also include any result timestamp/value fallback.
    $lab_price_expr = $lab_cost_col
        ? "CASE WHEN COALESCE(lt.$lab_cost_col, 0) > 0 AND COALESCE(lt.$lab_cost_col, 0) < 5000
                THEN COALESCE(lt.$lab_cost_col, 0) * 1000
                ELSE COALESCE(lt.$lab_cost_col, 0)
           END"
        : "0";
    $lab_where = "lr.patient_id = $patient_id";
    if ($lab_status_col) {
        $result_date_col = tableHasColumn('lab_requests', 'result_date');
        $result_value_col = tableHasColumn('lab_requests', 'result_value');
        $completed_or_resulted = "lr.status IN ('pending', 'processing', 'completed')";
        if ($result_date_col) {
            $completed_or_resulted .= " OR lr.result_date IS NOT NULL";
        }
        if ($result_value_col) {
            $completed_or_resulted .= " OR (lr.result_value IS NOT NULL AND lr.result_value <> '')";
        }
        $lab_where .= " AND ($completed_or_resulted)";
    }
    $lab_query = "SELECT lr.request_id, lr.request_date, lt.test_name, $lab_price_expr AS service_price
                  FROM lab_requests lr
                  JOIN lab_tests lt ON lt.test_id = lr.test_id
                  WHERE $lab_where
                    AND NOT EXISTS (
                        SELECT 1
                        FROM billing_items bi
                        JOIN billing b ON b.bill_id = bi.bill_id
                        WHERE bi.item_type = 'lab_test'
                          AND bi.item_id = lr.request_id
                          AND b.patient_id = $patient_id
                    )
                  ORDER BY lr.request_date DESC
                  LIMIT 100";
    $lab_result = mysqli_query($conn, $lab_query);
    if ($lab_result) {
        while ($row = mysqli_fetch_assoc($lab_result)) {
            $lab_tests[] = [
                'id' => (int)$row['request_id'],
                'name' => $row['test_name'] . ' - ' . date('d M Y', strtotime($row['request_date'])),
                'price' => (float)$row['service_price']
            ];
        }
    }
}

echo json_encode([
    'appointments' => $appointments,
    'lab_tests' => $lab_tests
]);
?>
