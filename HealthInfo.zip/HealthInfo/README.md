# HealthInfo - Hospital Management System

HealthInfo is a role-based Hospital Management System built with PHP and MySQL for internal hospital operations.

## Core Features
- Staff and patient authentication
- Patient registration and profile management
- Appointment scheduling and status tracking
- Laboratory request, processing, and result review
- Prescription workflow and pharmacy dispensing
- Inventory management with stock movement and low-stock alerts
- Billing, payment processing, and insurance handling
- HR operations: attendance, shifts, leave management
- Operational and financial reporting

## Role-Based Access
- `admin`: full system administration and configuration
- `doctor`: consultation, lab requests, result review, prescriptions
- `nurse`: patient care support workflows
- `receptionist`: patient registration and appointment operations
- `lab_tech`: sample processing and result entry
- `pharmacist`: dispensing and medicine inventory workflow
- `accountant`: billing, payment, insurance claim operations
- `hr_admin`: attendance, shifts, and leave approvals
- `patient`: personal portal access

## Auto-Billing for Uninsured Patients
- When treatment is marked complete, the system can auto-generate bills for uninsured patients.
- This is controlled from `system_settings.php`:
  `Enable automatic billing for uninsured patients after treatment completion`.
- Pending auto-generated uninsured bills are shown on dashboards and the billing page for review.

## Project Documentation
- Quick manual: `SYSTEM_MANUAL_SHORT.md`
- Detailed manual (HTML): `SYSTEM_MANUAL_DETAILED.html`
- Detailed manual (PDF): `SYSTEM_MANUAL_DETAILED.pdf`
- Credentials reference: `all_user_logins.txt`
- Staff and patient reset SQL: `reset_staff_users.sql`

## Local Access
- Staff login: `http://localhost/HealthInfo/login.php`
- Patient portal: `http://localhost/HealthInfo/patient_portal.php`

## Notes
- Currency is configured for Tanzanian use.
- Inventory and billing workflows are integrated with role-based permissions.
