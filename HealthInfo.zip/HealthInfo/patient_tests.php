<?php
require_once 'config.php';

// Check if user is logged in and is doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'doctor') {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$patients = [];
$selected_patient = null;
$lab_results = null;

if (!empty($search)) {
    // Search for patients
    $patient_query = "SELECT patient_id, patient_number, first_name, last_name, date_of_birth 
                      FROM patients 
                      WHERE patient_number LIKE '%$search%' 
                      OR first_name LIKE '%$search%' 
                      OR last_name LIKE '%$search%'
                      LIMIT 20";
    $patients = mysqli_query($conn, $patient_query);
}

// If a specific patient is selected
$patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;
if ($patient_id > 0) {
    // Get patient details
    $patient_info = mysqli_query($conn, "SELECT * FROM patients WHERE patient_id = $patient_id");
    $selected_patient = mysqli_fetch_assoc($patient_info);
    
    // Get all lab results for this patient
    $lab_results = mysqli_query($conn,
        "SELECT lr.*, lt.test_name, lt.category, lt.normal_range, lt.unit,
                u.full_name as doctor_name
         FROM lab_requests lr
         JOIN lab_tests lt ON lr.test_id = lt.test_id
         LEFT JOIN users u ON lr.doctor_id = u.user_id
         WHERE lr.patient_id = $patient_id
         ORDER BY lr.request_date DESC"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Tests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .search-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .patient-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .patient-item {
            padding: 12px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background 0.3s;
        }
        .patient-item:hover {
            background: #f8f9fa;
        }
        .patient-item.selected {
            background: #e3f2fd;
            border-left: 4px solid #007bff;
        }
        .test-item {
            border-left: 4px solid;
            padding: 15px;
            margin-bottom: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .test-pending { border-left-color: #ffc107; }
        .test-completed { border-left-color: #28a745; }
        .test-cancelled { border-left-color: #dc3545; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <h2><i class="fas fa-search"></i> Patient Test Search</h2>
        
        <div class="row">
            <!-- Search Column -->
            <div class="col-md-4">
                <div class="search-card">
                    <h5>Search Patient</h5>
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" 
                                   value="<?php echo htmlspecialchars($search); ?>" 
                                   placeholder="Patient # or name...">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                    
                    <?php if(!empty($search) && $patients && mysqli_num_rows($patients) > 0): ?>
                        <div class="patient-list">
                            <h6>Search Results:</h6>
                            <?php while($patient = mysqli_fetch_assoc($patients)): ?>
                                <a href="?patient_id=<?php echo $patient['patient_id']; ?>" 
                                   class="text-decoration-none">
                                    <div class="patient-item <?php echo ($patient_id == $patient['patient_id']) ? 'selected' : ''; ?>">
                                        <strong><?php echo $patient['first_name'] . ' ' . $patient['last_name']; ?></strong>
                                        <br>
                                        <small class="text-muted">#<?php echo $patient['patient_number']; ?></small>
                                    </div>
                                </a>
                            <?php endwhile; ?>
                        </div>
                    <?php elseif(!empty($search)): ?>
                        <p class="text-muted">No patients found</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Results Column -->
            <div class="col-md-8">
                <?php if($selected_patient): ?>
                    <div class="search-card">
                        <h4>
                            <?php echo $selected_patient['first_name'] . ' ' . $selected_patient['last_name']; ?>
                            <small class="text-muted">(<?php echo $selected_patient['patient_number']; ?>)</small>
                        </h4>
                        
                        <hr>
                        
                        <h5 class="mb-3">Lab Test History</h5>
                        
                        <?php if($lab_results && mysqli_num_rows($lab_results) > 0): ?>
                            <?php while($test = mysqli_fetch_assoc($lab_results)): 
                                $test_class = 'test-' . $test['status'];
                            ?>
                                <div class="test-item <?php echo $test_class; ?>">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h6><?php echo $test['test_name']; ?></h6>
                                            <p class="mb-1 small"><?php echo $test['category']; ?></p>
                                            <p class="mb-1">
                                                <strong>Result:</strong> 
                                                <?php if($test['status'] == 'completed'): ?>
                                                    <?php echo $test['result_value'] . ' ' . $test['unit']; ?>
                                                    <small class="text-muted">(Normal: <?php echo $test['normal_range']; ?>)</small>
                                                <?php else: ?>
                                                    <span class="text-muted">Pending</span>
                                                <?php endif; ?>
                                            </p>
                                            <p class="mb-0 small text-muted">
                                                Requested: <?php echo date('d M Y', strtotime($test['request_date'])); ?>
                                                <?php if($test['doctor_name']): ?> by Dr. <?php echo $test['doctor_name']; ?><?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <span class="badge bg-<?php 
                                                echo $test['status'] == 'completed' ? 'success' : 
                                                    ($test['status'] == 'pending' ? 'warning' : 'danger'); 
                                            ?> mb-2">
                                                <?php echo ucfirst($test['status']); ?>
                                            </span>
                                            <br>
                                            <a href="view_lab_request.php?id=<?php echo $test['request_id']; ?>" 
                                               class="btn btn-sm btn-info">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-muted">No lab tests found for this patient</p>
                        <?php endif; ?>
                        
                        <hr>
                        <div class="text-center">
                            <a href="create_prescription.php?patient_id=<?php echo $patient_id; ?>" 
                               class="btn btn-success">Write Prescription</a>
                            <a href="lab_request.php?patient_id=<?php echo $patient_id; ?>" 
                               class="btn btn-warning">Request New Test</a>
                            <a href="patient_history.php?patient_id=<?php echo $patient_id; ?>" 
                               class="btn btn-info">Full History</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="search-card text-center py-5">
                        <i class="fas fa-search fa-4x text-muted mb-3"></i>
                        <h5>Search for a patient to view their test history</h5>
                        <p class="text-muted">Enter patient number or name in the search box</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>