<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$claim_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($claim_id && in_array($action, ['approve', 'reject'])) {
    $status = ($action == 'approve') ? 'approved' : 'rejected';
    
    $query = "UPDATE insurance_claims SET status = '$status' WHERE claim_id = $claim_id";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Claim " . ($action == 'approve' ? 'approved' : 'rejected') . " successfully!";
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
}

header("Location: view_insurance.php?id=$claim_id");
exit();
?>