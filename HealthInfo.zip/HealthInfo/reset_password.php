<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch worker details
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "User not found";
    header("Location: workers.php");
    exit();
}

$user = mysqli_fetch_assoc($result);

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password != $confirm_password) {
        $error = "Passwords do not match";
    } elseif (strlen($new_password) < 8) {
        $error = "Password must be at least 8 characters long";
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $update_query = "UPDATE users SET password = '$hashed' WHERE user_id = $user_id";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Password reset successfully for " . $user['full_name'];
            
            // Log the password reset
            $log_query = "INSERT INTO user_logs (user_id, action, ip_address) 
                          VALUES ({$_SESSION['user_id']}, 'password_reset_for_{$user['username']}', '{$_SERVER['REMOTE_ADDR']}')";
            @mysqli_query($conn, $log_query);
            
            header("Location: view_worker.php?id=$user_id");
            exit();
        } else {
            $error = "Error resetting password: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header bg-warning">
                        <h4><i class="fas fa-key"></i> Reset Password</h4>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <strong>User:</strong> <?php echo htmlspecialchars($user['full_name']); ?> (<?php echo $user['username']; ?>)
                        </div>
                        
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">New Password</label>
                                <input type="password" class="form-control" name="new_password" 
                                       minlength="8" required>
                                <small class="text-muted">Minimum 8 characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" name="confirm_password" 
                                       minlength="8" required>
                            </div>
                            
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                This will immediately reset the user's password. They will need to use the new password on their next login.
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-warning">
                                    <i class="fas fa-key"></i> Reset Password
                                </button>
                                <a href="view_worker.php?id=<?php echo $user_id; ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>