<?php
// currency_helper.php - Currency formatting functions
// Make sure this file is saved in the same directory as config.php

/**
 * Format amount with currency symbol
 * @param float $amount The amount to format
 * @return string Formatted amount with currency symbol
 */
function format_currency($amount) {
    // Get settings
    static $settings = null;
    
    if ($settings === null) {
        $settings_file = __DIR__ . '/settings.json';
        if (file_exists($settings_file)) {
            $settings = json_decode(file_get_contents($settings_file), true);
        } else {
            $settings = [
                'currency' => 'TZS',
                'currency_symbol' => 'TZS'
            ];
        }
    }
    
    $symbol = $settings['currency_symbol'] ?? 'TSh';
    return $symbol . ' ' . number_format((float)$amount, 2);
}

/**
 * Get currency code
 * @return string Currency code (e.g., TZS, USD)
 */
function get_currency_code() {
    static $settings = null;
    
    if ($settings === null) {
        $settings_file = __DIR__ . '/settings.json';
        if (file_exists($settings_file)) {
            $settings = json_decode(file_get_contents($settings_file), true);
        } else {
            return 'TZS';
        }
    }
    
    return $settings['currency'] ?? 'TZS';
}

/**
 * Get currency symbol
 * @return string Currency symbol (e.g., TSh, $)
 */
function get_currency_symbol() {
    static $settings = null;
    
    if ($settings === null) {
        $settings_file = __DIR__ . '/settings.json';
        if (file_exists($settings_file)) {
            $settings = json_decode(file_get_contents($settings_file), true);
        } else {
            return 'TSh';
        }
    }
    
    return $settings['currency_symbol'] ?? 'TZS';
}

/**
 * Format amount without currency symbol
 * @param float $amount The amount to format
 * @return string Formatted amount
 */
function format_number($amount) {
    return number_format((float)$amount, 2);
}

/**
 * Convert amount to words (Tanzania Shilling specific)
 * @param float $amount The amount to convert
 * @return string Amount in words
 */
function amount_to_words($amount) {
    $words = array(
        0 => 'Zero',
        1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five',
        6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten',
        11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen',
        15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty', 40 => 'Forty',
        50 => 'Fifty', 60 => 'Sixty', 70 => 'Seventy', 80 => 'Eighty',
        90 => 'Ninety'
    );
    
    $amount = (float)$amount;
    $whole = floor($amount);
    $cents = round(($amount - $whole) * 100);
    
    if ($whole == 0) {
        $result = 'Zero';
    } else {
        $result = '';
        $hundreds = floor($whole / 100);
        $remainder = $whole % 100;
        
        if ($hundreds > 0) {
            $result .= $words[$hundreds] . ' Hundred';
            if ($remainder > 0) {
                $result .= ' and ';
            }
        }
        
        if ($remainder > 0) {
            if ($remainder < 20) {
                $result .= $words[$remainder];
            } else {
                $tens = floor($remainder / 10) * 10;
                $units = $remainder % 10;
                $result .= $words[$tens];
                if ($units > 0) {
                    $result .= ' ' . $words[$units];
                }
            }
        }
    }
    
    $result .= ' Tanzania Shillings';
    
    if ($cents > 0) {
        $result .= ' and ' . $cents . '/100';
    }
    
    return $result;
}

// Debug: Echo that the file was loaded (remove in production)
if (defined('DEBUG_MODE') && DEBUG_MODE) {
    error_log("currency_helper.php loaded successfully");
}
?>
