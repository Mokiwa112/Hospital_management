<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $full_name = sanitize($_POST['full_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $user_type = sanitize($_POST['user_type']);
    $department = sanitize($_POST['department']);
    $employee_id = generateUniqueId('EMP', 'users', 'employee_id');
    
    if (!isValidPhoneNumber($phone)) {
        $error = getPhoneValidationMessage();
    }
    // Check if username exists
    else {
        $check = mysqli_query($conn, "SELECT user_id FROM users WHERE username = '$username'");
        if (mysqli_num_rows($check) > 0) {
        $error = "Username already exists";
        } else {
            $query = "INSERT INTO users (username, password, full_name, email, phone, address, user_type, department, employee_id) 
                      VALUES ('$username', '$password', '$full_name', '$email', '$phone', '$address', '$user_type', '$department', '$employee_id')";
            
            if (mysqli_query($conn, $query)) {
                $_SESSION['success'] = "User added successfully! Employee ID: $employee_id";
                redirect('workers.php');
            } else {
                $error = "Error: " . mysqli_error($conn);
            }
        }
    }
}

// Get departments list
$departments = [
    'Administration',
    'Cardiology',
    'Pediatrics',
    'Neurology',
    'Orthopedics',
    'Emergency',
    'ICU',
    'Radiology',
    'Laboratory',
    'Pharmacy',
    'Billing',
    'Front Office',
    'HR',
    'IT'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4><i class="fas fa-user-plus"></i> Add New User</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" id="addUserForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Username *</label>
                                    <input type="text" class="form-control" name="username" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Password *</label>
                                    <input type="password" class="form-control" name="password" required 
                                           pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
                                           title="Must contain at least one number, one uppercase and lowercase letter, and at least 8 characters">
                                    <small class="text-muted">Minimum 8 characters with at least one uppercase, one lowercase, and one number</small>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="full_name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone *</label>
                                    <input type="tel" class="form-control" name="phone" required pattern="^(0\d{9}|\+\d{11,12})$" title="Use 10 digits starting with 0, or + followed by 11-12 digits">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">User Type *</label>
                                    <select class="form-control" name="user_type" required id="userType">
                                        <option value="">Select Type</option>
                                        <option value="admin">Administrator</option>
                                        <option value="doctor">Doctor</option>
                                        <option value="nurse">Nurse</option>
                                        <option value="receptionist">Receptionist</option>
                                        <option value="lab_tech">Lab Technician</option>
                                        <option value="pharmacist">Pharmacist</option>
                                        <option value="accountant">Accountant</option>
                                        <option value="hr_admin">HR Admin</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea class="form-control" name="address" rows="2"></textarea>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Department</label>
                                    <select class="form-control" name="department" id="department">
                                        <option value="">Select Department</option>
                                        <?php foreach($departments as $dept): ?>
                                            <option value="<?php echo $dept; ?>"><?php echo $dept; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Employee ID (Auto-generated)</label>
                                    <input type="text" class="form-control" value="Will be generated" disabled>
                                </div>
                            </div>
                            
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                Employee ID will be automatically generated upon submission.
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-save"></i> Add User
                                </button>
                                <a href="workers.php" class="btn btn-secondary btn-lg">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-suggest department based on user type
        document.getElementById('userType').addEventListener('change', function() {
            const type = this.value;
            const deptSelect = document.getElementById('department');
            
            const defaults = {
                'doctor': 'Cardiology',
                'nurse': 'ICU',
                'lab_tech': 'Laboratory',
                'pharmacist': 'Pharmacy',
                'accountant': 'Billing',
                'hr_admin': 'HR',
                'receptionist': 'Front Office',
                'admin': 'Administration'
            };
            
            if (defaults[type]) {
                // Try to select the matching department
                for (let option of deptSelect.options) {
                    if (option.value === defaults[type]) {
                        option.selected = true;
                        break;
                    }
                }
            }
        });
    </script>
</body>
</html>

