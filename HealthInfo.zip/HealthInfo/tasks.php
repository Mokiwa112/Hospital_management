<?php
require_once 'config.php';

// Handle task operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = getConnection();
    
    if (isset($_POST['create_task'])) {
        $task_title = sanitize($_POST['task_title']);
        $description = sanitize($_POST['description']);
        $assigned_to = sanitize($_POST['assigned_to']);
        $priority = sanitize($_POST['priority']);
        $due_date = sanitize($_POST['due_date']);
        
        $query = "INSERT INTO tasks (task_title, description, assigned_to, assigned_by, priority, due_date) 
                  VALUES ('$task_title', '$description', $assigned_to, {$_SESSION['user_id']}, '$priority', '$due_date')";
        
        if (mysqli_query($conn, $query)) {
            $_SESSION['success'] = "Task created successfully!";
        } else {
            $_SESSION['error'] = "Error: " . mysqli_error($conn);
        }
    }
    
    elseif (isset($_POST['update_status'])) {
        $task_id = sanitize($_POST['task_id']);
        $status = sanitize($_POST['status']);
        
        $completed_at = ($status == 'completed') ? ", completed_at = NOW()" : "";
        $query = "UPDATE tasks SET status = '$status' $completed_at WHERE task_id = $task_id";
        
        mysqli_query($conn, $query);
    }
    
    redirect('tasks.php');
}

// Fetch tasks
$conn = getConnection();

// Filter by status
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : 'all';
$user_filter = isset($_GET['user']) ? sanitize($_GET['user']) : '';

$where = [];
if ($status_filter != 'all') {
    $where[] = "t.status = '$status_filter'";
}
if ($user_filter) {
    $where[] = "t.assigned_to = $user_filter";
}

$where_clause = !empty($where) ? "WHERE " . implode(' AND ', $where) : "";

$tasks = mysqli_query($conn, 
    "SELECT t.*, 
     u1.full_name as assigned_to_name, 
     u2.full_name as assigned_by_name 
     FROM tasks t 
     LEFT JOIN users u1 ON t.assigned_to = u1.user_id 
     LEFT JOIN users u2 ON t.assigned_by = u2.user_id 
     $where_clause 
     ORDER BY 
        CASE t.priority 
            WHEN 'urgent' THEN 1 
            WHEN 'high' THEN 2 
            WHEN 'medium' THEN 3 
            WHEN 'low' THEN 4 
        END,
        t.due_date ASC"
);

// Fetch users for assignment
$users = mysqli_query($conn, "SELECT user_id, full_name, user_type FROM users WHERE user_type != 'admin' ORDER BY full_name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Schedule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css">
    <style>
        .priority-urgent { border-left: 4px solid #dc3545; }
        .priority-high { border-left: 4px solid #fd7e14; }
        .priority-medium { border-left: 4px solid #ffc107; }
        .priority-low { border-left: 4px solid #28a745; }
        
        .task-card {
            margin-bottom: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            transition: all 0.3s;
        }
        .task-card:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }
        .task-status {
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-4">
                <!-- Create Task Form -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5><i class="fas fa-plus-circle"></i> Create New Task</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Task Title *</label>
                                <input type="text" class="form-control" name="task_title" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <textarea class="form-control" name="description" rows="2"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Assign To *</label>
                                <select class="form-control" name="assigned_to" required>
                                    <option value="">Select User</option>
                                    <?php while($user = mysqli_fetch_assoc($users)): ?>
                                        <option value="<?php echo $user['user_id']; ?>">
                                            <?php echo $user['full_name']; ?> (<?php echo $user['user_type']; ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Priority *</label>
                                    <select class="form-control" name="priority" required>
                                        <option value="low">Low</option>
                                        <option value="medium" selected>Medium</option>
                                        <option value="high">High</option>
                                        <option value="urgent">Urgent</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Due Date *</label>
                                    <input type="date" class="form-control" name="due_date" min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>
                            <button type="submit" name="create_task" class="btn btn-primary w-100">
                                <i class="fas fa-save"></i> Create Task
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Task Statistics -->
                <div class="card mt-3">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-chart-pie"></i> Task Statistics</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $stats = mysqli_query($conn, 
                            "SELECT 
                                COUNT(*) as total,
                                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
                             FROM tasks"
                        );
                        $stat = mysqli_fetch_assoc($stats);
                        ?>
                        <div class="row text-center">
                            <div class="col-4">
                                <h3><?php echo $stat['total']; ?></h3>
                                <small>Total</small>
                            </div>
                            <div class="col-4">
                                <h3 class="text-warning"><?php echo $stat['pending']; ?></h3>
                                <small>Pending</small>
                            </div>
                            <div class="col-4">
                                <h3 class="text-primary"><?php echo $stat['in_progress']; ?></h3>
                                <small>In Progress</small>
                            </div>
                            <div class="col-4 mt-2">
                                <h3 class="text-success"><?php echo $stat['completed']; ?></h3>
                                <small>Completed</small>
                            </div>
                            <div class="col-4 mt-2">
                                <h3 class="text-danger"><?php echo $stat['cancelled']; ?></h3>
                                <small>Cancelled</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <!-- Filters -->
                <div class="card mb-3">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Status</label>
                                <select class="form-control" name="status">
                                    <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All</option>
                                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="in_progress" <?php echo $status_filter == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Assigned To</label>
                                <select class="form-control" name="user">
                                    <option value="">All Users</option>
                                    <?php 
                                    mysqli_data_seek($users, 0);
                                    while($user = mysqli_fetch_assoc($users)): 
                                    ?>
                                        <option value="<?php echo $user['user_id']; ?>" <?php echo $user_filter == $user['user_id'] ? 'selected' : ''; ?>>
                                            <?php echo $user['full_name']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" class="btn btn-primary d-block w-100">Apply Filters</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Task List -->
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-tasks"></i> Task List</h5>
                    </div>
                    <div class="card-body" style="max-height: 600px; overflow-y: auto;">
                        <?php if(mysqli_num_rows($tasks) > 0): ?>
                            <?php while($task = mysqli_fetch_assoc($tasks)): ?>
                                <div class="task-card priority-<?php echo $task['priority']; ?>">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h6 class="mb-1">
                                                <?php echo $task['task_title']; ?>
                                                <?php
                                                $badge_class = [
                                                    'pending' => 'bg-warning',
                                                    'in_progress' => 'bg-primary',
                                                    'completed' => 'bg-success',
                                                    'cancelled' => 'bg-danger'
                                                ];
                                                ?>
                                                <span class="badge <?php echo $badge_class[$task['status']]; ?> ms-2">
                                                    <?php echo str_replace('_', ' ', $task['status']); ?>
                                                </span>
                                            </h6>
                                            <p class="mb-1 text-muted"><?php echo $task['description']; ?></p>
                                            <small>
                                                <i class="fas fa-user"></i> Assigned to: <?php echo $task['assigned_to_name']; ?><br>
                                                <i class="fas fa-calendar"></i> Due: <?php echo date('d-m-Y', strtotime($task['due_date'])); ?>
                                                <?php if($task['completed_at']): ?>
                                                    <br><i class="fas fa-check-circle text-success"></i> Completed: <?php echo date('d-m-Y H:i', strtotime($task['completed_at'])); ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                        <div class="btn-group">
                                            <?php if($task['status'] != 'completed'): ?>
                                                <select class="form-control form-control-sm" onchange="updateTaskStatus(<?php echo $task['task_id']; ?>, this.value)" style="width: 120px;">
                                                    <option value="pending" <?php echo $task['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="in_progress" <?php echo $task['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                                                    <option value="completed">Complete</option>
                                                    <option value="cancelled">Cancel</option>
                                                </select>
                                            <?php else: ?>
                                                <span class="text-success">Completed</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-center text-muted">No tasks found</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Calendar View Toggle -->
                <div class="card mt-3">
                    <div class="card-header bg-secondary text-white">
                        <h5><i class="fas fa-calendar-alt"></i> Calendar View</h5>
                    </div>
                    <div class="card-body">
                        <div id="calendar"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    
    <script>
        // Update task status
        function updateTaskStatus(taskId, status) {
            $.ajax({
                url: 'tasks.php',
                method: 'POST',
                data: {
                    update_status: true,
                    task_id: taskId,
                    status: status
                },
                success: function() {
                    location.reload();
                }
            });
        }
        
        // Initialize calendar
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: 'get_tasks_calendar.php',
                eventClick: function(info) {
                    alert('Task: ' + info.event.title + '\nDescription: ' + info.event.extendedProps.description);
                }
            });
            calendar.render();
        });
    </script>
</body>
</html>