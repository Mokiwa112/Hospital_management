<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$claim_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch claim details
$query = "SELECT c.*, p.first_name, p.last_name, p.patient_number, p.address, p.phone,
          ip.provider_name, ip.coverage_percentage, ip.contact_person, ip.address as provider_address
          FROM insurance_claims c
          JOIN patients p ON c.patient_id = p.patient_id
          JOIN insurance_providers ip ON c.provider_id = ip.provider_id
          WHERE c.claim_id = $claim_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Claim not found");
}

$claim = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Claim #<?php echo $claim['claim_number']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
            body { font-size: 12pt; }
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #333;
        }
        .claim-info {
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container mt-4 mb-4">
        <div class="no-print text-end mb-3">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print
            </button>
            <button onclick="window.close()" class="btn btn-secondary">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
        
        <div class="header">
            <h2><?php echo SITE_NAME; ?></h2>
            <h3>Insurance Claim Form</h3>
        </div>
        
        <div class="claim-info">
            <div class="row">
                <div class="col-md-6">
                    <h5>Claim Information</h5>
                    <p><strong>Claim #:</strong> <?php echo $claim['claim_number']; ?></p>
                    <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($claim['claim_date'])); ?></p>
                    <p><strong>Amount:</strong> TSh <?php echo number_format($claim['claim_amount'], 2); ?></p>
                    <p><strong>Status:</strong> <?php echo ucfirst($claim['status']); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>Patient Information</h5>
                    <p><strong>Name:</strong> <?php echo $claim['first_name'] . ' ' . $claim['last_name']; ?></p>
                    <p><strong>Patient #:</strong> <?php echo $claim['patient_number']; ?></p>
                    <p><strong>Phone:</strong> <?php echo $claim['phone']; ?></p>
                    <p><strong>Address:</strong> <?php echo nl2br($claim['address']); ?></p>
                </div>
            </div>
            
            <hr>
            
            <div class="row">
                <div class="col-md-6">
                    <h5>Insurance Provider</h5>
                    <p><strong>Provider:</strong> <?php echo $claim['provider_name']; ?></p>
                    <p><strong>Contact:</strong> <?php echo $claim['contact_person']; ?></p>
                    <p><strong>Coverage:</strong> <?php echo $claim['coverage_percentage']; ?>%</p>
                </div>
                <div class="col-md-6">
                    <h5>Provider Address</h5>
                    <p><?php echo nl2br($claim['provider_address']); ?></p>
                </div>
            </div>
            
            <?php if($claim['remarks']): ?>
            <hr>
            <div class="mt-3">
                <h5>Remarks</h5>
                <p><?php echo nl2br($claim['remarks']); ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="footer text-center mt-5">
            <p>This is a computer generated document. No signature required.</p>
        </div>
    </div>
</body>
</html>