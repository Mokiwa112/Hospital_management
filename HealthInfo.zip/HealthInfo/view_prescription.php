<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) && !isset($_SESSION['patient_id'])) {
    redirect('login.php');
}

$conn = getConnection();
$prescription_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_pharmacist_id = tableHasColumn('prescriptions', 'pharmacist_id');

if ($prescription_id <= 0) {
    $_SESSION['error'] = "Invalid prescription";
    if (isset($_SESSION['patient_id'])) {
        redirect('view_medical_record.php');
    }
    redirect('pharmacist_dashboard.php');
}

$where = "p.prescription_id = $prescription_id";
if (isset($_SESSION['patient_id'])) {
    $where .= " AND p.patient_id = " . (int)$_SESSION['patient_id'];
}

$ph_join = $has_pharmacist_id ? "LEFT JOIN users ph ON p.pharmacist_id = ph.user_id" : "";
$ph_select = $has_pharmacist_id ? "ph.full_name AS pharmacist_name" : "NULL AS pharmacist_name";
$query = "SELECT p.*, pt.first_name, pt.last_name, pt.patient_number, pt.date_of_birth,
          d.full_name AS doctor_name, $ph_select
          FROM prescriptions p
          JOIN patients pt ON p.patient_id = pt.patient_id
          JOIN users d ON p.doctor_id = d.user_id
          $ph_join
          WHERE $where";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    $_SESSION['error'] = "Prescription not found";
    if (isset($_SESSION['patient_id'])) {
        redirect('view_medical_record.php');
    }
    redirect('pharmacist_dashboard.php');
}

$prescription = mysqli_fetch_assoc($result);
$items = mysqli_query($conn, "SELECT * FROM prescription_items WHERE prescription_id = $prescription_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3><i class="fas fa-prescription"></i> Prescription Details</h3>
            <div>
                <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_type'] ?? '') === 'pharmacist' && ($prescription['status'] ?? '') !== 'dispensed'): ?>
                    <a href="dispense_prescription.php?id=<?php echo $prescription_id; ?>" class="btn btn-success me-2">
                        <i class="fas fa-check-circle"></i> Mark as Dispensed
                    </a>
                <?php endif; ?>
                <a href="<?php echo isset($_SESSION['patient_id']) ? 'view_medical_record.php' : 'pharmacist_dashboard.php'; ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4"><strong>Prescription #:</strong> <?php echo htmlspecialchars($prescription['prescription_number']); ?></div>
                    <div class="col-md-4"><strong>Date:</strong> <?php echo date('d M Y h:i A', strtotime($prescription['prescription_date'])); ?></div>
                    <div class="col-md-4">
                        <strong>Status:</strong>
                        <span class="badge bg-<?php echo $prescription['status'] === 'dispensed' ? 'success' : 'warning'; ?>">
                            <?php echo ucfirst($prescription['status']); ?>
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-4"><strong>Patient:</strong> <?php echo htmlspecialchars($prescription['first_name'] . ' ' . $prescription['last_name']); ?> (<?php echo htmlspecialchars($prescription['patient_number']); ?>)</div>
                    <div class="col-md-4"><strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($prescription['doctor_name']); ?></div>
                    <div class="col-md-4"><strong>Dispensed By:</strong> <?php echo htmlspecialchars($prescription['pharmacist_name'] ?? 'Not dispensed'); ?></div>
                </div>
                <div class="mt-3">
                    <strong>Diagnosis:</strong>
                    <div><?php echo nl2br(htmlspecialchars($prescription['diagnosis'] ?? '')); ?></div>
                </div>
                <?php if (!empty($prescription['notes'])): ?>
                    <div class="mt-2">
                        <strong>Notes:</strong>
                        <div><?php echo nl2br(htmlspecialchars($prescription['notes'])); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <strong>Medication Items</strong>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Medicine</th>
                                <th>Dosage</th>
                                <th>Frequency</th>
                                <th>Duration</th>
                                <th>Quantity</th>
                                <th>Instructions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($items && mysqli_num_rows($items) > 0): ?>
                                <?php while ($item = mysqli_fetch_assoc($items)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['medicine_name']); ?></td>
                                        <td><?php echo htmlspecialchars($item['dosage']); ?></td>
                                        <td><?php echo htmlspecialchars($item['frequency']); ?></td>
                                        <td><?php echo htmlspecialchars($item['duration']); ?></td>
                                        <td><?php echo (int)$item['quantity']; ?></td>
                                        <td><?php echo htmlspecialchars($item['instructions'] ?? ''); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center text-muted">No medication items found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
