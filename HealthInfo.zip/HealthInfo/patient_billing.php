<?php
require_once 'config.php';

// Check if patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_portal.php");
    exit();
}

$conn = getConnection();
$patient_id = $_SESSION['patient_id'];

// Fetch patient details
$patient_query = "SELECT * FROM patients WHERE patient_id = $patient_id";
$patient_result = mysqli_query($conn, $patient_query);
$patient = mysqli_fetch_assoc($patient_result);

// Fetch billing history
$bills_query = "SELECT b.*, 
                COUNT(bi.billing_item_id) as item_count
                FROM billing b
                LEFT JOIN billing_items bi ON b.bill_id = bi.bill_id
                WHERE b.patient_id = $patient_id
                GROUP BY b.bill_id
                ORDER BY b.bill_date DESC";
$bills = mysqli_query($conn, $bills_query);

// Calculate totals
$total_billed = 0;
$total_paid = 0;
$pending_amount = 0;

$temp_result = mysqli_query($conn, "SELECT net_amount, payment_status FROM billing WHERE patient_id = $patient_id");
while ($row = mysqli_fetch_assoc($temp_result)) {
    $total_billed += $row['net_amount'];
    if ($row['payment_status'] == 'paid') {
        $total_paid += $row['net_amount'];
    } else {
        $pending_amount += $row['net_amount'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Billing History - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .stat-card {
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            backdrop-filter: blur(10px);
        }
        .stat-number {
            font-size: 28px;
            font-weight: bold;
            margin: 10px 0;
        }
        .bill-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        .bill-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .bill-paid { border-left-color: #28a745; }
        .bill-pending { border-left-color: #ffc107; }
        .bill-partial { border-left-color: #17a2b8; }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-paid { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-partial { background: #cce5ff; color: #004085; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-file-invoice-dollar"></i> My Billing History</h2>
                <p>View all your bills and payment history</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="patient_dashboard.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="summary-card">
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-file-invoice fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo mysqli_num_rows($bills); ?></div>
                        <div>Total Bills</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-wallet fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo format_currency($total_billed); ?></div>
                        <div>Total Billed</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo format_currency($total_paid); ?></div>
                        <div>Total Paid</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <div class="stat-number"><?php echo format_currency($pending_amount); ?></div>
                        <div>Pending</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bills List -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-list"></i> Bill Details</h5>
            </div>
            <div class="card-body">
                <?php if($bills && mysqli_num_rows($bills) > 0): ?>
                    <?php while($bill = mysqli_fetch_assoc($bills)): 
                        $status_class = $bill['payment_status'] == 'paid' ? 'bill-paid' : ($bill['payment_status'] == 'pending' ? 'bill-pending' : 'bill-partial');
                    ?>
                        <div class="bill-card <?php echo $status_class; ?>">
                            <div class="row">
                                <div class="col-md-3">
                                    <small class="text-muted">Bill Number</small>
                                    <h6 class="mb-0"><?php echo $bill['bill_number']; ?></h6>
                                </div>
                                <div class="col-md-2">
                                    <small class="text-muted">Date</small>
                                    <h6 class="mb-0"><?php echo date('d M Y', strtotime($bill['bill_date'])); ?></h6>
                                </div>
                                <div class="col-md-2">
                                    <small class="text-muted">Items</small>
                                    <h6 class="mb-0"><?php echo $bill['item_count']; ?> items</h6>
                                </div>
                                <div class="col-md-2">
                                    <small class="text-muted">Amount</small>
                                    <h6 class="mb-0"><?php echo format_currency($bill['net_amount']); ?></h6>
                                </div>
                                <div class="col-md-2">
                                    <small class="text-muted">Status</small>
                                    <div>
                                        <span class="status-badge status-<?php echo $bill['payment_status']; ?>">
                                            <?php echo ucfirst($bill['payment_status']); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <a href="view_patient_bill.php?id=<?php echo $bill['bill_id']; ?>" 
                                       class="btn btn-sm btn-info" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </div>
                            <?php if($bill['notes']): ?>
                                <div class="mt-2">
                                    <small class="text-muted">Notes: <?php echo htmlspecialchars($bill['notes']); ?></small>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-file-invoice fa-4x text-muted mb-3"></i>
                        <p class="text-muted">No billing records found</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
