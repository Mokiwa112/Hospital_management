<?php
require_once 'config.php';
requireRole('admin');

$report_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$format = isset($_GET['format']) ? $_GET['format'] : 'html';

$conn = getConnection();

if (!tableHasColumn('reports', 'report_id')) {
    $_SESSION['error'] = "Reports table is not available";
    header("Location: reports.php");
    exit();
}

// Fetch report details
$query = "SELECT * FROM reports WHERE report_id = $report_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Report not found";
    header("Location: reports.php");
    exit();
}

$report = mysqli_fetch_assoc($result);
$params = json_decode($report['parameters'], true);

// Generate report based on type
generateReport($report['report_type'], $params['date_from'], $params['date_to'], $format, $report_id);

function generateReport($type, $from, $to, $format, $report_id) {
    global $conn;
    
    $data = [];
    
    switch($type) {
        case 'patient':
            $query = "SELECT * FROM patients WHERE registration_date BETWEEN '$from' AND '$to' ORDER BY registration_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Patient Registration Report';
            $data['headers'] = ['Patient #', 'Name', 'Type', 'Registration Date', 'Contact', 'Insurance'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['patient_number'],
                    $row['first_name'] . ' ' . $row['last_name'],
                    $row['patient_type'],
                    date('d-m-Y', strtotime($row['registration_date'])),
                    $row['phone'],
                    $row['insurance_policy_number'] ?: 'None'
                ];
            }
            break;
            
        case 'appointment':
            $query = "SELECT a.*, p.first_name, p.last_name, p.patient_number, u.full_name as doctor_name 
                     FROM appointments a
                     JOIN patients p ON a.patient_id = p.patient_id
                     JOIN users u ON a.doctor_id = u.user_id
                     WHERE a.appointment_date BETWEEN '$from' AND '$to'
                     ORDER BY a.appointment_date, a.appointment_time";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Appointments Report';
            $data['headers'] = ['Date', 'Time', 'Patient', 'Doctor', 'Status', 'Reason'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    date('d-m-Y', strtotime($row['appointment_date'])),
                    date('h:i A', strtotime($row['appointment_time'])),
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    'Dr. ' . $row['doctor_name'],
                    $row['status'],
                    $row['reason']
                ];
            }
            break;
            
        case 'billing':
            $query = "SELECT b.*, p.first_name, p.last_name, p.patient_number 
                     FROM billing b
                     JOIN patients p ON b.patient_id = p.patient_id
                     WHERE b.bill_date BETWEEN '$from' AND '$to'
                     ORDER BY b.bill_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Billing Report';
            $data['headers'] = ['Bill #', 'Patient', 'Date', 'Total', 'Discount', 'Net', 'Status'];
            $data['rows'] = [];
            $total_amount = 0;
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['bill_number'],
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    date('d-m-Y', strtotime($row['bill_date'])),
                    format_currency($row['total_amount']),
                    format_currency($row['discount']),
                    format_currency($row['net_amount']),
                    $row['payment_status']
                ];
                $total_amount += $row['net_amount'];
            }
            $data['summary'] = ['Total Revenue: ' . format_currency($total_amount)];
            break;
            
        case 'inventory':
            $query = "SELECT * FROM inventory_items ORDER BY category, item_name";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Inventory Status Report';
            $data['headers'] = ['Item Code', 'Item Name', 'Category', 'Quantity', 'Unit', 'Reorder Level', 'Unit Price', 'Expiry Date'];
            $data['rows'] = [];
            $total_value = 0;
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['item_code'],
                    $row['item_name'],
                    $row['category'],
                    $row['quantity'],
                    $row['unit'],
                    $row['reorder_level'],
                    format_currency($row['unit_price']),
                    $row['expiry_date'] ? date('d-m-Y', strtotime($row['expiry_date'])) : 'N/A'
                ];
                $total_value += $row['quantity'] * $row['unit_price'];
            }
            $data['summary'] = ['Total Inventory Value: ' . format_currency($total_value)];
            break;
            
        case 'lab':
            $query = "SELECT lr.*, p.first_name, p.last_name, p.patient_number, lt.test_name, u.full_name as doctor_name 
                     FROM lab_requests lr
                     JOIN patients p ON lr.patient_id = p.patient_id
                     JOIN lab_tests lt ON lr.test_id = lt.test_id
                     JOIN users u ON lr.doctor_id = u.user_id
                     WHERE lr.request_date BETWEEN '$from' AND '$to'
                     ORDER BY lr.request_date";
            $result = mysqli_query($conn, $query);
            $data['title'] = 'Laboratory Report';
            $data['headers'] = ['Request #', 'Date', 'Patient', 'Test', 'Doctor', 'Status', 'Result'];
            $data['rows'] = [];
            while($row = mysqli_fetch_assoc($result)) {
                $data['rows'][] = [
                    $row['request_number'],
                    date('d-m-Y H:i', strtotime($row['request_date'])),
                    $row['patient_number'] . ' - ' . $row['first_name'] . ' ' . $row['last_name'],
                    $row['test_name'],
                    'Dr. ' . $row['doctor_name'],
                    $row['status'],
                    $row['result_value'] ?: 'Pending'
                ];
            }
            break;
    }
    
    if ($format == 'excel') {
        // Generate Excel
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $type . '_report_' . date('Ymd') . '.xls"');
        
        echo '<html>';
        echo '<head><meta charset="UTF-8"></head>';
        echo '<body>';
        echo '<h2>' . $data['title'] . '</h2>';
        echo '<p>Generated on: ' . date('d-m-Y H:i:s') . '</p>';
        echo '<table border="1">';
        
        // Headers
        echo '<tr>';
        foreach($data['headers'] as $header) {
            echo '<th>' . $header . '</th>';
        }
        echo '</tr>';
        
        // Data
        foreach($data['rows'] as $row) {
            echo '<tr>';
            foreach($row as $cell) {
                echo '<td>' . $cell . '</td>';
            }
            echo '</tr>';
        }
        
        // Summary
        if(isset($data['summary'])) {
            echo '<tr><td colspan="' . count($data['headers']) . '">';
            foreach($data['summary'] as $summary) {
                echo '<strong>' . $summary . '</strong><br>';
            }
            echo '</td></tr>';
        }
        
        echo '</table>';
        echo '</body>';
        echo '</html>';
        exit();
        
    } elseif ($format == 'pdf') {
        // For PDF, we'll use HTML2PDF or similar
        // For now, redirect to a PDF generation service or use HTML with print styles
        header('Content-Type: text/html');
        echo '<html><head>';
        echo '<style>@media print { body { font-size: 12pt; } }</style>';
        echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">';
        echo '</head><body>';
        echo '<div class="container mt-4">';
        echo '<h2 class="text-center">' . $data['title'] . '</h2>';
        echo '<p class="text-center">Generated on: ' . date('d-m-Y H:i:s') . '</p>';
        echo '<table class="table table-bordered">';
        echo '<thead><tr>';
        foreach($data['headers'] as $header) {
            echo '<th>' . $header . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach($data['rows'] as $row) {
            echo '<tr>';
            foreach($row as $cell) {
                echo '<td>' . $cell . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table>';
        if(isset($data['summary'])) {
            foreach($data['summary'] as $summary) {
                echo '<p><strong>' . $summary . '</strong></p>';
            }
        }
        echo '</div></body></html>';
        exit();
        
    } else {
        // HTML view
        displayReportHTML($data);
    }
}

function displayReportHTML($data) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title><?php echo $data['title']; ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            @media print {
                .no-print { display: none; }
                body { font-size: 12pt; }
            }
            .report-header {
                text-align: center;
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 2px solid #333;
            }
        </style>
    </head>
    <body>
        <div class="container mt-4">
            <div class="no-print mb-3">
                <button onclick="window.print()" class="btn btn-primary">
                    <i class="fas fa-print"></i> Print
                </button>
                <button onclick="window.close()" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
            
            <div class="report-header">
                <h2><?php echo SITE_NAME; ?></h2>
                <h3><?php echo $data['title']; ?></h3>
                <p>Generated on: <?php echo date('d-m-Y H:i:s'); ?></p>
            </div>
            
            <?php if(isset($data['summary'])): ?>
                <div class="alert alert-info">
                    <?php foreach($data['summary'] as $summary): ?>
                        <p class="mb-1"><?php echo $summary; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <?php foreach($data['headers'] as $header): ?>
                            <th><?php echo $header; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data['rows'] as $row): ?>
                        <tr>
                            <?php foreach($row as $cell): ?>
                                <td><?php echo $cell; ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <div class="text-muted mt-3">
                <small>Total Records: <?php echo count($data['rows']); ?></small>
            </div>
        </div>
        
        <script src="https://kit.fontawesome.com/your-code.js"></script>
    </body>
    </html>
    <?php
    exit();
}
?>
