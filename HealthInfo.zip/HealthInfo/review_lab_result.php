<?php
require_once 'config.php';

// Check if user is logged in and is doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'doctor') {
    header("Location: login.php");
    exit();
}

$conn = getConnection();
$doctor_id = $_SESSION['user_id'];
$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$has_doctor_approval = tableHasColumn('lab_requests', 'approved_by_doctor');

if ($request_id == 0) {
    header("Location: doctor_dashboard.php");
    exit();
}

// Fetch lab request details
$query = "SELECT lr.*, 
          p.first_name, p.last_name, p.patient_number, p.date_of_birth,
          lt.test_name, lt.category, lt.normal_range, lt.unit,
          u.full_name as requested_by
          FROM lab_requests lr
          JOIN patients p ON lr.patient_id = p.patient_id
          JOIN lab_tests lt ON lr.test_id = lt.test_id
          JOIN users u ON lr.doctor_id = u.user_id
          WHERE lr.request_id = $request_id AND lr.doctor_id = $doctor_id";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Lab result not found";
    header("Location: doctor_dashboard.php");
    exit();
}

$lab = mysqli_fetch_assoc($result);
$review_notes = $lab['lab_notes'] ?? ($lab['result_notes'] ?? '');
$parsed_lab_notes = parseStructuredLabNotes($review_notes);
$display_lab_unit = normalizeLabUnit($lab['unit'] ?? '');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Lab Result</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><i class="fas fa-flask"></i> Lab Result Details</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="doctor_dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Test Information</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Patient Name:</strong> <?php echo $lab['first_name'] . ' ' . $lab['last_name']; ?></p>
                        <p><strong>Patient #:</strong> <?php echo $lab['patient_number']; ?></p>
                        <p><strong>Date of Birth:</strong> <?php echo date('d-m-Y', strtotime($lab['date_of_birth'])); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Test Name:</strong> <?php echo $lab['test_name']; ?></p>
                        <p><strong>Category:</strong> <?php echo $lab['category']; ?></p>
                        <p><strong>Requested By:</strong> Dr. <?php echo $lab['requested_by']; ?></p>
                        <p><strong>Request Date:</strong> <?php echo date('d-m-Y H:i', strtotime($lab['request_date'])); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Result</h5>
            </div>
            <div class="card-body">
                <?php if($lab['status'] == 'completed'): ?>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Result Value:</strong> 
                                <span class="badge bg-primary fs-6 p-2"><?php echo htmlspecialchars($lab['result_value']); ?><?php echo $display_lab_unit !== '' ? ' ' . htmlspecialchars($display_lab_unit) : ''; ?></span>
                            </p>
                            <p><strong>Normal Range:</strong> <?php echo $lab['normal_range'] ?: 'Not specified'; ?></p>
                            <p><strong>Result Date:</strong> <?php echo date('d-m-Y H:i', strtotime($lab['result_date'])); ?></p>
                        </div>
                        <div class="col-md-6">
                            <?php if(!empty($parsed_lab_notes['parameters'])): ?>
                                <p><strong>Detailed Parameters:</strong></p>
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Parameter</th>
                                                <th>Value</th>
                                                <th>Reference</th>
                                                <th>Flag</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($parsed_lab_notes['parameters'] as $param): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($param['name']); ?></td>
                                                    <td><?php echo htmlspecialchars($param['value'] . (!empty($param['unit']) ? ' ' . $param['unit'] : '')); ?></td>
                                                    <td><?php echo htmlspecialchars($param['reference'] ?: '-'); ?></td>
                                                    <td><?php echo htmlspecialchars($param['flag'] ?: '-'); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($parsed_lab_notes['plain_notes'])): ?>
                                <p><strong>Lab Notes:</strong></p>
                                <p><?php echo nl2br(htmlspecialchars($parsed_lab_notes['plain_notes'])); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <p class="text-muted">Test is still <?php echo $lab['status']; ?>. No results available yet.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if($has_doctor_approval && $lab['status'] == 'completed' && empty($lab['approved_by_doctor'])): ?>
        <div class="card mt-3">
            <div class="card-header bg-warning">
                <h5 class="mb-0">Action Required</h5>
            </div>
            <div class="card-body">
                <p>This result needs to be marked as reviewed.</p>
                <a href="approve_lab_result.php?id=<?php echo $request_id; ?>" 
                   class="btn btn-warning" onclick="return confirm('Mark this result as reviewed?')">
                    <i class="fas fa-check"></i> Mark as Reviewed
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
