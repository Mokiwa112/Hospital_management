<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();
$user_id = (int)($_SESSION['user_id'] ?? 0);

// Ensure core leave tables exist and have baseline leave types
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    leave_name VARCHAR(80) NOT NULL UNIQUE,
    days_per_year DECIMAL(6,2) NOT NULL DEFAULT 0,
    is_paid TINYINT(1) NOT NULL DEFAULT 1,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS leave_requests (
    leave_request_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days DECIMAL(6,2) NOT NULL DEFAULT 0,
    reason TEXT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    approved_by INT NULL,
    approval_date DATETIME NULL,
    approval_comment TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_leave_user (user_id),
    KEY idx_leave_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Annual Leave', 28, 1)");
mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Sick Leave', 14, 1)");
mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Maternity Leave', 90, 1)");
mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('Unpaid Leave', 30, 0)");
// Disable fatigue-like leave names from selection
mysqli_query($conn, "UPDATE leave_types SET is_active = 0
                     WHERE LOWER(TRIM(leave_name)) IN ('uchovu','fatigue','leave ya uchovu','chovu')");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_leave_request'])) {
    $leave_type_raw = $_POST['leave_type_id'] ?? '';
    $leave_type_id = (int)$leave_type_raw;
    $custom_leave_name = trim((string)($_POST['custom_leave_name'] ?? ''));
    $start_date = sanitize($_POST['start_date'] ?? '');
    $end_date = sanitize($_POST['end_date'] ?? '');
    $reason = sanitize($_POST['reason'] ?? '');

    if (empty($leave_type_raw) || empty($start_date) || empty($end_date)) {
        $_SESSION['error'] = "Please fill all required fields";
        redirect('leave_request.php');
    }

    // Custom leave type: create or reuse dynamically
    if ($leave_type_raw === 'custom') {
        if ($custom_leave_name === '') {
            $_SESSION['error'] = "Please enter custom request type";
            redirect('leave_request.php');
        }
        $custom_leave_name_safe = sanitize($custom_leave_name);
        $existing = mysqli_query(
            $conn,
            "SELECT leave_type_id FROM leave_types
             WHERE LOWER(leave_name) = LOWER('$custom_leave_name_safe')
             LIMIT 1"
        );
        if ($existing && mysqli_num_rows($existing) === 1) {
            $leave_type_id = (int)mysqli_fetch_assoc($existing)['leave_type_id'];
            mysqli_query($conn, "UPDATE leave_types SET is_active = 1 WHERE leave_type_id = $leave_type_id");
        } else {
            mysqli_query(
                $conn,
                "INSERT INTO leave_types (leave_name, days_per_year, is_paid, is_active)
                 VALUES ('$custom_leave_name_safe', 0, 0, 1)"
            );
            $leave_type_id = (int)mysqli_insert_id($conn);
        }
    }

    if ($leave_type_id <= 0) {
        $_SESSION['error'] = "Invalid leave type";
        redirect('leave_request.php');
    }

    if ($end_date < $start_date) {
        $_SESSION['error'] = "End date cannot be before start date";
        redirect('leave_request.php');
    }

    $days = ((strtotime($end_date) - strtotime($start_date)) / 86400) + 1;
    if ($days <= 0) {
        $_SESSION['error'] = "Invalid date range";
        redirect('leave_request.php');
    }

    $query = "INSERT INTO leave_requests (user_id, leave_type_id, start_date, end_date, total_days, reason, status)
              VALUES ($user_id, $leave_type_id, '$start_date', '$end_date', $days, '$reason', 'pending')";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Leave request submitted successfully";
        app_log_action($user_id, 'leave_request_submit');
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    redirect('leave_request.php');
}

$leave_types_rs = mysqli_query(
    $conn,
    "SELECT leave_type_id, leave_name, days_per_year, is_paid
     FROM leave_types
     WHERE is_active = 1
       AND LOWER(TRIM(leave_name)) NOT IN ('uchovu','fatigue','leave ya uchovu','chovu')
     ORDER BY leave_name"
);
$leave_types = [];
if ($leave_types_rs) {
    while ($lt = mysqli_fetch_assoc($leave_types_rs)) {
        $leave_types[] = $lt;
    }
}
$my_requests = mysqli_query(
    $conn,
    "SELECT lr.*, lt.leave_name, u.full_name AS approver_name
     FROM leave_requests lr
     JOIN leave_types lt ON lt.leave_type_id = lr.leave_type_id
     LEFT JOIN users u ON u.user_id = lr.approved_by
     WHERE lr.user_id = $user_id
     ORDER BY lr.created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Request - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-pill { padding: 5px 10px; border-radius: 16px; font-size: 12px; font-weight: 600; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid mt-4">
    <div class="row mb-3">
        <div class="col-md-8">
            <h3><i class="fas fa-calendar-minus"></i> Leave Request</h3>
            <p class="text-muted mb-0">Submit leave requests to admin for approval.</p>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-plus-circle"></i> New Request</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Leave Type *</label>
                            <select class="form-select" name="leave_type_id" id="leave_type_id" required>
                                <option value="">Select leave type</option>
                                <?php foreach ($leave_types as $lt): ?>
                                    <option value="<?php echo (int)$lt['leave_type_id']; ?>">
                                        <?php echo htmlspecialchars($lt['leave_name']); ?> (<?php echo (float)$lt['days_per_year']; ?> days/yr)
                                    </option>
                                <?php endforeach; ?>
                                <option value="custom">Custom Request</option>
                            </select>
                        </div>
                        <div class="mb-3 d-none" id="custom_leave_wrap">
                            <label class="form-label">Custom Request Type *</label>
                            <input type="text" class="form-control" name="custom_leave_name" id="custom_leave_name" placeholder="e.g. Study Leave, Family Emergency, Official Assignment">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Start Date *</label>
                                <input type="date" class="form-control" name="start_date" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">End Date *</label>
                                <input type="date" class="form-control" name="end_date" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Reason *</label>
                            <textarea class="form-control" name="reason" rows="4" required></textarea>
                        </div>
                        <button type="submit" name="submit_leave_request" class="btn btn-primary w-100">
                            <i class="fas fa-paper-plane"></i> Submit Request
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-list"></i> My Leave Requests</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Period</th>
                                    <th>Days</th>
                                    <th>Status</th>
                                    <th>Admin Feedback</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($my_requests && mysqli_num_rows($my_requests) > 0): ?>
                                    <?php while ($r = mysqli_fetch_assoc($my_requests)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($r['leave_name']); ?></td>
                                            <td><?php echo date('d-m-Y', strtotime($r['start_date'])); ?> to <?php echo date('d-m-Y', strtotime($r['end_date'])); ?></td>
                                            <td><?php echo (float)$r['total_days']; ?></td>
                                            <td><span class="status-pill status-<?php echo htmlspecialchars($r['status']); ?>"><?php echo ucfirst($r['status']); ?></span></td>
                                            <td>
                                                <?php if (!empty($r['approval_comment'])): ?>
                                                    <?php echo htmlspecialchars($r['approval_comment']); ?><br>
                                                    <small class="text-muted">By <?php echo htmlspecialchars($r['approver_name'] ?: 'Admin'); ?> on <?php echo !empty($r['approval_date']) ? date('d-m-Y H:i', strtotime($r['approval_date'])) : '-'; ?></small>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center">No leave requests yet</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    (function () {
        const leaveType = document.getElementById('leave_type_id');
        const customWrap = document.getElementById('custom_leave_wrap');
        const customInput = document.getElementById('custom_leave_name');
        if (!leaveType || !customWrap || !customInput) return;

        function toggleCustomInput() {
            const isCustom = leaveType.value === 'custom';
            customWrap.classList.toggle('d-none', !isCustom);
            customInput.required = isCustom;
            if (!isCustom) customInput.value = '';
        }

        leaveType.addEventListener('change', toggleCustomInput);
        toggleCustomInput();
    })();
</script>
</body>
</html>
