<?php
require_once 'config.php';

$conn = getConnection();
$query = "SELECT item_id as id, item_name as name, unit_price as price FROM inventory_items WHERE category = 'Medicine' AND quantity > 0";
$result = mysqli_query($conn, $query);

$medicines = [];
while($row = mysqli_fetch_assoc($result)) {
    $medicines[] = $row;
}

echo json_encode($medicines);
mysqli_close($conn);
?>