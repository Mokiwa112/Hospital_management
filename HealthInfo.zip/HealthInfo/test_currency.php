<?php
require_once 'config.php';

echo "<h2>Currency Helper Test</h2>";

echo "<h3>Testing Currency Functions:</h3>";
echo "format_currency(1000): " . format_currency(1000) . "<br>";
echo "format_currency(1500.50): " . format_currency(1500.50) . "<br>";
echo "get_currency_code(): " . get_currency_code() . "<br>";
echo "get_currency_symbol(): " . get_currency_symbol() . "<br>";
echo "format_number(1000.5): " . format_number(1000.5) . "<br>";

echo "<h3>Settings File Check:</h3>";
$settings_file = __DIR__ . '/settings.json';
if (file_exists($settings_file)) {
    echo "✅ settings.json exists<br>";
    $settings = json_decode(file_get_contents($settings_file), true);
    echo "Current currency: " . ($settings['currency'] ?? 'Not set') . "<br>";
    echo "Current symbol: " . ($settings['currency_symbol'] ?? 'Not set') . "<br>";
} else {
    echo "❌ settings.json does not exist - using defaults<br>";
}

echo "<h3>Timezone Check:</h3>";
echo "Current timezone: " . date_default_timezone_get() . "<br>";
echo "Current time: " . date('Y-m-d H:i:s') . "<br>";
?>