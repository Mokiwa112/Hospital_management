<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['admin', 'hr_admin']);

$conn = getConnection();

function ensureHrCoreSchema($conn) {
    $queries = [];
    $queries[] = "CREATE TABLE IF NOT EXISTS hr_departments (
                    department_id INT(11) NOT NULL AUTO_INCREMENT,
                    name VARCHAR(100) NOT NULL,
                    description TEXT DEFAULT NULL,
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (department_id),
                    UNIQUE KEY uniq_hr_department_name (name)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS hr_positions (
                    position_id INT(11) NOT NULL AUTO_INCREMENT,
                    department_id INT(11) DEFAULT NULL,
                    title VARCHAR(120) NOT NULL,
                    description TEXT DEFAULT NULL,
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (position_id),
                    KEY idx_hr_positions_dept (department_id)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS employee_employment_details (
                    emp_detail_id INT(11) NOT NULL AUTO_INCREMENT,
                    user_id INT(11) NOT NULL,
                    department_id INT(11) DEFAULT NULL,
                    position_id INT(11) DEFAULT NULL,
                    hire_date DATE DEFAULT NULL,
                    employment_type ENUM('full_time','part_time','contract','intern') NOT NULL DEFAULT 'full_time',
                    status ENUM('active','inactive','terminated') NOT NULL DEFAULT 'active',
                    deactivation_date DATE DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (emp_detail_id),
                    UNIQUE KEY uniq_emp_user (user_id),
                    KEY idx_emp_dept (department_id),
                    KEY idx_emp_position (position_id)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS leave_types (
                    leave_type_id INT(11) NOT NULL AUTO_INCREMENT,
                    leave_name VARCHAR(80) NOT NULL,
                    days_per_year DECIMAL(6,2) NOT NULL DEFAULT 0.00,
                    is_paid TINYINT(1) NOT NULL DEFAULT 1,
                    is_active TINYINT(1) NOT NULL DEFAULT 1,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (leave_type_id),
                    UNIQUE KEY uniq_leave_name (leave_name)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS leave_requests (
                    leave_request_id INT(11) NOT NULL AUTO_INCREMENT,
                    user_id INT(11) NOT NULL,
                    leave_type_id INT(11) NOT NULL,
                    start_date DATE NOT NULL,
                    end_date DATE NOT NULL,
                    total_days DECIMAL(6,2) NOT NULL DEFAULT 0.00,
                    reason TEXT DEFAULT NULL,
                    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                    approved_by INT(11) DEFAULT NULL,
                    approval_date DATETIME DEFAULT NULL,
                    approval_comment TEXT DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (leave_request_id),
                    KEY idx_leave_user (user_id),
                    KEY idx_leave_status (status)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS performance_reviews (
                    review_id INT(11) NOT NULL AUTO_INCREMENT,
                    user_id INT(11) NOT NULL,
                    period_start DATE NOT NULL,
                    period_end DATE NOT NULL,
                    score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                    comments TEXT DEFAULT NULL,
                    supervisor_id INT(11) DEFAULT NULL,
                    evaluation_date DATE DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (review_id),
                    KEY idx_review_user (user_id)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS job_postings (
                    job_posting_id INT(11) NOT NULL AUTO_INCREMENT,
                    title VARCHAR(150) NOT NULL,
                    department_id INT(11) DEFAULT NULL,
                    description TEXT DEFAULT NULL,
                    status ENUM('open','closed') NOT NULL DEFAULT 'open',
                    posted_date DATE NOT NULL,
                    closed_date DATE DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (job_posting_id),
                    KEY idx_job_status (status)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS applicants (
                    applicant_id INT(11) NOT NULL AUTO_INCREMENT,
                    job_posting_id INT(11) DEFAULT NULL,
                    full_name VARCHAR(150) NOT NULL,
                    email VARCHAR(120) DEFAULT NULL,
                    phone VARCHAR(30) DEFAULT NULL,
                    resume_path VARCHAR(300) DEFAULT NULL,
                    status ENUM('applied','shortlisted','interviewed','offered','hired','rejected') NOT NULL DEFAULT 'applied',
                    applied_date DATE NOT NULL,
                    notes TEXT DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (applicant_id),
                    KEY idx_applicant_status (status)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    $queries[] = "CREATE TABLE IF NOT EXISTS disciplinary_records (
                    disciplinary_id INT(11) NOT NULL AUTO_INCREMENT,
                    user_id INT(11) NOT NULL,
                    action_type VARCHAR(120) NOT NULL,
                    action_date DATE NOT NULL,
                    description TEXT DEFAULT NULL,
                    compliance_notes TEXT DEFAULT NULL,
                    confidential_remarks TEXT DEFAULT NULL,
                    recorded_by INT(11) DEFAULT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (disciplinary_id),
                    KEY idx_disciplinary_user (user_id)
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    foreach ($queries as $q) {
        mysqli_query($conn, $q);
    }

    // seed leave types
    $seed = [
        ["Annual Leave", 28, 1],
        ["Sick Leave", 14, 1],
        ["Maternity Leave", 90, 1],
        ["Unpaid Leave", 30, 0]
    ];
    foreach ($seed as $s) {
        $name = mysqli_real_escape_string($conn, $s[0]);
        mysqli_query($conn, "INSERT IGNORE INTO leave_types (leave_name, days_per_year, is_paid) VALUES ('$name', {$s[1]}, {$s[2]})");
    }
}

ensureHrCoreSchema($conn);

$stats = [];
$stats['employees'] = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM users WHERE user_type <> 'admin'"))['c'] ?? 0);
$stats['departments'] = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM hr_departments WHERE is_active=1"))['c'] ?? 0);
$stats['open_leaves'] = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM leave_requests WHERE status='pending'"))['c'] ?? 0);
$stats['open_jobs'] = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM job_postings WHERE status='open'"))['c'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .dash-head{background:linear-gradient(135deg,#198754,#0f5132);color:#fff;padding:24px;border-radius:14px}
        .mod-card{border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,.08);height:100%}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid mt-4">
    <div class="dash-head mb-4">
        <h3 class="mb-1"><i class="fas fa-users-cog"></i> HR Admin Dashboard</h3>
        <p class="mb-0">Core HR operations separated from accounting/finance modules</p>
    </div>

    <div class="row mb-4">
        <div class="col-md-3"><div class="card bg-primary text-white"><div class="card-body"><div>Employees</div><h2><?php echo $stats['employees']; ?></h2></div></div></div>
        <div class="col-md-3"><div class="card bg-info text-white"><div class="card-body"><div>Departments</div><h2><?php echo $stats['departments']; ?></h2></div></div></div>
        <div class="col-md-3"><div class="card bg-warning"><div class="card-body"><div>Pending Leave</div><h2><?php echo $stats['open_leaves']; ?></h2></div></div></div>
        <div class="col-md-3"><div class="card bg-dark text-white"><div class="card-body"><div>Open Jobs</div><h2><?php echo $stats['open_jobs']; ?></h2></div></div></div>
    </div>

    <div class="row g-3">
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=employees"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-id-badge text-primary"></i> Employee Management</h5><p class="text-muted mb-0">Personal details, employment details, documents, activation/deactivation</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=org"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-sitemap text-success"></i> Department & Position</h5><p class="text-muted mb-0">Create and assign departments/positions</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=attendance"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-user-clock text-warning"></i> Attendance</h5><p class="text-muted mb-0">Daily attendance and monthly summaries</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=leave"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-calendar-minus text-danger"></i> Leave Management</h5><p class="text-muted mb-0">Leave types, requests, approvals and balances</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="human_resource.php"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-money-check-dollar text-secondary"></i> Payroll Data Support</h5><p class="text-muted mb-0">Salary structure + payroll-ready records (HR side)</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=performance"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-chart-line text-info"></i> Performance</h5><p class="text-muted mb-0">Appraisals, scores, comments, supervisor evaluation</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=recruitment"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-user-plus text-primary"></i> Recruitment & Onboarding</h5><p class="text-muted mb-0">Job postings, applicants, interviews, convert to employee</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=compliance"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-shield-halved text-dark"></i> Discipline & Compliance</h5><p class="text-muted mb-0">Warnings, disciplinary actions, confidential remarks</p></div></div></a></div>
        <div class="col-md-4"><a class="text-decoration-none" href="hr_core.php?tab=reports"><div class="card mod-card"><div class="card-body"><h5><i class="fas fa-file-lines text-success"></i> HR Reports</h5><p class="text-muted mb-0">Employee, attendance, leave and department-wise reports</p></div></div></a></div>
    </div>
</div>
</body>
</html>
