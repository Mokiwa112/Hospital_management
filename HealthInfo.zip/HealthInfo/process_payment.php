<?php
require_once 'config.php';
requireStaffLogin();

$conn = getConnection();

function ensureBillingPaymentsTable($conn) {
    static $ready = false;
    if ($ready) {
        return;
    }
    $sql = "CREATE TABLE IF NOT EXISTS billing_payments (
                payment_id INT AUTO_INCREMENT PRIMARY KEY,
                bill_id INT NOT NULL,
                amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
                payment_method VARCHAR(30) NOT NULL,
                payment_reference VARCHAR(120) NULL,
                payment_notes TEXT NULL,
                paid_by INT NULL,
                paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_bill_id (bill_id),
                INDEX idx_paid_at (paid_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    mysqli_query($conn, $sql);
    $ready = true;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    ensureBillingPaymentsTable($conn);

    $bill_id = (int)($_POST['bill_id'] ?? 0);
    $payment_method = sanitize($_POST['payment_method'] ?? '');
    $amount_paid_raw = trim((string)($_POST['amount_paid'] ?? ''));
    $payment_reference = sanitize($_POST['payment_reference'] ?? '');
    $payment_notes = sanitize($_POST['payment_notes'] ?? '');
    $paid_by = (int)($_SESSION['user_id'] ?? 0);
    $allowed_methods = ['cash', 'card', 'insurance', 'bank_transfer'];

    if ($bill_id <= 0) {
        $_SESSION['error'] = "Invalid bill selected";
        header("Location: billing.php");
        exit();
    }
    if (!in_array($payment_method, $allowed_methods, true)) {
        $_SESSION['error'] = "Invalid payment method";
        header("Location: view_bill.php?id=$bill_id");
        exit();
    }

    if ($amount_paid_raw === '' || !is_numeric($amount_paid_raw)) {
        $_SESSION['error'] = "Enter a valid payment amount";
        header("Location: view_bill.php?id=$bill_id");
        exit();
    }

    $amount_paid = (float)$amount_paid_raw;

    if ($amount_paid < 0) {
        $_SESSION['error'] = "Payment amount cannot be negative";
        header("Location: view_bill.php?id=$bill_id");
        exit();
    }

    mysqli_begin_transaction($conn);
    try {
        // Lock bill row while calculating and updating payments
        $bill_query = "SELECT * FROM billing WHERE bill_id = $bill_id FOR UPDATE";
        $bill_result = mysqli_query($conn, $bill_query);
        $bill = $bill_result ? mysqli_fetch_assoc($bill_result) : null;

        if (!$bill) {
            throw new Exception("Bill not found");
        }

        $bill_total = max(0.0, (float)($bill['net_amount'] ?? 0));
        $paid_query = mysqli_query($conn, "SELECT COALESCE(SUM(amount_paid), 0) AS total_paid FROM billing_payments WHERE bill_id = $bill_id");
        $total_paid_before = $paid_query ? (float)(mysqli_fetch_assoc($paid_query)['total_paid'] ?? 0) : 0.0;

        // Backward compatibility for old bills marked paid before payment ledger existed
        if ($total_paid_before <= 0 && ($bill['payment_status'] ?? '') === 'paid') {
            $total_paid_before = $bill_total;
        }

        $remaining_before = max(0.0, $bill_total - $total_paid_before);
        if ($remaining_before <= 0) {
            throw new Exception("This bill is already fully paid");
        }
        if ($amount_paid > $remaining_before) {
            throw new Exception("Payment amount cannot exceed remaining balance (" . format_currency($remaining_before) . ")");
        }

        $insert_payment = "INSERT INTO billing_payments (bill_id, amount_paid, payment_method, payment_reference, payment_notes, paid_by, paid_at)
                           VALUES ($bill_id, $amount_paid, '$payment_method', " .
                           ($payment_reference !== '' ? "'$payment_reference'" : "NULL") . ", " .
                           ($payment_notes !== '' ? "'$payment_notes'" : "NULL") . ", " .
                           ($paid_by > 0 ? $paid_by : "NULL") . ", NOW())";
        if (!mysqli_query($conn, $insert_payment)) {
            throw new Exception("Failed to record payment: " . mysqli_error($conn));
        }

        $paid_after_query = mysqli_query($conn, "SELECT COALESCE(SUM(amount_paid), 0) AS total_paid FROM billing_payments WHERE bill_id = $bill_id");
        $total_paid_after = $paid_after_query ? (float)(mysqli_fetch_assoc($paid_after_query)['total_paid'] ?? 0) : 0.0;
        $remaining_after = max(0.0, $bill_total - $total_paid_after);

        $payment_status = 'pending';
        if ($total_paid_after >= $bill_total && $bill_total > 0) {
            $payment_status = 'paid';
        } elseif ($total_paid_after > 0) {
            $payment_status = 'partial';
        }

        $update_query = "UPDATE billing SET
                         payment_status = '$payment_status',
                         payment_method = '$payment_method'
                         WHERE bill_id = $bill_id";
        if (!mysqli_query($conn, $update_query)) {
            throw new Exception("Failed to update bill status: " . mysqli_error($conn));
        }

        if (!empty($bill['insurance_claim_id'])) {
            $claim_id = (int)$bill['insurance_claim_id'];
            mysqli_query($conn, "UPDATE insurance_claims SET status = 'processing' WHERE claim_id = $claim_id");
        }

        mysqli_commit($conn);
        $_SESSION['success'] = "Payment recorded successfully. Remaining balance: " . format_currency($remaining_after);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = $e->getMessage();
    }
    
    header("Location: view_bill.php?id=$bill_id");
    exit();
}
?>
