<?php
require_once 'config.php';
requireStaffLogin();
requireAnyRole(['doctor', 'nurse', 'receptionist']);

$conn = getConnection();
$user_type = $_SESSION['user_type'] ?? '';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$type_filter = isset($_GET['type']) ? sanitize($_GET['type']) : '';

$where = [];
if ($search) {
    $where[] = "(p.first_name LIKE '%$search%' OR p.last_name LIKE '%$search%' OR p.patient_number LIKE '%$search%' OR p.phone LIKE '%$search%')";
}
if ($type_filter) {
    $where[] = "p.patient_type = '$type_filter'";
}
$where_clause = !empty($where) ? "WHERE " . implode(' AND ', $where) : '';

$query = "SELECT p.*,
          (SELECT COUNT(*) FROM appointments a WHERE a.patient_id = p.patient_id) AS appointment_count,
          (SELECT COUNT(*) FROM lab_requests lr WHERE lr.patient_id = p.patient_id) AS lab_count,
          (SELECT COUNT(*) FROM billing b WHERE b.patient_id = p.patient_id) AS bill_count
          FROM patients p
          $where_clause
          ORDER BY p.registration_date DESC";
$patients = mysqli_query($conn, $query);

$stats = mysqli_query($conn, "SELECT
    COUNT(*) AS total,
    SUM(CASE WHEN patient_type = 'inpatient' THEN 1 ELSE 0 END) AS inpatient,
    SUM(CASE WHEN patient_type = 'outpatient' THEN 1 ELSE 0 END) AS outpatient
    FROM patients");
$patient_stats = mysqli_fetch_assoc($stats);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients Management - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container-fluid mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-users"></i> Patients Management</h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="register_patient.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Register New Patient
                </a>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5>Total Patients</h5>
                        <h2><?php echo (int)$patient_stats['total']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5>Inpatients</h5>
                        <h2><?php echo (int)$patient_stats['inpatient']; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5>Outpatients</h5>
                        <h2><?php echo (int)$patient_stats['outpatient']; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row">
                    <div class="col-md-5">
                        <input type="text" class="form-control" name="search" placeholder="Search by name, ID, or phone..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-3">
                        <select class="form-control" name="type">
                            <option value="">All Patients</option>
                            <option value="inpatient" <?php echo $type_filter === 'inpatient' ? 'selected' : ''; ?>>Inpatients Only</option>
                            <option value="outpatient" <?php echo $type_filter === 'outpatient' ? 'selected' : ''; ?>>Outpatients Only</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Search</button>
                    </div>
                    <div class="col-md-2">
                        <a href="patients.php" class="btn btn-secondary w-100">Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">Patient Directory</h5>
            </div>
            <div class="card-body">
                <table id="patientsTable" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Patient #</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Type</th>
                            <th>Registration Date</th>
                            <th>Activity</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($patients): ?>
                            <?php while($patient = mysqli_fetch_assoc($patients)): ?>
                                <?php
                                $is_new = strtotime((string)$patient['registration_date']) >= strtotime('-7 days');
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($patient['patient_number']); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></strong>
                                        <?php if($is_new): ?>
                                            <span class="badge bg-danger ms-1">New</span>
                                        <?php endif; ?>
                                        <br>
                                        <small>DOB: <?php echo date('d-m-Y', strtotime($patient['date_of_birth'])); ?></small>
                                    </td>
                                    <td>
                                        <i class="fas fa-phone"></i> <?php echo htmlspecialchars($patient['phone']); ?><br>
                                        <small><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($patient['email'] ?: 'N/A'); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $patient['patient_type'] === 'inpatient' ? 'primary' : 'success'; ?>">
                                            <?php echo ucfirst($patient['patient_type']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d-m-Y', strtotime($patient['registration_date'])); ?></td>
                                    <td>
                                        <span class="badge bg-info" title="Appointments"><i class="fas fa-calendar-check"></i> <?php echo (int)$patient['appointment_count']; ?></span>
                                        <span class="badge bg-warning text-dark" title="Lab Tests"><i class="fas fa-flask"></i> <?php echo (int)$patient['lab_count']; ?></span>
                                        <span class="badge bg-success" title="Bills"><i class="fas fa-file-invoice"></i> <?php echo (int)$patient['bill_count']; ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="view_patient.php?id=<?php echo (int)$patient['patient_id']; ?>" class="btn btn-info" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit_patient.php?id=<?php echo (int)$patient['patient_id']; ?>" class="btn btn-warning" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="schedule_appointment.php?patient_id=<?php echo (int)$patient['patient_id']; ?>" class="btn btn-primary" title="New Appointment">
                                                <i class="fas fa-calendar-plus"></i>
                                            </a>
                                            <?php if ($user_type === 'doctor'): ?>
                                                <a href="create_prescription.php?patient_id=<?php echo (int)$patient['patient_id']; ?>" class="btn btn-secondary" title="Write Prescription">
                                                    <i class="fas fa-prescription"></i>
                                                </a>
                                                <a href="lab_request.php?patient_id=<?php echo (int)$patient['patient_id']; ?>" class="btn btn-success" title="Request Lab Test">
                                                    <i class="fas fa-flask"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#patientsTable').DataTable({
                pageLength: 25,
                order: [[4, 'desc']]
            });
        });
    </script>
</body>
</html>
