<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();
$admin_id = (int)($_SESSION['user_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_leave'])) {
    $leave_request_id = (int)($_POST['leave_request_id'] ?? 0);
    $decision = sanitize($_POST['decision'] ?? '');
    $comment = sanitize($_POST['approval_comment'] ?? '');

    if (!in_array($decision, ['approved', 'rejected'], true)) {
        $_SESSION['error'] = "Invalid decision";
        redirect('leave_approvals.php');
    }

    $query = "UPDATE leave_requests
              SET status = '$decision',
                  approved_by = $admin_id,
                  approval_date = NOW(),
                  approval_comment = '$comment'
              WHERE leave_request_id = $leave_request_id";

    if (mysqli_query($conn, $query)) {
        $_SESSION['success'] = "Leave request updated";
        app_log_action($admin_id, 'leave_request_' . $decision);
    } else {
        $_SESSION['error'] = "Error: " . mysqli_error($conn);
    }
    redirect('leave_approvals.php');
}

$requests = mysqli_query(
    $conn,
    "SELECT lr.*, lt.leave_name, u.full_name, u.employee_id, u.department, a.full_name AS approver_name
     FROM leave_requests lr
     JOIN leave_types lt ON lt.leave_type_id = lr.leave_type_id
     JOIN users u ON u.user_id = lr.user_id
     LEFT JOIN users a ON a.user_id = lr.approved_by
     ORDER BY (lr.status='pending') DESC, lr.created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Approvals - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .status-pill { padding: 5px 10px; border-radius: 16px; font-size: 12px; font-weight: 600; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container-fluid mt-4">
    <div class="row mb-3">
        <div class="col-md-8">
            <h3><i class="fas fa-user-check"></i> Leave Approvals</h3>
            <p class="text-muted mb-0">Review and approve/reject staff leave requests.</p>
        </div>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-list"></i> All Leave Requests</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Type</th>
                            <th>Period</th>
                            <th>Days</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($requests && mysqli_num_rows($requests) > 0): ?>
                            <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($r['full_name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($r['employee_id'] ?: 'N/A'); ?> | <?php echo htmlspecialchars($r['department'] ?: 'N/A'); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($r['leave_name']); ?></td>
                                    <td><?php echo date('d-m-Y', strtotime($r['start_date'])); ?> to <?php echo date('d-m-Y', strtotime($r['end_date'])); ?></td>
                                    <td><?php echo (float)$r['total_days']; ?></td>
                                    <td><?php echo nl2br(htmlspecialchars($r['reason'] ?: '-')); ?></td>
                                    <td>
                                        <span class="status-pill status-<?php echo htmlspecialchars($r['status']); ?>"><?php echo ucfirst($r['status']); ?></span>
                                        <?php if (!empty($r['approval_comment'])): ?>
                                            <br><small><?php echo htmlspecialchars($r['approval_comment']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($r['status'] === 'pending'): ?>
                                            <form method="POST" class="mb-2">
                                                <input type="hidden" name="leave_request_id" value="<?php echo (int)$r['leave_request_id']; ?>">
                                                <textarea class="form-control form-control-sm mb-2" name="approval_comment" rows="2" placeholder="Optional comment"></textarea>
                                                <div class="d-flex gap-1">
                                                    <button type="submit" name="review_leave" value="1" class="btn btn-sm btn-success" onclick="this.form.decision.value='approved'">Approve</button>
                                                    <button type="submit" name="review_leave" value="1" class="btn btn-sm btn-danger" onclick="this.form.decision.value='rejected'">Reject</button>
                                                </div>
                                                <input type="hidden" name="decision" value="">
                                            </form>
                                        <?php else: ?>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($r['approver_name'] ?: 'Admin'); ?><br>
                                                <?php echo !empty($r['approval_date']) ? date('d-m-Y H:i', strtotime($r['approval_date'])) : '-'; ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center">No leave requests found</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
