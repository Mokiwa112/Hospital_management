<?php
require_once 'config.php';
requireRole('admin');

$conn = getConnection();
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch worker details
$query = "SELECT * FROM users WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    $_SESSION['error'] = "Worker not found";
    header("Location: workers.php");
    exit();
}

$worker = mysqli_fetch_assoc($result);

// Fetch attendance history
$attendance = mysqli_query($conn,
    "SELECT * FROM attendance 
     WHERE user_id = $user_id 
     ORDER BY date DESC 
     LIMIT 30"
);

// Fetch activity log
$activity = mysqli_query($conn,
    "SELECT * FROM user_logs 
     WHERE user_id = $user_id 
     ORDER BY log_time DESC 
     LIMIT 20"
);

// Calculate statistics
$stats_query = "SELECT 
    COUNT(*) as total_days,
    SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
    SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
    SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late,
    SUM(CASE WHEN approval_status = 'pending' THEN 1 ELSE 0 END) as pending_approval,
    SUM(overtime_hours) as total_overtime
    FROM attendance 
    WHERE user_id = $user_id";

$stats_result = mysqli_query($conn, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Details - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .info-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .stat-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            border-left: 4px solid #007bff;
        }
        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        .stat-label {
            color: #666;
            font-size: 13px;
        }
        .activity-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .role-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .role-admin { background: #dc3545; color: white; }
        .role-doctor { background: #28a745; color: white; }
        .role-nurse { background: #17a2b8; color: white; }
        .role-receptionist { background: #ffc107; color: #333; }
        .role-lab_tech { background: #007bff; color: white; }
        .role-pharmacist { background: #6c757d; color: white; }
        .role-accountant { background: #6610f2; color: white; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-4">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="row">
                <div class="col-md-8">
                    <h2><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($worker['full_name']); ?></h2>
                    <p class="mb-1">
                        <i class="fas fa-id-card"></i> Employee ID: <?php echo $worker['employee_id']; ?> |
                        <i class="fas fa-briefcase"></i> Department: <?php echo $worker['department'] ?: 'N/A'; ?>
                    </p>
                    <p class="mb-0">
                        <i class="fas fa-envelope"></i> <?php echo $worker['email']; ?> |
                        <i class="fas fa-phone"></i> <?php echo $worker['phone']; ?>
                    </p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="role-badge role-<?php echo $worker['user_type']; ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $worker['user_type'])); ?>
                    </span>
                    <br>
                    <a href="edit_worker.php?id=<?php echo $user_id; ?>" class="btn btn-light mt-2">
                        <i class="fas fa-edit"></i> Edit Worker
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-md-2">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_days'] ?? 0; ?></div>
                    <div class="stat-label">Total Days</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card" style="border-left-color: #28a745;">
                    <div class="stat-number"><?php echo $stats['present'] ?? 0; ?></div>
                    <div class="stat-label">Present</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card" style="border-left-color: #ffc107;">
                    <div class="stat-number"><?php echo $stats['late'] ?? 0; ?></div>
                    <div class="stat-label">Late</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card" style="border-left-color: #dc3545;">
                    <div class="stat-number"><?php echo $stats['absent'] ?? 0; ?></div>
                    <div class="stat-label">Absent</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card" style="border-left-color: #ffc107;">
                    <div class="stat-number"><?php echo $stats['pending_approval'] ?? 0; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stat-card" style="border-left-color: #17a2b8;">
                    <div class="stat-number"><?php echo round($stats['total_overtime'] ?? 0, 2); ?></div>
                    <div class="stat-label">Overtime (hrs)</div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- Personal Information -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-info-circle"></i> Personal Information</h5>
                    
                    <p><strong>Username:</strong> <?php echo $worker['username']; ?></p>
                    <p><strong>Full Name:</strong> <?php echo htmlspecialchars($worker['full_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo $worker['email']; ?></p>
                    <p><strong>Phone:</strong> <?php echo $worker['phone']; ?></p>
                    <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($worker['address'] ?: 'N/A')); ?></p>
                    <p><strong>Department:</strong> <?php echo $worker['department'] ?: 'N/A'; ?></p>
                    <p><strong>User Type:</strong> 
                        <span class="role-badge role-<?php echo $worker['user_type']; ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $worker['user_type'])); ?>
                        </span>
                    </p>
                    <p><strong>Employee ID:</strong> <?php echo $worker['employee_id']; ?></p>
                    <p><strong>Member Since:</strong> <?php echo date('d M Y', strtotime($worker['created_at'] ?? 'now')); ?></p>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-history"></i> Recent Activity</h5>
                    
                    <?php if($activity && mysqli_num_rows($activity) > 0): ?>
                        <?php while($act = mysqli_fetch_assoc($activity)): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between">
                                    <span>
                                        <i class="fas fa-<?php echo $act['action'] == 'login' ? 'sign-in-alt text-success' : 'circle text-info'; ?> me-2"></i>
                                        <?php echo ucfirst($act['action']); ?>
                                    </span>
                                    <small class="text-muted">
                                        <?php echo date('d M H:i', strtotime($act['log_time'])); ?>
                                    </small>
                                </div>
                                <small class="text-muted">IP: <?php echo $act['ip_address']; ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted">No recent activity</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Recent Attendance -->
            <div class="col-md-4">
                <div class="info-card">
                    <h5 class="mb-3"><i class="fas fa-clock"></i> Recent Attendance</h5>
                    
                    <?php if($attendance && mysqli_num_rows($attendance) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>In</th>
                                        <th>Out</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($att = mysqli_fetch_assoc($attendance)): ?>
                                        <tr>
                                            <td><?php echo date('d M', strtotime($att['date'])); ?></td>
                                            <td><?php echo $att['check_in'] ? date('H:i', strtotime($att['check_in'])) : '-'; ?></td>
                                            <td><?php echo $att['check_out'] ? date('H:i', strtotime($att['check_out'])) : '-'; ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $att['status'] == 'present' ? 'success' : 
                                                        ($att['status'] == 'late' ? 'warning' : 
                                                        ($att['status'] == 'absent' ? 'danger' : 'secondary')); 
                                                ?>">
                                                    <?php echo ucfirst($att['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center mt-2">
                            <a href="attendance_history.php?employee=<?php echo $user_id; ?>" class="btn btn-sm btn-primary">
                                View Full History
                            </a>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No attendance records</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>