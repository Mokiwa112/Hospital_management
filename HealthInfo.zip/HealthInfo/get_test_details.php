<?php
require_once 'config.php';

$conn = getConnection();

if (isset($_POST['request_id'])) {
    $request_id = (int)sanitize($_POST['request_id']);
    $query = "SELECT lt.test_name, lt.normal_range, lt.unit,
              CONCAT(p.first_name, ' ', p.last_name) AS patient_name
              FROM lab_requests lr
              JOIN lab_tests lt ON lr.test_id = lt.test_id
              JOIN patients p ON lr.patient_id = p.patient_id
              WHERE lr.request_id = $request_id";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode($row);
    } else {
        echo json_encode([]);
    }
    exit();
}

if (isset($_POST['test_id'])) {
    $test_id = (int)sanitize($_POST['test_id']);
    $query = "SELECT * FROM lab_tests WHERE test_id = $test_id";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode($row);
    } else {
        echo json_encode([]);
    }
    exit();
}

echo json_encode([]);
?>
